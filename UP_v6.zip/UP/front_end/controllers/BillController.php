<?php
class BillController extends Controller
{
	public function actionIndex()
	{
		$bill_id = isset($_GET['bill_id']) ? intval($_GET['bill_id']) : 0;
		//Hien thi gio hang
		list($camera, $access, $colors, $access_free) = Bill::getProductBill($bill_id);
		$bill_info = Bill::getBillById($bill_id);
		if($bill_info['status']=='active')
		{
			$this->redirect('home/index');
			exit();
		}
		$this->pageTitle = 'Hóa đơn';
		$this->metaKeywords = 'hoa don';
		$this->metaDescription = 'Hóa đơn';
		$this->renderPartial('index', 
				array('camera'=>$camera, 'access'=>$access, 'colors'=>$colors, 'access_free'=>$access_free,
					  'bill_info'=>$bill_info, 'bill_id'=>$bill_id
		));
	}
	
}
?>