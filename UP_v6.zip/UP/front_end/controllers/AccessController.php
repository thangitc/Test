﻿<?php
class AccessController extends Controller
{
	public function actionIndex()
	{
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$hot_news = News::getLatestNews(5);
		$this->pageTitle = !empty($cat_info ) && $cat_info['meta_title']!='' ? $cat_info['meta_title'] : $cat_info['title'];
		$this->metaKeywords = !empty($cat_info ) && $cat_info['meta_keyword']!='' ? $cat_info['meta_keyword'] : $cat_info['title'];
		$this->metaDescription = !empty($cat_info ) && $cat_info['meta_description']!='' ? $cat_info['meta_description'] : $cat_info['title'];
		$this->render('index', 
				array('cat_info'=>$cat_info, 'cats'=>$cats, 'cat_id'=>$cat_id,
					  'hot_news'=>$hot_news
		));
	}
	
	public function actionCat()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=24;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
		
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
		$alias = isset($_GET['alias']) ? $_GET['alias'] : '';
		
		$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : '';
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$sub_id = isset($cat_info['sub_id']) ? $cat_info['sub_id']:$cat_id;
		list($products, $paging, $total_product, $list_total_brand, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5) = Access::getAccessByCat($cat_id, $sub_id, $alias, $orderby, $page, $num_per_page);
			
		$h1 = '';
		if(!empty($cat_info)) $h1.=$cat_info['title'];
		
		//Brand
		$brands = BBrand::getAllBrand();
		//Model
		$models = BModel::getModelByCat($cat_id, $sub_id);
		//Seo
		$metaTitle = $h1;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = isset($cat_info['meta_description']) && $cat_info['meta_description']!='' ? $cat_info['meta_description'] : $h1;
		$metaDes .= $tag_page;
		$metaKeyword = isset($cat_info['meta_keyword']) && $cat_info['meta_keyword']!='' ? $cat_info['meta_keyword'] : $metaTitleKD;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		$this->linkCanoncical = Url::createUrl('access/cat', array('cat_id'=>$cat_id, 'alias'=>$cat_info['alias']));
		
		$render = 'cat';
		
		$this->render($render, 
				array('products'=>$products, 'paging'=>$paging, 'total_product'=>$total_product, 'page'=>$page, 'num_per_page'=>$num_per_page,
					  'cats'=>$cats,'cat_info'=>$cat_info, 
					  'alias' => $alias, 'cat_id'=>$cat_id, 'orderby'=>$orderby,
					  'h1'=>$h1,
					  'page'=>$page, 'num_pert_page'=>$num_per_page,
					  'brands'=>$brands, 'models'=>$models,
					  'list_total_brand'=>$list_total_brand, 'total_price_1'=>$total_price_1, 'total_price_2'=>$total_price_2, 'total_price_3'=>$total_price_3, 'total_price_4'=>$total_price_4, 'total_price_5'=>$total_price_5
		));
	}
	
	public function actionDetail()
	{
		$access_id = isset($_GET['access_id']) ? intval($_GET['access_id']) : 0;
		$color_id = isset($_GET['color_id']) ? intval($_GET['color_id']) : 0;
		$detail = Access::getAccessById($access_id);
		
		if(!empty($detail))
		{
			//Color
			$access_color = AccessColor::getAccessColor($access_id);
			//Neu phu kien nhieu mau sac thi redirect mac dinh ve 1 mau nao do
			if(!empty($access_color) && $color_id==0)
			{
				$color_id = isset($access_color[0]['id']) ? intval($access_color[0]['id']) : 0;
				$link_redirect = Url::createUrl('access/detail', array('access_id'=>$access_id, 'alias'=>$detail['alias'], 'color_id'=>$color_id));
				$this->redirect($link_redirect);
				exit();
			}
			
			$color_info = AccessColor::getAccessColorById($color_id);
			if(!empty($color_info))
				$detail['color'] = $color_info['color'];
			else
				$detail['color'] = '';
			$cat_id = $detail['cat_id'];
			$cats = $this->array_category;
			$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
			
			//Tin khac cung danh muc
			$other = Access::getOtherByCat($access_id, $cat_id);
			
			//Picture
			$access_pic = AccessPic::getPicByAccessId($access_id);
			$access_color_pic = array();
			if(!empty($color_info))
			{
				$access_color_pic = AccessColorPic::getPicAccessColor($color_id);
			}
			//Cap nhat hit
			Access::updateHit($access_id);
			
			
			//Brand
			$brand_info = BBrand::getBrandById($detail['brand_id']);
			//SEO
			$metaTitle = isset($detail['meta_title']) && $detail['meta_title']!='' ? $detail['meta_title'] : $detail['title'];
			$metaTitleKD = Common::change($metaTitle);
			$metaDes = isset($detail['meta_description']) && $detail['meta_description']!='' ? $detail['meta_description'] : $detail['title'].':'.trim(strip_tags($detail['introtext']));
			$metaKeyword = isset($detail['meta_keyword']) && $detail['meta_keyword']!='' ? $detail['meta_keyword'] : $metaTitleKD;
			$metaTitleKD = Common::change($metaTitle);
			$this->pageTitle = $metaTitle;
			$this->metaKeywords = $metaKeyword;
			$this->metaDescription = $metaDes;
			if(empty($color_info))
				$this->linkCanoncical = Yii::app()->params['baseUrl'].Url::createUrl('access/detail', array('access_id'=>$detail['id'], 'alias'=>$detail['alias']));
			else
				$this->linkCanoncical = Yii::app()->params['baseUrl'].Url::createUrl('access/detail', array('access_id'=>$detail['id'], 'alias'=>$detail['alias'], 'color_id'=>$color_id));
			if(!empty($cat_info))
			{
				$this->linkRss = '<link rel="alternate" title="RSS - '.$cat_info['title'].'"  href="'.Url::createUrl('access/rssCat', array('cat_id'=>$cat_info['id'], 'alias'=>$cat_info['alias'])).'" type="application/rss+xml" />';
			}
			$this->srcImg = Common::getImage($detail['picture'], 'access', '');
			
			$render = 'detail';
			
			$this->render($render,
					array('detail'=>$detail, 'cat_info'=>$cat_info, 'other'=>$other, 
						  'access_pic'=>$access_pic,'cats'=>$cats,
						  'access_color'=>$access_color, 'brand_info'=>$brand_info, 'color_info'=>$color_info,
						  'access_color_pic'=>$access_color_pic
			));
		}
		else
		{
			$this->redirect(Url::createUrl('home/index'));
			exit();
		}
	}
	
	public function actionSearch()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
				
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;		
		$min_price = isset($_GET['min_price']) ? $_GET['min_price'] : 0;
		$max_price = isset($_GET['max_price']) ? $_GET['max_price'] : 0;
		$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : '';
		$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$list_brand_id = '';
		$list_276_id = '';
		$list_273_1_id = '';
		$list_273_2_id = '';
		$list_price = array();
		$s = isset($_GET['s']) ? $_GET['s'] : '';
		$list_filter = explode(' ',$s);
		if(!empty($list_filter))
		foreach($list_filter as $value)
		{
			//Thuong hieu
			if(is_numeric($value) && preg_match('/3579/si', $value))
			{
				$list_brand_id.=str_replace('3579','',$value).',';
			}
			//Kich thuoc
			if(is_numeric($value) && preg_match('/1235/si', $value))
			{
				$list_276_id.=str_replace('1235','',$value).',';
			}
			//Duong luong
			if(is_numeric($value) && preg_match('/3456/si', $value))
			{
				$list_273_1_id.=str_replace('3456','',$value).',';
			}
			//Toc do the
			if(is_numeric($value) && preg_match('/6789/si', $value))
			{
				$list_273_2_id.=str_replace('6789','',$value).',';
			}
			//Gia
			if(preg_match('/VND/si',$value))
			{
				$list_price[] = str_replace('VND','', $value);
			}
		}
		$list_brand_id = rtrim($list_brand_id, ',');
		$list_276_id = rtrim($list_276_id, ',');
		$list_273_1_id = rtrim($list_273_1_id, ',');
		$list_273_2_id = rtrim($list_273_2_id, ',');
		$price1 = 0;
		$price2 = 0;
		$min_price_search = 0;
		$max_price_search = 0;
		if(!empty($list_price))
		{
			$price1 = isset($list_price[0]) ? $list_price[0]:0;
			$price2 = isset($list_price[1]) ? $list_price[1]:0;
			if($price1<$price2)
			{
				$min_price_search = $price1;
				$max_price_search = $price2;
			}
			else
			{
				$min_price_search = $price2;
				$max_price_search = $price1;
			}
		}
		if($min_price!=0) $min_price_search = $min_price;
		if($max_price!=0) $max_price_search = $max_price;
		
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$sub_id = isset($cat_info['sub_id']) ? $cat_info['sub_id']:'';
		//Brand
		$brands = BBrand::getAllBrand();
		//Url rewrite
		$url_rewrite=Common::genUrlRewrite();
		list($products, $paging, $total_product, $list_total_brand, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5) = Access::getAccessFilter($cat_id, $sub_id, $list_brand_id, $list_276_id, $list_273_1_id, $list_273_2_id, $min_price_search, $max_price_search, $keyword, $orderby, $page, $num_per_page, $url_rewrite);
		//Seo
		$h1 = $cat_info['title'];
		$metaTitle = $h1;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = $h1;
		$metaDes .= $tag_page;
		$metaKeyword = $h1;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		
		$this->linkCanoncical = Url::createUrl('access/search', array('cat_id'=>$cat_id,'alias'=>$cat_info['alias']));
		$render = 'search';
		
		$this->render($render, 
				array('products'=>$products, 'paging'=>$paging, 'total_product'=>$total_product, 'page'=>$page, 'num_per_page'=>$num_per_page,
					  'cat_id'=>$cat_id, 'list_brand_id'=>$list_brand_id,'list_276_id'=>$list_276_id, 'list_273_1_id'=>$list_273_1_id, 'list_273_2_id'=>$list_273_2_id,
					  'min_price'=>$min_price, 'max_price'=>$max_price, 'orderby'=>$orderby, 'price1'=>$price1, 'price2'=>$price2,'keyword'=>$keyword,
					  'h1'=>$h1,
					  'cat_info'=>$cat_info, 'cats'=>$cats, 'brands'=>$brands,
					  'list_total_brand'=>$list_total_brand, 'total_price_1'=>$total_price_1, 'total_price_2'=>$total_price_2, 'total_price_3'=>$total_price_3, 'total_price_4'=>$total_price_4, 'total_price_5'=>$total_price_5
		));
	}
	
	public function actionSearchTop()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
				
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;		
		$min_price = isset($_GET['min_price']) ? $_GET['min_price'] : 0;
		$max_price = isset($_GET['max_price']) ? $_GET['max_price'] : 0;
		$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : '';
		$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_top = isset($_GET['keyword_top']) ? $_GET['keyword_top'] : '';
		$list_brand_id = '';
		$list_276_id = '';
		$list_273_1_id = '';
		$list_273_2_id = '';
		$list_price = array();
		$s = isset($_GET['s']) ? $_GET['s'] : '';
		$list_filter = explode(' ',$s);
		if(!empty($list_filter))
		foreach($list_filter as $value)
		{
			//Thuong hieu
			if(is_numeric($value) && preg_match('/3579/si', $value))
			{
				$list_brand_id.=str_replace('3579','',$value).',';
			}
			//Kich thuoc
			if(is_numeric($value) && preg_match('/1235/si', $value))
			{
				$list_276_id.=str_replace('1235','',$value).',';
			}
			//Duong luong
			if(is_numeric($value) && preg_match('/3456/si', $value))
			{
				$list_273_1_id.=str_replace('3456','',$value).',';
			}
			//Toc do the
			if(is_numeric($value) && preg_match('/6789/si', $value))
			{
				$list_273_2_id.=str_replace('6789','',$value).',';
			}
			//Gia
			if(preg_match('/VND/si',$value))
			{
				$list_price[] = str_replace('VND','', $value);
			}
		}
		$list_brand_id = rtrim($list_brand_id, ',');
		$list_276_id = rtrim($list_276_id, ',');
		$list_273_1_id = rtrim($list_273_1_id, ',');
		$list_273_2_id = rtrim($list_273_2_id, ',');
		$price1 = 0;
		$price2 = 0;
		$min_price_search = 0;
		$max_price_search = 0;
		if(!empty($list_price))
		{
			$price1 = isset($list_price[0]) ? $list_price[0]:0;
			$price2 = isset($list_price[1]) ? $list_price[1]:0;
			if($price1<$price2)
			{
				$min_price_search = $price1;
				$max_price_search = $price2;
			}
			else
			{
				$min_price_search = $price2;
				$max_price_search = $price1;
			}
		}
		if($min_price!=0) $min_price_search = $min_price;
		if($max_price!=0) $max_price_search = $max_price;
		
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$sub_id = isset($cat_info['sub_id']) ? $cat_info['sub_id']:'';
		//Brand
		$brands = BBrand::getAllBrand();
		//Url rewrite
		$url_rewrite=Common::genUrlRewrite();
		list($products, $paging, $total_product, $list_total_brand, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5) = Access::getAccessBySearchTop($cat_id, $sub_id, $list_brand_id, $list_276_id, $list_273_1_id, $list_273_2_id, $min_price_search, $max_price_search, $keyword, $keyword_top, $orderby, $page, $num_per_page, $url_rewrite);
		//Seo
		$h1 = $keyword_top;
		$metaTitle = 'Kết quả tìm kiếm từ khóa: '.$keyword_top;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = $h1;
		$metaDes .= $tag_page;
		$metaKeyword = $h1;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		
		$this->linkCanoncical = Url::createUrl('access/searchTop', array('keyword_top'=>$keyword_top));
		$render = 'search_top';
		
		$this->render($render, 
				array('products'=>$products, 'paging'=>$paging, 'total_product'=>$total_product, 'page'=>$page, 'num_per_page'=>$num_per_page,
					  'cat_id'=>$cat_id, 'list_brand_id'=>$list_brand_id,'list_276_id'=>$list_276_id, 'list_273_1_id'=>$list_273_1_id, 'list_273_2_id'=>$list_273_2_id,
					  'min_price'=>$min_price, 'max_price'=>$max_price, 'orderby'=>$orderby, 'price1'=>$price1, 'price2'=>$price2,'keyword'=>$keyword, 'keyword_top'=>$keyword_top,
					  'h1'=>$h1,
					  'cat_info'=>$cat_info, 'cats'=>$cats, 'brands'=>$brands,
					  'list_total_brand'=>$list_total_brand, 'total_price_1'=>$total_price_1, 'total_price_2'=>$total_price_2, 'total_price_3'=>$total_price_3, 'total_price_4'=>$total_price_4, 'total_price_5'=>$total_price_5
		));
	}
	
	public function actionSale()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
		$cat_id = isset($_GET['cat_id2']) ? intval($_GET['cat_id2']) : 0;		
		$alias = isset($_GET['alias_cat']) ? $_GET['alias_cat'] : '';
		$min_price = isset($_GET['min_price']) ? $_GET['min_price'] : 0;
		$max_price = isset($_GET['max_price']) ? $_GET['max_price'] : 0;
		$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : '';
		
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
			
		$h1 = '';
		if(!empty($cat_info)) $h1.='Máy ảnh '.$cat_info['title'];
		if($min_price!=0) $h1.=' giá từ '.Common::formatNumber($min_price*1000000);
		if($max_price!=0 && $min_price==0) $h1.=' giá nhỏ hơn '.Common::formatNumber($max_price*1000000);
		if($max_price!=0 && $min_price!=0) $h1.=' đến '.Common::formatNumber($max_price*1000000);
		if($h1=='') $h1 = 'Sản phẩm khuyến mại';
		list($products, $paging, $total) = Access::getAccessBySale($cat_id, $alias, $min_price, $max_price, $orderby, $page, $num_per_page);
			
		//Seo
		$metaTitle = $h1;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = $h1;
		$metaDes .= $tag_page;
		$metaKeyword = $h1;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		
		$this->linkCanoncical = Url::createUrl('access/sale');
		
		$render = 'sale';
		
		$this->render($render, 
				array('products'=>$products, 'paging'=>$paging, 'total'=>$total, 'page'=>$page, 'num_per_page'=>$num_per_page,
					  'alias' => $alias, 'cat_id'=>$cat_id,
					  'min_price'=>$min_price, 'max_price'=>$max_price, 'orderby'=>$orderby,
					  'h1'=>$h1
		));
	}
	
	public function actionHot()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
		$cat_id = isset($_GET['cat_id2']) ? intval($_GET['cat_id2']) : 0;		
		$alias = isset($_GET['alias_cat']) ? $_GET['alias_cat'] : '';
		$min_price = isset($_GET['min_price']) ? $_GET['min_price'] : 0;
		$max_price = isset($_GET['max_price']) ? $_GET['max_price'] : 0;
		$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : '';
		
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
			
		$h1 = '';
		if(!empty($cat_info)) $h1.='Giá sốc máy ảnh '.$cat_info['title'];
		if($min_price!=0) $h1.=' giá từ '.Common::formatNumber($min_price*1000000);
		if($max_price!=0 && $min_price==0) $h1.=' giá nhỏ hơn '.Common::formatNumber($max_price*1000000);
		if($max_price!=0 && $min_price!=0) $h1.=' đến '.Common::formatNumber($max_price*1000000);
		if($h1=='') $h1 = 'Giá sốc trong ngày';
		list($products, $paging, $total) = Access::getAccessByHot($cat_id, $alias, $min_price, $max_price, $orderby, $page, $num_per_page);
			
		//Seo
		$metaTitle = $h1;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = $h1;
		$metaDes .= $tag_page;
		$metaKeyword = $h1;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		
		$this->linkCanoncical = Url::createUrl('access/hot');
		
		$render = 'hot';
		
		$this->render($render, 
				array('products'=>$products, 'paging'=>$paging, 'total'=>$total, 'page'=>$page, 'num_per_page'=>$num_per_page,
					  'alias' => $alias, 'cat_id'=>$cat_id,
					  'min_price'=>$min_price, 'max_price'=>$max_price, 'orderby'=>$orderby,
					  'h1'=>$h1
		));
	}
	
	public function actionViews()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
		$cat_id = isset($_GET['cat_id2']) ? intval($_GET['cat_id2']) : 0;		
		$alias = isset($_GET['alias_cat']) ? $_GET['alias_cat'] : '';
		$min_price = isset($_GET['min_price']) ? $_GET['min_price'] : 0;
		$max_price = isset($_GET['max_price']) ? $_GET['max_price'] : 0;
		$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : '';
		
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
			
		$h1 = '';
		if(!empty($cat_info)) $h1.='Máy ảnh '.$cat_info['title'];
		if($min_price!=0) $h1.=' giá từ '.Common::formatNumber($min_price*1000000);
		if($max_price!=0 && $min_price==0) $h1.=' giá nhỏ hơn '.Common::formatNumber($max_price*1000000);
		if($max_price!=0 && $min_price!=0) $h1.=' đến '.Common::formatNumber($max_price*1000000);
		if($h1=='') $h1 = 'Sản phẩm nổi bật';
		list($products, $paging, $total) = Access::getAccessByHot($cat_id, $alias, $min_price, $max_price, $orderby, $page, $num_per_page);
			
		//Seo
		$metaTitle = $h1;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = $h1;
		$metaDes .= $tag_page;
		$metaKeyword = $h1;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		
		$this->linkCanoncical = Url::createUrl('access/views');
		
		$render = 'views';
		
		$this->render($render, 
				array('products'=>$products, 'paging'=>$paging, 'total'=>$total, 'page'=>$page, 'num_per_page'=>$num_per_page,
					  'alias' => $alias, 'cat_id'=>$cat_id,
					  'min_price'=>$min_price, 'max_price'=>$max_price, 'orderby'=>$orderby,
					  'h1'=>$h1
		));
	}
	
	public function actionRssCat()
    {
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
		$cat_info = Cats::getCatInfo($cat_id);
		if(!empty($cat_info))
		{
			$sub_cat_id = $cat_info['sub_id'];
			header("Content-Type: application/xml; charset=UTF-8");
			echo '<?xml version="1.0" encoding="UTF-8" ?>
			<rss version="2.0">
			<channel>
			<title>'.$cat_info['title'].'</title>
			<description>'.$cat_info['meta_description'].'</description>
			<link>'.Yii::app()->params['baseUrl'].'/'.$cat_info['alias'].'-c'.$cat_id.'.html</link>
			';
			$list = Access::getAccessByCatRss($cat_id, $sub_cat_id, 15);
			if($list)
			{
				foreach($list as $row) 
				{
					$link=Yii::app()->params['baseUrl'].'/'.$row['alias'].'-'.'b'.$row['id'].'.html';
					echo '<item>';
					echo '<title>'.htmlspecialchars($row['title']).'</title>';
					echo '<link>'.$link.'</link>';
					echo '<description>'.htmlspecialchars(strip_tags($row['introtext'])).'</description>';
					echo '<pubDate>'.date('r', $row['publish_date']).'</pubDate>';
					echo '<guid>'.$link.'</guid>';
					echo '</item>';
				}
			}
			echo '</channel></rss>';
			exit();
		}
		else
		{
			$this->redirect('home/index');
		}
    }
	
	
	public function actionDealAccess()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
		
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$sub_id = isset($cat_info['sub_id']) ? $cat_info['sub_id']:'';
		list($access_deal, $total) = Access::getDealAccess($cat_id, $sub_id, $page, $num_per_page);
		
		//Feature
		list($products_feature, $access_free_feature) = BList::getDealListFeature(12);
		$h1 = empty($cat_info) ? 'Phụ kiện giảm giá' : $cat_info['title'].' giảm giá';
		$metaTitle = $h1;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = $h1;
		$metaDes .= $tag_page;
		$metaKeyword = $h1;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		
		$this->linkCanoncical = Url::createUrl('access/dealAccess');
		
		$render = 'deal_access';
		
		$this->render($render, 
				array('access_deal'=>$access_deal, 'total'=>$total,
					  'products_feature'=>$products_feature, 'access_free_feature'=>$access_free_feature,
					  'page'=>$page, 'num_per_page'=>$num_per_page,
					  'cat_id'=>$cat_id,'cats'=>$cats, 'cat_info'=>$cat_info,
					  'h1'=>$h1
		));
	}
	
}
?>