<?php
class HomeController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		
		$products_deal = BList::getListSales(6);
		$row_soc = BList::getOneSoc();
		$camera_id = isset($row_soc['id']) ? $row_soc['id'] : 0;
		$model_id = isset($row_soc['model_id']) ? $row_soc['model_id'] : 0;
		$model_info  = BModel::getModelById($model_id);
		
		$camera_pic = BListPic::getPicById($camera_id);
		
		list($timeline, $total_timeline) = BTimeline::getTimeline($page, $num_per_page);
		$this->render('index',
				array('row_soc'=>$row_soc, 'model_info'=>$model_info, 'camera_pic'=>$camera_pic, 'products_deal'=>$products_deal, 'timeline'=>$timeline, 'total_timeline'=>$total_timeline,
					  'page'=>$page, 'num_per_page'=>$num_per_page
															 
		));
	}
    public function actionIntro()
	{
		$company = Company::getHotCompany(3);
		
		$this->pageTitle = 'Giới thiệu website - VJCamera.com';
		$this->metaKeywords = 'dang tin cho thue nha dat, nha mat pho, van phong, rao bán nhà,đăng tin bán nhà, rao vặt miễn phí, rao vat';
		$this->metaDescription = 'Giới thiệu website - VJCamera.com';
		$this->linkCanoncical = Url::createUrl('home/intro');
		$this->render('intro', array('company'=>$company));		
	}
	//Quy che hoat dong
	public function actionPrivacy()
	{
		$company = Company::getHotCompany(3);
		$this->pageTitle = 'Quy chế hoạt động - VJCamera.com';
		$this->metaKeywords = 'quy che hoat dong';
		$this->metaDescription = 'Quy chế hoạt động - VJCamera.com';
		$this->linkCanoncical = Url::createUrl('home/privacy');
		$this->render('privacy', array('company'=>$company));		
	}
	
	//Dieu khoan, thoa thuan
	public function actionTos()
	{
		$company = Company::getHotCompany(3);
		$this->pageTitle = 'Điều khoản thỏa thuận - VJCamera.com';
		$this->metaKeywords = 'dieu khoan thoa thuan,dang tin cho thue nha dat, nha mat pho, van phong, rao bán nhà,đăng tin bán nhà, rao vặt miễn phí, rao vat';
		$this->metaDescription = 'Điều khoản thỏa thuận - VJCamera.com';
		$this->linkCanoncical = Url::createUrl('home/tos');
		$this->render('tos', array('company'=>$company));		
	}
	//Lien he
	public function actionContact()
	{
		$detail = BStaticContent::getStaticContentById(1);
		$hot_news = News::getLatestNews(5);
		
		$this->pageTitle = 'Liên hệ - VJCamera.com';
		$this->metaKeywords = 'lien he';
		$this->metaDescription = 'Liên hệ - VJCamera.com';
		$this->linkCanoncical = Url::createUrl('home/contact');
		$this->render('contact', array('detail'=>$detail, 'hot_news'=>$hot_news));
	}
	
	public function actionRss()
    {
		header("Content-Type: application/xml; charset=UTF-8");
		echo '<?xml version="1.0" encoding="UTF-8" ?>
		<rss version="2.0">
		<channel>
		<title>Trang chủ VJCamera.com</title>
		<description>Camera</description>
		<link>'.Yii::app()->params['baseUrl'].'</link>
		';
		$list = BList::getListRss(15);
		if($list)
		{
			foreach($list as $row) 
			{
				$link=Yii::app()->params['baseUrl'].'/'.$row['alias'].'-'.'b'.$row['id'].'.html';
				echo '<item>';
				echo '<title>'.htmlspecialchars($row['title']).'</title>';
				echo '<link>'.$link.'</link>';
				echo '<description>'.htmlspecialchars(strip_tags($row['introtext'])).'</description>';
				echo '<pubDate>'.date('r', $row['publish_date']).'</pubDate>';
				echo '<guid>'.$link.'</guid>';
				echo '</item>';
			}
		}
		echo '</channel></rss>';
		exit();
    }
	
	public function actionError()
    {
		//var_dump(Yii::app()->errorHandler->error);
        if($error = Yii::app()->errorHandler->error)
		{
			$this->renderPartial('error',array("error"=>$error));
		}
        else
		{
            throw new CHttpException(404, 'Trang không tồn tại.');
		}
    }
	public function actionUpdateSubCat()
	{
		//Cats::updateSubCat();
		Cats::updateNumProduct();
	}
}
?>