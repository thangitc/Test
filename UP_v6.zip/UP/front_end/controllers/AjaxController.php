<?php
class AjaxController extends Controller
{
	public $layout = false;
	public $output = array();
	public function actionLoadDistrict()
	{
		$city_id = isset($_POST['city_id']) ? intval($_POST['city_id']) : 0;
		$citys = City::getCitys();
		$html = '<option value="0">--Quận huyện--</option>';
		foreach($citys as $row)
		{
			if($row['parent_id']==$city_id)
			{
				$html .= '<option value="'.$row['id'].'">'.$row['title'].'</option>';
			}
		}
		echo $html;
	}
	
	public function actionRegAcc()
	{
		$email = isset($_POST['email']) ? trim(strip_tags($_POST['email'])) : '';
		$password = isset($_POST['password']) ? trim(strip_tags($_POST['password'])) : '';
		$re_password = isset($_POST['re_password']) ? trim(strip_tags($_POST['re_password'])) : '';
		$fullname = isset($_POST['fullname']) ? trim(strip_tags($_POST['fullname'])) : '';
		$mobile = isset($_POST['mobile']) ? trim(strip_tags($_POST['mobile'])) : '';
		$error='';
		$status=0;
		if($email=='')
		{
			$error.='Vui lòng nhập địa chỉ email!<br>';
		}
		else
		{
			if(!Common::validateEmailSyntax($email))
			{
				$error.='Email không hợp lệ!<br>';
			}
			else
			{
				$check_user = Users::getUserByEmail($email);
				if($check_user)
				{
					$error.='Địa chỉ email đã tồn tại trong hệ thống!<br>';
				}
			}
		}
		if($password=='')
		{
			$error.='Vui lòng nhập mật khẩu đăng nhập!<br>';
		}
		else
		{
			if((strlen($password)<6 && strlen($password)>24))
			{
				$error.='Mật khẩu đăng nhập từ 6 - 24 ký tự!<br>';
			}
		}
		if($re_password=='')
		{
			$error.='Vui lòng nhập lại mật khẩu!<br>';
		}
		if($password!=$re_password)
		{
			$error.='Mật khẩu không khớp!<br>';
		}
		
		if($fullname=='')
		{
			$error.='Vui lòng nhập họ tên đầy đủ!<br>';
		}
		/*
		if($secure_code=='')
		{
			$error.='Vui lòng nhập mã bảo mật!<br>';
		}
		else
		{
			if($secure_code!=$_SESSION['secure_code'])
			{
				$error.='Mã bảo mật không đúng!<br>';
			}
		}
		*/
		if($error!='')
		{
			$output=array('error'=>$error,'status'=>0);
		}
		else
		{
			/*Reset capcha*/
			//Common::resetCapcha();
			$pass = Common::genPass($password);
			
			$array_input = array('email'=>mysql_escape_string($email),'password'=>mysql_escape_string($pass),'fullname'=>mysql_escape_string($fullname),'mobile'=>mysql_escape_string($mobile),'status'=>1,'create_date'=>time());
			$user_id = CommonModel::insertObject($array_input,'b_user');
			if($user_id!=0)
			{
				$status=1;
				$error='Đăng ký thành công';
				$_SESSION["userid"] = $user_id;
				$_SESSION["email"] = $email;
				//Tao 1 tai khoan tien
				
				$array_account = array('user_id'=>$user_id, 'email'=>mysql_escape_string($email),'point'=>1, 'money'=>1000, 'create_date'=>time(), 'edit_date'=>time());
				CommonModel::insertObject($array_account,'b_user_account');
				
			}
			else
			{
				$status = 0;
				$error = 'Có lỗi trong quá trình xử lý';
			}
		}
		$output=array('error'=>$error,'status'=>$status);
		$output=json_encode($output);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}		
	
	public function actionLogout()
	{
		if(isset($_SESSION['userid'])) unset($_SESSION['userid']);
		if(isset($_SESSION['email'])) unset($_SESSION['email']);
		exit();
	}
	public function actionLogin()
	{
		$email = isset($_POST['email']) ? trim(strip_tags($_POST['email'])) : '';
		$password = isset($_POST['password']) ? trim(strip_tags($_POST['password'])) : '';
		$error='';
		$status=0;
		if($email=='')
		{
			$error .= 'Vui lòng nhập địa chỉ email!<br />';
		}
		
		if($password=='')
		{
			$error .= 'Vui lòng nhập mật khẩu đăng nhập!<br />';
		}
		if($error=='')
		{
			$pass = Common::genPass($password);
			$check = Users::getUserLogin($email,$pass);
			if($check)
			{
				$_SESSION['userid']=$check['id'];
				$_SESSION['email']=$check['email'];
				$error.= "Đăng nhập thành công!<br>";
				$status=1;
			}
			else
			{
				$error.= "Địa chỉ Email đăng nhập hoặc Mật khẩu không chính xác. Vui lòng thử lại!<br>";
			}
		}
		$output=array('error'=>$error,'status'=>$status);
		$output=json_encode($output);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
		exit();
	}
	
	//Them moi tin BDS
	public function actionLoadProductCat()
	{
		$type = isset($_POST['type']) ? intval($_POST['type']) : 0;
		$cats = Cats::getCats();
		$html = '<option value="0" selected="selected">--Danh mục--</option>';
		foreach($cats as $row)
		{
			if($row['cat_type']==$type && $row['parent_id']!=0)
			{
				$html .= '<option value="'.$row['id'].'">'.$row['title'].'</option>';
			}
		}
		echo $html;
	}
	
	public function actionLoadWard()
	{
		$district_id = isset($_POST['district_id']) ? intval($_POST['district_id']) : 0;
		$wards = Ward::getWardByDistrictId($district_id);
		$html = '<option value="0">--Phường Xã--</option>';
		foreach($wards as $row)
		{
			if($row['district_id']==$district_id)
			{
				$html .= '<option value="'.$row['id'].'" rel="'.$row['pre'].'">'.$row['title'].'</option>';
			}
		}
		echo $html;
	}
	
	public function actionLoadStreet()
	{
		$district_id = isset($_POST['district_id']) ? intval($_POST['district_id']) : 0;
		$street = Street::getStreetByDistrictId($district_id);
		$html = '<option value="0">--Đường phố--</option>';
		foreach($street as $row)
		{
			if($row['district_id']==$district_id)
			{
				$html .= '<option value="'.$row['id'].'" rel="'.$row['pre'].'">'.$row['title'].'</option>';
			}
		}
		echo $html;
	}
	
	public function actionLoadProject()
	{
		$district_id = isset($_POST['district_id']) ? intval($_POST['district_id']) : 0;
		$project = Project::getProjectByDistrictId($district_id);
		$html = '<option value="0" lat="0" lng="0">--Dự án--</option>';
		foreach($project as $row)
		{
			if($row['district_id']==$district_id)
			{
				$html .= '<option value="'.$row['id'].'" lat="'.$row['lat'].'" lng="'.$row['lng'].'">'.$row['title'].'</option>';
			}
		}
		echo $html;
	}
	
	public function actionAddList()
	{
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		$vip_type = isset($_POST['vip_type']) ? intval($_POST['vip_type']) : 0;
		$title = isset($_POST['title']) ? $_POST['title'] : '';
		$alias = Common::generate_slug($title);
		$publish_date = isset($_POST['publish_date']) ? $_POST['publish_date'] : '';
		$expired_date = isset($_POST['expired_date']) ? $_POST['expired_date'] : '';
		
		$create_date = time();
		if($publish_date!='')
		{
			$publish_date=explode('/',$publish_date);
			$publish_date=mktime(0,0,0,$publish_date[1],$publish_date[0],$publish_date[2]);
		}
		else
		{
			$publish_date = $create_date;
		}
		if($expired_date!='')
		{
			$expired_date=explode('/',$expired_date);
			$expired_date=mktime(23,59,59,$expired_date[1],$expired_date[0],$expired_date[2]);
		}
		else
		{
			$expired_date = $publish_date + 86400*30;
		}
		$introtext = isset($_POST['introtext']) ? $_POST['introtext'] : '';
		$description = isset($_POST['description']) ? $_POST['description'] : '';
		$picture = isset($_POST['picture']) ? $_POST['picture'] : '';
		$html_img=isset($_POST['html_img']) ? $_POST['html_img']:'';
		$original_link = isset($_POST['original_link']) ? $_POST['original_link'] : '';
		$bds_source = isset($_POST['bds_source']) ? $_POST['bds_source'] : '';
		//Thong tin co ban
		$type = isset($_POST['type']) ? intval($_POST['type']) : 0;
		$cat_id = isset($_POST['cat_id']) ? intval($_POST['cat_id']) : 0;
		$city_id = isset($_POST['city_id']) ? intval($_POST['city_id']) : 0;
		$district_id = isset($_POST['district_id']) ? intval($_POST['district_id']) : 0;
		$ward_id = isset($_POST['ward_id']) ? intval($_POST['ward_id']) : 0;
		$street_id = isset($_POST['street_id']) ? intval($_POST['street_id']) : 0;
		$project_id = isset($_POST['project_id']) ? intval($_POST['project_id']) : 0;
		$area = isset($_POST['area']) ? $_POST['area'] : '';
		$price = isset($_POST['price']) ? $_POST['price'] : '';
		$unit_id = isset($_POST['unit_id']) ? intval($_POST['unit_id']) : 0;
		$address = isset($_POST['address']) ? $_POST['address'] : '';
		//Thong tin khac
		$mat_tien = isset($_POST['mat_tien']) ? $_POST['mat_tien'] : '';
		$duong_vao = isset($_POST['duong_vao']) ? $_POST['duong_vao'] : '';
		$huong_nha = isset($_POST['huong_nha']) ? $_POST['huong_nha'] : '';
		$huong_ban_cong = isset($_POST['huong_ban_cong']) ? $_POST['huong_ban_cong'] : '';
		$tang = isset($_POST['tang']) ? intval($_POST['tang']) : 0;
		$phong_ngu = isset($_POST['phong_ngu']) ? $_POST['phong_ngu'] : '';
		$toilet = isset($_POST['toilet']) ? $_POST['toilet'] : '';
		$noi_that = isset($_POST['noi_that']) ? $_POST['noi_that'] : '';
		$phong_ngu = isset($_POST['phong_ngu']) ? $_POST['phong_ngu'] : '';
		//Thong tin lien he
		$ten_lien_he = isset($_POST['ten_lien_he']) ? $_POST['ten_lien_he'] : '';
		$dia_chi_lien_he = isset($_POST['dia_chi_lien_he']) ? $_POST['dia_chi_lien_he'] : '';
		$mobile_lien_he = isset($_POST['mobile_lien_he']) ? $_POST['mobile_lien_he'] : '';
		$yahoo = isset($_POST['yahoo']) ? $_POST['yahoo'] : '';
		$skype = isset($_POST['skype']) ? $_POST['skype'] : '';
		$lat = isset($_POST['lat']) ? $_POST['lat'] : '';
		$lng = isset($_POST['lng']) ? $_POST['lng'] : '';
		$status = 'active';
		
		$secure_code = isset($_POST['secure_code']) ? trim(strip_tags($_POST['secure_code'])) : '';
		
		$user_id = isset($_SESSION['userid']) ? intval($_SESSION['userid']) : 0;
		
		//Anh
		preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
		
		if(!empty($matches))
		{
			$picture = isset($matches[1][0]) ? $matches[1][0] : '';
		}
		else
		{
			$picture = '';
		}
		
		$introtext = Common::getIntroText($description,200,'');
		
		$description = preg_replace('/http:\/\/(.*?)\s|http:\/\/(.*?)\n|http:\/\/(.*?)/si','<a href="http://$1">http://$1</a> ',$description);
		
		$error = '';
		if($type==0)
		{
			$error.='Vui lòng chọn hình thức tin!<br>';
		}
		if($cat_id==0)
		{
			$error.='Vui lòng chọn danh mục tin!<br>';
		}
		if($city_id!=0 && $district_id==0)
		{
			$error.='Vui lòng chọn tỉnh thành!<br>';
		}
		if($title=='')
		{
			$error.='Vui lòng nhập tiêu đề tin!<br>';
		}
		
		if($mobile_lien_he=='')
		{
			$error.='Vui lòng nhập số điện thoại liên hệ!<br>';
		}
		
		if($secure_code=='')
		{
			$error.='Vui lòng nhập mã bảo mật!<br>';
		}
		else
		{
			if($secure_code!=$_SESSION['secure_code'])
			{
				$error.='Mã bảo mật không đúng!<br>';
			}
		}
		
		if($error!='')
		{
			$output = array('error'=>$error,'status'=>0);
			$output=json_encode($output);
			header("Content-Type: application/json; charset=utf-8");
			echo $output;
			exit();
		}
		
		Common::resetCapcha();
		
		$array_input = array('vip_type'=>$vip_type,'title'=>mysql_escape_string($title), 'alias'=>mysql_escape_string($alias), 'publish_date'=>$publish_date, 'expired_date'=>$expired_date, 'introtext'=>mysql_escape_string($introtext), 'picture'=>mysql_escape_string($picture), 'original_link'=>mysql_escape_string($original_link), 'bds_source'=>mysql_escape_string($bds_source), 'type'=>$type, 'cat_id'=>$cat_id, 'city_id'=>$city_id, 'district_id'=>$district_id, 'ward_id'=>$ward_id, 'street_id'=>$street_id, 'project_id'=>$project_id, 'area'=>mysql_escape_string($area), 'price'=>mysql_escape_string($price), 'unit_id'=>$unit_id, 'address'=>mysql_escape_string($address), 'mat_tien'=>mysql_escape_string($mat_tien), 'duong_vao'=>mysql_escape_string($duong_vao), 'huong_nha'=>mysql_escape_string($huong_nha), 'huong_ban_cong'=>mysql_escape_string($huong_ban_cong), 'tang'=>mysql_escape_string($tang), 'phong_ngu'=>mysql_escape_string($phong_ngu), 'toilet'=>mysql_escape_string($toilet), 'noi_that'=>mysql_escape_string($noi_that), 'phong_ngu'=>mysql_escape_string($phong_ngu), 'ten_lien_he'=>mysql_escape_string($ten_lien_he), 'dia_chi_lien_he'=>mysql_escape_string($dia_chi_lien_he), 'mobile_lien_he'=>mysql_escape_string($mobile_lien_he), 'yahoo'=>mysql_escape_string($yahoo), 'skype'=>mysql_escape_string($skype), 'lat'=>mysql_escape_string($lat), 'lng'=>mysql_escape_string($lng), 'user_id'=>$user_id);
		
		if($camera_id!=0)
		{
			$edit_date = time();
			/*
			$array_input['edit_date'] = $edit_date;
			$array_input['edit_name'] = $admin_name;
			*/
			CommonModel::updateObject($array_input, 'id', $camera_id, 'b_camera');
			//Cap nhat noi dung
			CommonModel::updateObject(array('description'=>mysql_escape_string($description)), 'camera_id', $camera_id, 'b_camera_content');
			//Delete Anh
			BListPic::deletePic($camera_id);
			//Cap nhat anh
			$sub_sql = '';
			preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
			if(!empty($matches))
			{
				$k = 0;
				$create_date = time();
				
				if(isset($matches[1]))
				foreach($matches[1] as $value)
				{
					$value = mysql_escape_string(trim(strip_tags($value)));
					$sub_sql .= "(".$camera_id.", '".$value."', '".$create_date."'),";
				}
				
			}
			if($sub_sql!='')
			{
				$sub_sql = rtrim($sub_sql, ',');
				BListPic::insertPic($sub_sql);
			}
		}
		else
		{
			$array_input['status'] = $status;
			$array_input['create_date'] = $create_date;
			$array_input['edit_date'] = $create_date;
			$camera_id = CommonModel::insertObject($array_input, 'b_camera');
			if($camera_id>0)
			{
				CommonModel::insertObject(array('camera_id'=>$camera_id, 'description'=>mysql_escape_string($description)), 'b_camera_content');
				
				//Cap nhat anh
				$sub_sql = '';
				preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
				if(!empty($matches))
				{
					$k = 0;
					$create_date = time();
					
					if(isset($matches[1]))
					foreach($matches[1] as $value)
					{
						$value = mysql_escape_string(trim(strip_tags($value)));
						$sub_sql .= "(".$camera_id.", '".$value."', '".$create_date."'),";
					}
					
				}
				if($sub_sql!='')
				{
					$sub_sql = rtrim($sub_sql, ',');
					BListPic::insertPic($sub_sql);
				}
				
			}			
		}
		
		//Output
		$output = array('error'=>$error,'status'=>1);
		$output=json_encode($output);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
		exit();
	}
	
	public function actionDeleteList()
	{
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		$user_id = isset($_SESSION['userid']) ? intval($_SESSION['userid']) : 0;
		if($user_id!=0)
		{
			$ok = CommonModel::deleteObject(array('id'=>$camera_id, 'user_id'=>$user_id),'b_camera');
			if($ok)
			{
				$ok2 = CommonModel::deleteObject(array('camera_id'=>$camera_id),'b_camera_content');
				echo "DONE!";
			}
			else
			{
				echo "Lỗi!";
			}
		}
		else
		{
			echo "Lỗi!";
		}
	}
	public function actionDeleteAllList()
	{
		$user_id = isset($_SESSION['userid']) ? intval($_SESSION['userid']) : 0;
		$list_id = isset($_POST['list_id']) ? intval($_POST['list_id']) : 0;
		if($user_id!=0)
		{
			BList::deleteAllList($list_id, $user_id);
			echo "DONE!";
		}
		else
		{
			echo "Lỗi!";
		}
	}
	
	public function actionChangeUserInfo()
	{
		$error='';
		$status=0;
		
		if(!isset($_SESSION['userid']))
		{
			$error = 'Bạn phải đăng nhập để thực hiện tính năng này!';
			$output=array('error'=>$error,'status'=>0);
			$output=json_encode($output);
			header("Content-Type: application/json; charset=utf-8");
			echo $output;
			exit();
		}
		$user_id = $_SESSION['userid'];
		$fullname = isset($_POST['fullname']) ? trim(strip_tags($_POST['fullname'])) : '';
		$mobile = isset($_POST['mobile']) ? trim(strip_tags($_POST['mobile'])) : '';
		$address = isset($_POST['address']) ? trim(strip_tags($_POST['address'])) : '';
		$avatar = isset($_POST['avatar']) ? trim(strip_tags($_POST['avatar'])) : '';
		
		if($fullname=='')
		{
			$error.='Vui lòng nhập họ tên liên hệ!<br>';
		}
		if($mobile=='')
		{
			$error.='Vui lòng nhập số điện thoại!<br>';
		}
		
		if($error!='')
		{
			$output=array('error'=>$error,'status'=>0);
		}
		else
		{
			$array_input = array('fullname'=>mysql_escape_string($fullname),'mobile'=>mysql_escape_string($mobile),'address'=>mysql_escape_string($address),'avatar'=>$avatar);
			$ok = CommonModel::updateObject($array_input,'id', $user_id,'b_user');
			if($ok >= 0)
			{
				$status=1;
				$error='Cập nhật thành công';
			}
			else
			{
				$status = 0;
				$error = 'Có lỗi trong quá trình xử lý';
			}
		}
		$output=array('error'=>$error,'status'=>$status);
		$output=json_encode($output);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}
	
	public function actionChangePass()
	{
		$error='';
		$status=0;
		
		if(!isset($_SESSION['userid']))
		{
			$error = 'Bạn phải đăng nhập để thực hiện tính năng này!';
			$output=array('error'=>$error,'status'=>0);
			$output=json_encode($output);
			header("Content-Type: application/json; charset=utf-8");
			echo $output;
			exit();
		}
		$user_id = $_SESSION['userid'];
		$users = $this->users;
		$old_pass = isset($_POST['old_pass']) ? trim(strip_tags($_POST['old_pass'])) : '';
		$new_pass = isset($_POST['new_pass']) ? trim(strip_tags($_POST['new_pass'])) : '';
		$re_new_pass = isset($_POST['re_new_pass']) ? trim(strip_tags($_POST['re_new_pass'])) : '';
		
		if($old_pass=='')
		{
			$error.='Vui lòng nhập mật khẩu cũ!<br>';
		}
		else
		{
			$old_pass_check = Common::genPass($old_pass);
			if($users['password']!=$old_pass_check)
			{
				$error.='Mật khẩu cũ không đúng!<br>';
			}
		}
		if($new_pass=='')
		{
			$error.='Vui lòng nhập mật khẩu mới!<br>';
		}
		if($re_new_pass=='')
		{
			$error.='Vui lòng nhập lại mật khẩu mới!<br>';
		}
		if($new_pass!=$re_new_pass)
		{
			$error.='Mật khẩu mới không khớp!<br>';
		}
		if($error!='')
		{
			$output=array('error'=>$error,'status'=>0);
		}
		else
		{
			$pass = Common::genPass($new_pass);
			$array_input = array('password'=>mysql_escape_string($pass));
			$ok = CommonModel::updateObject($array_input,'id', $user_id,'b_user');
			if($ok >= 0)
			{
				$status=1;
				$error='Cập nhật thành công';
			}
			else
			{
				$status = 0;
				$error = 'Có lỗi trong quá trình xử lý';
			}
		}
		$output=array('error'=>$error,'status'=>$status);
		$output=json_encode($output);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}
			
	public function actionSetDesktop()
    {
        $expire=time()+3600;
		setcookie('isDesktop',1,$expire,'/');
		echo 'Done';exit();
    }
	//VJCamera
	public function actionAddCart()
	{
		$product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
		$product_type = isset($_POST['product_type']) ? intval($_POST['product_type']) : 0;
		$qty = isset($_POST['qty']) ? intval($_POST['qty']) : 1;
		$price = isset($_POST['price']) ? $_POST['price'] : 0;
		if($product_type==1)
			$detail = Access::getAccessById($product_id); //Phu kien
		else if($product_type==0)
			$detail = BList::getListInfoById($product_id); //San pham
		else
			$detail = AccessColor::getAccessColorById($product_id);//Mau sac
		if(empty($detail))
		{
			$output=array('error'=>0);//San pham khong ton tai
		}
		else
		{
			if (!isset($qty) || !(is_numeric($qty)))
			{
				$qty = 1;
			}
			if (isset($_SESSION['product_order']) && sizeof($_SESSION['product_order'])>0) 
			{
				$product = $_SESSION['product_order'];
				$flag=false;
				foreach($product as $key=>$value) 
				{
					if ($value['id'] == $product_id)
					{
						$_SESSION['product_order'][$key]['qty'] = $_SESSION['product_order'][$key]['qty'] + $qty;
						$flag=true;
						break;
					}
					//$i++;
				}
				if(!$flag && isset($product_id))
				{
					$_SESSION['product_order'][]=array('id'=>$product_id,'price'=>$price,'qty'=>$qty, 'product_type'=>$product_type);
				}
			} 
			else
			{
				if(isset($product_id))
				{
					$_SESSION['product_order'][]=array('id'=>$product_id,'price'=>$price,'qty'=>$qty, 'product_type'=>$product_type);
				}
			}
			$output=array('error'=>1);//Them vao gio hang thanh cong
		}
		$output=json_encode($output);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}
	public function actionClearCart()
	{
		unset($_SESSION['product_order']);
		echo 1;
	}
	public function actionRemoveOneCart()
	{
		$product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
		$product_type = isset($_POST['product_type']) ? intval($_POST['product_type']) : 0;
		if(isset($_SESSION['product_order']))
		foreach($_SESSION['product_order'] as $key=>$value)
		{
			if($value['id']==$product_id && $value['product_type']==$product_type)
			{
				unset($_SESSION['product_order'][$key]);
				break;
			}
		}
		echo 1;
	}
	public function actionCheckOutCart()
	{		
		$error = '';
		if (!$_POST['billing_name']) $error.='*Bạn vui lòng nhập họ và tên!<br />';
		if (!$_POST['billing_mobile']) $error.='*Bạn vui lòng nhập số điện thoại!<br />';
		if (!$_POST['billing_address']) $error.='*Bạn vui lòng nhập địa chỉ!<br />';
		
		$status=0;
		if ($error=='')
		{
			$uid = isset($_SESSION['userid']) ? intval($_SESSION['userid']) : 0;
			$billing_name = isset($_POST['billing_name']) ? $_POST['billing_name']:'';
			$billing_mobile = isset($_POST['billing_mobile']) ? $_POST['billing_mobile']:'';
			$billing_email = isset($_POST['billing_email']) ? $_POST['billing_email']:'';
			$billing_address = isset($_POST['billing_address']) ? $_POST['billing_address']:'';
			$billing_note = isset($_POST['billing_note']) ? $_POST['billing_note']:'';
			
			list($list_camera, $list_access, $list_color, $list_model) = Cart::getProductOrder();
			$count = 0;
			$total_price = 0;
			if($list_camera)
			foreach($list_camera as $row)
			{
                list($is_combo, $row_combo) = Combos::checkComboProduct($row['id'], 0, $list_model);

                if($is_combo==1){
                    $total_price += $row_combo['price_new']*$row['qty'];
                }else{
                    if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=time())
                    {
                        $total_price += $row['price_sale']*$row['qty'];
                    }
                    else
                    {
                        $total_price += $row['price']*$row['qty'];
                    }
                }

				$count++;
			}
			
			if($list_access)
			foreach($list_access as $row)
			{
                list($is_combo, $row_combo) = Combos::checkComboProduct($row['id'], 1, $list_model);
                if($is_combo==1){
                    $total_price += $row_combo['price_new']*$row['qty'];
                }else{
                    if($row['price_deal']!=0 && $row['time_deal']!=0 && $row['time_deal']>=time())
                    {
                        $total_price += $row['price_deal']*$row['qty'];
                    }
                    else
                    {
                        $total_price += $row['price']*$row['qty'];
                    }
                }

				
				$count++;
			}
			
			if($list_color)
			foreach($list_color as $row)
			{
				if($row['price_deal']!=0 && $row['time_deal']!=0 && $row['time_deal']>=time())
				{
					$total_price += $row['price_deal']*$row['qty'];
				}
				else
				{
					$total_price += $row['price']*$row['qty'];
				}
				$count++;
			}
			
			$array_input = array('order_status'=>'pending', 'product_count'=>$count, 'total_price'=>$total_price, 'billing_name'=>mysql_escape_string($billing_name), 'billing_mobile'=>mysql_escape_string($billing_mobile), 'billing_address'=>mysql_escape_string($billing_address), 'billing_email'=>mysql_escape_string($billing_email), 'billing_note'=>mysql_escape_string($billing_note), 'created'=>time(), 'uid'=>$uid);
			$order_id = CommonModel::insertObject($array_input, 'tbl_order');
			
			//Cap nhat san pham don hang
			if($order_id>0)
			{
				$sub_sql = '';
				if($list_camera)
				foreach($list_camera as $row)
				{
					if($row['price_sale']!=0 && $row['time_sale']!=0)
					{
						$price_buy = $row['price_sale'];
					}
					else
					{
						$price_buy = $row['price'];
					}
					$sub_sql .= "(".$order_id.", ".$row['id'].", 0, ".$row['qty'].", ".$price_buy.",".$row['price_sale'].",".$row['price'].",".$row['price_in'].", '".mysql_escape_string($row['title'])."'),";
				}
				
				if($list_access)
				foreach($list_access as $row)
				{
					if($row['price_deal']!=0 && $row['time_deal']!=0)
					{
						$price_buy = $row['price_deal'];
					}
					else
					{
						$price_buy = $row['price'];
					}
					$sub_sql .= "(".$order_id.", ".$row['id'].", 1, ".$row['qty'].", ".$price_buy.",".$row['price_deal'].",".$row['price'].",".$row['price_in'].", '".mysql_escape_string($row['title'])."'),";
				}
				
				if($list_color)
				foreach($list_color as $row)
				{
					if($row['price_deal']!=0 && $row['time_deal']!=0)
					{
						$price_buy = $row['price_deal'];
					}
					else
					{
						$price_buy = $row['price'];
					}
					$sub_sql .= "(".$order_id.", ".$row['id'].", 2, ".$row['qty'].", ".$price_buy.",".$row['price_deal'].",".$row['price'].",".$row['price_in'].", '".mysql_escape_string($row['title'])."'),";
				}
				if($sub_sql!='')
				{
					$sub_sql = rtrim($sub_sql, ',');
					Cart::insertProductOrder($sub_sql);
				}
				
				$_SESSION['cart_information']=array('billing_name'=>$billing_name,'billing_mobile'=>$billing_mobile,'billing_address'=>$billing_address,'billing_email'=>$billing_email,'billing_note'=>$billing_note);
				$status=1;
			}
		}
		if($status==1)
		{
			unset($_SESSION['product_order']);
		}
		$output=array('error'=>$error,'status'=>$status);
		$output=json_encode($output);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}
	public function acctionCartComplete()
	{
		unset($_SESSION['product_order']);
		$mes = "";
		sendmail('', 'vnjapancamera@gmail.com','Co don dat hang. Kiem tra mail ngay!',$mes);
		echo 1;
	}
	
	public function actionLoadPopAccess()
	{
		$access_id = isset($_POST['access_id']) ? intval($_POST['access_id']) : 0;
		$is_deal = isset($_POST['is_deal']) ? intval($_POST['is_deal']) : 0;
		$access_info = Access::getAccessById($access_id);
		$this->renderPartial('application.views.access.pop_access', array('access_info'=>$access_info, 'is_deal'=>$is_deal));
		exit();
	}
	public function actionEmailSubscribe()
	{
		$email = isset($_POST['email']) ? $_POST['email'] : '';
		if($email=='' || !Common::validateEmailSyntax($email))
		{
			echo 'Địa chỉ email không hợp lệ!';
			exit();
		}
		else
		{
			CommonModel::insertObject(array('email'=>mysql_escape_string($email), 'create_date'=>time()), 'b_subscribe');
		}
		echo 1;
		exit();
	}
	public function actionRemoveOneBill()
	{
		$product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
		$product_type = isset($_POST['product_type']) ? intval($_POST['product_type']) : 0;
		$bill_id = isset($_POST['bill_id']) ? intval($_POST['bill_id']) : 0;
		CommonModel::deleteObject(array('product_id'=>$product_id, 'product_type'=>$product_type,'bill_id'=>$bill_id), 'tbl_bill_product');
		echo 1;
	}

    public function actionSetGridList()
    {
        $is_grid = isset($_POST['is_grid']) ? intval($_POST['is_grid']) : 1;
        $expire=time()+3600;
        setcookie('isGrid',$is_grid,$expire,'/');
        echo 'Done';exit();
    }
}
?>