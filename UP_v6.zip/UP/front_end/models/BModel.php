<?php
class BModel extends CActiveRecord
{
	public function getModelById($model_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_model WHERE id=".$model_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function getAllModel()
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_model";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function getModelByCat($cat_id, $sub_id)
	{
		$connect=Yii::app()->db;
		if($sub_id!='')			
			$sql="SELECT * FROM b_model WHERE cat_id IN (".$sub_id.")";
		else
			$sql="SELECT * FROM b_model WHERE cat_id=".$cat_id;
			
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function getModelByCatBrand($cat_id, $sub_id, $list_brand_id)
	{
		$connect=Yii::app()->db;
		$cond = '1 AND status="active"';
		$cond .= $sub_id!='' ? ' AND cat_id IN ('.$sub_id.')' : ' AND cat_id='.$cat_id;
		
		$cond .= $list_brand_id!='' ? ' AND brand_id IN ('.$list_brand_id.')' : '';
		
		$sql="SELECT * FROM b_model WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
}
?>