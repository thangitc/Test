<?php
class Bill extends CActiveRecord
{	
	public function getProductBill($bill_id) 
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM tbl_bill_product WHERE bill_id=".$bill_id;
		$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		$list_camera_id="";
		$list_access_id="";
		$list_color_id="";
		foreach($rows as $row)
		{
			if($row['product_type']==0) // San pham
				$list_camera_id.=$row['product_id'].',';
			else if($row['product_type']==1) //Phu kien
				$list_access_id.=$row['product_id'].',';
			else //Phu kien, Mau sac
				$list_color_id.=$row['product_id'].',';
		}
		$list_camera_id=rtrim($list_camera_id,',');
		$list_access_id=rtrim($list_access_id,',');
		$list_color_id=rtrim($list_color_id,',');
		$camera = array();
		$access = array();
		$colors = array();
		$access_free = array();
		if($list_camera_id!='')
		{
			$sql="SELECT * FROM b_camera WHERE id in (".$list_camera_id.")";
			$command = $connect->createCommand($sql);
			$camera = $command->queryAll();
			//Qua tang
			$sql = "SELECT t1.camera_id, t2.title, t2.alias, t2.id, t2.price FROM b_camera_access_free t1, b_accessories t2 WHERE t1.camera_id IN (".$list_camera_id.") AND t1.access_id=t2.id AND status='active'";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$access_free[$row['camera_id']][] = $row;
			}
		}
		if($list_color_id!='')
		{
			$sql = "SELECT t2.*, t1.title, t1.alias, t1.time_bh, t1.price_buy FROM b_accessories t1, b_accessories_color t2 WHERE t2.id IN (".$list_color_id.") AND t1.id=t2.access_id";
			$command = $connect->createCommand($sql);
			$colors = $command->queryAll();
		}
		if($list_access_id!='')
		{
			$sql = "SELECT * FROM b_accessories WHERE id IN (".$list_access_id.")";
			$command = $connect->createCommand($sql);
			$access = $command->queryAll();
		}
		
		
		$a = array($camera, $access, $colors, $access_free);
		return $a;
	}
	public function getBillById($bill_id)
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM tbl_bill WHERE id=".$bill_id;
		$command = $connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}
?>