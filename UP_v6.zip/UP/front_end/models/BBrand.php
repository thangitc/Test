<?php
class BBrand extends CActiveRecord
{
	public function getBrandById($brand_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_brand WHERE id=".$brand_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function getAllBrand()
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_brand";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
}
?>