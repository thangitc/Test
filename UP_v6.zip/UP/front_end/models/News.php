<?php
class News extends CActiveRecord
{	
	public function getLatestNews($limit)
	{
		//Cache
		$cacheService = new CacheService("News","getLatestNews", $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT `id`, cat_id, `title`, `alias`, `introtext`, `picture`, publish_date FROM b_news ORDER BY publish_date DESC LIMIT ".$limit."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	
	public function getNews($page, $num_per_page)
	{	
		//Cache
		$cacheService = new CacheService("News","getNews", $page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = '1 ';
			$sql = "SELECT count(*) as total FROM b_news t1 WHERE ".$cond."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			//Phân trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			$url_rewrite = Url::createUrl('news/index');
			$url_rewrite1 = $url_rewrite;
			$url_rewrite = str_replace('.html', '', $url_rewrite).'/';
			$paging = Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite1);
			
			$sql = "SELECT `id`, cat_id, `title`, `alias`, `introtext`, `picture`, publish_date, hit, author_name FROM b_news t1 WHERE ".$cond." ORDER BY publish_date DESC LIMIT ".$begin.",".$num_per_page." ";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
		   	
			$a = array($rows, $paging, $total);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	
	//Tin noi bat danh muc(middle)
	public function getHotNews($limit)
	{
		//Cache
		$cacheService = new CacheService("News","getHotNews", $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT `id`, cat_id, `title`, `alias`, `introtext`, `picture`, publish_date, author_name FROM b_news WHERE  is_hot=1 ORDER BY publish_date DESC LIMIT ".$limit."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	public function getViewsNews($limit)
	{
		//Cache
		$cacheService = new CacheService("News","getViewsNews", $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT `id`, `title`, `alias`,cat_id, `introtext`, `picture`, publish_date, author_name FROM b_news ORDER BY hit DESC LIMIT ".$limit."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	//Tin noi bat danh muc(middle)
	public function getHotNewsByCat($cat_id, $sub_cat_id,$limit)
	{
		//Cache
		$cacheService = new CacheService("News","getHotNewsByCat", $cat_id, $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$cond = '1 AND status="active"';
			$cond .= $sub_cat_id!='' ? ' AND cat_id IN ('.$sub_cat_id.')' : '';
			$sql = "SELECT `id`, `title`, `alias`,cat_id, `introtext`, `picture`, publish_date, author_name FROM b_news WHERE ".$cond." AND is_hot=1 ORDER BY publish_date DESC LIMIT ".$limit."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	//Tin duoc nhieu nguoi xem(danh muc)
	public function getViewsNewsByCat($cat_id, $sub_cat_id,$limit)
	{
		//Cache
		$cacheService = new CacheService("News","getHotNewsByCat", $cat_id, $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$cond = '1 AND status="active"';
			$cond .= $sub_cat_id!='' ? ' AND cat_id IN ('.$sub_cat_id.')' : '';
			$sql = "SELECT `id`, `title`, `alias`, cat_id, `introtext`, `picture`, author_name, publish_date FROM b_news WHERE ".$cond." ORDER BY hit DESC LIMIT ".$limit."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	//Tin theo danh muc
	public function getNewsByCat($cat_id,$sub_cat_id, $alias, $page, $num_per_page)
	{	
		//Cache
		$cacheService = new CacheService("News","getHotNewsByCat", $cat_id, $page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = '1 ';
			
			$cond .= $sub_cat_id!='' ? 'AND t1.cat_id IN ('.$sub_cat_id.')' : '';
			
			$sql = "SELECT count(*) as total FROM b_news t1 WHERE ".$cond."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			//Phân trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			$url_rewrite = Url::createUrl('news/cat', array('cat_id'=>$cat_id, 'alias'=>$alias));
			$url_rewrite1 = $url_rewrite;
			$url_rewrite = str_replace('.html', '', $url_rewrite).'/';
			$paging = Paging::show_paging_news($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite1);
			
			$sql = "SELECT `id`, cat_id, `title`, `alias`, `introtext`, `picture`, publish_date, hit, author_name FROM b_news t1 WHERE ".$cond." ORDER BY publish_date DESC LIMIT ".$begin.",".$num_per_page." ";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
		   
			$a = array($rows, $paging, $total);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	
	//1 Tin noi bat danh muc(middle)
	public function getOneHotNewsByCat($cat_id)
	{
		//Cache
		$cacheService = new CacheService("News","getOneHotNewsByCat", $cat_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$sql = "SELECT `id`, `title`, `alias`, `introtext`, `picture`, publish_date, hit FROM b_news WHERE cat_id IN (".$cat_id.") AND is_hot=1 ORDER BY publish_date DESC LIMIT 1";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			Yii::app()->cache->set($key, $row, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row = $cache;
		}           
		return $row;
	}
	//Chi tiet tin
	public function getNewsById($news_id)
	{
		//Cache
		$cacheService = new CacheService("News","getNewsById", $news_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$sql = "SELECT `id`, cat_id, `title`, `alias`, `introtext`, description, `picture`, publish_date, hit, keyword, meta_title, meta_description, meta_keyword, username, author_name FROM b_news WHERE id=".$news_id."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			Yii::app()->cache->set($key, $row, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row = $cache;
		}           
		return $row;
	}
	public function getNewsOtherCat($news_id, $cat_id, $sub_cat_id, $limit)
	{
		$cacheService = new CacheService("News","getNewsOtherCat", $cat_id, $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = '1 AND status="active"';
			$cond .= $sub_cat_id!='' ? ' AND cat_id IN ('.$sub_cat_id.')' : '';
			$sql = "SELECT `id`, cat_id, `title`, `alias`, `picture`, publish_date, username FROM b_news WHERE ".$cond." AND id!=".$news_id." ORDER BY publish_date DESC LIMIT ".$limit."";
			//echo $sql;exit();
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	//Tin lien quan
	public function getRelatedNews($news_id)
	{
		$cacheService = new CacheService("News","getRelatedNews",$news_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$sql = "SELECT `id`, `title`, `alias`, `keyword`, `picture`, `publish_date`, cat_id, author_name FROM b_news WHERE id IN (SELECT related_id FROM b_news_related WHERE news_id='".$news_id."' AND related_id!=0)";
			$connect = Yii::app()->db;
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			$middle = array();
			if($rows)
			foreach($rows as $row)
			{
				$middle[$row['id']]=$row;
			}

			$sql = "SELECT `news_id`, `related_id`, `related_title`, `related_link` FROM b_news_related WHERE news_id='".$news_id."'";
			$connect = Yii::app()->db;
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			$output = array();
			if($rows)
			foreach($rows as $row)
			{
				if($row['related_link']!='') $ouput[]=$row;
				else
				{
					if($row['related_id']!=0)
					{
						$news = isset($middle[$row['related_id']]) ? $middle[$row['related_id']]:array();
						if(!empty($news))
						{
							$news['related_id']=$row['related_id'];
						}
						$output[] = $news;
					}
				}
			}
			
			Yii::app()->cache->set($key,$output,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$output=$cache;
		}
		return $output;
	}
	public function updateHit($news_id)
	{
		$connect = Yii::app()->db;
		$sql = "UPDATE b_news SET hit=hit+1 WHERE id=".$news_id."";
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	//Solr
	public function getSearchSolr($keyword, $page,$num_per_page)
	{
		$cacheService = new CacheService("News","getSearchSolr",$keyword.$page);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			//Ket qua search		
			$output=array();
			$total=0;
			$paging='';
			
			Yii::import('application.vendors.*');
			require_once('solr/Service.php');
			$query = 'content_type:"2" AND (title:"'.$keyword.'" OR title_en:"'.$keyword.'" OR keyword:"'.$keyword.'" OR title:'.$keyword.' OR title_en:'.$keyword.')';
			//echo $query;exit();
			
			$host = Yii::app()->params['hostSolr'];
			$port = '8983';
			$path ='/solr/bds';
			
			$solr = new Apache_Solr_Service($host,$port,$path);
			if(!$solr->ping(5))
			{
				echo 'Khong connect Solr Server: '.$host.' - '.$port.' - '.$path;
				die();
			}
			
			if(get_magic_quotes_gpc() == 1)
			{
				$query = stripcslashes($query);
			}
			
			try
			{
				$start=($page-1)*$num_per_page;
				$params=array("sort" =>"publish_date desc");
				$results = $solr->search($query,$start,$num_per_page,$params);
				//Phan trang
				$total=$results->response->numFound;
				
				$num_page=ceil($total/$num_per_page);
				$iSEGSIZE =9;
				$url = Url::createUrl('search/news',array('keyword'=>str_replace(' ', '-', $keyword)));
				
				$url1=$url;
				$url=str_replace('.html','',$url).'/';
				$paging=Paging::show_paging_profile($num_page,$page,$iSEGSIZE,$url,$url1);//Phan trang
				//End
				$results = $results->response->docs;
				if($results)
				foreach($results as $row)
				{
					$output[]=array('id'=>$row->content_id,'cat_id'=>$row->cat_id, 'title'=>$row->title,'alias'=>$row->alias,'introtext'=>$row->introtext,'keyword'=>$row->keyword,'picture'=>$row->picture,'create_date'=>$row->create_date,'publish_date'=>$row->publish_date);
				}
			}catch(exception $e){
				exit();
			}
			$a=array($output,$paging,$total);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_300);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	
	//Tin theo chuyen de
	public function getNewsByTopic($topic_id, $alias, $page, $num_per_page)
	{	
		//Cache
		$cacheService = new CacheService("News","getNewsByTopic", $topic_id, $page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			
			$sql = "SELECT count(distinct(news_id)) as total FROM b_topic_news WHERE topic_id=".$topic_id."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			//Phân trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			$url_rewrite = Url::createUrl('topic/detail', array('topic_id'=>$topic_id, 'alias'=>$alias));
			$url_rewrite1 = $url_rewrite;
			$url_rewrite = str_replace('.html', '', $url_rewrite).'/';
			$paging = Paging::show_paging_profile($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			
			$sql = "SELECT `id`, `title`, `alias`, `introtext`, `picture`, publish_date, hit FROM b_news WHERE id IN (SELECT news_id FROM b_topic_news WHERE topic_id=".$topic_id.") AND status='active' ORDER BY publish_date DESC LIMIT ".$begin.",".$num_per_page." ";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
		   
			$a = array($rows, $paging, $total);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	
	public function getNewsByCatRss($cat_id,$sub_cat_id,$limit)
	{
		//Cache
		$cacheService = new CacheService("News","getNewsByCatRss", $cat_id, $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT `id`, `title`, `alias`, `introtext`, `picture`, publish_date	 FROM b_news WHERE cat_id IN (".$sub_cat_id.") ORDER BY publish_date DESC LIMIT ".$limit."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	
	public function getNewsByTopicRss($topic_id, $limit)
	{	
		//Cache
		$cacheService = new CacheService("News","getNewsByTopicRss", $topic_id, $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$sql = "SELECT `id`, `title`, `alias`, `introtext`, `picture`, publish_date, hit FROM b_news WHERE id IN (SELECT news_id FROM b_topic_news WHERE topic_id=".$topic_id.") AND status='active' ORDER BY publish_date DESC LIMIT ".$limit."";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
		   
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}
		
		return $rows;
	}
	
	//Search
	public function getNewsBySearch($keyword, $page, $num_per_page)
	{	
		//Cache
		$cacheService = new CacheService("News","getNewsBySearch", $keyword.$page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = '1 AND status="active" AND (title LIKE "%'.$keyword.'%" || meta_keyword LIKE "%'.$keyword.'%")';
			
			//Tong so
			$sql = "SELECT count(*) as total FROM b_news t1 WHERE ".$cond."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			
			//Phân trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			$url_rewrite = Url::createUrl('news/search',array('keyword'=>Common::generate_slug($keyword)));
			$url_rewrite1 = $url_rewrite;
			$url_rewrite = str_replace('.html', '', $url_rewrite).'/';
			$paging = Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite1);
			
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, publish_date, author_name FROM b_news t1 WHERE ".$cond." ORDER BY publish_date DESC LIMIT ".$begin.",".$num_per_page." ";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
		   
			$a = array($rows, $paging, $total);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
}
?>