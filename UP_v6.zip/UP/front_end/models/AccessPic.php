<?php
class AccessPic extends CActiveRecord
{
	public function getPicByAccessId($access_id)
	{
		$connect =Yii::app()->db;
		$sql = "SELECT access_id, picture FROM b_accessories_picture WHERE access_id=".$access_id." ORDER BY id ASC";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
}
?>