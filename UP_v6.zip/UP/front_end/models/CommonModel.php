<?php
class CommonModel extends CActiveRecord
{
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }
   /*Insert*/
	public function insertObject($array_input,$table)
	{
		$sql='';
		foreach($array_input as $key=>$value)
		{
			$sql.=$key."='".$value."',"; 
		}
		$sql='INSERT IGNORE INTO '.$table.' SET '.$sql;
		$sql=rtrim($sql,',');
		$connect = Yii::app()->db;
		$command = $connect->createCommand($sql);
		$command->execute();
		$record_id=Yii::app()->db->getLastInsertID();  
		return $record_id;
	}
	/*Update*/
	public function updateObject($array_input,$key_id,$key_value,$table)
	{
		$sql='';
		foreach($array_input as $key=>$value)
		{
			$sql.=$key."='".$value."',"; 
		}
		$sql=rtrim($sql,',');
		if($sql!='')
		{
			$sql='UPDATE '.$table.' SET '.$sql.' WHERE '.$key_id.'="'.$key_value.'"';
			$connect = Yii::app()->db;
			$command = $connect->createCommand($sql);
			$a=$command->execute();
			return $a;
		}
		return -1;
	}
	/*Update*/
	public function deleteObject($array_input,$table)
	{
		$sql=' 1 ';
		foreach($array_input as $key=>$value)
		{
			$sql.=" AND ".$key."='".$value."'"; 
		}
		$sql=rtrim($sql,',');
		if($sql!='')
		{
			$sql='delete from '.$table.' where '.$sql.'';
			$connect = Yii::app()->db;
			$command = $connect->createCommand($sql);
			$a=$command->execute();
			if($a) return 1;
			else return 0;
		}
		else return 0;
			
	}
	/*Select */
	public function getObject($array_input,$table)
	{
		$connect =Yii::app()->db;
		$sub_sql='1 ';
		foreach($array_input as $key=>$value)
		{
			$sub_sql.=" AND ".$key."='".$value."'";
		}
		$sql="SELECT * FROM ".$table." WHERE ".$sub_sql."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	public function insertMultiObject($sub_sql,$table)
	{
		$connect =Yii::app()->db;
		$sql="INSERT IGNORE INTO ".$table." VALUES ".$sub_sql."";
		$command=$connect->createCommand($sql);
		$a= $command->execute();
		return $a;
	}
	
	public function insertAssignPermis($sub_sql)
	{
		$sql = "REPLACE INTO tbl_front_authassignment(`user_id`, `trainer_id`, `permit_id`, `module_id`, `username`, `permit`, `module`, `create_date`) VALUES ".$sub_sql."";
		$command = Yii::app()->db->createCommand($sql);       
		$result = $command->execute();
		
		$lastId = Yii::app()->db->getLastInsertID();
        return $lastId;
	}
	
	public function deleteAssignPermisByUser($userId)
	{
		$sql = "DELETE FROM tbl_front_authassignment WHERE user_id=:user_id";
		$command = Yii::app()->db->createCommand($sql);
		$command->bindValue(":user_id", $userId, PDO::PARAM_STR);       
		$result = $command->execute();
		
		return $result;
	}
	
	public function getAssginPermisUser($permisId,$userId)
	{
		$sql = "SELECT * FROM tbl_front_authassignment WHERE permit_id=".$permisId." AND user_id=".$userId."";       
        $command = Yii::app()->db->createCommand($sql);
        $rows = $command->queryAll();
           
		$array=array();
		if(!empty($rows)){
			foreach($rows as $row)
			{
				$array[$row['user_id'].'_'.$row['trainer_id'].'_'.$row['permit_id'].'_'.$row['module_id']]=$row;
			}
		}
			
		return $array;
	}
}
?>
