<?php
class Cats extends CActiveRecord
{
	public function getCateById($category_id,$array_category)
	{
		if($array_category)
		{
			foreach($array_category as $row)
			{
				if($row['id']==$category_id)
					return $row;
			}
		}
		return '';

	}
	
	public function getCatInfo($id)
	{
		$connect = Yii::app()->db;
		$sql = "SELECT * FROM b_cat WHERE id=".$id;
		$command = $connect->createCommand($sql);
		$row = $command->queryRow();    

		return $row;
	}
	public function getCatHome()
	{
		$connect = Yii::app()->db;
		$sql = "SELECT * FROM b_cat WHERE is_hot=1 AND status=1 ORDER BY order_hot ASC";
		$command = $connect->createCommand($sql);
		$rows = $command->queryAll();    
		$a=array();
		if($rows)
		foreach($rows as $row)
		{
			$is_child_level3 = 0;
			if($row['parent_id']==0)
			{
				foreach($rows as $row2)
				{
					if($row['id']==$row2['parent_id'])
					{
						foreach($rows as $row3)
						{
							if($row3['parent_id']==$row2['id'])
							{
								$is_child_level3 = 1;
								break;
							}
						}
					}
				}
			}
			$row['is_child_level3'] = $is_child_level3;
			$a[$row['id']]=$row;
		}
		return $a;
	}
	
	public function getCatHomeBottom()
	{
		$connect = Yii::app()->db;
		$sql = "SELECT * FROM b_cat WHERE is_home_bottom=1 AND status=1 ORDER BY order_home_bottom ASC";
		$command = $connect->createCommand($sql);
		$rows = $command->queryAll();    
		$a=array();
		if($rows)
		foreach($rows as $row)
		{
			$is_child_level3 = 0;
			if($row['parent_id']==0)
			{
				foreach($rows as $row2)
				{
					if($row['id']==$row2['parent_id'])
					{
						foreach($rows as $row3)
						{
							if($row3['parent_id']==$row2['id'])
							{
								$is_child_level3 = 1;
								break;
							}
						}
					}
				}
			}
			$row['is_child_level3'] = $is_child_level3;
			$a[$row['id']]=$row;
		}
		return $a;
	}
	
	public function getCatMenu($list_cats)
	{
		$connect = Yii::app()->db;
		$sql = "SELECT * FROM b_cat WHERE is_menu=1 AND status=1 ORDER BY order_menu ASC";
		$command = $connect->createCommand($sql);
		$rows = $command->queryAll();    
		$a=array();
		if($rows)
		foreach($rows as $row)
		{
			$is_child_level3 = 0;
			if($row['parent_id']==0)
			{
				foreach($list_cats as $row2)
				{
					if($row['id']==$row2['parent_id'])
					{
						foreach($list_cats as $row3)
						{
							if($row3['parent_id']==$row2['id'])
							{
								$is_child_level3 = 1;
								break;
							}
						}
					}
				}
			}
			$row['is_child_level3'] = $is_child_level3;
			$a[$row['id']]=$row;
		}
		return $a;
	}
	public function getCats()
	{
		//Cache
		$cacheService = new CacheService("Cats","getCats");
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		$a=array();
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT * FROM b_cat WHERE status=1 ORDER BY order_hot ASC";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			if($rows)
			foreach($rows as $row)
			{
				$is_child_level3 = 0;
				if($row['parent_id']==0)
				{
					foreach($rows as $row2)
					{
						if($row['id']==$row2['parent_id'])
						{
							foreach($rows as $row3)
							{
								if($row3['parent_id']==$row2['id'])
								{
									$is_child_level3 = 1;
									break;
								}
							}
						}
					}
				}
				$row['is_child_level3'] = $is_child_level3;
				$a[$row['id']]=$row;
			}
			
			Yii::app()->cache->set($key, $a, 0);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	
	public function getChildCat($cat_id)
	{
		$cacheService = new CacheService("Cats","getChildCat", $cat_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT * FROM b_cat WHERE parent_id=".$cat_id;
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	
	public function updateSubCat()
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_cat";
		$command=$connect->createCommand($sql);
		$cats = $command->queryAll();
		//Level 1
		foreach($cats as $row)
		{
			if($row['parent_id']==0)
			{
				$list_sub=$row['id'].',';
				foreach($cats as $row2)
				{
					if($row2['parent_id']==$row['id'])
					{
						$list_sub.=$row2['id'].',';
						foreach($cats as $row3)
						{
							if($row3['parent_id']==$row2['id'])
							{
								$list_sub.=$row3['id'].',';
							}
						}
					}
				}
				$list_sub=rtrim($list_sub,',');
				$sql="UPDATE b_cat SET sub_id='".$list_sub."' WHERE id=".$row['id'];
				$command=$connect->createCommand($sql);
				$result = $command->execute();
			}
		}
		//Level 2
		foreach($cats as $row)
		{
			if($row['parent_id']==0)
			{
				foreach($cats as $row2)
				{
					if($row2['parent_id']==$row['id'])
					{
						$list_sub=$row2['id'].',';
						foreach($cats as $row3)
						{
							if($row3['parent_id']==$row2['id'])
							{
								$list_sub.=$row3['id'].',';
							}
						}
						$list_sub=rtrim($list_sub,',');
						$sql="UPDATE b_cat SET sub_id='".$list_sub."',level=2 WHERE id=".$row2['id'];
						$command=$connect->createCommand($sql);
						$result = $command->execute();
					}						
				}
			}
		}
		//Level 3
		$sql="UPDATE b_cat SET sub_id=id WHERE level=3";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
	}
	
	
	public function updateNumProduct()
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_cat";
		$command=$connect->createCommand($sql);
		$cats = $command->queryAll();
		//Cap nhat san pham		
		foreach($cats as $row)
		{
			if($row['cat_type']==1)
			{
				$sub_id = $row['sub_id'];
				if($sub_id!='')
				{
					$sql = "UPDATE b_cat SET num_p=(SELECT count(id) FROM b_camera WHERE cat_id IN (".$sub_id.") AND status='active' AND is_show=1 AND status_new IN (0,1)) WHERE id=".$row['id'];
					$command=$connect->createCommand($sql);
					$result = $command->execute();
				}
			}
		}
		//Cap nhat phu kien
		foreach($cats as $row)
		{
			if($row['cat_type']==3)
			{
				$sub_id = $row['sub_id'];
				if($sub_id!='')
				{
					$sql = "UPDATE b_cat SET num_p=(SELECT count(id) FROM b_accessories WHERE cat_id IN (".$sub_id.") AND status='active') WHERE id=".$row['id'];
					//echo $sql;
					$command=$connect->createCommand($sql);
					$result = $command->execute();
				}
			}
		}
		
	}
}
?>