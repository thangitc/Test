<?php
class AccessColor extends CActiveRecord
{
	public function getAccessColor($access_id)
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_accessories_color WHERE access_id=".$access_id." ORDER BY id ASC";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	public function getAccessColorById($color_id)
	{	
		$connect = Yii::app()->db;
		$sql = "SELECT * FROM b_accessories_color WHERE id=".$color_id."";
		$command = $connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}
?>