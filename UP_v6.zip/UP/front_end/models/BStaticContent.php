<?php
class BStaticContent extends CActiveRecord
{		
	public function getStaticContentById($static_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_static_content WHERE id=".$static_id;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}
?>