<?php
class BBody extends CActiveRecord
{
	public function getBodyByModel($model_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_combo_body WHERE model_id=".$model_id;
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function getBodyById($body_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_combo_body WHERE id=".$body_id;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}
?>