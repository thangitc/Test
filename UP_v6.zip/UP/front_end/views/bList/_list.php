<div class="items full-width list-view elevn c2" data-selenium="items">
    <!-- list of items -->
    <?php
    //$time_sale_expired = mktime(0,0,0, date('m'),date('d'), date('Y'))-86400;
    $time_sale_expired = time()-86400;

    $start_day = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
    $arr_rating = LoadConfig::$arr_rating;
    if($products)
        foreach($products as $row)
        {
            $src_img = Common::getImage($row['picture'], 'camera', '', 'medium');
            $link_detail = Url::createUrl('bList/detail', array('camera_id'=>$row['id'], 'alias'=>$row['alias']));
            if($row['status_new']==0)
                $title_product = $row['title'].' 2nd(#'.$row['seri'].')';
            else
                $title_product = $row['title'];
            $rating_name = isset($arr_rating[$row['rating']]) ? $arr_rating[$row['rating']].'.png' : 'A.png';
            $class = '';
            if($row['is_special']==1) $class = 'new-realese'; //SP sap ve
            if($row['is_special']==2) $class = 'new-arrival'; //SP ban chay
            if($row['is_special']==3) $class = 'on-special'; //SP dang hot
            if($row['is_special']==4) $class = 'top-seller'; //SP gia tot
            if($row['is_special']==5) $class = 'edu-special'; //SP Khuyen mai

            //Qua tang
            $access_free_price_one = isset($access_free_price[$row['id']]) ? $access_free_price[$row['id']]:0;
            ?>
            <div data-selenium="itemDetail" class="item clearfix js-item <?php echo $class;?> js-bhItemObj" itemscope="" itemtype="http://schema.org/Product">
                <div class="img-zone zone" data-selenium="img-zone">
                    <div class="padding"> <a name="image" class="itemImg" href="<?php echo $link_detail;?>" data-selenium="itemImg"> <img data-selenium="imgLoad" src="<?php echo $src_img;?>" itemprop="image" alt="<?php echo $row['title'];?>" height="150" width="150"> </a> </div>
                    <p><a href="<?php echo $link_detail;?>" data-selenium="itemReviews" class="listDetailStars review-stars-medium ten c2">
                            <!--
                             <span class="review-stars">
                            <svg class="review-stars-grey">
                                <use xlink:href="#stars"></use>
                            </svg>
                            <span class="review-stars-inner" style="width:90%;">
                            <svg class="review-stars-green">
                                <use xlink:href="#stars"></use>
                            </svg>
                            </span> </span>
                            -->
                            <img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_name;?>" />
                        </a>
                    </p>
                </div>
                <div class="desc-zone zone" data-selenium="itemInfo-zone">
                    <div class="headder sect clearfix" data-selenium="itemHeader">
                        <h3 data-selenium="itemHeading" class="bold fourteen"> <a href="<?php echo $link_detail;?>" class="c5" data-selenium="itemHeadingLink" itemprop="url"> <?php echo $title_product;?></a> </h3>
                        <!--<p class="skus full-width c1 left" data-selenium="skus"> <span>B&amp;H # <span class="sku" data-selenium="sku">SOA7S2</span></span> <span class="mfrBullet">MFR # <span class="sku" data-selenium="sku">ILCE7SM2/B</span></span> </p>-->
                        <p class="src right twelve bold" data-selenium="itemSrc"> <span></span> </p>
                    </div>
                    <div class="sect highlights" data-selenium="highlights">
                        <div class="sellingPoints">
                            <h4 class="sellingPointsTitle show-for-standard-res-only">Thông tin nổi bật</h4>
                            <?php
                            $model_info = isset($models[$row['model_id']]) ? $models[$row['model_id']] : array();
                            if($row['status_new']==1)
                            {
                                if(!empty($model_info)) echo $model_info['introtext']; else echo $row['introtext'];
                            }
                            if($row['status_new']==0)
                            {
                                if($row['introtext']!='')
                                    echo $row['introtext'];
                                else if(!empty($model_info))
                                    echo $model_info['introtext'];
                                else
                                    echo '';
                            }
                            ?>
                        </div>
                    </div>
                    <div class="sect add-info twelve" data-selenium="itemSection">
                        <!-- Sales Comments -->
                        <div class="salesComments scAvailability_scShipTime clearfix " data-selenium="salesComments">
                            <p class="scAvailability fs11" data-selenium="CommentAvailability"> <strong class="c2">Trạng thái: </strong> <span class="upper c5 bold " data-selenium="popoverContent">
                                <?php
                                if($row['is_sale']==1)
                                    echo '<strong style="color:#990000">Hết hàng</strong>';
                                else if($row['is_sale']==0)
                                    echo 'Còn hàng';
                                else echo '<strong style="color:#018D72">Order</strong>';
                                ?>
                                </span>
                            </p>
                            <p class="scAvailability fs11" style="width:100%; float:right;"><?php if($row['status_new']==0) { ?>Bảo hành:<strong><?php echo $row['time_bh'];?></strong><?php }?></p>
                        </div>

                    </div>
                </div>
                <div class="conversion-zone zone" data-selenium="conversion-zone">
                    <div class="price-zone " data-selenium="price-zone">
                        <?php
                        if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired)
                        {
                            $price_deal_show = $row['price'];
                            $price_deal = $row['price_sale'];
                            $saving = Common::formatNumber($price_deal_show-$price_deal);
                            ?>
                            <div data-selenium="prices" class="prices">
                                <p> Giá: <span> <?php echo Common::formatNumber($price_deal_show);?> VND </span> </p>
                                <p> Giảm giá: <span class="c7"> <?php echo $saving;?> VND </span> </p>
                                <?php
                                if($access_free_price_one!=0)
                                {
                                    ?>
                                    <p> Quà tặng kèm trị giá: <span class="c7"> <?php echo Common::formatNumber($access_free_price_one);?> VND </span> </p>
                                    <?php
                                }
                                ?>
                            </div>

                            <div class="atc-price " data-selenium="addToCartPrice">
                                <p data-selenium="finalPrice" class="clearfix twelve"> <span class="youpay">Giá KM: </span> <span data-selenium="price" class="price  bold sixteen c7"><?php echo Common::formatNumber($row['price_sale']);?> VND</span> </p>
                                <p>Thời gian KM: <?php echo date('d/m/Y', $row['time_sale']);?></p>
                            </div>
                            <?php
                        }
                        else
                        {
                            ?>
                            <div data-selenium="prices" class="prices"> </div>
                            <div class="atc-price " data-selenium="addToCartPrice">
                                <p data-selenium="finalPrice" class="clearfix twelve"> <span class="youpay">Giá: </span> <span data-selenium="price" class="price  bold sixteen c7"><?php echo Common::formatNumber($row['price']);?> VND</span> </p>
                                <?php
                                if($access_free_price_one!=0)
                                {
                                    ?>
                                    <p> Quà tặng kèm trị giá: <span class="c7"> <?php echo Common::formatNumber($access_free_price_one);?> VND </span> </p>
                                    <?php
                                }
                                ?>
                            </div>
                            <?php
                        }

                        ?>

                        <div class="atc-zone clearfix" data-selenium="addToCartZone">
                            <div class="acMapMessageCont clearfix"> </div>
                            <!--
                                <form class="clearfix submitToOnePopup" action="<?php echo Url::createUrl('bList/addCart');?>" method="post">
                                    <input id="qty<?php echo $row['id'];?>" value="1" class="qty-box js-mqQty" data-mq="3" type="text">
                                    <button type="button" onclick="addCart(<?php echo $row['id'];?>, 0, $('#qty<?php echo $row['id'];?>').val(),<?php if($row['price_sale']!=0 && $row['time_sale']!=0  && $row['time_sale']>=$time_sale_expired) echo $row['price_sale']; else echo $row['price'];?>);" class="addToCart right blueBtn cursor-pointer pill-shaped-button fs14 one-line"><?php if($row['is_sale']==2) echo 'Preorder'; else echo 'Thêm vào giỏ hàng';?></button>
                                    <a href="<?php echo Url::createUrl('bList/cart');?>" data-selenium="inCartBtn" class="right inCart inc-btn  pill-shaped-button whiteBlueBtn fs14 ">Giỏ hàng</a>
                                </form>
                                -->
                            <button onclick="window.location.href='<?php echo $link_detail;?>';" style="width:100%;" class="addToCart right blueBtn cursor-pointer pill-shaped-button fs14 one-line">Xem chi tiết</button>
                        </div>
                    </div>

                </div>
            </div>
            <?php
        }

    ?>

</div>