<div class="items full-width grid-view clearfix" data-selenium="items">
    <!-- list of items -->
    <?php
    //$time_sale_expired = mktime(0,0,0, date('m'),date('d'), date('Y'))-86400;
    $time_sale_expired = time()-86400;

    $start_day = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
    $arr_rating = LoadConfig::$arr_rating;
    if($products)
    foreach($products as $row)
    {
        $src_img = Common::getImage($row['picture'], 'camera', '', 'medium');
        $link_detail = Url::createUrl('bList/detail', array('camera_id'=>$row['id'], 'alias'=>$row['alias']));
        if($row['status_new']==0)
            $title_product = $row['title'].' 2nd(#'.$row['seri'].')';
        else
            $title_product = $row['title'];
        $rating_name = isset($arr_rating[$row['rating']]) ? $arr_rating[$row['rating']].'.png' : 'A.png';
        $class = '';
        if($row['is_special']==1) $class = 'new-realese'; //SP sap ve
        if($row['is_special']==2) $class = 'new-arrival'; //SP ban chay
        if($row['is_special']==3) $class = 'on-special'; //SP dang hot
        if($row['is_special']==4) $class = 'top-seller'; //SP gia tot
        if($row['is_special']==5) $class = 'edu-special'; //SP Khuyen mai

        //Qua tang
        $access_free_price_one = isset($access_free_price[$row['id']]) ? $access_free_price[$row['id']]:0;

        ?>
        <div class="item clearfix js-item elevn new-realese js-bhItemObj" itemscope="" itemtype="http://schema.org/Product" style="height: 400px;">
            <div class="img-zone " data-selenium="img-zone">
                <div class="padding"> <a name="image" class="itemImg" href="<?php echo $link_detail;?>" data-selenium="itemImg"> <img data-selenium="imgLoad" src="<?php echo $src_img;?>" itemprop="image" alt="<?php echo $row['title'];?>" width="150" height="150"> </a> </div>
                <div class="js-reviewCont" data-selenium="reviewCont" style="height: 36px;"> 
                    <?php
                    $rating_name = isset($arr_rating[$row['rating']]) ? $arr_rating[$row['rating']].'' : 'A';
                    $rating_img_name = $rating_name.'.png';
                    ?>
                        <img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_img_name;?>" />
                </div>
                <h3 data-selenium="itemHeading" class="bold twelve js-itemHeading" style="height: 54px;"> <a href="<?php echo $link_detail;?>" class="c5" data-selenium="itemHeadingLink" itemprop="url" title="<?php echo $title_product;?>"> <span itemprop="name"><?php echo $title_product;?></span> </a> </h3>
                
            </div>
            <div class="" data-selenium="itemInfo-zone">
                <div class="js-similarItemCont" data-selenium="similarItemCont" style="height: 0px;"> </div>
            </div>
            <div class="conversion-zone" data-selenium="conversion-zone">
                <div class="price-zone " data-selenium="price-zone">
                    <div class="prices js-prices" data-selenium="prices" style="height: 0px;"> </div>
                    <div class="js-atc-price" data-selenium="addToCartPrice" style="height: <?php if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired) echo 40; else echo 20;?>px;">
                        <div class="atc-price " data-selenium="addToCartPrice">
                        <?php
                        if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired)
                        {
                            $price_deal_show = $row['price'];
                            $price_deal = $row['price_sale'];
                            $saving = Common::formatNumber($price_deal_show-$price_deal);
                            ?>
                            <p data-selenium="finalPrice" class="clearfix therteen  bold c7  ">
                                <span class="youpay" data-selenium="youpayPrice">Giá Khuyến Mại: </span>
                                <span data-selenium="price" class="price "> <?php echo Common::formatNumber($price_deal);?> VND </span>
                            </p>
                            <p class="left ten c2 Savings">
                                <span>
                                    Giảm giá: <?php echo $saving;?> VND
                                </span>
                            </p>
                            <p class="left ten c2 Savings">
                                <span>
                                    Thời gian KM: <?php echo date('d/m/Y', $row['time_sale']);?>
                                </span>
                            </p>
                            <?php
                            /*
                            if($access_free_price_one!=0)
                            {
                                ?>
                                <p> Quà tặng kèm trị giá: <span class="c7"> <?php echo Common::formatNumber($access_free_price_one);?> VND </span> </p>
                                <?php
                            }
                            */
                        }
                        else
                        {
                            ?>
                            <p data-selenium="finalPrice" class="clearfix therteen  bold c7  "> <span class="youpay" data-selenium="youpayPrice">Giá: </span> <span data-selenium="price" class="price "> <?php echo Common::formatNumber($row['price']);?> VND </span> </p>
                            <?php
                            /*
                            if($access_free_price_one!=0)
                            {
                                ?>
                                <p> Quà tặng kèm trị giá: <span class="c7"> <?php echo Common::formatNumber($access_free_price_one);?> VND </span> </p>
                                <?php
                            }
                            */
                        }

                        ?>
                        </div>
                    </div>
                    <div class="atc-zone clearfix" data-selenium="addToCartZone">
                    	
                        <div class="js-acMapMessageCont" data-selenium="MapMessageCont" style="height: 20px;">
                            <div class="acMapMessageCont clearfix c7"> </div>
                        </div>
                        <!--
                        <div class="rebatesCont js-rebatesCont" data-selenium="rebatesCont" style="height: 61px;">
                            <div class="rebateLinks clearfix"> </div>
                        </div>
                        -->
                        <span class="upper c5 bold  left inStock underline-on-hover cursor-pointer js-popover-opener" title="">                        

                        <?php
                        if($row['is_sale']==1)
                            echo '<strong style="color:red;">Hết hàng</strong>';
                        else if($row['is_sale']==0)
                            echo 'Còn hàng';
                        else echo 'Order';
                        ?>
                        </span>
                        <button type="button" onclick="window.location.href='<?php echo $link_detail;?>';" data-selenium="submitBtn" class="addToCart right blueBtn cursor-pointer atc-btn fs11 bold one-line">Xem chi tiết</button>
                            
                    </div>
                </div>
            </div>
            
        </div>
        <?php
    }
    
    ?>
    
</div>