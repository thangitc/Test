<div id="sidebar-second" class="column sidebar">
    <div class="section">
        <div class="region region-sidebar-second">
            <div id="block-views-recently-discussed-block" class="block block-views">
                <h2>Tin nổi bật</h2>
                <div class="content">
                    <div class="view view-recently-discussed view-id-recently_discussed view-display-id-block three-ho view-dom-id-ba43c7b1c49a396e58cdfb5b82ed2746">
                        <div class="view-content">
                        <?php
						$k=0;
						if(!empty($hots))
						foreach($hots as $row)
						{
							$src_img = Common::getImage($row['picture'], 'news', '', 'small');
							$link_detail = Url::createUrl('news/detail', array('news_id'=>$row['id'], 'alias'=>$row['alias']));
							$row_cat = isset($cats[$row['cat_id']]) ? $cats[$row['cat_id']] : array();
							$cat_title = isset($row_cat['title']) ? $row_cat['title'] : '';
							$link_cat = !empty($row_cat) ? Url::createUrl('news/cat',array('cat_id'=>$row_cat['id'], 'alias'=>$row_cat['alias'])) : '';
							
							$k++;
							if($k%2!=0) $class = 'views-row-odd';
							else	$class = 'views-row-even';
							?>                            
                            <div class="views-row <?php echo $class;?> clearfix">
                                <div class="views-field views-field-field-top-shot">
                                    <div class="field-content">
                                        <div class="top-shot-280"><a href="<?php echo $link_detail;?>"><img src="<?php echo $src_img;?>"></a></div>
                                    </div>
                                </div>
                                <div class="views-field views-field-php"> <span class="field-content"><a href="<?php echo $link_cat;?>"><?php echo $cat_title;?></a></span> </div>
                                <div class="views-field views-field-title"> <span class="field-content"><a href="<?php echo $link_detail;?>"><?php echo $row['title'];?></a></span> </div>
                                <?php if($row['author_name']!='') {?>
                                <div class="views-field views-field-field-display-author">
                                    <div class="field-content">by <a href="javascript:" rel="nofollow" class="username"><?php echo $row['author_name'];?></a></div>
                                </div>
                                <?php } ?>
                                <div class="views-field views-field-field-updated-date">
                                    <div class="field-content"><span class="date-display-interval"><em class="placeholder"><?php echo date('d/m/Y', $row['publish_date']);?></em></span></div>
                                </div>
                            </div>
							<?php
						}
						?>
                        </div>
                    </div>
                </div>
            </div>
            <div id="block-views-category-pages-sidebar-block-1" class="block block-views">
                <h2>Tin xem nhiều</h2>
                <div class="content">
                    <div class="view view-category-pages-sidebar view-id-category_pages_sidebar view-display-id-block_1 three-ho view-dom-id-4b32cca8994b285436b0ff9f530a4207">
                        <div class="view-content">
                        <?php
						$k=0;
						if(!empty($views))
						foreach($views as $row)
						{
							$src_img = Common::getImage($row['picture'], 'news', '', 'small');
							$link_detail = Url::createUrl('news/detail', array('news_id'=>$row['id'], 'alias'=>$row['alias']));
							$row_cat = isset($cats[$row['cat_id']]) ? $cats[$row['cat_id']] : array();
							$cat_title = isset($row_cat['title']) ? $row_cat['title'] : '';
							$link_cat = !empty($row_cat) ? Url::createUrl('news/cat',array('cat_id'=>$row_cat['id'], 'alias'=>$row_cat['alias'])) : '';
							
							$k++;
							if($k%2!=0) $class = 'views-row-odd';
							else	$class = 'views-row-even';
							?>                            
                            <div class="views-row <?php echo $class;?> clearfix">
                                <div class="views-field views-field-field-top-shot">
                                    <div class="field-content">
                                        <div class="top-shot-280"><a href="<?php echo $link_detail;?>"><img src="<?php echo $src_img;?>"></a></div>
                                    </div>
                                </div>
                                <div class="views-field views-field-php"> <span class="field-content"><a href="<?php echo $link_cat;?>"><?php echo $cat_title;?></a></span> </div>
                                <div class="views-field views-field-title"> <span class="field-content"><a href="<?php echo $link_detail;?>"><?php echo $row['title'];?></a></span> </div>
                                <?php if($row['author_name']!='') {?>
                                <div class="views-field views-field-field-display-author">
                                    <div class="field-content">by <a href="javascript:" rel="nofollow" class="username"><?php echo $row['author_name'];?></a></div>
                                </div>
                                <?php } ?>
                                <div class="views-field views-field-field-updated-date">
                                    <div class="field-content"><span class="date-display-interval"><em class="placeholder"><?php echo date('d/m/Y', $row['publish_date']);?></em></span></div>
                                </div>
                            </div>
							<?php
						}
						?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>