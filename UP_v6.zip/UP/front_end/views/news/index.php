<div class="outerpagewrap">
    <div class="pagewrap">
        <div class="pagecontent">
            <div class="pagecontentContent">
                <h1>Tin tức</h1>
                <p><a href="<?php echo Yii::app()->params['baseUrl'];?>">Camera</a> » Tin tức</p>
            </div>
            <div class="homeIcon"><a href="<?php echo Yii::app()->params['baseUrl'];?>"></a></div>
        </div>
    </div>
</div>
<div id="mainwrap">
    <div id="main" class="clearfix">
        <div class="pad"></div>
        <div class="content blog">
			<?php
            $cats =  $this->array_category;
            if(!empty($news))
            foreach($news as $row)
            {
                $src_img = Common::getImage($row['picture'], 'news', '');
				$link_detail = Url::createUrl('news/detail', array('news_id'=>$row['id'], 'alias'=>$row['alias']));
				$row_cat = isset($cats[$row['cat_id']]) ? $cats[$row['cat_id']] : array();
				?>
				
				<div class="blogpostcategory">
					<a class="overdefultlink" href="<?php echo $link_detail;?>">
						<div style="display: none;" class="overdefult"> </div>
					</a>
					<div class="blogimage">
						<div class="loading"></div>
						<a href="<?php echo $link_detail;?>" rel="bookmark" title="Permanent Link to <?php echo $row['title'];?>"><img src="<?php echo $src_img;?>" class="attachment-blog wp-post-image" alt="photography equipment" height="390" width="800"></a> </div>
					<div class="bottomborder"></div>
					<div class="entry">
						<div class="leftholder">
							<div class="blogAuthor"> 
								<!--
								<a href="http://camy.premiumcoding.com/author/admin/"><img alt="admin" src="News%20_%20Camy_files/admin_avatar-64x64.png" class="avatar avatar-64 photo" height="64" width="64"></a>
								-->
								<?php if($row['author_name']!='') { ?>
								<div class="authorBlogName"> <strong>By:</strong> <a href="javascript:" title="Posts by <?php echo $row['author_name'];?>" rel="author"><?php echo $row['author_name'];?></a> </div>
                                <?php } ?>
							</div>
							<div class="blogIcon">
								<div class="blogIconDefault"></div>
							</div>
						</div>
						<div class="meta">
							<div class="topLeftBlog">
								<h2 class="title"><a href="<?php echo $link_detail;?>" rel="bookmark" title="Permanent Link to <?php echo $row['title'];?>"><?php echo $row['title'];?></a></h2>
								<div class="posted-date"> <strong>Ngày: </strong> <a href="javascript:" rel="nofollow"><?php echo date("d/m/Y", $row['publish_date']);?></a> </div>
								<div class="categoryblog">
									<strong>Danh mục:</strong>
									<?php
									if(!empty($row_cat))
									{
										$link_cat = Url::createUrl('news/cat', array('cat_id'=>$row_cat['id'], 'alias'=>$row_cat['alias']));
										?>
										<a href="<?php echo $link_cat;?>" title="<?php echo $row_cat['title'];?>"><?php echo $row_cat['title'];?></a>
										<?php
									}
									?>
								</div>
							</div>
							
							<div class="blogContent">
								<div class="blogcontent"><?php echo $row['introtext'];?></div>
								<a class="blogmore" href="<?php echo $link_detail;?>">Read more →</a>
							</div>
						</div>
					</div>
				</div>
				<?php
            }
            ?>
            <?php if(!empty($news)) {?>
            <div class="wp-pagenavi">
            	<span class="pages">Page <?php echo $page;?> of <?php echo $total;?></span>
                <?php echo $paging;?>
            </div>
            <?php }else {?>
            	<strong>Không tìm thấy kết quả!</strong>
            <?php } ?>
        </div>
        <?php $this->renderPartial("_right", array('cats'=>$cats, 'hots'=>$hots, 'views'=>$views));?>
    </div>
</div>