<div id="above_main">
    <div class="region region-above-main">
        <div id="block-superfish-1" class="block block-superfish">
            <div class="content">
                <ul id="superfish-1" class="menu sf-menu sf-menu-bar-nav sf-horizontal sf-style-none sf-total-items-9 sf-parent-items-7 sf-single-items-2 superfish-processed sf-js-enabled">
                <?php if(!empty($cat_info)) {?>
                <li class="middle even sf-item-2 sf-depth-1 sf-total-children-5 sf-parent-children-0 sf-single-children-5 menuparent">
                	<a href="<?php echo Url::createUrl('news/cat', array('cat_id'=>$cat_info['id'], 'alias'=>$cat_info['alias']));?>" title="Tin tức máy ảnh, công nghệ" class="sf-depth-1 menuparent">Tất cả</a>
                </li>
                <?php } ?>
                <?php
                $cats = $this->array_category;
				if($cats)
				foreach($cats as $row)
				{
					if($row['cat_type']==2 && $row['level']==2)
					{
						$link_news = Url::createUrl('news/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
						?>
						<li class="middle even sf-item-2 sf-depth-1 sf-total-children-5 sf-parent-children-0 sf-single-children-5 menuparent">
							<a href="<?php echo $link_news; ?>" title="<?php echo $row['title'];?>" class="sf-depth-1 menuparent"><?php echo $row['title'];?></a>
							<ul class="sf-hidden" style="float: none; width: 12em;">
							<?php
							$k=0;
							foreach($cats as $row2)
							{
								if($row2['parent_id']==$row['id'])
								{
									$link_news_child = Url::createUrl('news/cat', array('cat_id'=>$row2['id'], 'alias'=>$row2['alias']));
									if($k%2==0) $class = 'odd';
									else $class = 'even';
									?>
									<li style="white-space: normal; float: left; width: 100%;" class="<?php echo $class;?> sf-item-1 sf-depth-2 sf-no-children"><a style="float: none; width: auto;" href="<?php echo $link_news_child; ?>" title="<?php echo $row2['title'];?>" class="sf-depth-2"><?php echo $row2['title'];?></a></li>
									<?php
									$k++;
								}
							}
							?>
							</ul>
						</li>
						<?php
					}
				}
                ?>
                </ul>
            </div>
        </div>
    </div>
</div>