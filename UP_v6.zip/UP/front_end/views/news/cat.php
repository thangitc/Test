<div class="mPage">
    <?php $this->renderPartial("_menu", array('cat_info'=>$cat_info));?>
    <!--      <div id="breadcrumb"><h2 class="element-invisible">You are here</h2><div class="breadcrumb"><a href="/explora/">Home</a> » <a href="/explora/photography">Photography</a></div></div>
-->
    <div id="main-wrapper">
    	<?php
		$ads_cat = Ads::getAdsCatByPos($cat_id, 1);
		if($ads_cat)
		{
			$src_img = Common::getImage($ads_cat['picture'], 'ads', '');
			?>
            <div class="bg-outer">
                <a style="text-align: center" class="overlay-on-hover" href="<?php echo $ads_cat['ads_link'];?>"> <img style="vertical-align: bottom; max-width: 100%;" src="<?php echo $src_img;?>"> </a>
            </div>
			<?php
		} 
		else
		{
			?>
            <div class="bg-outer">
                <div class="bg-inner"></div>
            </div>
            <?php
		}
		?>
        
        <div id="main" class="clearfix">
            <div id="content" class="column clearfix">
                <div class="section"> <a id="main-content"></a>
                    <!---->
                    <h1 class="title" id="page-title"><?php echo $cat_info['title'];?></h1>
                    <div class="tabs edit-content"></div>
                    <div class="region region-content">
                        <div id="block-system-main" class="block block-system">
                            <div class="content">
                                <div class="view view-regular-categories view-id-regular_categories view-display-id-dynamic_background_2 view-dom-id-f496f3df29eee304c46d491863615c4e">
                                    <div class="view-header"> <?php echo $cat_info['title'];?> </div>
                                    <div class="view-content">
                                    <?php
									$k=0;
									$cats =  $this->array_category;
									if(!empty($news))
									foreach($news as $row)
									{
										$src_img = Common::getImage($row['picture'], 'news', '');
										$link_detail = Url::createUrl('news/detail', array('news_id'=>$row['id'], 'alias'=>$row['alias']));
										$row_cat = isset($cats[$row['cat_id']]) ? $cats[$row['cat_id']] : array();
										$cat_title = isset($row_cat['title']) ? $row_cat['title'] : '';
										$link_cat = !empty($row_cat) ? Url::createUrl('news/cat',array('cat_id'=>$row_cat['id'], 'alias'=>$row_cat['alias'])) : '';
										$k++;
										if($k%2!=0) $class = 'views-row-odd';
										else	$class = 'views-row-even';
										?>
                                        <div class="views-row <?php echo $class;?>">
                                            <div class="views-field views-field-field-top-shot">
                                                <div class="field-content"><a href="<?php echo $link_detail;?>"><center><img src="<?php echo $src_img;?>" style="max-width:900px;" alt="<?php echo $row['title'];?>"></center></a></div>
                                            </div>
                                            <div class="views-field views-field-php"> <span class="field-content"><a href="<?php echo $link_cat;?>"><?php echo $cat_title;?></a></span> </div>
                                            <div class="views-field views-field-title"> <span class="field-content"><a href="<?php echo $link_detail;?>"><?php echo $row['title'];?></a></span> </div>
                                            <?php if($row['author_name']!='') { ?>
                                            <div class="views-field views-field-field-display-author">
                                                <div class="field-content">by <span class="auth-name"><a href="javascript:" rel="nofollow" class="username"><?php echo $row['author_name'];?></a></span></div>
                                            </div>
                                            <?php } ?>
                                            <div class="views-field views-field-field-updated-date">
                                                <div class="field-content"><span class="date-display-interval"><em class="placeholder"><?php echo date('d/m/Y', $row['publish_date']);?></em> </span></div>
                                            </div>
                                            <!--
                                            <div class="views-field views-field-comment-count"> <span class="field-content">
                                                <div class="share-widget" data-nid="29096">
                                                    <ul>
                                                        <li class="s-comments-button"> <a class="comment-button" href="<?php echo Yii::app()->params['baseUrl']; ?>/explora/node/29096#comments"> <span class="bs-comment">&nbsp;</span> <span class="comment-counts">0</span> </a> </li>
                                                    </ul>
                                                </div>
                                                </span>
                                            </div>
                                            -->
                                            <div class="views-field views-field-body"> <span class="field-content">
                                            	<?php echo $row['introtext'];?>
                                            </span> </div>
                                            <div class="views-field views-field-body-1">
                                                <div class="field-content"></div>
                                            </div>
                                            <div class="views-field views-field-addtoany-link"> <span class="field-content"><span style="line-height: 16px;" class="a2a_kit a2a_target addtoany_list" id=""> <a class="comments-button" href="#comments"> <span class="bs-comment">&nbsp;</span> <span class="comment-count"></span> </a> <a rel="nofollow" href="<?php echo Yii::app()->params['baseUrl']; ?>/#twitter" target="_blank" class="a2a_button_twitter a2a_counter twitter-button"> <span class="bs-twitter">&nbsp;</span> </a> <a rel="nofollow" href="<?php echo Yii::app()->params['baseUrl']; ?>/#facebook" target="_blank" class="a2a_button_facebook a2a_counter"> <span class="bs-facebook">&nbsp;</span> <span style="line-height: 16px; height: 16px; width: 32px; font-size: 8px; border-radius: 2px;" class="a2a_count"><span>0</span></span></a> <a rel="nofollow" target="_blank" class="a2a_button_email" href="<?php echo Yii::app()->params['baseUrl']; ?>/#email"> <span class="bs-email">&nbsp;</span> </a> <a class="print-button" href="javascript:window.print()"> <span class="bs-print">&nbsp;</span> </a> <a href="https://www.addtoany.com/share#url=<?php echo $link_detail;?>&amp;title=<?php echo $row['title'];?>&amp;description=" class="a2a_dd"> <span class="bs-share">&nbsp;</span> </a> </span>
                                                </span> </div>
                                        </div>
                                        <?php
										$k++;
									}
                                    ?>
                                    </div>
                                    <?php if($news) { ?>
                                    <h2 class="element-invisible">Pages</h2>
                                    <div class="item-list">
                                        <?php echo $paging;?>
                                    </div>
                                    <?php } ?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.section, /#content -->
            <div id="content-bottom">
                <div class="section"> </div>
            </div>
            <!-- /.section, /#content-bottom -->
            <?php $this->renderPartial("_right", array('cats'=>$cats, 'hots'=>$hots, 'views'=>$views));?>
            <!-- /.section, /#sidebar-second -->
        </div>
    </div>
    <!-- /#main, /#main-wrapper -->
</div>