<script>
function addCart(product_id, product_type, qty, price)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addCart');?>',
		type: "POST",
		data:({
			product_id:product_id,
			product_type:product_type,
			qty:qty,
			price:price
		}),
		success: function(resp){
			if(resp['error']==1)
			{
				alert('Thêm sản phẩm vào giỏ hàng thành công!');
				//window.location.href='<?php echo Url::createUrl('cart/index');?>';
				location.reload();
				return false;
			}
			else
			{
				alert('Thêm vào giỏ hàng lỗi!');
				return false;
			}
		}
	});
}
function addCart2(product_id, product_type, qty, price)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addCart');?>',
		type: "POST",
		data:({
			product_id:product_id,
			product_type:product_type,
			qty:qty,
			price:price
		}),
		success: function(resp){
			if(resp['error']==1)
			{
				window.location.href='<?php echo Url::createUrl('cart/index');?>';
				return false;
			}
			else
			{
				alert('Thêm vào giỏ hàng lỗi!');
				return false;
			}
		}
	});
}
function clearCart()
{
	if(confirm('Bạn có chắc chắn muốn xóa tất cả giỏ hàng?'))
	{
		$.ajax({
			url: '<?php echo Url::createUrl('ajax/clearCart');?>',
			type: "POST",
			data:({
				status:1
			}),
			success: function(resp){
				window.location.href='<?php echo Url::createUrl('home/index');?>';
	
			}
	
		});
	}
}
function updateCart()
{
	$('#form_cart').submit();
}

function removeOneCart(product_id, product_type)
{
	if(confirm('Bạn có chắc chắn muốn xóa sản phẩm khỏi giỏ hàng?'))
	{
		$.ajax({
			url: '<?php echo Url::createUrl('ajax/removeOneCart');?>',
			type: "POST",
			data:({
				product_id:product_id,
				product_type:product_type
			}),
	
			success: function(resp){
				window.location.href='<?php echo Url::createUrl('cart/index');?>';
			}
	
		});
	}
}
function checkOutCart()
{
	var billing_name = $('#billing_name').val();
	var billing_mobile = $('#billing_mobile').val();
	var billing_email = $('#billing_email').val();
	var billing_address = $('#billing_address').val();
	var billing_note = $('#billing_note').val();
	if(billing_name=='')
	{
		alert('Vui lòng nhập họ tên người đặt hàng');
		$('#billing_name').focus();
		return false;
	}
	if(billing_mobile=='')
	{
		alert('Vui lòng nhập số điện thoại để tiện liên hệ');
		$('#billing_mobile').focus();
		return false;
	}
	if(billing_address=='')
	{
		alert('Vui lòng nhập địa chỉ nhận hàng');
		$('#billing_address').focus();
		return false;
	}
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/checkOutCart');?>',
		type: "POST",
		data:({
			billing_name:$('#billing_name').val(),
			billing_address:$('#billing_address').val(),
			billing_email:$('#billing_email').val(),
			billing_mobile:$('#billing_mobile').val(),
			billing_note:$('#billing_note').val()
		}),
		success: function(resp){
			if(resp['status']==0)
			{
				$('#checkout_result').html(resp['error']);
			}
			else
			{
				$('#checkout_result').html(resp['error']);
				window.location.href='<?php echo Url::createUrl('cart/complete');?>';
			}
		}
	});
}

</script>