<div id="cartWrapper" class="borderBoxBlock clearfix" data-selenium="cartWrapper" data-itemsincart="2">
    <div class="cart-items">
        <div id="cartMessages" class="clearfix" data-selenium="cartMessages">

        </div>
        <!-- start bundled item - ADM -->
        <!-- end bundled item - ADM -->
        <?php
        $total_prices = 0;
        if ($camera) {
            foreach ($camera as $row) {
                $src_img = Common::getImage($row['picture'], 'camera', '', 'small');
                $link_detail = Url::createUrl('bList/detail', array('camera_id' => $row['id'], 'alias' => $row['alias']));
                $product_type = $row['title'];
                list($is_combo, $row_combo) = Combos::checkComboProduct($row['id'], 0, $list_model);
                ?>
                <div class="itemInCart js-cartItem" data-selenium="itemInCart">
                    <div class="table">
                        <div class="table-row">
                            <div class="item-details">
                                <div class="table">
                                    <div class="item-image">
                                        <!--item image-->
                                        <span class="itemImg" data-selenium="itemImg"> <a target="_blank"
                                                                                          href="<?php echo $link_detail; ?>"
                                                                                          data-selenium="smallImgLink"><img
                                                        data-selenium="smallImgItemLink" src="<?php echo $src_img; ?>"
                                                        alt="<?php echo $row['title']; ?>" border="0"></a> </span>
                                        <!--end item image-->
                                    </div>
                                    <!-- END .table-cell.item-image -->
                                    <div class="table-row">
                                        <div class="item-title"><a class="itemName underline-on-hover c31 bold fs16"
                                                                   data-selenium="itemName"
                                                                   href="<?php echo $link_detail; ?>"><?php echo $row['title']; ?></a>

                                        </div>
                                        <!-- END .table-cell.item-title -->
                                        <div class="stock-msg">
                                            <p class="bold c41"> <span class="c29 fs16 bold" data-selenium="inStock"><?php
                                                    if ($row['is_sale'] == 0) echo 'Còn hàng';
                                                    else if ($row['is_sale'] == 1) echo 'Hết hàng';
                                                    else echo 'Order';
                                                    ?>
                                                        </span></p>
                                            <p class="fs11"></p>
                                        </div>
                                        <div class="item-qty">
                                                        <span class="qty qty-input-wrap">
                                                            <input class="input js-qty-input" maxlength="3" size="2"
                                                                   value="<?php echo $row['qty']; ?>"
                                                                   name="qty<?php echo $row['id']; ?>_0" data-mq="50"
                                                                   type="text">
                                                            <input type="hidden" value="<?php echo $row['id']; ?>"
                                                                   name="product_id<?php echo $row['id']; ?>_0"/>
                                                            <a href="javascript:"
                                                               class="update-qty js-update-qty displayNone fs13 underline-on-hover c5"
                                                               onclick="$('#form_cart').submit();">Update</a>
														</span>
                                        </div>
                                        <!-- END .table-cell.item-qty -->
                                        <div class="item-price">
                                                        <span class="">
                                                        	<?php
                                                            if ($row['time_sale'] != 0 && $row['time_sale'] >= $time_sale_expired && $row['price_sale'] != 0) //if($row['time_sale']!=0 && $row['price_sale']!=0)
                                                            {
                                                                echo Common::formatNumber($row['price_sale']);
                                                            } else {
                                                                echo Common::formatNumber($row['price']);
                                                            }
                                                            ?>
                                                        </span>
                                        </div>
                                        <!-- END .table-cell.item-price -->

                                        <div class="item-right-actions">
                                            <a href="javascript:" class="remove-item js-remove-item"
                                               data-selenium="cartRemoveLink"
                                               onclick="removeOneCart(<?php echo $row['id'] ?>, 0);">
                                                <svg class="delete-item">
                                                    <use xlink:href="#trash-can"></use>
                                                </svg>
                                            </a>
                                            <!--
                                            <a class="move-item js-select-item-loginToMove openInOnePopupLayer" href="https://www.bhphotovideo.com/bnh/controller/home?O=cart&amp;A=getpage&amp;Q=Login.jsp" data-selenium="batchCommandMove">
                                            <svg class="delete-item">
                                                <use xlink:href="#move"></use>
                                            </svg>
                                            <span class="fs10">MOVE</span></a>
                                            -->
                                        </div>

                                        <!-- END .table-cell.item-right-actions -->

                                    </div>
                                </div>
                                <!-- END .item-details > .table -->
                            </div>
                            <!-- END .table-cell.item-details -->
                        </div>
                        <!-- END .itemInCart > .table > .table-row -->
                        <br class="clearfix">
                    </div>
                    <!-- END .itemInCart > .table -->
                    <div class="item-total-wrapper">
                        <div class="item-total clearfix ">
                            <p class="subL fs18 c1 bold"><span class="priceTTL1 item-total-label">Tổng:</span>
                                <span class="lPrice item-total-value "><span class="fs14"></span><span
                                            class="itemTTLprice">
                                        <?php
                                        if ($row['time_sale'] != 0 && $row['time_sale'] >= $time_sale_expired && $row['price_sale'] != 0) //if($row['time_sale']!=0 && $row['price_sale']!=0)
                                        {
                                            echo Common::formatNumber($row['price_sale'] * $row['qty']);
                                            $total_prices += $row['price_sale'] * $row['qty'];
                                        } else {
                                            echo Common::formatNumber($row['price'] * $row['qty']);
                                            $total_prices += $row['price'] * $row['qty'];
                                        }
                                        ?>
                                        VND
                                        </span></span></p>
                        </div>
                    </div>
                    <!--
                    <div class="addRemoveWL displayNone" data-selenium="addRemoveWishlist">                                    <a href="https://www.bhphotovideo.com/bnh/controller/home?O=cart&amp;A=removeItem&amp;Q=&amp;sku=680103&amp;is=USA" class="sprBtn cartRemove" data-selenium="cartRemoveLink">Remove</a>
                    </div>

                    <div class="itemInCartLeft displayNone" data-selenium="itemInCartLeftSide">
                        <div class="mft" data-selenium="mfr"> </div>
                    </div>
                    <div class="itemActs itemInCartRight displayNone"> </div>
                    -->
                </div>
                <?php
            }
        }
        if ($access){
            foreach ($access as $row) {
                $src_img = Common::getImage($row['picture'], 'access', '', 'small');
                $link_detail = Url::createUrl('access/detail', array('access_id' => $row['id'], 'alias' => $row['alias']));
                $product_type = $row['title'];
                ?>
                <div class="itemInCart js-cartItem" data-selenium="itemInCart">
                    <div class="table">
                        <div class="table-row">
                            <div class="item-details">
                                <div class="table">
                                    <div class="item-image">
                                        <!--item image-->
                                        <span class="itemImg" data-selenium="itemImg"> <a target="_blank"
                                                                                          href="<?php echo $link_detail; ?>"
                                                                                          data-selenium="smallImgLink"><img
                                                        data-selenium="smallImgItemLink" src="<?php echo $src_img; ?>"
                                                        alt="<?php echo $row['title']; ?>" border="0"></a> </span>
                                        <!--end item image-->
                                    </div>
                                    <!-- END .table-cell.item-image -->
                                    <div class="table-row">
                                        <div class="item-title"><a class="itemName underline-on-hover c31 bold fs16"
                                                                   data-selenium="itemName"
                                                                   href="<?php echo $link_detail; ?>"><?php echo $row['title']; ?></a>

                                        </div>
                                        <!-- END .table-cell.item-title -->
                                        <div class="stock-msg">
                                            <p class="bold c41"> <span class="c29 fs16 bold" data-selenium="inStock">
                                                        <?php
                                                        if ($row['status_buy'] == 1) echo 'Còn hàng';
                                                        else echo 'Hết hàng';
                                                        ?>
                                                        </span></p>
                                            <p class="fs11"></p>
                                        </div>
                                        <div class="item-qty">
                                                        <span class="qty qty-input-wrap">
                                                            <input class="input js-qty-input" maxlength="3" size="2"
                                                                   value="<?php echo $row['qty']; ?>"
                                                                   name="qty<?php echo $row['id']; ?>_1" data-mq="50"
                                                                   type="text">
                                                            <input type="hidden" value="<?php echo $row['id']; ?>"
                                                                   name="product_id<?php echo $row['id']; ?>_1"/>
                                                            <a href="javascript:"
                                                               class="update-qty js-update-qty displayNone fs13 underline-on-hover c5"
                                                               onclick="$('#form_cart').submit();">Update</a>
														</span>
                                        </div>
                                        <!-- END .table-cell.item-qty -->
                                        <div class="item-price">
                                                        <span class="">
                                                        	<?php
                                                            if ($row['time_deal'] != 0 && $row['time_deal'] > time() && $row['price_deal'] != 0) //if($row['time_deal']!=0 && $row['price_deal']!=0)
                                                            {
                                                                echo Common::formatNumber($row['price_deal']);
                                                            } else {
                                                                echo Common::formatNumber($row['price']);
                                                            }
                                                            ?>
                                                        </span>
                                        </div>
                                        <div class="item-right-actions">
                                            <a href="javascript:" class="remove-item js-remove-item"
                                               data-selenium="cartRemoveLink"
                                               onclick="removeOneCart(<?php echo $row['id'] ?>, 1);">
                                                <svg class="delete-item">
                                                    <use xlink:href="#trash-can"></use>
                                                </svg>
                                            </a>
                                            <!--
                                            <a class="move-item js-select-item-loginToMove openInOnePopupLayer" href="https://www.bhphotovideo.com/bnh/controller/home?O=cart&amp;A=getpage&amp;Q=Login.jsp" data-selenium="batchCommandMove">
                                            <svg class="delete-item">
                                                <use xlink:href="#move"></use>
                                            </svg>
                                            <span class="fs10">MOVE</span></a>
                                            -->
                                        </div>

                                    </div>
                                </div>
                                <!-- END .item-details > .table -->
                            </div>
                            <!-- END .table-cell.item-details -->
                        </div>
                        <!-- END .itemInCart > .table > .table-row -->
                        <br class="clearfix">
                    </div>
                    <!-- END .itemInCart > .table -->
                    <div class="item-total-wrapper">
                        <div class="item-total clearfix ">
                            <p class="subL fs18 c1 bold"><span class="priceTTL1 item-total-label">Tổng:</span>
                                <span class="lPrice item-total-value "><span class="fs14"></span><span
                                            class="itemTTLprice">
                                        <?php
                                        if ($row['time_deal'] != 0 && $row['time_deal'] > time() && $row['price_deal'] != 0) //if($row['time_deal']!=0 && $row['price_deal']!=0)
                                        {
                                            echo Common::formatNumber($row['price_deal'] * $row['qty']);
                                            $total_prices += $row['price_deal'] * $row['qty'];
                                        } else {
                                            echo Common::formatNumber($row['price'] * $row['qty']);
                                            $total_prices += $row['price'] * $row['qty'];
                                        }
                                        ?>
                                        VND
                                        </span></span></p>
                        </div>
                    </div>
                    <!--
                    <div class="addRemoveWL displayNone" data-selenium="addRemoveWishlist">                                    <a href="https://www.bhphotovideo.com/bnh/controller/home?O=cart&amp;A=removeItem&amp;Q=&amp;sku=680103&amp;is=USA" class="sprBtn cartRemove" data-selenium="cartRemoveLink">Remove</a>
                    </div>

                    <div class="itemInCartLeft displayNone" data-selenium="itemInCartLeftSide">
                        <div class="mft" data-selenium="mfr"> </div>
                    </div>
                    <div class="itemActs itemInCartRight displayNone"> </div>
                    -->
                </div>
                <?php
            }
        }
        //Color
        if ($colors){
            foreach ($colors as $row) {
                $src_img = Common::getImage($row['picture'], 'access', '', 'small');
                $link_detail = Url::createUrl('access/detail', array('access_id' => $row['access_id'], 'color_id' => $row['id'], 'alias' => $row['alias']));

                ?>
                <div class="itemInCart js-cartItem" data-selenium="itemInCart">
                    <div class="table">
                        <div class="table-row">
                            <div class="item-details">
                                <div class="table">
                                    <div class="item-image">
                                        <!--item image-->
                                        <span class="itemImg" data-selenium="itemImg"> <a
                                                    href="<?php echo $link_detail; ?>" data-selenium="smallImgLink"><img
                                                        data-selenium="smallImgItemLink" src="<?php echo $src_img; ?>"
                                                        alt="<?php echo $row['title']; ?>" border="0"></a> </span>
                                        <!--end item image-->
                                    </div>
                                    <!-- END .table-cell.item-image -->
                                    <div class="table-row">
                                        <div class="item-title"><a class="itemName underline-on-hover c31 bold fs16"
                                                                   data-selenium="itemName"
                                                                   href="<?php echo $link_detail; ?>"><?php echo $row['title']; ?>
                                                (<?php echo $row['color']; ?>)</a>

                                        </div>
                                        <!-- END .table-cell.item-title -->
                                        <div class="stock-msg">
                                            <p class="bold c41"> <span class="c29 fs16 bold" data-selenium="inStock">
                                                        <?php
                                                        if ($row['status_buy'] == 1) echo 'Còn hàng';
                                                        else echo 'Hết hàng';
                                                        ?>
                                                        </span></p>
                                            <p class="fs11"></p>
                                        </div>
                                        <div class="item-qty">
                                                        <span class="qty qty-input-wrap">
                                                            <input class="input js-qty-input" maxlength="3" size="2"
                                                                   value="<?php echo $row['qty']; ?>"
                                                                   name="qty<?php echo $row['id']; ?>_2" data-mq="50"
                                                                   type="text">
                                                            <input type="hidden" value="<?php echo $row['id']; ?>"
                                                                   name="product_id<?php echo $row['id']; ?>_2"/>
                                                            <a href="javascript:"
                                                               class="update-qty js-update-qty displayNone fs13 underline-on-hover c5"
                                                               onclick="$('#form_cart').submit();">Update</a>
														</span>
                                        </div>
                                        <!-- END .table-cell.item-qty -->
                                        <div class="item-price">
                                                        <span class="">
                                                        	<?php
                                                            if ($row['time_deal'] != 0 && $row['time_deal'] > time() && $row['price_deal'] != 0) //if($row['time_deal']!=0 && $row['price_deal']!=0)
                                                            {
                                                                echo Common::formatNumber($row['price_deal']);
                                                            } else {
                                                                echo Common::formatNumber($row['price']);
                                                            }
                                                            ?>
                                                        </span>
                                        </div>
                                        <div class="item-right-actions">
                                            <a href="javascript:" class="remove-item js-remove-item"
                                               data-selenium="cartRemoveLink"
                                               onclick="removeOneCart(<?php echo $row['id'] ?>, 2);">
                                                <svg class="delete-item">

                                                    <use xlink:href="#trash-can"></use>
                                                </svg>
                                            </a>
                                            <!--
                                            <a class="move-item js-select-item-loginToMove openInOnePopupLayer" href="https://www.bhphotovideo.com/bnh/controller/home?O=cart&amp;A=getpage&amp;Q=Login.jsp" data-selenium="batchCommandMove">
                                            <svg class="delete-item">
                                                <use xlink:href="#move"></use>
                                            </svg>
                                            <span class="fs10">MOVE</span></a>
                                            -->
                                        </div>

                                    </div>
                                </div>
                                <!-- END .item-details > .table -->
                            </div>
                            <!-- END .table-cell.item-details -->
                        </div>
                        <!-- END .itemInCart > .table > .table-row -->
                        <br class="clearfix">
                    </div>
                    <!-- END .itemInCart > .table -->
                    <div class="item-total-wrapper">
                        <div class="item-total clearfix ">
                            <p class="subL fs18 c1 bold"><span class="priceTTL1 item-total-label">Tổng:</span>
                                <span class="lPrice item-total-value "><span class="fs14"></span><span
                                            class="itemTTLprice">
                                        <?php
                                        if ($row['time_deal'] != 0 && $row['time_deal'] > time() && $row['price_deal'] != 0) //if($row['time_deal']!=0 && $row['price_deal']!=0)
                                        {
                                            echo Common::formatNumber($row['price_deal'] * $row['qty']);
                                            $total_prices += $row['price_deal'] * $row['qty'];
                                        } else {
                                            echo Common::formatNumber($row['price'] * $row['qty']);
                                            $total_prices += $row['price'] * $row['qty'];
                                        }
                                        ?>
                                        VND
                                        </span></span></p>
                        </div>
                    </div>
                    <!--
                    <div class="addRemoveWL displayNone" data-selenium="addRemoveWishlist">                                    <a href="https://www.bhphotovideo.com/bnh/controller/home?O=cart&amp;A=removeItem&amp;Q=&amp;sku=680103&amp;is=USA" class="sprBtn cartRemove" data-selenium="cartRemoveLink">Remove</a>
                    </div>

                    <div class="itemInCartLeft displayNone" data-selenium="itemInCartLeftSide">
                        <div class="mft" data-selenium="mfr"> </div>
                    </div>
                    <div class="itemActs itemInCartRight displayNone"> </div>
                    -->
                </div>
                <?php
            }
        }
        ?>
        <!--<div class="clearfix cart-id-number c2 OpenSans-600-normal" id="cart-id-number">Cart ID: #2083885387</div>-->
    </div>
    <!-- .cart-items -->
    <!--under cart item listing, here is checkout-->
    <div class="totals-col">
        <div class="left cartTotalContainer">

            <div class="ng-scope" id="cartAppContainer">
                <div class="ng-scope" ng-controller="TotalsController as vm" ng-init="vm.init()">

                    <!-- /enterLocation -->

                    <div class="cart-shipping-totals">
                        <div class="totals clearfix">

                            <div class="clearfix"><span class="you-pay left clearfix bold">Tổng đơn hàng</span><span
                                        class="bold right ng-binding"><?php echo Common::formatNumber($total_prices); ?></span>
                            </div>
                            <!--
                            <div class="clearfix promoDiscount ng-hide" ng-show="vm.totals.totalPromoDiscount &amp;&amp; vm.totals.totalPromoDiscount != '0.00'"> <span class="center clearfix ng-binding">Promotion Savings <span class="fs14 ng-hide" ng-show="vm.totals.currencyInfo">USD </span> $0.00</span> </div>
                            <div class="clearfix right italic fs14 ng-binding ng-hide" ng-show="vm.totals.currencyInfo">Est. <span bh-bind-html="vm.totals.currencyInfo.symbol"></span><br>
                            </div>
                            -->
                        </div>
                        <span class="checkout-button">
											<a href="<?php echo Url::createUrl('cart/checkout'); ?>"
                                               class="bold logInRel loginCheckout openInOnePopupLayer">

                                            <input data-selenium="checkoutLogin" name="checkoutLogin"
                                                   class="btn btn-primary btn-begin-checkout upper checkoutB"
                                                   value="Đặt hàng" id="loginCart" type="button">
                                            <svg class="checkout-icon">
                                                <use xlink:href="#lock"></use>
                                            </svg>
                                            </a>                                        </span>
                        <span class="clearfix"></span></div>

                </div>
            </div>
        </div>


        <!--end#totalWrapper -->
    </div>
    <!-- .totals-col -->
</div>