<?php
$ads = Ads::getAdsHome(1,10);
if($ads){
?>

<script>
var current_here=<?php echo sizeof($ads);?>;
var time=0;
function runSlide(vecto, size)
{
	var cur=$('#slide_'+current_here+'');
	cur.hide();
	if(vecto==1)
	{
		current_here=parseInt(current_here)+1;	
	}
	else
	{
		current_here=parseInt(current_here)-1;	
	}
	if(current_here > size) current_here = 1;
	else if(current_here == 0)
		current_here = size;
	
	var next_cur=$('#slide_'+current_here+'');

	cur.hide();
	next_cur.show();
	clearTimeout(time);
	start();

}
function start(){
	time = setInterval(function(){runSlide(1,<?php echo sizeof($ads);?>);},5000);
}

$(function(){
	showHideSlide('jcarousel','jcarousel-next','jcarousel-prev',<?php echo sizeof($ads);?>,1,'li',0);
	runSlide(1, <?php echo sizeof($ads);?>);
});
</script>

<!--<section class="newRegion personalized">-->
<section class="newRegion">
    <div class="bhView ">
        <section class="newRegion subRegion">
            <div class="bhView ">
                <section class="inner-section">
                	<!--
                    <header class="section-header">
                        <h1> VJCamera </h1>
                    </header>
                    -->
                    <div data-attach="collectionRegion">
                        <div class="bhView itemCarouselView">
                            <div>
                                <!--<div class="section-inner-container clearfix">-->
                                <div>
                                    <ul id="jcarousel">
                                    <?php
									$k=0;
                                    if($ads)
                                    foreach($ads as $row)
                                    {
										$k++;
										$class='';
										if($k!=1) $class='style="display:none"';
                                        $src_img = Common::getImage($row['picture'], 'ads', '');
                                        ?>
                                        <li id="slide_<?php echo $k;?>" <?php echo $class;?>><a href="<?php echo $row['ads_link'];?>"><img style="width:100%;" src="<?php  echo $src_img;?>" /></a></li>
                                        <?php
                                    }
                                    ?>
                                    </ul>
                                </div>
                                
                                <div id="jcarousel-prev" class="nav-button nav-back"> <span >
                                    <svg>
                                        <use xlink:href="#arrow-down-light"></use>
                                    </svg>
                                    </span>
								</div>
                                <div id="jcarousel-next" class="nav-button nav-forward"> <span >
                                    <svg>
                                        <use xlink:href="#arrow-down-light"></use>
                                    </svg>
                                    </span>
								</div>
                                
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </section>
    </div>
</section>
<?php
}
?>