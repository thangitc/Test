<div id="categoryLandingContent" class=" clp-hasCategoryImage clp-lightBreadcrumbs clp-lightPageTitle clp-condensableTopBanner">
    <div class="clp-topBannerArea">
        <div class="clp-pageImage clp-lowResImage" style="background-image: url('<?php echo Yii::app()->params['static_url']; ?>/images/HeaderBG_Photography_mini.jpg')"></div>
        <div class="clp-pageImage js-pageImage" style="background-image: url('<?php echo Yii::app()->params['static_url']; ?>/images/HeaderBG_Photography.jpg')"></div>
    </div>
    <div class="clp-content clearfix">
        <div class="new-page-width">
            <ul id="breadcrumbs" class="page-width">
                <li class="first"><a href="<?php echo Yii::app()->params['base_url']; ?>">Trang chủ</a></li>
            </ul>
            <h1 class="clp-pageTitle">Liên hệ</h1>
        </div>
        <div class="clp-sectionWrapper">
            <div class="new-page-width clearfix ">
                <div class="clp-categoryGroups">
                    <div data-selenium="mainCategories" style="margin-top:200px;">
                    <h2>Bản đồ</h2>
                    <br />
                    <img style="width:100%;" src="<?php echo Yii::app()->params['static_url']; ?>/images/map_vj.jpg" alt="Ban do" />
                    <br /><br />
					<?php echo $detail['description'];?>
                    </div>
                    <!--end#pageBody-->
                </div>
                <div class="clp-sidebar has-item" data-selenium="sideContent">
                    <div class="clp-sectionContainer" style="margin-top:200px;">
                    <?php
					if($hot_news)
					foreach($hot_news as $row)
					{
						$link_new = Url::createUrl('news/detail', array('alias'=>$row['alias'], 'news_id'=>$row['id']));
						$src_img = Common::getImage($row['picture'], 'news', '', 'small');
						?>
                        <div>
                        	<a href="<?php echo $link_new;?>" class="clp-textSidebarBanner overlay-on-hover js-exploraLink">
                            <div class="clp-sidebarImgHelper"> <img class="clp-sidebarBannerImg js-clp-unveil" src="<?php echo $src_img;?>" data-src="<?php echo $src_img;?>"> </div>
                            <div class="clp-sidebarBanner-text clp-sidebarBanner-textWithHeading">
                                <h6><?php echo $row['title'];?></h6>
                                <div class="ellipsizer">
                                    <p><?php echo $row['introtext'];?></p>
                                </div>
                            </div>
                            </a>
						</div>
                        <?php
					}
                    ?>
                    </div>
                </div>
                <!-- end clp-sidebar -->
            </div>
        </div>
    </div>
</div>