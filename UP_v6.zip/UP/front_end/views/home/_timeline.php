<?php if(!empty($timeline)) { ?>
<section class="newRegion moduleTrendingRegion">
    <div class="bhView ">
        <section>
            <header class="section-header">
                <h1> Hoạt động trên VJCamera
                    <p class="sub-header c32 fs12">Cập nhật hàng giờ</p>
                </h1>
			</header>
            <div id="content">
                <div class="bhView " style="position: relative;">
                <?php
				$k = 0;
				$arr_rating = LoadConfig::$arr_rating;
				foreach($timeline as $row)
				{
					$k++;
					$src_img = Common::getImage($row['picture'], 'timeline', '', 'small');
					$src_img_medium = Common::getImage($row['picture'], 'timeline', '', 'medium');
					$textHour = Common::genTextHour($row['publish_date']);
					$rating_name = isset($arr_rating[$row['rating']]) ? $arr_rating[$row['rating']].'.png' : 'A.png';
					$class = '';
					if($k%4==1) $class='style="left:0px;"';
					if($k%4==2) $class='style="left:324px;"';
					if($k%4==3) $class='style="left:649px;"';
					if($k%4==0) $class='style="left:974px;"';
					if($row['object_type']==0)
					{
						preg_match('/b(\d+)\.html/si', $row['links'], $match);
						$product_id = isset($match[1]) ? intval($match[1]):0;
						?>
                        <section class="trending-item fadeInHidden fadeInVisible" <?php echo $class;?>>
                        <header class="trending-header trending-header_product hasSubheader ">
                            <h2><?php echo $row['title_box'];?></h2>
                            <span class="subHeader"><?php echo $textHour;?></span> <span class="timeCreated"></span>
						</header>
                        <span>
                            <a href="<?php echo $row['links'];?>"> <img src="<?php echo $src_img;?>" class="itemImage">
                            <h2><?php echo $row['title'];?></h2>
                            <img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_name;?>" />
                            <div class="itemPrice"> <?php echo Common::formatNumber($row['price']);?> </div>
                            </a>
                            
                            <button  class="js-addToCart overlay-on-hover button" <?php if($product_id!=0) { ?> onclick="addCart(<?php echo $product_id;?>, 0, 1,<?php echo $row['price'];?>);" <?php }?> >
                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" class="circle-loader circle-loader20">
                                <g>
                                    <circle r="40%" cy="50%" cx="50%" class="fixed"/>
                                </g>
                                <g>
                                    <circle r="40%" cy="50%" cx="50%" class="rotate"/>
                                </g>
                            </svg>
                            <span>Thêm vào giỏ hàng</span>
                            </button>
                        </span>
                        </section>
                        <?php
					}
					if($row['object_type']==1)
					{
						?>
                        <section class="trending-item fadeInHidden fadeInVisible" <?php echo $class;?>>
                            <header class="trending-header trending-header-facebook  ">
                            	<a target="_blank" href="<?php echo $row['links'];?>"> 
                            	<!--
                            	<span class="social-icon icon-facebook">
                                <svg>
                                    <use xlink:href="#facebook"/>
                                </svg>
                                </span>
                                -->
                                <h2> <?php echo $row['title_box'];?> </h2>
                                </a>
                                <span class="subHeader"><?php echo $textHour;?></span>
                                <span class="timeCreated"><?php //echo $textHour;?></span>
                            </header>
                            <span>
                            	<a target="_blank" href="<?php echo $row['links'];?>"> 
                            	<img alt="<?php echo $row['title'];?>" src="<?php echo $src_img_medium;?>">
                            	<div class="socialCaption"> <?php echo $row['title'];?></div>
                                </a>
                            </span>
                        </section>
                        <?php
					}
					if($row['object_type']==2) //Video
					{
						?>
                        <section class="trending-item fadeInHidden fadeInVisible" <?php echo $class;?>>
                            <header class="trending-header trending-header-video  ">
                                <h2><?php echo $row['title_box'];?></h2>
                                <span class="subHeader"><?php echo $textHour;?></span>
                                <span class="timeCreated"><?php //echo $textHour;?></span> </header>
                            <span>
                            <div class="js-showVideo videoContainer" onclick="$('#videoContainer<?php echo $row['id'];?>').show(); $(this).hide();">
                            	<img width="100%" height="100%" src="<?php echo $src_img_medium;?>">
                                <div class="overlay"></div>
                                <svg>
                                    <use xlink:href="#play"/>
                                </svg>
                            </div>
                            <div id="videoContainer<?php echo $row['id'];?>" class="videoContainer js-showVideo" style="display:none;">
    						<?php
							$embed_video = $row['embed_video'];
							preg_match('/v=(.*)/si', $embed_video, $match);
							$youtube_key = isset($match[1]) ? $match[1]:'';
							if($youtube_key=='')
							{
								preg_match('/youtu.be\/(.*)/si', $embed_video, $match);
								$youtube_key = isset($match[1]) ? $match[1]:'';
							}
							echo Common::embedYoutube3($youtube_key);
							?>
							</div>
                            <div><?php echo $row['title'];?> </div>
                            </span>
                        </section>
                        <?php
					}
				}
                ?>
                </div>
            </div>
            <footer class="clearfix" id="timeline">
            	<?php
				$num_page = ceil($total_timeline / $num_per_page);
				if($page+1<=$num_page)
				{
					$link_more = Url::createUrl('home/index', array('page'=>$page+1)).'#content';
					?>
                    <button class="load-more js-load-more" onclick="window.location.href='<?php echo $link_more;?>'">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" class="circle-loader circle-loader20">
                        <g>
                            <circle r="40%" cy="50%" cx="50%" class="fixed"/>
                        </g>
                        <g>
                            <circle r="40%" cy="50%" cx="50%" class="rotate"/>
                        </g>
                    </svg>
                    <span>Xem thêm</span> </button>
					<?php
				}
				?>                
                
            </footer>
        </section>
    </div>
</section>

<?php } ?>