<li class="pmcbig menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children has-sub-menu" id="menu-item-8785-6669"><a href="javascript:" rel="nofollow"><strong>Tìm kiếm</strong></a>
    <ul class="sub-menu" style="display: none;">
        <li class="pmcmenutitle menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children" id="menu-item-3974-6670"><a href="javascript:" rel="nofollow">Giá tiền</a>
            <ul class="sub-menu">
                <li class="menu-item menu-item-type-custom menu-item-object-custom" id="menu-item-3429-6671"><a href="<?php echo Url::createUrl('bList/cat', array('cat_id'=>0, 'alias'=>'tim-kiem','min_price'=>1, 'max_price'=>5));?>">1.000.000 &ndash; 5.000.000</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom" id="menu-item-4474-6672"><a href="<?php echo Url::createUrl('bList/cat', array('cat_id'=>0, 'alias'=>'tim-kiem','min_price'=>5, 'max_price'=>10));?>">5.000.000 &ndash; 10.000.000</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom" id="menu-item-6785-6673"><a href="<?php echo Url::createUrl('bList/cat', array('cat_id'=>0, 'alias'=>'tim-kiem','min_price'=>10, 'max_price'=>15));?>">10.000.000 &ndash; 15.000.000</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom" id="menu-item-2696-6674"><a href="<?php echo Url::createUrl('bList/cat', array('cat_id'=>0, 'alias'=>'tim-kiem','min_price'=>15, 'max_price'=>20));?>">15.000.000 &ndash; 20.000.000</a></li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom" id="menu-item-2696-6674"><a href="<?php echo Url::createUrl('bList/cat', array('cat_id'=>0, 'alias'=>'tim-kiem','min_price'=>20, 'max_price'=>100));?>">20.000.000 &ndash; 100.000.000</a></li>
            </ul>
        </li>
        <li class="pmcmenutitle menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children" id="menu-item-5649-6675"><a href="javascript:" rel="nofollow">Thể loại</a>
            <ul class="sub-menu">
            <?php
			$arr_camera_type = LoadConfig::$arr_camera_type;
			foreach($arr_camera_type as $key=>$value)
			{
				$link_f = Url::createUrl('bList/filterL', array('alias'=>$value, 'lense_id'=>$key));
				?>
                <li class="menu-item menu-item-type-taxonomy menu-item-object-product_cat"><a href="<?php echo $link_f;?>"><?php echo $value;?></a></li>
                <?php
			}
            ?>
            </ul>
        </li>
    </ul>
</li>
