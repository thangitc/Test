<style>
#greenNav.nav-tabs-outer-wrapper #nav li:not(.empty-li) .navDownArrowIcon {
	bottom: 2px;
	display: none;
	height: 12px;
	left: 0;
	line-height: 8px;
	position: absolute;
	right: 0;
	text-align: center;
}
#greenNav.nav-tabs-outer-wrapper #nav li:not(.empty-li) .navDownArrowIcon svg {
	fill: #018d72;
	height: 12px;
	margin: 0 auto;
	width: 11px;
}
#greenNav.nav-tabs-outer-wrapper #nav li.ui-tabs-active .navDownArrowIcon, #greenNav.nav-tabs-outer-wrapper #nav li.active:not(.empty-li) .navDownArrowIcon {
	display: block;
	opacity: 1;
	visibility: visible;
}
#greenNav.nav-tabs-outer-wrapper #nav li.active a, #greenNav.nav-tabs-outer-wrapper #nav li.ui-tabs-active a {
	background: #fff none repeat scroll 0 0;
	box-shadow: none;
	color: #018d72;
}
#greenNav #nav {
	display: table;
	margin: 0 auto;
	overflow: hidden;
	width: 100%;
}
#greenNav #nav li:not(.empty-li) {
	height: 60px;
	margin-right: 10px;
	padding: 8px 0;
	position: relative;
	text-align: left;
}
#greenNav #nav li.disabled a {
	box-shadow: none;
	cursor: default;
	opacity: 0.5;
}
#greenNav #nav li:not(.empty-li) a {
	background: #018d72 none repeat scroll 0 0;
	border-radius: 4px;
	box-shadow: 0 2px 0 0 #018d72;
	color: #fff;
	display: inline-block;
	font-size: 16px;
	line-height: 44px;
	padding: 0 35px;
	position: relative;
	text-decoration: none;
	transition: background 0.1s ease-in-out 0s;
}
#greenNav #nav li:not(.empty-li):not(.ui-tabs-active):not(.active) a:hover {
	background: #018d72 none repeat scroll 0 0;
}
#greenNav #nav li:hover:not(.active):not(.ui-tabs-active):not(.disabled):not(.empty-li) a, #greenNav #nav li:hover:not(.active):not(.ui-tabs-active):not(.disabled):not(.empty-li) span {
	color: #fff;
}
</style>
<?php
$this->renderPartial('application.views.cart.js') ;
?>
<script>
$(document).on("click", ".js-filter h6", function(t) {
    if ($(t.target).is("h6")) {
        $(this).parent(".js-filter").toggleClass("js-shown js-hidden");
    }
});
$(document).on("click", ".js-toggleShow", function(e) {
    var t = $(this);
    t.toggleClass("js-show js-hide");
    $(t.data("toggleshow")).toggleClass("js-open js-close");
	$('.price-range').toggle();
});
/*
$(function(){
	$('.show-range').click(function(){
		$(".price-range").toggleClass("js-open js-close");
	});
});
*/
</script>
<?php
$current_url = Common::genCurrentUrl();
preg_match('/\?(.*)/si', $current_url, $match);
$cond_cat = isset($match[1]) ? $match[1]:'';

?>
<div class="t-main js-t-main page-width full-width clearfix" data-selenium="t-main">
    <ul id="breadcrumbs" class="page-width twelve">
        <li class="first"><a href="<?php echo Yii::app()->params['baseUrl'];?>">Trang chủ</a></li>
        <?php
		$parent_info = !empty($cat_info) && isset($cats[$cat_info['parent_id']]) ? $cats[$cat_info['parent_id']] : array();
		if(!empty($parent_info))
		{
			?>
            <li> <a href="<?php echo Url::createUrl('access/searchTop',array('cat_id'=>$parent_info['id']));?>?keyword_top=<?php echo $keyword_top;?>&s="> <?php echo $parent_info['title'];?> </a> </li>
            <?php
		}
		if(!empty($cat_info))
		{
			?>
            <li> <a href="<?php echo Url::createUrl('access/searchTop',array('cat_id'=>$cat_info['id']));?>?keyword_top=<?php echo $keyword_top;?>&s="> <?php echo $cat_info['title'];?> </a> </li>
            <?php
		}
        ?>
        <li> <a href="<?php echo Url::createUrl('access/searchTop');?>?keyword_top=<?php echo $keyword_top;?>&s="> <?php echo $keyword_top;?> </a> </li>
    </ul>
    <div class="side nav left js-sideNav" data-selenium="sideNav">
        <div class="bold twelve get-help" data-selenium="get-help">
            <p class="c5">Hotline</p>
            <p class="elevn"> <span class="call"> 0965.505.515</span> <a data-selenium="liveChat" href="https://www.facebook.com/vn.japan" class="chat c2" target="livechat"> Live Chat </a> </p>
        </div>
        <div class="js-filters-cont filters-cont elevn" data-selenium="filters-container">
        	<?php if($cats) {?>
            <div class="catgory js-clickOne bold" data-selenium="catgory">
                <h5 class="filter-head twelve" data-selenium="filter-head">Danh mục</h5>
                <ul>
                <?php
				if(empty($cat_info))
				{
					if($cats)
					foreach($cats as $row)
					{
						if($row['level']==2 && $row['cat_type']==3)
						{
							$link_cat = Url::createUrl('access/searchTop',array('cat_id'=>$row['id']));
							if($cond_cat!='') $link_cat .= '?'.$cond_cat;
							?>
							<li class="first clearfix" data-selenium="loadSubCat"> <a href="<?php echo $link_cat;?>" class="c5 fs12" data-selenium="loadSubCatLink"><?php echo $row['title'];?><!--<span class="amt"> (<?php echo $row['num_p'];?>)</span>--></a> </li>
							<?php
						}
					}
				}
				else
				{
					if($cat_info['sub_id']!=$cat_info['id'])
					{
						if($cats)
						foreach($cats as $row)
						{
							if($row['parent_id']==$cat_info['id'])
							{
								$link_cat = Url::createUrl('access/search',array('cat_id'=>$row['id']));
								if($cond_cat!='') $link_cat .= '?'.$cond_cat;
								?>
								<li class="clearfix" data-selenium="loadSubCat"> <a href="<?php echo $link_cat;?>" class="c5 fs12" data-selenium="loadSubCatLink"><?php echo $row['title'];?><!--<span class="amt"> (<?php echo $row['num_p'];?>)</span>--></a> </li>
								<?php
							}
						}
					}
					else
					{
						if($cats)
						foreach($cats as $row)
						{
							if($row['parent_id']==$cat_info['parent_id'] && $cat_info['parent_id']!=0)
							{
								$link_cat = Url::createUrl('access/search',array('cat_id'=>$row['id']));
								if($cond_cat!='') $link_cat .= '?'.$cond_cat;
								?>
								<li class="clearfix " data-selenium="loadSubCat"> <a href="<?php echo $link_cat;?>" class="c5 fs12" data-selenium="loadSubCatLink"><?php echo $row['title'];?><!--<span class="amt"> (<?php echo $row['num_p'];?>)</span>--></a> </li>
								<?php
							}
						}
					}
				}
                ?>
                </ul>
            </div>
            <?php } ?>
            <div class="narrow js-narrow twelve" data-selenium="narrowResults">
                <h5 class="filter-head twelve bold" data-selenium="filter-head">Tìm kiếm</h5>
                <div class="js-shown js-filter filter js-clickMultiple js-brands " data-selenium="filter">
                    <h6 class="fs14 bold c11" data-selenium="allbrands">Thương hiệu</h6>
                    <!--
                    <div class="filter-form clearfix full-width" data-selenium="filter-form">
                        <input name="brand" placeholder="Tìm thương hiệu" class="search elevn" data-selenium="filterSearch" type="text">
                        <button type="button" class="search" data-selenium="searchBtn" disabled="disabled">Search</button>
                        <div class="ui-front" data-selenium="ui-front" style="display:none;"></div>
                    </div>
                    -->
                    <ul class="js-brandsList" data-selenium="brandsList">
                    <?php
					preg_match('/(.*?)s=(.*)/si', $current_url, $match);
					$cond = isset($match[2]) ? $match[2]:'';
					$link_root = isset($match[1]) ? $match[1]:'';
					$list_brand_id = $list_brand_id!='' ? explode(',',$list_brand_id) : array();
					$list_brand_active = '';
					$list_brand_unactive = '';
					if($brands)
					foreach($brands as $row)
					{
						if($row['brand_type']==1)
						{
							$link_brand = $current_url.'+3579'.$row['id'];
							$class = '';
							if(in_array($row['id'],$list_brand_id))
							{
								$class = 'active';
								$cond_match = preg_replace('/3579'.$row['id'].'\+|\+3579'.$row['id'].'\+|3579'.$row['id'].'|\+3579'.$row['id'].'/si', '+', $cond);
								if(preg_match('/\?/si',$link_root))
									$link_brand = $link_root.'&s='.$cond_match;
								else
									$link_brand = $link_root.'?s='.$cond_match;
							}
							$link_brand = preg_replace('/s=\+/si','s=', $link_brand);
							$link_brand = rtrim($link_brand,'+');
							$link_brand = str_replace('?&', '?',$link_brand);
							$link_brand = str_replace('&&', '&',$link_brand);
							
							$total_brand_one = isset($list_total_brand[$row['id']]) ? $list_total_brand[$row['id']]:0;
							
							if(in_array($row['id'],$list_brand_id))
							{
								$list_brand_active.='<li> <a data-nvalue="'.$row['id'].'" href="'.$link_brand.'" class="checkbox '.$class.'">'.$row['title'].' </a> </li>';
							}
							else
							{
								$count_brand = '';
								//if($total_brand_one!=0) $count_brand = '<span class="amt">('.$total_brand_one.') </span>';
								if($total_brand_one!=0)
								{
									$count_brand = '<span class="amt">('.$total_brand_one.') </span>';
									$list_brand_unactive.='<li> <a data-nvalue="'.$row['id'].'" href="'.$link_brand.'" class="checkbox">'.$row['title'].' '.$count_brand.' </a> </li>';
								}
							}
						}
					}
					echo $list_brand_active.$list_brand_unactive;
                    ?>
                    </ul>
                </div>
                <?php if($cat_id==276 || (!empty($cat_info) && $cat_info['parent_id']==276)){ ?>
                <div class="js-shown js-filter filter js-clickMultiple js-brands " data-selenium="filter">
                    <h6 class="fs14 bold c11" data-selenium="allbrands">Kích thước</h6>
                    
                    <ul class="js-brandsList" data-selenium="brandsList">
                    <?php
					preg_match('/(.*?)s=(.*)/si', $current_url, $match);
					$cond = isset($match[2]) ? $match[2]:'';
					$link_root = isset($match[1]) ? $match[1]:'';
					$list_276_id = $list_276_id!='' ? explode(',',$list_276_id):array();
					$list_276_active = '';
					$list_276_unactive = '';
					$arr_276 = LoadConfig::$arr_276;
                    if($arr_276)
                    foreach($arr_276 as $key=>$value)
                    {
						$link_276 = $current_url.'+1235'.$key;
                        $class = '';
						if(in_array($key,$list_276_id))
						{
							$class = 'active';
							$cond_match = preg_replace('/1235'.$key.'\+|\+1235'.$key.'\+|1235'.$key.'|\+1235'.$key.'/si', '+', $cond);
							if(preg_match('/\?/si',$link_root))
								$link_276 = $link_root.'&s='.$cond_match;
							else
								$link_276 = $link_root.'?s='.$cond_match;
						}
						$link_276 = preg_replace('/s=\+/si','s=', $link_276);
						$link_276 = rtrim($link_276,'+');
						$link_276 = str_replace('?&', '?',$link_276);
						$link_276 = str_replace('&&', '&',$link_276);
						$total_276_one = isset($list_total_276[$key]) ? $list_total_276[$key]:0;
						if(in_array($key,$list_276_id))
						{
							$list_276_active.='<li> <a data-nvalue="'.$key.'" href="'.$link_276.'" class="checkbox '.$class.'">'.$value.' </a> </li>';
						}
						else
						{
							$count_model = '';
							//if($total_276_one!=0) $count_model = '<span class="amt">('.$total_276_one.') </span>';
							$list_276_unactive.='<li> <a data-nvalue="'.$key.'" href="'.$link_276.'" class="checkbox">'.$value.' '.$count_model.'</a> </li>';
						}
                    }
					echo $list_276_active.$list_276_unactive;
                    ?>
                    </ul>
                </div>
                <?php } ?>
                <?php if($cat_id==273 || (!empty($cat_info) && $cat_info['parent_id']==273)){ ?>
                <div class="js-shown js-filter filter js-clickMultiple js-brands " data-selenium="filter">
                    <h6 class="fs14 bold c11" data-selenium="allbrands">Dung lượng thẻ nhớ</h6>
                    
                    <ul class="js-brandsList" data-selenium="brandsList">
                    <?php
					preg_match('/(.*?)s=(.*)/si', $current_url, $match);
					$cond = isset($match[2]) ? $match[2]:'';
					$link_root = isset($match[1]) ? $match[1]:'';
					$list_273_1_id = $list_273_1_id!='' ? explode(',',$list_273_1_id):array();
					$list_273_1_active = '';
					$list_273_1_unactive = '';
					$arr_273_1 = LoadConfig::$arr_273_1;
                    if($arr_273_1)
                    foreach($arr_273_1 as $key=>$value)
                    {
						$link_273_1 = $current_url.'+3456'.$key;
                        $class = '';
						if(in_array($key,$list_273_1_id))
						{
							$class = 'active';
							$cond_match = preg_replace('/3456'.$key.'\+|\+3456'.$key.'\+|3456'.$key.'|\+3456'.$key.'/si', '+', $cond);
							if(preg_match('/\?/si',$link_root))
								$link_273_1 = $link_root.'&s='.$cond_match;
							else
								$link_273_1 = $link_root.'?s='.$cond_match;
						}
						$link_273_1 = preg_replace('/s=\+/si','s=', $link_273_1);
						$link_273_1 = rtrim($link_273_1,'+');
						$link_273_1 = str_replace('?&', '?',$link_273_1);
						$link_273_1 = str_replace('&&', '&',$link_273_1);
						$total_273_1_one = isset($list_total_273_1[$key]) ? $list_total_273_1[$key]:0;
						if(in_array($key,$list_273_1_id))
						{
							$list_273_1_active.='<li> <a data-nvalue="'.$key.'" href="'.$link_273_1.'" class="checkbox '.$class.'">'.$value.' </a> </li>';
						}
						else
						{
							$count_model = '';
							//if($total_273_1_one!=0) $count_model = '<span class="amt">('.$total_273_1_one.') </span>';
							$list_273_1_unactive.='<li> <a data-nvalue="'.$key.'" href="'.$link_273_1.'" class="checkbox">'.$value.' '.$count_model.'</a> </li>';
						}
                    }
					echo $list_273_1_active.$list_273_1_unactive;
                    ?>
                    </ul>
                </div>
                
                <div class="js-shown js-filter filter js-clickMultiple js-brands " data-selenium="filter">
                    <h6 class="fs14 bold c11" data-selenium="allbrands">Tốc độ thẻ</h6>
                    
                    <ul class="js-brandsList" data-selenium="brandsList">
                    <?php
					preg_match('/(.*?)s=(.*)/si', $current_url, $match);
					$cond = isset($match[2]) ? $match[2]:'';
					$link_root = isset($match[1]) ? $match[1]:'';
					$list_273_2_id = $list_273_2_id!='' ? explode(',',$list_273_2_id):array();
					$list_273_2_active = '';
					$list_273_2_unactive = '';
					$arr_273_2 = LoadConfig::$arr_273_2;
                    if($arr_273_2)
                    foreach($arr_273_2 as $key=>$value)
                    {
						$link_273_2 = $current_url.'+6789'.$key;
                        $class = '';
						if(in_array($key,$list_273_2_id))
						{
							$class = 'active';
							$cond_match = preg_replace('/6789'.$key.'\+|\+6789'.$key.'\+|6789'.$key.'|\+6789'.$key.'/si', '+', $cond);
							if(preg_match('/\?/si',$link_root))
								$link_273_2 = $link_root.'&s='.$cond_match;
							else
								$link_273_2 = $link_root.'?s='.$cond_match;
						}
						$link_273_2 = preg_replace('/s=\+/si','s=', $link_273_2);
						$link_273_2 = rtrim($link_273_2,'+');
						$link_273_2 = str_replace('?&', '?',$link_273_2);
						$link_273_2 = str_replace('&&', '&',$link_273_2);
						$total_273_2_one = isset($list_total_273_2[$key]) ? $list_total_273_2[$key]:0;
						if(in_array($key,$list_273_2_id))
						{
							$list_273_2_active.='<li> <a data-nvalue="'.$key.'" href="'.$link_273_2.'" class="checkbox '.$class.'">'.$value.' </a> </li>';
						}
						else
						{
							$count_model = '';
							//if($total_273_2_one!=0) $count_model = '<span class="amt">('.$total_273_2_one.') </span>';
							$list_273_2_unactive.='<li> <a data-nvalue="'.$key.'" href="'.$link_273_2.'" class="checkbox">'.$value.' '.$count_model.'</a> </li>';
						}
                    }
					echo $list_273_2_active.$list_273_2_unactive;
                    ?>
                    </ul>
                </div>
                <?php } ?>
                <div class="js-shown js-filter js-clickOne filter" data-selenium="filter">
                    <h6 class="fs14 bold c11">Khoảng giá</h6>
                    <?php					
					if($price1!=0 || $price2!=0)
					{
						$link_remove = preg_replace('/\+VND'.$price1.'\+'.$price2.'VND\+|VND'.$price1.'\+'.$price2.'VND\+|\+VND'.$price1.'\+'.$price2.'VND|VND'.$price1.'\+'.$price2.'VND/si', '+', $current_url);
						$link_remove = rtrim($link_remove,'+');
						$link_remove = str_replace('?&', '?',$link_remove);
						?>
                        <div data-selenium="selected" class="selected">
							<ul>                        
                            	<li><a class="remove-filter" href="<?php echo $link_remove;?>"><?php echo Common::formatNumber($price1);?> &ndash; <?php echo Common::formatNumber($price2);?></a></li>
                            </ul>
                        </div>
                        <?php
					}
					?>
                    <ul class="price-range" data-selenium="price-range" <?php if($price1==0 && $price2==0) echo 'style="display:block;"'; else echo 'style="display:none;"';?>>
                    	<?php if('VND'.$price1.'+'.$price2.'VND'!='VND100000+5000000VND') {?>
                        <li><a href="<?php $url = $current_url.'+VND100000+5000000VND'; echo $url;?>">100.000 &ndash; 5.000.000 <span class="amt"> <?php if($total_price_1!=0) echo '('.$total_price_1.')';?></span></a> </li>
                        <?php } ?>
                        <?php if('VND'.$price1.'+'.$price2.'VND'!='VND5000000+10000000VND') {?>
                        <li><a href="<?php $url = $current_url.'+VND5000000+10000000VND'; echo $url;?>">5.000.000 &ndash; 10.000.000 <span class="amt"> <?php if($total_price_2!=0) echo '('.$total_price_2.')';?></span></a> </li>
                        <?php } ?>
                        <?php if('VND'.$price1.'+'.$price2.'VND'!='VND10000000+15000000VND') {?>
                        <li><a href="<?php $url = $current_url.'+VND10000000+15000000VND'; echo $url;?>">10.000.000 &ndash; 15.000.000 <span class="amt"> <?php if($total_price_3!=0) echo '('.$total_price_3.')';?></span></a> </li>
                        <?php } ?>
                        <?php if('VND'.$price1.'+'.$price2.'VND'!='VND15000000+20000000VND') {?>
                        <li><a href="<?php $url = $current_url.'+VND15000000+20000000VND'; echo $url;?>">15.000.000 &ndash; 20.000.000 <?php if($total_price_4!=0) echo '('.$total_price_4.')';?></span></a> <span class="amt"> </li>
                        <?php } ?>
                        <?php if('VND'.$price1.'+'.$price2.'VND'!='VND20000000+100000000VND') {?>
                        <li><a href="<?php $url = $current_url.'+VND20000000+100000000VND'; echo $url;?>">20.000.000 &ndash; 100.000.000 <span class="amt"> <?php if($total_price_5!=0) echo '('.$total_price_5.')';?></span></a> </li>
                        <?php } ?>
                    </ul>
                    <form action="<?php echo $current_url;?>" method="get" class="filter-form clearfix full-width price-form js-price-form">
                        
                        <span>Nhập khoảng giá:</span>
                        <label>VND
                            <input name="min_price" id="min_price" class="elevn js-mnp" value="<?php if($min_price!=0) echo $min_price;?>" data-selenium="minPrice" type="text">
                            &nbsp;&nbsp;-&nbsp;&nbsp; </label>
                        <label>VND
                            <input name="max_price" id="max_price" class="elevn js-mxp" value="<?php if($max_price!=0) echo $max_price;?>" data-selenium="maxPrice" type="text">
                        </label>
                        <script>
						function searchByPrice()
						{
							var min_price = $('#min_price').val();
							var max_price = $('#max_price').val();
							if(min_price=='' || max_price=='')
							{
								alert('Vui lòng nhập khoảng giá cần tìm');
								return false;
							}
							<?php
							$link_price = preg_replace('/min_price=(.*?)&max_price=(.*?)&|min_price=(.*?)&max_price=(.*?)/si','', $current_url);
							$link_price = rtrim($link_price, '&');
							?>
							var link_p = '<?php echo $link_price;?>';
							var cond = '';
							if(min_price!=0 || min_price!='')
								cond += '&min_price='+min_price;
							if(min_price!=0 || min_price!='')
								cond += '&max_price='+max_price+'&';
							link_p = link_p.replace('?','?'+cond);
							link_p = link_p.replace('?&','?');
							link_p = link_p.replace('&&','&');
							
							window.location.href = link_p;
						}
						</script>
                        <button type="button" class="go litGrayBtn" data-selenium="pricerangeBtn" onclick="searchByPrice();">Go</button>
                    </form>
                    <button class="show-range bold js-show toggleShow js-toggleShow" data-selenium="show-range">
                        <span data-selenium="displayShown" class="js-show">
                            Tất cả khoảng giá<span data-selenium="pricearrow" class="arrow">‹</span>
                        </span>
                        <span data-selenium="filterHide" class="js-hide">
                            Ẩn khoảng giá<span data-selenium="pricearrow" class="arrow">›</span>
                        </span>
                    </button>
                </div>
                
                <div class="no-filter js-clickOne" data-selenium="no-filter">
                    <h6 class="therteen bold c11">Tìm theo tên sản phẩm</h6>
                    <form action="<?php echo $current_url;?>" method="get" id="search-within-form" class="filter-form clearfix full-width js-filterForm">
                        <input name="keyword" id="keyword" value="<?php echo $keyword;?>" placeholder="Tên sản phẩm" class="search elevn js-searchInput" data-selenium="searchWithin" type="text">
                        <script>
						function searchByKeyword()
						{
							var keyword = $('#keyword').val();
							if(keyword=='')
							{
								alert('Vui lòng nhập từ khóa cần tìm');
								return false;
							}
							<?php
							$link_keyword = preg_replace('/keyword=(.*?)&|keyword=(.*)/si','', $current_url);
							$link_keyword = rtrim($link_keyword, '&');
							?>
							var link_p = '<?php echo $link_keyword;?>';
							var cond = '';
							if(keyword!='')
							{
								cond = '&keyword='+keyword+'&';
							}
							link_p = link_p.replace('?','?'+cond);
							link_p = link_p.replace('?&','?');
							link_p = link_p.replace('&&','&');
							window.location.href = link_p;
						}
						</script>
                        <button type="button" class="search js-searchButton" data-selenium="searchBtn" onclick="searchByKeyword();">Search</button>
                    </form>
                </div>
            </div>
        </div>
        <div id="adv">
        	<?php
            $ads_info = Ads::getAdsCatByPos($cat_id,3);
			if($ads_info)
			{
				$src_img = Common::getImage($ads_info['picture'], 'ads', '');
				?>
                <img src="<?php echo $src_img;?>" />
                <?php
			}
			?>
        </div>
    </div>
    
    <div class="right main-content js-main-content" data-selenium="main-content">
    	<?php if($cats) {?>
        <div class="page-banner-zone full-width" data-selenium="page-banner-zone">
        	<div class="nav-tabs-outer-wrapper js-nav-tabs-outer-wrapper stick-nav--bottom" id="greenNav">
                <div id="navTabs" class="nav-tabs-inner-wrapper">
                    <ul role="tablist" id="nav">
                        <li style="width:14%; float:left"> <a class="ui-tabs-anchor" href="<?php echo Url::createUrl('bList/searchTop');?>?keyword_top=<?php echo $keyword_top;?>&s="> <span>Máy ảnh</span> <span class="navDownArrowIcon">
                            <svg>
                                <use xlink:href="#arrow-down-light"></use>
                            </svg>
                            </span> </a>
                        </li>
                        <li style="width:30%; float:left" class="ui-tabs-active"> <a class="ui-tabs-anchor" href="<?php echo Url::createUrl('access/searchTop');?>?keyword_top=<?php echo $keyword_top;?>&s="> <span>Phụ kiện</span> <span class="navDownArrowIcon">
                            <svg>
                                <use xlink:href="#arrow-down-light"></use>
                            </svg>
                            </span> </a>
                        </li>
                        
                    </ul>
                </div>
            </div>
        	<!--
            <div id="searchTermBannerMain" data-selenium="searchTermBannerMain">
                <div id="searchTermBannerHead" data-selenium="searchTermBannerHead">
                    <h1><?php echo $h1;?></h1>
                </div>
                <div id="searchTermBody" data-selenium="searchTermBody">
                    <div id="searchTermLinksWrap" data-selenium="searchTermLinksWrap">
                    <?php
					/*
					if($cat_info['sub_id']!=$cat_info['id'])
					{
						$list_sub_id = $cat_info['sub_id'];
						$list_sub_id = explode(',',$list_sub_id);
						$total = sizeof($list_sub_id)-1;
						$style = '';
						if($total==1) $style = 'style="width:100%"';
						if($total==2) $style = 'style="width:48%"';
						if($total==3) $style = 'style="width:33%"';
						if($total==4) $style = 'style="width:24%"';
						if($total>=5) $style = 'style="width:19%"';
						
						foreach($cats as $row)
						{
							if($row['parent_id']==$cat_info['id'])
							{
								$link_cat = Url::createUrl('access/cat',array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
								$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
								$class='';
								if($row['id']==$cat_id) $class = 'border_bottom';
								?>
                        		<a <?php echo $style;?> data-selenium="searchTermLink" href="<?php echo $link_cat;?>" class="searchTermLink <?php echo $class;?>"> <span class="searchLinkImage" data-selenium="searchLinkImage"><img src="<?php echo $src_img;?>" border="0"></span> <span class="searchLinkName" data-selenium="searchLinkName"><?php echo $row['title'];?></span> </a>
								<?php
							}
						}
					}
					else
					{
						$style = '';
						if($cat_info['parent_id']!=0)
						{
							$parent_info = isset($cats[$cat_info['parent_id']]) ? $cats[$cat_info['parent_id']]:array();
							$list_sub_id = $parent_info['sub_id'];
							$list_sub_id = explode(',',$list_sub_id);
							$total = sizeof($list_sub_id)-1;
							if($total==1) $style = 'style="width:100%"';
							if($total==2) $style = 'style="width:48%"';
							if($total==3) $style = 'style="width:33%"';
							if($total==4) $style = 'style="width:24%"';
							if($total>=5) $style = 'style="width:19%"';
						}
						foreach($cats as $row)
						{
							if($row['parent_id']==$cat_info['parent_id'] && $cat_info['parent_id']!=0)
							{
								$link_cat = Url::createUrl('access/cat',array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
								$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
								$class='';
								if($row['id']==$cat_id) $class = 'border_bottom';
								?>
                        		<a <?php echo $style;?> data-selenium="searchTermLink" href="<?php echo $link_cat;?>" class="searchTermLink <?php echo $class;?>"> <span class="searchLinkImage" data-selenium="searchLinkImage"><img src="<?php echo $src_img;?>" border="0"></span> <span class="searchLinkName" data-selenium="searchLinkName"><?php echo $row['title'];?></span> </a>
								<?php
							}
						}
					}
					*/
					?>
					</div>
                </div>
            </div>
            -->
        </div>
        <?php } ?>
        <div data-selenium="page-info" class="page-info top full-width c2">
            <div data-selenium="pagination" class="pagination top">
                <div class="top c1 fs24 clearfix">
                    <h1 class="left">Kết quả tìm kiếm <em class="bold"><?php echo $keyword_top;?></em> trong mục Phụ kiện</h1>
                    <span class="fs16 bold"> &nbsp;&nbsp;&nbsp;&nbsp;<?php echo ($page-1)*$num_per_page+1;?> - <?php if($total_product<=$page*$num_per_page) echo $total_product; else echo $page*$num_per_page;?> <span class="fs12">của</span> <?php echo $total_product;?> sản phẩm </span>
                </div>
            </div>
        </div>
        
        <?php $this->renderPartial("_list", array('products'=>$products));?>
        <!-- end list of items -->
        
    </div>
    <!-- end main-content -->
    <div class="bottomSection js-bottomSection clearfix full-width left" data-selenium="bottomSection">
        <div class="bottom pagination js-pagination clearfix left" data-selenium="pagination">
            <div class="back-to-top js-backToTop right bold fs12 c2">Back to top</div>
            <div class="pagination-zone  twelve" data-selenium="pagination-zone"> <?php echo $paging;?></div>
            <div class="twelve c2">
                <p class="pageNuber"> Page <?php echo $page;?> of <?php echo $total_product;?> <span class="c3 eighteen">&nbsp; | &nbsp;</span> <?php echo ($page-1)*$num_per_page;?> - <?php echo $page*$num_per_page;?> of <?php echo $total_product;?> Items </p>
            </div>
        </div>
    </div>
    <!-- BEGIN COREMETRICS This must be before the Coremetrics.jsp include below.-->
    <!-- END COREMETRICS -->
</div>