<script>
$(function(){
	$('.zoomImageIcom').click(function(){		
		$('.zoomImageIcom').each(function(){
			$(this).removeClass('active');
		});
		$('#zoomImage').attr('src', $(this).attr('rel'));
		var is_active  =  $(this).attr('data-index');
		$(this).addClass('active');
		$('.imageGroup').each(function(){
			if( $(this).attr('data-index')==is_active)
			{
				$(this).show();
			}
			else
			{
				$(this).hide();
			}
		});
	});
	showHideSlide('zoomContainer','next','prev',<?php if(empty($color_pic)) echo sizeof($access_pic); else echo sizeof($access_color_pic);?>,1,'div',0);
});
</script>
<div id="moreImages" data-selenium="moreImagesWrapper">
    <div class="close" data-selenium="close">Close</div>
    <div id="miNavWrapper" data-selenium="moreImagesNavWrapper">
        <div data-selenium="moreImagesNav" id="miNav">
            <div class="imgsCont only show" id="miNavImages">
            <?php
			$k=0;
			if(empty($color_info))
			{
				if($access_pic)
				foreach($access_pic as $row)
				{
					$src_img_smallest = Common::getImage($row['picture'], 'access', '' ,'smallest');
					$src_img = Common::getImage($row['picture'], 'access', '');
					?>
					<img rel="<?php echo $src_img;?>" data-index="<?php echo $k;?>" src="<?php echo $src_img_smallest;?>" class="zoomImageIcom <?php if($k==0) echo 'active';?>">
					<?php
					$k++;
				}
			}
			else
			{
				if($access_color_pic)
				foreach($access_color_pic as $row)
				{
					$src_img_smallest = Common::getImage($row['picture'], 'access', '' ,'smallest');
					$src_img = Common::getImage($row['picture'], 'access', '');
					?>
					<img rel="<?php echo $src_img;?>" data-index="<?php echo $k;?>" src="<?php echo $src_img_smallest;?>" class="zoomImageIcom <?php if($k==0) echo 'active';?>">
					<?php
					$k++;
				}
			}
			?>
            </div>
        	<div class="threeDCont"></div>
        </div>
    </div>
    <div id="miContent" data-selenium="moreImagesContent">
        <div id="zoomContent" data-selenium="zoomContent">
            <div id="zoomPages" data-selenium="zoomPages" style="display:block">
                <div id="prev" class="prev" data-selenium="prev"><span> </span></div>
                <div id="next" class="next" data-selenium="next"><span> </span></div>
            </div>
            <div id="zoomContainer" data-selenium="zoomContainer">
            	<!--
                <svg class="circle-loader circle-loader100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                    <g>
                        <circle class="fixed" cx="50%" cy="50%" r="40%"></circle>
                    </g>
                    <g>
                        <circle class="rotate" cx="50%" cy="50%" r="40%"></circle>
                    </g>
                </svg>
                -->
                <?php
				$k=0;
				if(empty($color_info))
				{
					if($access_pic)
					foreach($access_pic as $row)
					{
						$src_img_smallest = Common::getImage($row['picture'], 'access', '' ,'smallest');
						$src_img = Common::getImage($row['picture'], 'access', '');
						?>
						<div data-index="<?php echo $k;?>" class="imageGroup ui-draggable" style="top: 90px; left: 299px; width: 500px; height: 500px;">
                    	<img style="width: 500px; height: 500px;" src="<?php echo $src_img;?>" id="zoomImage">
                		</div>
						<?php
						$k++;
					}
				}
				else
				{
					if($access_color_pic)
					foreach($access_color_pic as $row)
					{
						$src_img_smallest = Common::getImage($row['picture'], 'access', '' ,'smallest');
						$src_img = Common::getImage($row['picture'], 'access', '');
						?>
						<div data-index="<?php echo $k;?>" class="imageGroup ui-draggable" style="top: 90px; left: 299px; width: 500px; height: 500px;">
                    		<img style="width: 500px; height: 500px;" src="<?php echo $src_img;?>" id="zoomImage">
                		</div>
						<?php
						$k++;
					}
				}
				?>
            </div>
            
            <div class="imageBtmText">
                <div data-selenium="imageDesc" class="imageDesc"><?php if(empty($color_info)) echo $detail['title']; else echo $detail['title'].' '.$color_info['color'];?></div>
            </div>
            <div id="zoomControls" data-selenium="zoomControls">
                <ul>
                    <li id="zoomIn" title="zoom in" data-selenium="zoomIn"></li>
                    <li id="zoomOut" title="zoom out" data-selenium="zoomOut"></li>
                    <li id="zoomReset" title="reset zoom" data-selenium="zoomReset"></li>
                </ul>
            </div>
        </div>
    </div>
    <div id="kitItemBar" data-selenium="kitItem">
        <div id="kitItemsWrapper" data-selenium="kitItemsWrapper">
            <div id="kitItemImageSelector" data-selenium="kitItemImageSelector"></div>
            <div id="kitItemOpener" data-selenium="kitItemOpener"></div>
        </div>
        <p id="kitItemDescriptionCont">
            <span>Now Viewing: </span>
            <b data-selenium="kitItemDescription" id="kitItemDescription"><?php if(empty($color_info)) echo $detail['title']; else echo $detail['title'].' '.$color_info['color'];?></b>
        </p>
    </div>
</div>