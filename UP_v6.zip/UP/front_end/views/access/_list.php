<?php
//$time_sale_expired = mktime(0,0,0, date('m'),date('d'), date('Y'))-86400;
$time_sale_expired = time()-86400;
?>
<div class="items full-width grid-view clearfix" data-selenium="items">
    <!-- list of items -->
    <?php
    $start_day = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
    if($products)
    foreach($products as $row)
    {
        $src_img = Common::getImage($row['picture'], 'access', '', 'medium');
        $link_detail = Url::createUrl('access/detail', array('access_id'=>$row['id'], 'alias'=>$row['alias']));
        ?>
        <div class="item clearfix js-item elevn new-realese js-bhItemObj" itemscope="" itemtype="http://schema.org/Product" style="height: 400px;">
            <div class="img-zone " data-selenium="img-zone">
                <div class="padding"> <a name="image" class="itemImg" href="<?php echo $link_detail;?>" data-selenium="itemImg"> <img data-selenium="imgLoad" src="<?php echo $src_img;?>" itemprop="image" alt="Sony <?php echo $row['title'];?>" width="150" height="150"> </a> </div>
                <div class="js-reviewCont" data-selenium="reviewCont" style="height: 36px;"> 
                    <?php
                    $arr_rating = LoadConfig::$arr_rating;
                    $rating_name = isset($arr_rating[$row['rating']]) ? $arr_rating[$row['rating']].'' : 'A';
                    $rating_img_name = $rating_name.'.png';
                    ?>
                        <img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_img_name;?>" />
                </div>
                <h3 data-selenium="itemHeading" class="bold twelve js-itemHeading" style="height: 54px;"> <a href="<?php echo $link_detail;?>" class="c5" data-selenium="itemHeadingLink" itemprop="url" title="<?php echo $row['title'];?>"> <span itemprop="name"><?php echo $row['title'];?></span> </a> </h3>
                
            </div>
            <div class="" data-selenium="itemInfo-zone">
                <div class="js-similarItemCont" data-selenium="similarItemCont" style="height: 0px;"> </div>
            </div>
            <div class="conversion-zone" data-selenium="conversion-zone">
                <div class="price-zone " data-selenium="price-zone">
                    <div class="prices js-prices" data-selenium="prices" style="height: 0px;"> </div>
                    <div class="js-atc-price" data-selenium="addToCartPrice" style="height: 20px;">
                        <div class="atc-price " data-selenium="addToCartPrice">
                        <?php 
                        if($row['price_deal']!=0 && $row['time_deal']!=0 && $row['time_deal']>=$time_sale_expired)
                        {
                            $price_deal_show = $row['price'];
                            $price_deal = $row['price_deal'];
                            $saving = Common::formatNumber($price_deal_show-$price_deal);
                            ?>
                            <p data-selenium="finalPrice" class="clearfix therteen  bold c7  "> <span class="youpay" data-selenium="youpayPrice">Giá: </span> <span data-selenium="price" class="price "> <?php echo Common::formatNumber($price_deal_show);?> VND </span> </p>
                            <p class="left ten c2 Savings">
                                <span>
                                    Giảm giá: <?php echo $saving;?> VND
                                </span>
                            </p>
                            <p class="left ten c2 Savings">
                                <span>
                                    Thời gian KM: <?php echo date('d/m/Y', $row['time_deal']);?>
                                </span>
                            </p>	
                            <?php
                        }
                        else
                        {
                            ?>
                            <p data-selenium="finalPrice" class="clearfix therteen  bold c7  "> <span class="youpay" data-selenium="youpayPrice">Giá: </span> <span data-selenium="price" class="price "> <?php echo Common::formatNumber($row['price']);?> VND </span> </p>
                            <?php
                        }
                        ?>
                        </div>
                    </div>
                    <div class="atc-zone clearfix" data-selenium="addToCartZone">
                    	
                        <div class="js-acMapMessageCont" data-selenium="MapMessageCont" style="height: 20px;">
                            <div class="acMapMessageCont clearfix c7"> </div>
                        </div>
                        <!--
                        <div class="rebatesCont js-rebatesCont" data-selenium="rebatesCont" style="height: 61px;">
                            <div class="rebateLinks clearfix"> </div>
                        </div>
                        -->
                        <span class="upper c5 bold  left inStock underline-on-hover cursor-pointer js-popover-opener" title="">                        
                        <?php
                        if($row['status_buy']==0)
                            echo 'Hết hàng';
                        else
                            echo 'Còn hàng';
                        ?>
                        </span>
                        <button type="button" onclick="window.location.href='<?php echo $link_detail;?>';" data-selenium="submitBtn" class="addToCart right blueBtn cursor-pointer atc-btn fs11 bold one-line">Xem chi tiết</button>
                            
                    </div>
                </div>
            </div>
            
        </div>
        <?php
    }
    
    ?>
    
</div>