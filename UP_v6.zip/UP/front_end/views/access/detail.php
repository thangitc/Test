<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/slide/jquery.prettyPhoto.min.js"></script>
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/slide/jquery.prettyPhoto.init.min.js"></script>
<link rel="stylesheet" id="googleFont-css" href="<?php  echo Yii::app()->params['static_url']; ?>/js/slide/prettyPhoto.css" type="text/css" media="all">
<script type="text/javascript" >

 jQuery(document).ready(function(){

    jQuery("a[rel^='lightbox']").prettyPhoto({theme:'light_rounded',show_title: false, deeplinking:false});

  });
function showTab(i, a)
{
	if(i==1)
	{
		$('#tab1').show();
		$('#tab2,#tab3,#tab4').hide();
	}
	if(i==2)
	{
		$('#tab2').show();
		$('#tab1,#tab3,#tab4').hide();
	}
	if(i==3)
	{
		$('#tab3').show();
		$('#tab1,#tab2,#tab4').hide();
	}
	if(i==4)
	{
		$('#tab4').show();
		$('#tab1,#tab2,#tab3').hide();
	}
	$('.tabs>li').removeClass('active');
	$(a).addClass('active');
}
</script>
<?php
$start_day = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
$this->renderPartial('application.views.cart.js') ;
$time_sale_expired = time()-86400;
?>

<div id="t-main" data-selenium="tContent" class="borderBoxBlock">
    <div class="breadcrums-cont clearfix new-page-width" data-selenium="breadcrumbs">
        <ul id="breadcrumbs" class="page-width twelve">
            <li class="first"><a href="<?php echo Yii::app()->params['baseUrl'];?>">Trang chủ</a></li>
            <?php
			$parent_info = !empty($cat_info) && isset($cats[$cat_info['parent_id']]) ? $cats[$cat_info['parent_id']] : array();
			$parent_info_root = !empty($parent_info) && !empty($cats[$parent_info['parent_id']]) ? $cats[$parent_info['parent_id']] : array();
			if(!empty($parent_info_root))
			{
				?>
				<li> <a href="<?php echo Url::createUrl('access/index',array('alias'=>$parent_info_root['alias'],'cat_id'=>$parent_info_root['id']));?>"> <?php echo $parent_info_root['title'];?> </a> </li>
				<?php
			}
			
			
			if(!empty($parent_info))
			{
				?>
				<li> <a href="<?php echo Url::createUrl('access/cat',array('alias'=>$parent_info['alias'],'cat_id'=>$parent_info['id']));?>"> <?php echo $parent_info['title'];?> </a> </li>
				<?php
			}
			?>
            <?php if(!empty($cat_info)) {?>
            <li><a href="<?php echo Url::createUrl('access/cat', array('cat_id'=>$cat_info['id'], 'alias'=>$cat_info['alias']));?>"><?php echo $cat_info['title'];?></a></li>
            <?php } ?>
            <li class="detailCrumb"> <a href="<?php echo $this->linkCanoncical?>"><?php /*if(!empty($brand_info)) echo $brand_info['title'].' ';*/ echo $detail['title'];?></a> </li>
        </ul>
    </div>
    <div id="tMain" class="clearfix" itemtype="http://schema.org/Product" itemscope="" data-selenium="mainItem">
        <div class="topWrapper clearfix js-item new-page-width js-bhItemObj" data-selenium="topPage" >           
			<div class="pinned-header js-itemPinnedHeader">
                <div class="pinned-inner-wrapper new-page-width full-width table">
                    <div class="pinned-header-productImage table-cell"> <img alt="<?php echo $detail['title'];?> <?php if($detail['color']!='') '('.$detail['color'].')';?>" src="<?php echo Common::getImage($detail['picture'], 'access', '', 'smallest');?>" height="50" width="50"> </div>
                    <div class="product-name-container table-cell">
                        <h1 class="ph-product-name smbold c31">
                        	<!--
							<?php if(!empty($brand_info)) {?>
                            <span><?php echo $brand_info['title'];?></span>
                            <?php } ?>
                            -->
                            <span> <?php echo $detail['title']; if(!empty($color_info)) echo ' ('.$color_info['color'].')';?> </span>
                        </h1>
                    </div>
                    <div class="pinned-header-mapMessage fs16"></div>
                    <div class="pinned-header-atcContainer table-cell">
                        <!--FormAddToCart-->
                    </div>
                </div>
            </div>
            <div class="pProductNameContainer">
                <h1 class="pProductName bold c31 js-main-product-name">
                <!--
                <?php if(!empty($brand_info)) {?>
                <span itemprop="brand"><?php echo $brand_info['title'];?></span>
                <?php } ?>
                -->
                <span itemprop="name"> <?php echo $detail['title']; if(!empty($color_info)) echo ' ('.$color_info['color'].')';?> </span> </h1>
			</div>
            
            <div class="full-width table">
                <!-- Start topLeft -->
                <script>
				(function(){
				var BH = window.BH || {};
				BH.globals = BH.globals || {};
				BH.globals.detailPageGlobals = BH.globals.detailPageGlobals || {};
				BH.globals.detailPageGlobals.demoVideo = {};
				})()
				</script>
                <div class="left-2-sections table-cell">
                    <div class="top-left js-topLeft left ">
                    	<?php if(!empty($brand_info)) { ?>
                        <h2 class="mfrLogo" data-selenium="mfrLogo"> <a href="javascript:" data-selenium="itemLogoLink" class="noUnderline"> <img src="<?php echo Common::getImage($brand_info['picture'], 'brand', '', 'small');?>" alt="<?php echo $brand_info['title'];?>" data-selenium="itemLogo" border="0"> </a> </h2>
						<?php } ?>
                        <!--Hinh anh-->
                        <?php if(empty($color_info)) {?>
                            <a class="noUnderline clearfix enlargeMain" name="enlarge" href="<?php echo Common::getImage($detail['picture'], 'access', '');?>" data-selenium="enlargeMain" itemprop="image"> <img id="mainImage" data-image-folder="images500x500" class="main-image"  src="<?php echo Common::getImage($detail['picture'], 'access', '');?>" alt="<?php $detail['title'];?> <?php if($detail['color']!='') '('.$detail['color'].')';?>" data-selenium="mainImage" border="0">
                                <p style="visibility: visible;" class="productDescription message-under-image fs14 c31 underline-on-hover"></p>
                                <p class="message-under-image fs14 c31 underline-on-hover noteDescription displayNone"></p>
                            </a>
                        <?php } else {?>
                            <a class="noUnderline clearfix enlargeMain" name="enlarge" href="<?php echo Common::getImage($color_info['picture'], 'access', '');?>" data-selenium="enlargeMain" itemprop="image"> <img id="mainImage" data-image-folder="images500x500" class="main-image"  src="<?php echo Common::getImage($color_info['picture'], 'access', '');?>" alt="<?php $detail['title'];?> <?php if($color_info['color']!='') '('.$detail['color'].')';?>" data-selenium="mainImage" border="0">
                                <p style="visibility: visible;" class="productDescription message-under-image fs14 c31 underline-on-hover"></p>
                                <p class="message-under-image fs14 c31 underline-on-hover noteDescription displayNone"></p>
                            </a>
                        <?php } ?>
                        
                        <div class="image-thumbs js-imageThumbs js-close" data-selenium="productThumbnail">
							<?php
							if(empty($color_info))
							{
								if($access_pic)
								foreach($access_pic as $row)
								{
									$src_img_smallest = Common::getImage($row['picture'], 'access', '' ,'smallest');
									$src_img = Common::getImage($row['picture'], 'access', '');
									?>
									<a class="cursor-pointer smImgLink" data-selenium="smallImgLink" onclick="cmCreateElementTag('MATB200GR-REG', 'MAIN:Prod:Sm`Imgs`Clickd`Dtl');"> <img class="js-lazyImage" src="<?php echo $src_img_smallest;?>" data-src="<?php echo $src_img;?>" alt="<?php echo $detail['title'];?>">
										<!--<p class="displayNone"><?php echo $detail['title'];?></p>-->
									</a>
									<?php
								}
							}
							else
							{
								if($access_color_pic)
								foreach($access_color_pic as $row)
								{
									$src_img_smallest = Common::getImage($row['picture'], 'access', '' ,'smallest');
									$src_img = Common::getImage($row['picture'], 'access', '');
									?>
									<a class="cursor-pointer smImgLink" data-selenium="smallImgLink" onclick="cmCreateElementTag('MATB200GR-REG', 'MAIN:Prod:Sm`Imgs`Clickd`Dtl');"> <img class="js-lazyImage" src="<?php echo $src_img_smallest;?>" data-src="<?php echo $src_img;?>" alt="<?php echo $detail['title'];?>">
										<!--<p class="displayNone"><?php echo $detail['title'];?></p>-->
									</a>
									<?php
								}
							}
                            ?>                         
                            <p class="js-toggleShow fs14 c31 cursor-pointer toggle-more-image-thumbs js-show" data-toggleshow=".js-imageThumbs">Show <span class="js-show">More</span><span class="js-hide">Less</span></p>
                        </div>
                        <div class="media-links fs14 clearfix"> </div>
                        <?php $this->renderPartial('_screenshot', array('detail'=>$detail, 'color_info'=>$color_info, 'access_pic'=>$access_pic, 'access_color_pic'=>$access_color_pic));?>
                        <!--
                        <div id="moreImages" data-selenium="moreImagesWrapper" data-scriptsrc="https://static.bhphoto.com/FrameWork/js/zooom.js?v=release20160822v10t114220114221" data-imagessrc="https://www.bhphotovideo.com/find/getImages.jsp/sku/821151/is/REG/cm_sp/ZoomImgs-_-DTLpg-_-MainImg">
                            <div class="close" data-selenium="close">Close</div>
                            <div id="miNavWrapper" data-selenium="moreImagesNavWrapper">
                                <div id="miNav" data-selenium="moreImagesNav"></div>
                            </div>
                            <div id="miContent" data-selenium="moreImagesContent">
                                <div id="zoomContent" data-selenium="zoomContent">
                                    <div id="zoomPages" data-selenium="zoomPages">
                                        <div class="prev" data-selenium="prev"><span> </span></div>
                                        <div class="next" data-selenium="next"><span> </span></div>
                                    </div>
                                    <div id="zoomContainer" data-selenium="zoomContainer">
                                        <svg class="circle-loader circle-loader100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <circle class="fixed" cx="50%" cy="50%" r="40%"></circle>
                                            </g>
                                            <g>
                                                <circle class="rotate" cx="50%" cy="50%" r="40%"></circle>
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="imageBtmText">
                                        <div class="imageDesc" data-selenium="imageDesc"></div>
                                    </div>
                                    <div id="zoomControls" data-selenium="zoomControls">
                                        <ul>
                                            <li id="zoomIn" title="zoom in" data-selenium="zoomIn"></li>
                                            <li id="zoomOut" title="zoom out" data-selenium="zoomOut"></li>
                                            <li id="zoomReset" title="reset zoom" data-selenium="zoomReset"></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div id="kitItemBar" data-selenium="kitItem">
                                <div id="kitItemsWrapper" data-selenium="kitItemsWrapper">
                                    <div id="kitItemImageSelector" data-selenium="kitItemImageSelector"></div>
                                    <div id="kitItemOpener" data-selenium="kitItemOpener"></div>
                                </div>
                                <p id="kitItemDescriptionCont"> <span>Now Viewing: </span> <b id="kitItemDescription" data-selenium="kitItemDescription"></b> </p>
                            </div>
                        </div>
                        -->
                        <ul class="social-share-links js-social-share-links" data-selenium="productSharing">
                            <li> <a title="Share on Facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $this->linkCanoncical;?>" class="social-link" data-selenium="shareFaceBook" data-width="700" data-height="400">
                                <svg class="facebook-share-icon">
                                    <use xlink:href="#facebook"></use>
                                </svg>
                                </a> </li>
                            <li> <a title="Share on Twitter" href="https://twitter.com/intent/tweet?url=<?php echo $this->linkCanoncical;?>" class="social-link js-twitter-share-link" data-selenium="shareTwitter" data-width="700" data-height="400">
                                <svg class="twitter-share-icon">
                                    <use xlink:href="#twitter"></use>
                                </svg>
                                </a> </li>
                            <li> <a title="Share on Google+" href="https://plus.google.com/share?url=<?php echo $this->linkCanoncical;?>" class="social-link" data-selenium="shareGooglePlus" data-width="700" data-height="500">
                                <svg class="google-share-icon">
                                    <use xlink:href="#gplus"></use>
                                </svg>
                                </a> </li>
                            <li> <a title="Share on Pinterest" href="http://pinterest.com/pin/create/button/?url=<?php echo $this->linkCanoncical;?>&amp;media=<?php echo $this->srcImg;?>&amp;description=<?php echo $detail['title'];?>" class="social-link js-pinterest-share-link" data-selenium="sharePinterest" data-width="720" data-height="570">
                                <svg class="pinterest-share-icon">
                                    <use xlink:href="#pintrest"></use>
                                </svg>
                                </a>
							</li>
                        </ul>
                    </div>
                    <!-- End topLeft -->
                    <!-- Start topRight -->
                    <div class="top-center left" data-selenium="topCenter">
                        <!--
                        <div class="c28 fs14 salesComments" data-selenium="salesComments"> <span class="c33 fs16 bold upper" data-selenium="notStock">Back-ordered</span>
                            <div class="scShipTime js-scShipTime" data-selenium="commentShipTime"> <span class="bold">Ship Time: </span>Not available <span title="" data-original-title="" class="ship-time-popover-opener js-popover-opener" data-popover-content-container=".js-scLongDescription" data-trigger="hover" data-animation="true">
                                <svg class="orange-info small">
                                    <use xlink:href="#info-light"></use>
                                </svg>
                                </span> <span class="js-scLongDescription" style="display:none;">
                                <div class="fs11" style="width:250px;"> This item is backordered by the manufacturer. </div>
                                </span> </div>
                            <div class="shipping-messages js-removeIfNoText fs14"> <a class="openInNewOnePopupLayer pShipCalc" href="https://www.bhphotovideo.com/bnh/controller/home?O=product-detail.jsp&amp;A=estimateShip&amp;Q=&amp;sku=821151&amp;is=REG" data-selenium="ShipCalc" rel="noLayerCache"><span class="pShipCalcLink">Calculate Shipping</span></a> </div>
                        </div>
                        -->
                        <div class="js-highlightsAndReviews">
                            <div class="js-productHighlights product-highlights c28 fs14 js-close" data-selenium="ProductHighlight">
                                <p class="fs16 OpenSans-600-normal upper product-highlights-header"> Thông tin nổi bật </p>
                                <div id="highlightList" data-selenium="highlightList" class="top-section-list show_hide_class">
                                	<?php echo $detail['introtext'];?>
                                </div>
                                <span class="js-toggleShow js-viewAllHighlights c31 cursor-pointer view-all-highlights underline-on-hover js-show" data-toggleshow=".js-productHighlights"><span class="js-show" onclick="$('#highlightList').removeClass('show_hide_class');">Show more</span><span class="js-hide" onclick="$('#highlightList').addClass('show_hide_class');">Show less</span></span> 
							</div>
                            <div class="reviews fs14 c28" data-selenium="productRating" itemtype="http://schema.org/AggregateRating" itemscope="" itemprop="aggregateRating"> <span class="reviews-link">
                                <meta content="4.5" itemprop="ratingValue">
                                <a href="#customerReview" data-selenium="readReviewsLink" class="js-readReviewsLink review-stars-medium underline-on-hover c31"> 
									<?php
                                    $arr_rating = LoadConfig::$arr_rating;
                                    $rating_name = isset($arr_rating[$detail['rating']]) ? $arr_rating[$detail['rating']].'' : 'A';
                                    $rating_img_name = $rating_name.'.png';
                                    ?>
                                    <img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_img_name;?>" />
                                </a>
								</span>
                                <!--
                                <span data-animation="true" data-trigger="hover" data-popover-content-container=".js-scLongDescription" class="ship-time-popover-opener js-popover-opener" data-original-title="" title="">
                                    <svg class="orange-info small">
                                        <use xlink:href="#info-light"/>
                                    </svg>
                                </span>
                                -->
                                <?php if($detail['time_bh']!='') { ?>
                                <span style="float:right;">Bảo hành: <strong><?php echo $detail['time_bh'];?></strong></span>
                                <?php } ?>
							</div>
                        </div>
                        <?php if($access_color) { ?>
                        <div class="groups">
                            <div class="items-group js-itemsGroup c28 fs14 color clearfix" data-selenium="pColors" data-selected="<?php echo $detail['color'];?>">
                                <p class="fs16 truncate-ellipsis"> Color: <span class="OpenSans-600-normal js-itemValue"><?php echo $detail['color'];?></span> </p>
                                <?php
								if($access_color)
								foreach($access_color as $row)
								{
									$src_img = Common::getImage($row['picture'], 'access', '');
									$src_img_smallest = Common::getImage($row['picture'], 'access', '','smallest');
									$link_access_color = Url::createUrl('access/detail', array('access_id'=>$row['access_id'], 'alias'=>$detail['alias'], 'color_id'=>$row['id']));
									$selected = '';
									if(!empty($color_info) && $row['id']==$color_info['id']) $selected = 'selcted-item';
									?>
                                    <a class="group-item js-groupItem c28 noUnderline <?php echo $selected;?>" data-imagesrc="<?php echo $src_img;?>" data-itemvalue="<?php echo $row['color'];?>" title="<?php echo $detail['title'];?> (<?php echo $row['color'];?>)" href="<?php echo $link_access_color;?>" data-selenium="thumbLink" alt="<?php echo $detail['title'];?> (<?php echo $row['color'];?>)"> <img src="<?php echo $src_img_smallest;?>" alt="<?php echo $detail['title'];?> (<?php echo $row['color'];?>)"> </a>
                                    <?php
								}
                                ?>
                                
                                <div class="js-popover-container">
                                    <div class="content">
                                        <p class="c28 fs14">Back-ordered</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                        <div class="rebate-lists"> </div>
                    </div>
                </div>
                <!-- end left-2-sections -->
                <div class="top-right table-cell">
                    <div class="pPriceZoneRight fs14 c28 js-priceZone " data-selenium="PriceZoneRight" itemtype="http://schema.org/Offer" itemscope="" itemprop="offers">
                        <meta content="NewCondition" href="http://schema.org/OfferItemCondition" itemprop="itemCondition">
                        <?php
						if(($detail['price_deal']!=0 && $detail['time_deal']!=0 && $detail['time_deal']>=$time_sale_expired && empty($color_info)) || (!empty($color_info) && $color_info['price_deal']!=0 && $color_info['time_deal']!=0 && $color_info['time_deal']>=$time_sale_expired))
						{
							if(!empty($color_info)) $price_deal_show = $color_info['price']; 
							else $price_deal_show = $detail['price'];
							if(!empty($color_info)) $price_deal = $color_info['price_deal']; 
							else $price_deal = $detail['price_deal'];
							$saving = Common::formatNumber($price_deal_show-$price_deal);
							?>
                            <div data-selenium="ProductPrice" class="pPrice">
                                <p>Giá: <?php echo Common::formatNumber($price_deal_show);?> VND</p>
                                <p>
                                Giảm giá: 
                                <span class="c32 OpenSans-600-normal">
                                    <?php echo $saving;?> VND
                                </span>
                                </p>				
                            </div>
                            <div class="youPay" data-selenium="youPayPrice">
                                <meta itemprop="priceCurrency" content="VNĐ">
                                <p class="fs16 clearfix"> <span class="you-pay-final"> Giá KM: </span> <span class="ypYouPay c32 right fs24 OpenSans-600-normal"><?php echo Common::formatNumber($price_deal);?> VND
                                    <meta itemprop="price" content="<?php echo Common::formatNumber($price_deal);?>">
                                    </span> </p>
                                <p>
                                	Thời gian KM: <?php echo date('d/m/Y', $detail['time_deal']);?>
                                </p>
                            </div>
                            <?php
						}
						else
						{
							if(!empty($color_info)) $price_show = $color_info['price']; 
							else $price_show = $detail['price'];
							?>
                            <div class="youPay" data-selenium="youPayPrice">
                                <meta itemprop="priceCurrency" content="VNĐ">
                                <p class="fs16 clearfix"> <span class="you-pay-final"> Giá: </span> <span class="ypYouPay c32 right fs24 OpenSans-600-normal"><?php echo Common::formatNumber($price_show);?> VND
                                    <meta itemprop="price" content="<?php echo Common::formatNumber($price_show);?>">
                                    </span> </p>
                            </div>
                            <?php
						}
                        ?>
                        
                        
                        <div>
                        	<?php
							$price_cart = 0;
							if(!empty($color_info))
							{
								if($color_info['price_deal']!=0 && $color_info['time_deal']!=0 && $color_info['time_deal']>=$time_sale_expired)
									$price_cart = $color_info['price_deal'];
								else
									$price_cart = $color_info['price'];
							}
							else
							{
								if($detail['price_deal']!=0 && $detail['time_deal']!=0 && $detail['time_deal']>=$time_sale_expired)
									$price_cart = $detail['price_deal'];
								else
									$price_cart = $detail['price'];
							}
                            ?>
                            <form name="addItemToCart" class="atcForm clearfix dotted-border submitToOnePopup" method="post" action="<?php echo $this->linkCanoncical;?>" >
                            	<label class="fs14 quantity-label upper">Số lượng</label>
                                <input type="text" data-mq="10" data-selenium="atcForminput" size="2" value="1" name="qty" class="atcForminput quantity js-mqQty fs20" id="qty">
                                
                                <div data-selenium="addToCartButton" class="addToCartButton addToCart ">
                                    <button type="button" class="atc-btn atcImage blueBtn pill-shaped-button fs26 cursor-pointer one-line borderBox" onclick="addCart(<?php if(!empty($color_info)) echo $color_info['id']; else echo $detail['id'];?>, <?php if(!empty($color_info)) echo 2; else echo 1;?>, $('#qty').val(),<?php echo $price_cart;?>);">Thêm vào giỏ hàng</button>
                            </div>
                            </form>
                            
                        </div>
                        <!-- End add to cart form -->
                        <!-- End Price Zone -->
                    </div>
                    <div class="ask-experts c28 chatTypes_4" data-selenium="AskExperts">
                        <p class="fs16 OpenSans-600-normal chatTypeBlack">Liên hệ để có giá tốt nhất: </p>
                        <p class="ask-experts-links"> <span class="call-experts c28 fs14" href="tel:8006066969">
                            <svg class="phone">
                                <use xlink:href="#phone"></use>
                            </svg>
                            0965.505.515 </span> <a class="c31 noUnderline openInPopup fs14" href="https://www.facebook.com/vn.japan"> <span class="underline-on-hover chatType_4">Live Chat</span> </a> </p>
                    </div>
                </div>
            </div>
            <div class="print-email right fs14" data-selenium="productPrintEmail"> <a class="openInOnePopupLayer email underline-on-hover" href="mailto:vnjapancamera@gmail.com" data-selenium="productEmail" target="email">
                <svg class="envelope">
                    <use xlink:href="#envelope"></use>
                </svg>
                <span>Email</span></a> <a class="print js-print underline-on-hover" href="javascript:" onclick="window.print() ;" data-selenium="productPrint">
                <svg class="printer">
                    <use xlink:href="#printer"></use>
                </svg>
                <span>Print</span> </a> </div>
            <!-- End topRight -->
        </div>
        <div style="min-height: 230px;" class="section-wrapper freq-rec-accessories kf-fadeIn" id="freq-rec-accessories">
            <div class="freqBoughtContainer">
                <div class="freqBought-innerWrapper new-page-width clearfix">
                    <div class="freqBoughtHeader">Phụ kiện khác <span class="freqRecViewAll underline-on-hover js-acc-view-all">Xem thêm
                        <svg>
                            <use xlink:href="#right-arrow"></use>
                        </svg>
                        </span></div>
                    <div class="freqBoughtItems clearfix twoGridAccssories">                        
                        <?php
						$total_access = sizeof($other);
						$style = '';
						if($total_access==1) $style = 'style="width:100%"';
						if($total_access==2) $style = 'style="width:48%"';
						if($total_access==3) $style = 'style="width:33%"';
						if($total_access>=4) $style = 'style="width:24%"';
						$k = 0;
						if($other)
						foreach($other as $row)
						{
							$src_img = Common::getImage($row['picture'], 'access', '', 'small');
							$link_access = Url::createUrl('access/detail', array('access_id'=>$row['id'], 'alias'=>$row['alias']));
							$class = '';							
							
							?>
                            <div class="freqBoughtItem js-item  js-bhItemObj" <?php echo $style;?>>
                                <div class="freqBoughtItemImageContainer"> <img src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>"> </div>
                                <div class="freqBoughtItemDescription"> <a style="height:38px;" href="<?php echo $link_access;?>" class="freqBoughtItemTitle multiline underline-on-hover cursor-pointer"> <?php echo $row['title'];?> </a>
                                    <div class="freqBoughtItemPrice fs16"> <span class="c7 bold"><?php echo Common::formatNumber($row['price']);?></span> VND </div>
                                    <div class="freqBoughtItemAtc">
                                        <div class="freqBoughtItemAtcLink underline-on-hover fs14 bold c31"> <a class="atc-link fs16 smbold c5 js-ajaxItemAction noUnderline" href="javascript:" onclick="addCart(<?php echo $row['id'];?>, 1, 1,<?php echo $row['price'];?>);">Thêm vào giỏ hàng</a> </div>
                                    </div>
                                </div>
                            </div>
							
							<?php
							$k++;
						}
						?>
                        
                    </div>
                </div>
            </div>
        </div>
        <div id="bottomWrapper" class="clearfix ui-tabs ui-widget ui-widget-content ui-corner-all" data-selenium="bottomPage">
            <div id="greenNav" class="nav-tabs-outer-wrapper js-nav-tabs-outer-wrapper stick-nav--bottom">
                <div id="navTabs" class="nav-tabs-inner-wrapper">
                    <ul role="tablist" id="nav" class="findLast new-page-width ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" data-selenium="prodNav">
                        <li aria-selected="true" aria-labelledby="ui-id-6" aria-controls="ov" tabindex="0" role="tab" class="cursor-pointer   current ui-state-default ui-corner-top ui-tabs-active ui-state-active" id="navOverView" data-sectiontab="overview" data-selenium="navOverView"> <a id="ui-id-6" tabindex="-1" role="presentation" class="ui-tabs-anchor" href="#ov" onclick="cmCreateElementTag('MATB200GR-REG', 'MAIN:Prod:Tab Overview');" data-selenium="OverviewTab"> <span>Mô tả</span> <span class="navDownArrowIcon">
                            <svg>
                                <use xlink:href="#arrow-down-light"></use>
                            </svg>
                            </span> </a> </li>
                        <li aria-selected="false" aria-labelledby="ui-id-7" aria-controls="sp" tabindex="-1" role="tab" class="cursor-pointer ui-state-default ui-corner-top" id="navSpecifications" data-sectiontab="specifications" data-selenium="navSpecifications"> <a id="ui-id-7" tabindex="-1" role="presentation" class="ui-tabs-anchor" href="#sp" onclick="cmCreateElementTag('MATB200GR-REG', 'MAIN:Prod:Tab Specifications');" data-selenium="SpecificationTab"> <span>Thông số kỹ thuật</span> <span class="navDownArrowIcon">
                            <svg>
                                <use xlink:href="#arrow-down-light"></use>
                            </svg>
                            </span> </a> </li>
                        <!--
                        <li aria-selected="false" aria-labelledby="ui-id-10" aria-controls="ac" tabindex="-1" role="tab" id="navAccessories" class="cursor-pointer  ui-state-default ui-corner-top" data-sectiontab="accessories" data-selenium="navAccessories"> <a id="ui-id-10" tabindex="-1" role="presentation" href="#ac" rel="nofollow" data-selenium="accessoryIntermediateTab" onclick="cmCreateElementTag('MATB200GR-REG','MAIN:Prod:Tab Accessories');" class="ui-tabs-anchor"> <span>Accessories</span> <span class="navDownArrowIcon">
                            <svg>
                                <use xlink:href="#arrow-down-light"></use>
                            </svg>
                            </span> </a> </li>
                         -->
                        <li aria-selected="false" aria-disabled="true" aria-labelledby="scrollTop" aria-controls="ui-tabs-1" tabindex="-1" role="tab" class="empty-li ui-state-default ui-corner-top ui-state-disabled last"> <a tabindex="-1" role="presentation" id="scrollTop" class="scrollTop-wrapper right clearfix cursor-pointer ui-tabs-anchor" href="javascript:void(0)"> <span class="scrollTopIcon">
                            <svg>
                                <use xlink:href="#arrow-up-light"></use>
                            </svg>
                            </span> <span class="smbold upper fs14">to top</span> </a> </li>
                    </ul>
                </div>
            </div>
            <!-- Start bottomBodyWrapper -->
            <div class="bottomBodyWrapper clearfix" data-selenium="bottomBodyWrapperPage">
                <div aria-hidden="false" aria-expanded="true" role="tabpanel" aria-labelledby="ui-id-6" id="ov" class="section-wrapper mainTabs  removeSectionHeaders  ui-tabs-panel ui-widget-content ui-corner-bottom" data-section="overview">
                    <div id="Overview" class="section-inner-wrapper new-page-width noTimeline" data-selenium="OverviewBody">
                        <div class="toggleFadeWrap"> <span class="toggleButton toggle-more-less"> <span class="toggle-show-more">Show more</span> <span class="toggle-show-less">Show less</span> </span> </div>
                        <div class="inner-wrapper clearfix ">
                            <div class="sectionHeader">Overview</div>
                            <div class="leftTimeline  js-leftOverviewTimeline">
                                <ul class="tickerList">
                                    <li data-tickertrigger="ov-ft-1"><span>1</span><span class="trWrap"><span class="ticker">Description</span></span></li>
                                </ul>
                            </div>
                            <div class="leftPanel">
                                <div class="featureWrapper bulletlist clearfix" data-selenium="featureWrapper">
                                	<!--
                                    <div class="primaryExploraBanner">
                                        <div class="detailPageBanners"> <a href="https://www.bhphotovideo.com/explora/photography/hands-review/magnus-tripods-offer-support-and-versatility" class="js-openSlideInTray">
                                            <div class="bannerSqImgLeft"> <img class="js-lazyImage" src="detail_phukien_files/explora_sidebar_placeholder.jpg" data-src="/images/explora_sidebar_placeholder.jpg"> </div>
                                            <div class="bannerDescRight">
                                                <p>Magnus Tripods Offer Support and Versatility</p>
                                                <div><span class="readMoreButton">Read More <span class="readMoreRightArrow">
                                                    <svg>
                                                        <use xlink:href="#right-arrow"></use>
                                                    </svg>
                                                    </span></span></div>
                                            </div>
                                            </a> </div>
                                    </div>
                                    -->
                                    <div class="ov-wrapper js-overview-desc">
                                        <p class="ov-desc">
                                        
                                        <?php echo $detail['description'];?>
                                        </p>
                                    </div>
                                    
                                </div>
                                
                            </div>
                            <div class="rightPanel">
                                <div class="whatsInTheBoxWrapper">
                                    <div class="toggleFadeWrap"> <span class="toggleButton smallToggle invert-color"><span class="minus"></span>
                                        <svg>
                                            <use xlink:href="#plus"></use>
                                        </svg>
                                        </span> </div>
                                    <div class="whatsInTheBoxHeader"> In the Box </div>
                                    <div class="whatsInTheBoxBody">
                                        <div class="c2 fs14 " data-selenium="itemIncTitle">
                                            <div class="completeItemName"> <?php echo $detail['title'];?></div>
                                        </div>
                                        <?php echo $detail['in_the_box'];?>
                                    </div>
                                </div>
                                <div class="itemBanners">
                                    <div class="itemBannersInnerWrapper">
                                        <div class="itemLinks"> </div>
                                    </div>
                                </div>
                                <div class="rightTimeline">
                                    <div class="js-rightOverviewTimeline rightTimelineContainer">
                                        <div class="timelineHeader">Table of Contents</div>
                                        <ul class="tickerList">
                                            <li data-tickertrigger="ov-ft-1"><span>1</span><span class="trWrap"><span class="ticker">Description</span></span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div aria-hidden="true" aria-expanded="false" style="display: none;" role="tabpanel" aria-labelledby="ui-id-7" id="sp" class="section-wrapper mainTabs  removeSectionHeaders  ui-tabs-panel ui-widget-content ui-corner-bottom" data-section="specifications">
                    <div id="Specification" class="section-inner-wrapper new-page-width " data-selenium="SpecificationBody">
                        <div class="toggleFadeWrap"> <span class="toggleButton toggle-more-less"> <span class="toggle-show-more">Show more</span> <span class="toggle-show-less">Show less</span> </span> </div>
                        <div class="inner-wrapper clearfix">
                            <div class="sectionHeader">Thông số kỹ thuật</div>
                            <div class="leftPanel">
                                <div data-selenium="specWrapper" class="specWrapper">
                                    <?php echo $detail['specs'];?>
                                </div>
                            </div>
                            <div class="rightPanel">
                                <script>lazyLoad.lazyCss("https://www.bhphotovideo.com/find/stylesheet.jsp?files=brightcove_icons.css&min=Y&vr=327372615",300);</script>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!--
                <div aria-hidden="true" aria-expanded="false" style="display: none;" role="tabpanel" aria-labelledby="ui-id-10" id="ac" class="section-wrapper mainTabs  removeSectionHeaders  ui-tabs-panel ui-widget-content ui-corner-bottom" data-section="accessories">
                    <div id="accSection" class="section-inner-wrapper clearfix new-page-width">
                        <div class="inner-wrapper">
                            <div class="sectionHeader">Accessories</div>
                            <div id="accContent" class="accessoriesContent" data-href="https://www.bhphotovideo.com/bnh/controller/home?O=productDetail&amp;A=accessoryIntermediate&amp;Q=&amp;sku=821151&amp;is=REG&amp;si=acc&amp;via=js&amp;includedIn=detailPage">
                                <div class="emptySectionLoader" style="height: 800px;">
                                    <div style="margin-top: 10%">
                                        <svg class="circle-loader circle-loader50" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <circle class="fixed" cx="50%" cy="50%" r="40%"></circle>
                                            </g>
                                            <g>
                                                <circle class="rotate" cx="50%" cy="50%" r="40%"></circle>
                                            </g>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                -->
                <div aria-hidden="true" aria-expanded="false" style="display: none;" role="tabpanel" aria-labelledby="scrollTop" aria-live="polite" class="ui-tabs-panel ui-widget-content ui-corner-bottom" id="ui-tabs-1"></div>
            </div>
            <!-- end bottomWrapper -->
        </div>
        <!-- End tMain -->
    </div>
    
</div>
<script>lazyLoad.lazyCss("<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_lazy.css");</script>
<script type="text/javascript">
	lazyLoad.setOdUrl("<?php  echo Yii::app()->params['static_url']; ?>/images/javascripts.js");
</script>