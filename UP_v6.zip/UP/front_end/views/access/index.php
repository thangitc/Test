<div id="categoryLandingContent" class=" clp-hasCategoryImage clp-lightBreadcrumbs clp-lightPageTitle clp-condensableTopBanner">
    <div class="clp-topBannerArea">
    <?php
	$ads_cat = Ads::getAdsCatByPos($cat_id, 0);
	if(!empty($ads_cat))
	{
		$src_img = Common::getImage($ads_cat['picture'], 'ads', '');
		$src_img_small = Common::getImage($ads_cat['picture'], 'ads','', 'small');
		?>
        <div class="clp-pageImage clp-lowResImage" style="background-image: url('<?php echo $src_img_small;?>')"></div>
        <div class="clp-pageImage js-pageImage" style="background-image: url('<?php echo $src_img;?>')"></div>
		<?php
	} 
    ?>
        
    </div>
    <div class="clp-content clearfix">
        <div class="new-page-width">
            <ul id="breadcrumbs" class="page-width">
                <li class="first"><a href="<?php echo Yii::app()->params['base_url']; ?>">Trang chủ</a></li>
                <li> <a href="<?php echo Url::createUrl('access/index', array('alias'=>$cat_info['alias'], 'cat_id'=>$cat_info['id']));?>"> <?php echo $cat_info['title'];?> </a> </li>
            </ul>
            <h1 class="clp-pageTitle"><?php echo $cat_info['title'];?></h1>
        </div>
        <div class="clp-sectionWrapper">
            <div class="new-page-width clearfix ">
                <div class="clp-categoryGroups">
                    <div data-selenium="mainCategories">
					<?php
					if($cats && $cat_info['level']==1)
					{
						$link_cat = Url::createUrl('access/index', array('alias'=>$cat_info['alias'], 'cat_id'=>$cat_info['id']));
						?>
						<div class="clp-sectionContainer js-category-wrapper" data-selenium="categoriesSection">
							<a style="position:absolute;" name="<?php echo $cat_info['title'];?>"></a>
							<h2 class="clp-sectionTitle"><a href="<?php echo $link_cat;?>" title="<?php echo $cat_info['title'];?>"><?php echo $cat_info['title'];?></a></h2>
							<ul class="clp-gridItemsContainer">
							<?php
							foreach($cats as $row)
							{
								if($row['parent_id']==$cat_id)
								{
									$link_cat = Url::createUrl('access/cat', array('alias'=>$row['alias'], 'cat_id'=>$row['id']));
									$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
									?>
									 <li style="width:32%;" class="clp-category" data-selenium="category">
									 <a class="overlay-on-hover" href="<?php echo $link_cat;?>" data-selenium="categoryLink" name="<?php echo $row['title'];?>"> <img class="clp-150CatImg" src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>">
										<div class="clp-categoryName"><?php echo $row['title'];?></div>
									</a>
									</li>
									<?php
								}
							}
							?>
							</ul>
						</div>
						<?php
					}
					/*
					$check_sub = 0;
					if($cats)
					foreach($cats as $row)
					{
						if($row['parent_id']==$cat_info['id'])
						{
							if($row['sub_id']!=$row['id'])
							{
								$check_sub=1;
								break;
							}
						}
					}
					if($check_sub==0) //Cac danh muc con ko co con
					{
						if($cat_info['sub_id']==$cat_info['id'])
							$link_cat = Url::createUrl('access/cat', array('alias'=>$cat_info['alias'], 'cat_id'=>$cat_info['id']));
						else
							$link_cat = Url::createUrl('access/index', array('alias'=>$cat_info['alias'], 'cat_id'=>$cat_info['id']));
						?>
                        <div class="clp-sectionContainer js-category-wrapper" data-selenium="categoriesSection">
                            <a style="position:absolute;" name="<?php echo $cat_info['title'];?>"></a>
                            <h2 class="clp-sectionTitle"><a href="<?php echo $link_cat;?>" title="<?php echo $cat_info['title'];?>"><?php echo $cat_info['title'];?></a></h2>
                            <ul class="clp-gridItemsContainer">
                            <?php
                            foreach($cats as $row)
                            {
                                if($row['parent_id']==$cat_id)
                                {
                                    $link_cat = Url::createUrl('access/cat', array('alias'=>$row['alias'], 'cat_id'=>$row['id']));
                                    $src_img = Common::getImage($row['picture'], 'cat', '', 'small');
                                    ?>
                                     <li style="width:33%;" class="clp-category" data-selenium="category">
                                     <a class="overlay-on-hover" href="<?php echo $link_cat;?>" data-selenium="categoryLink" name="<?php echo $row['title'];?>"> <img class="clp-150CatImg" src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>">
                                        <div class="clp-categoryName"><?php echo $row['title'];?></div>
                                    </a>
                                    </li>
                                    <?php
                                }
                            }
                            ?>
                            </ul>
                        </div>
                        <?php
						
					}
					else
					{
						if($cats && $cat_info['level']==1)
						foreach($cats as $row)
						{
							if($row['parent_id'] == $cat_id )
							{
								if($row['sub_id']==$row['id'])
									$link_cat = Url::createUrl('access/cat', array('alias'=>$row['alias'], 'cat_id'=>$row['id']));
								else
									$link_cat = Url::createUrl('access/index', array('alias'=>$row['alias'], 'cat_id'=>$row['id']));
								?>
								<div class="clp-sectionContainer js-category-wrapper" data-selenium="categoriesSection">
									<a style="position:absolute;" name="<?php echo $row['title'];?>"></a>
									<h2 class="clp-sectionTitle"><a href="<?php echo $link_cat;?>" title="<?php echo $row['title'];?>"><?php echo $row['title'];?></a></h2>
									<ul class="clp-gridItemsContainer">
										<?php
										foreach($cats as $row2)
										{
											 if($row2['parent_id']==$row['id'])
											 {
												 $link_cat = Url::createUrl('access/cat', array('alias'=>$row2['alias'], 'cat_id'=>$row2['id']));
												 $src_img = Common::getImage($row2['picture'], 'cat', '', 'small');
												 ?>
												 <li style="width:33%;" class="clp-category" data-selenium="category">
												 <a class="overlay-on-hover" href="<?php echo $link_cat;?>" data-selenium="categoryLink" name="<?php echo $row2['title'];?>"> <img class="clp-150CatImg" src="<?php echo $src_img;?>" alt="<?php echo $row2['title'];?>">
													<div class="clp-categoryName"><?php echo $row2['title'];?></div>
												</a>
												</li>
												 <?php
											 }
										}
										?>
									</ul>
								</div>
								<?php
							}
						}
						
						if($cats && $cat_info['level']==2)
						{
							if($cat_info['sub_id']==$cat_info['id'])
								$link_cat = Url::createUrl('access/cat', array('alias'=>$cat_info['alias'], 'cat_id'=>$cat_info['id']));
							else
								$link_cat = Url::createUrl('access/index', array('alias'=>$cat_info['alias'], 'cat_id'=>$cat_info['id']));
							?>
							<div class="clp-sectionContainer js-category-wrapper" data-selenium="categoriesSection">
								<a style="position:absolute;" name="<?php echo $cat_info['title'];?>"></a>
								<h2 class="clp-sectionTitle"><a href="<?php echo $link_cat;?>" title="<?php echo $cat_info['title'];?>"><?php echo $cat_info['title'];?></a></h2>
								<ul class="clp-gridItemsContainer">
								<?php
								foreach($cats as $row)
								{
									if($row['parent_id']==$cat_id)
									{
										$link_cat = Url::createUrl('access/cat', array('alias'=>$row['alias'], 'cat_id'=>$row['id']));
										$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
										?>
										 <li style="width:33%;" class="clp-category" data-selenium="category">
										 <a class="overlay-on-hover" href="<?php echo $link_cat;?>" data-selenium="categoryLink" name="<?php echo $row['title'];?>"> <img class="clp-150CatImg" src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>">
											<div class="clp-categoryName"><?php echo $row['title'];?></div>
										</a>
										</li>
										<?php
									}
								}
								?>
								</ul>
							</div>
							<?php
						}	
					}
                    */
                    ?>
                       
                    </div>
                    <!--end#pageBody-->
                </div>
                <div class="clp-sidebar has-item" data-selenium="sideContent">
                    <div class="clp-sectionContainer">
                    <?php
					if($hot_news)
					foreach($hot_news as $row)
					{
						$link_new = Url::createUrl('news/detail', array('alias'=>$row['alias'], 'news_id'=>$row['id']));
						$src_img = Common::getImage($row['picture'], 'news', '', 'small');
						?>
                        <div>
                        	<a href="<?php echo $link_new;?>" class="clp-textSidebarBanner overlay-on-hover js-exploraLink">
                            <div class="clp-sidebarImgHelper"> <img class="clp-sidebarBannerImg js-clp-unveil" src="<?php echo $src_img;?>" data-src="<?php echo $src_img;?>"> </div>
                            <div class="clp-sidebarBanner-text clp-sidebarBanner-textWithHeading">
                                <h6><?php echo $row['title'];?></h6>
                                <div class="ellipsizer">
                                    <p><?php echo $row['introtext'];?></p>
                                </div>
                            </div>
                            </a>
						</div>
                        <?php
					}
                    ?>
                    </div>
                </div>
                <!-- end clp-sidebar -->
            </div>
        </div>
    </div>
</div>