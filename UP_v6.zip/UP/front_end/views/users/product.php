<div class="t-main full-width clearfix">
    <div class="my-account-outer">
        <div class="new-page-width">
            <?php echo $this->renderPartial('_left');?>
            <div class="col-2">
                <div class="content-block">
                    <div class="section expandable" data-selenium="giftCardSection" id="GiftCard">
                        <div class="sHeader" data-selenium="GCHead">
                            <div class="column arrowContainer"><span class="arrow"></span></div>
                            <div class="column sTitleContainer">
                                <h2 class="sTitle" data-selenium="GCTitle">Sản phẩm đã mua</h2>
                                <p class="sSubTitle" style="font-size:12px;">
                                	Danh sách sản phẩm khách hàng đã mua trên VJCamera
                                </p>
                            </div>
                            <p class="sInfo"></p>
                            <span class="clearB" style="display:block;"></span>
						</div>
                        <div class="sContent sContentOverride" data-selenium="GCContent">
                        
                        </div>
                    </div>
                </div>
                
                
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <!-- .my-account-outer -->
    <!-- working on email  -->
</div>
