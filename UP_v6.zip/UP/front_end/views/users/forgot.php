<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="ie lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="ie ie7"> <![endif]-->
<!--[if IE 8]>         <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>         <html class="ie ie9"> <![endif]-->
<html class="gecko win js">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_login.css">
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<title>Đăng nhập</title>
</head>
<body class="full-width twelve c2 loginForm " style="width:378px;">
    <div class="cont">
        <form id="form_login2" class="login clearfix cent-width">
            <label>
                <input id="email" name="emailAddress" placeholder="Địa chỉ Email" maxlength="50" class="fs14" type="text">
            </label>                     
            <button onClick="forgot();return false;" class="loginButton fs18">Reset mật khẩu</button>            
        </form>
       
        <div class="no-acc bold">
            
        </div>
        <br>
        <span id="result_forgot" style="font-size:14px;">
		</span>
            
    </div>

<script>

function forgot()
{	
	var email=$('#email').val();
	

	$.ajax({
		type: "POST",
		url: '<?php echo Url::createUrl('ajax/forgot');?>',
		data: {
			email:email
		},
		success: function(resp){
		}
	});
	return false;
};
</script>
</body>
</html>
