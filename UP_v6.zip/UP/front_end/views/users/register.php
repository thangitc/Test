<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="ie lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="ie ie7"> <![endif]-->
<!--[if IE 8]>         <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>         <html class="ie ie9"> <![endif]-->
<html class="gecko win js">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_login.css">
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<title>Đăng nhập</title>
</head>
<body class="full-width twelve c2 loginForm " style="width:378px;">
    <div class="cont">
        <form id="form_login2" class="login clearfix cent-width">
        	<label>
                <input id="fullname" placeholder="Họ và tên" maxlength="50" class="fs14" type="text">
            </label>
            <label>
                <input id="email" name="emailAddress" placeholder="Địa chỉ email đăng nhập" maxlength="50" class="fs14" type="text">
            </label>
            <label>
            	<input id="password" name="password" data-selenium="password" placeholder="Mật khẩu" maxlength="15" class="fs14" value="" type="password">
            </label>
            <label>
	            <input id="re_password" name="password" data-selenium="password" placeholder="Nhập lại mật khẩu" maxlength="15" class="fs14" value="" type="password">            
            </label>
            <label>
                <input id="mobile" name="mobile" placeholder="Số điện thoại" maxlength="50" class="fs14" type="text">
            </label>
            <button onClick="register();return false;" class="loginButton fs18">Tạo tài khoản</button>            
        </form>
       
        <br>
        <span id="result_reg" style="font-size:14px;">
		</span>
            
    </div>

<script>
$(function(){
	$('#form_login2').keypress(function(e){
		switch(e.which)
		{
			case 13: 
				register();
			break;
			default:
			break;
		}
	});
});
function register()
{
	
	var error='';
	var fullname=$('#fullname').val();
	var mobile=$('#mobile').val();
	var email=$('#email').val();
	var password=$('#password').val();
	var re_password=$('#re_password').val();
	if(fullname=='')
	{
		error+='Vui lòng nhập họ tên!<br>';
	}
	if(email=='')
	{
		error+='Vui lòng nhập địa chỉ email!<br>';
	}
	if(password=='')
	{
		error+='Vui lòng nhập mật khẩu!<br>';
	}
	if(re_password=='')
	{
		error+='Vui lòng nhập lại mật khẩu!<br>';
	}
	if(mobile=='')
	{
		error+='Vui lòng nhập số điện thoại liên hệ!<br>';
	}
	if(error!='')
	{
		$("#result_reg").css('color','red');
		$("#result_reg").html(error);
		return false;
	}
	$.ajax({
		type: "POST",
		url: '<?php echo Url::createUrl('ajax/regAcc');?>',
		data: {
			fullname:fullname,
			mobile:mobile,
			email:email,
			password:password,
			re_password:re_password
		},
		success: function(resp){
			if(resp['status']==0)
			{
				$("#result_reg").html(resp['error']);
			}
			else
			{
				window.location.href='<?php echo Url::createUrl('users/dashboard');?>';
			}
		}
	});
};
</script>
</body>
</html>
