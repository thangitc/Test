<h1><a style="text-decoration:none;" href="<?php echo Url::createUrl('users/dashboard');?>">My Account</a></h1>
<div class="col-1 my-account-nav">
    <div class="nav nav-1">
        <a href="<?php echo Url::createUrl('users/edit');?>">Thông tin cá nhân</a>
        <a href="<?php echo Url::createUrl('users/gifcard');?>">Gift / Rewards Card Balance</a>
    </div>
    <h2>SẢN PHẨM</h2>
    <div class="nav nav-2">
        <a href="<?php echo Url::createUrl('users/product');?>">Sản phẩm đã mua</a>
        </div>
</div>