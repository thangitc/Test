    <div class="t-footer styled-async">
    	<!--
        <footer class="footer OpenSans-600-normal home-page-footer ">
            <div class="footer-inner footer-contact-info clearfix " data-selenium="footerContact">
                <div class="upper inlineBlock"> <span class="fs14 c37 OpenSans-300-normal">Hotline</span> <br>
                    <span class="fs30 c38 OpenSans-600-normal">0965.505.515</span> <br>
                    <span class="fs16 OpenSans-300-normal"><span class="c35 lower">or</span> Mobile: 01688.888.400 </span> </div>
                <div class="upper inlineBlock"> <span class="fs14 c37 OpenSans-300-normal">Hỗ trợ khách hàng, sửa chữa</span> <br>
                    <span class="fs30 c38 OpenSans-600-normal">01684.049.059</span> </div>
            </div>
            <div class="footer-customer-informaion" data-selenium="footerCustI">
                <div class="footer-inner">
                    <div class="footer-customer-informaion-top clearfix">
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Hình ảnh</span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">Sản phẩm đã qua sử dụng luôn có hình ảnh thật, chụp chi tiết, được đánh giá chất lượng rõ ràng, mô tả khách quan</span> 
                            </a>
						</div>
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Bảo hành</span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">1 đổi 1 trong 15 ngày, cam kết BH nghiêm chỉnh 3-6-12 tháng, trong thời gian chờ BH, VJCamera cho khách hàng mượn miễn phí thiết bị tương đương.</span> 
                            </a>
						</div>
                        
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Hỗ trợ </span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">Tư vấn, giải đáp thắc mắc với khách hàng 1 cách khách quan, chính xác nhất, luôn đưa cho khách hàng các sự lựa chọn khác nhau.</span> 
                            </a>
						</div>
                        
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Order </span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">Những mặt hàng khó tìm ở VN, đặt hàng trực tiếp từ Nhật, VJCamera tư vấn khách hang địa điểm mua và luôn có mức giá tốt nhất.</span> 
                            </a>
						</div>
                        
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Free Shipping </span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">Free ship mọi miền tổ quốc với đơn hang giá trị >3tr, không giới hạn khoảng cách với khách hàng của VJCamera</span> 
                            </a>
						</div>
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Giá sốc </span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">Hàng ngày sẽ có sản phẩm giảm giá sốc, cập nhật vào lúc 10h sáng, chỉ áp dụng trong thời gian ngắn</span> 
                            </a>
						</div>
                        
                    </div>
                    
                </div>
            </div>
            
        </footer>
        -->
    </div>
    <!-- end t-footer -->
</div>
</body>
</html>
<?php 
$ip = Common::getRealIpAddr();
$list_ip = array('117.1.151.170', '127.0.0.1');
if(in_array($ip,$list_ip)){
?>
<div class="showSql">                    
   <fieldset>
		<legend>Database</legend>
		<?php 
		echo Yii::app()->db->showSql;
		?>
	</fieldset>
	
	<?php echo "<b>Thời gian tải trang:</b> ".sprintf('%0.5f',Yii::getLogger()->getExecutionTime())." giây"; ?>
</div>
<?php }?>