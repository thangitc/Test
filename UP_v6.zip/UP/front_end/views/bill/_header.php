<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="ie lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="ie ie7"> <![endif]-->
<!--[if IE 8]>         <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>         <html class="ie ie9"> <![endif]-->
<html class="gecko win js">
<head>
<?php
require_once("_meta.php");
$controller_id = Yii::app()->controller->id;
$action_id = Yii::app()->controller->action->id;
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<?php if($controller_id =='access' || $controller_id =='bList'){?>
<body id="details-page" class="detailPage en" data-selenium="details-page">
<?php } else if($controller_id=='cart') { ?>
<body class="" id="cart-page">
<?php } else { ?>
<body class="en">
<?php } ?>
<?php
	if($controller_id=='bList' && $action_id=='detail')
		$this->renderPartial('application.views.layouts._svg_detail');
	else
		$this->renderPartial('application.views.layouts._svg');
?>
<div class="t-content">
    <div class="t-head">
    	<?php $this->renderPartial('application.views.layouts._svg1') ;?>
        <?php $this->renderPartial('application.views.layouts._svg2') ;?>
        <header id="header" class="page-header js-header" data-selenium="page-header">
        	<!--
            <section class="header-top" style="border-bottom:none;">
                <div class="new-page-width"> <span class="left"> <span class="site-links" data-selenium="siteLinkS"> <span data-selenium="openSites" class="open-more-sites smbold current-reg"> Other VJCamera Corp.
                    <svg>
                        <use xlink:href="#arrowDown"></use>
                    </svg>
                    </span>
                    <ul data-selenium="siteLinks" class="js-siteLinksDropdown">
                        <li data-selenium="rootPage" class="active first"> <a class="site-link-nav" href="<?php echo Yii::app()->params['baseUrl']; ?>" data-selenium="rootPageLink">VJCamera.com site</a></li>
                        <li data-selenium="gsaPage" class=""> <a class="site-link-nav" href="http://vn-japan.com" data-selenium="gsaLink">vn-japan.com</a> </li>
                    </ul>
                    </span> </span> 
                    
                    <span class="right"> <span style="line-height:inherit; margin-right:39px;" id="js-phonenum" class="phone js-phone fs14 c4 smbold">Hotline:0965.505.515 / Mobile: 01688.888.400</span></span>
                    <div class="scene">
                        <div class="cube outer" data-selenium="cubeOut">
                            
                            <div class="cube-face cube-face-front"><span class="tagline fs16"> <span class="bold">Everything For Your Passion</span> </span> </div>
                            
                        </div>
                    </div>
                    <br class="clearfix">
                </div>

            </section>
            -->
            <section class="header-main new-page-width" style="height:52px; padding-top:10px;">
                <svg class="mobile-menu left">
                    <use xlink:href="#menu"></use>
                </svg>
                <a class="logo left" href="<?php  echo Yii::app()->params['baseUrl']; ?>" data-selenium="rootPageLink" title="VJCamera">
                <img style="width:380px;padding-top: 15px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/logo_header.png" />
                </a>
            
                <div data-clicked="no" id="account-cart" data-selenium="accCart" style="width:393px; padding-top:0px; line-height:22px; margin-right:120px;">
                	<strong>Công Ty TNHH Vn-Japan Camera</strong><br>
                    SĐT: 0965.505.515<br>
                    Cơ sở 1: 11 Nguyễn Phong Sắc, Cầu Giấy, Hà Nội<br>
                    Cơ sở 2: 237/80B Trần Văn Đang, Q3, HCM (CS Bảo Hành)
                </div>
                <!-- .account-cart -->
            </section>
            
        </header>
        
    </div>