<?php
class Combos extends CActiveRecord
{
	public function getComboByProductId($product_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM tbl_combos WHERE id IN (SELECT combo_id FROM tbl_combos_products WHERE product_id=".$product_id." AND product_type=0)";
		$command = $connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}

    public function getProductsByCombo($combo_id)
    {
        $connect=Yii::app()->db;
        $sql = "SELECT * FROM tbl_combos_products WHERE combo_id=".$combo_id;
        $command = $connect->createCommand($sql);
        $rows = $command->queryAll();

        $list_camera = array();
        $list_access = array();
        $list_camera_id = '0';
        $list_access_id = '0';

        if($rows){
            foreach($rows as $row)
            {
                if($row['product_type']==0){
                    $list_camera_id.=','.$row['product_id'];
                }else{
                    $list_access_id.=','.$row['product_id'];
                }
            }
        }

        //Camera
        $sql = "SELECT * FROM b_camera WHERE id IN (".$list_camera_id.")";
        $command = $connect->createCommand($sql);
        $row_cameras = $command->queryAll();
        if($row_cameras){
            foreach($row_cameras as $row){
                $list_camera[$row['id']] = $row;
            }
        }
        //Access
        $sql = "SELECT * FROM b_accessories WHERE id IN (".$list_access_id.")";
        $command = $connect->createCommand($sql);
        $row_access = $command->queryAll();
        if($row_access){
            foreach($row_access as $row){
                $list_access[$row['id']] = $row;
            }
        }
        return array($rows, $list_camera, $list_access);
    }
}
?>