<div id="addOnAccContent" class="">
    <div class="aosLayoutWrapper">
        <div class="aosRow">
            <div class="aosMainItemImage " data-price="3299.00"><img
                        src="https://static.bhphoto.com/images/images500x500/canon_eos_5d_mark_iv_1472097112000_1274705.jpg"
                        title="Canon EOS 5D Mark IV DSLR Camera (Body Only)"></div>
            <div class="aosItemImgWrapper js-miniProdLayer " data-detailonly="true"
                 data-miniproditem="1109799-REG-false" data-sku="1109799_REG" data-bundleid="14838" data-savings="20.00"
                 data-amount="99.88" data-itemcode="ADCCPP12"><img src="/images/images150x150/1424062211000_1109799.jpg"
                                                                   title="Adobe Creative Cloud Photography Plan (12 Month Subscription, Download Card)">
            </div>
            <div class="aosItemImgWrapper js-miniProdLayer " data-detailonly="true"
                 data-miniproditem="1363001-REG-false" data-sku="1363001_REG" data-bundleid="15187" data-savings="20.00"
                 data-amount="79.99" data-itemcode="ADPRELM18"><img
                        src="/images/images150x150/1507121411000_1363001.jpg"
                        title="Adobe Premiere Elements 2018 (Disc)"></div>
            <div class="aosTotalWrapper">
                <div class="aosSavingsCircleWrapper">
                    <div class="aosSavingsCircle"><span>YOU SAVE <br><b>$40.00</b></span></div>
                </div>
                <div class="aosTotalAmountWrapper">
                    <div class="aosTotalAmount"><span>Total:</span><span>$3,478<span class="superscript_cents">87</span></span>
                    </div>
                    <div class="aosAddBundleToCartBtnWrapper"><span>Add to Cart</span> <span>View Cart</span></div>
                </div>
            </div>
        </div>
        <div class="aosRow">
            <div class="aosMainItemTitleWrapper"> Canon EOS 5D Mark IV DSLR Camera (Body Only)</div>
        </div>
        <div class="aosRow aosSelectors ">
            <div class="aosItemSelectorWrapper">
                <div class="aosItemSelector aosItemSelected" data-sku="1109799_REG" data-bundleid="14838"></div>
            </div>
            <div class="aosItemName"> Adobe Creative Cloud Photography Plan (12 Month Subscription, Download Card)
                <div class="aosItemLevelPricingWrapper"><span class="aosPriceBeforeSavings">$119<span
                                class="superscript_cents">88</span></span><span class="aosFinalPrice">$99<span
                                class="superscript_cents">88</span></span></div>
            </div>
        </div>
        <div class="aosRow aosSelectors ">
            <div class="aosItemSelectorWrapper">
                <div class="aosItemSelector aosItemSelected" data-sku="1363001_REG" data-bundleid="15187"></div>
            </div>
            <div class="aosItemName"> Adobe Premiere Elements 2018 (Disc)
                <div class="aosItemLevelPricingWrapper"><span class="aosPriceBeforeSavings">$99<span
                                class="superscript_cents">99</span></span><span class="aosFinalPrice">$79<span
                                class="superscript_cents">99</span></span></div>
            </div>
        </div>
    </div>
    <div class="aosAllSavingsWrapper">
        <div class="aosAllSavingsBtn">See all Add-On Savings</div>
    </div>
</div>