<script type="text/javascript" src="<?php  echo Yii::app()->params['static_url']; ?>/js/core.js"></script>
<script type="text/javascript" src="<?php  echo Yii::app()->params['static_url']; ?>/js/jquery-ui-1.js"></script>
<script type="text/javascript" src="<?php  echo Yii::app()->params['static_url']; ?>/js/mouse.js"></script>
<script type="text/javascript" src="<?php  echo Yii::app()->params['static_url']; ?>/js/slider.js"></script>
<script type="text/javascript" src="<?php  echo Yii::app()->params['static_url']; ?>/js/jquery-ui-touch-punch.js"></script>
<script type="text/javascript">
/* <![CDATA[ */
var woocommerce_price_slider_params = {"currency_symbol":" Triệu","currency_pos":"right","min_price":"<?php if(isset($min_price)) echo $min_price;?>","max_price":"<?php if(isset($max_price) && $max_price!=0) echo $max_price; else echo 100;?>"};
/* ]]> */
</script>
<script type="text/javascript" src="<?php  echo Yii::app()->params['static_url']; ?>/js/price-slider.js"></script>

<div class="categorytopbarWraper">
    <form id="form_order" class="woocommerce_ordering woocommerce-ordering" method="get" action="<?php echo $this->linkCanoncical;?>">
        <select name="orderby" class="orderby" onchange="$('#form_order').submit();">
            <option value="" >&nbsp;&nbsp;Sắp xếp&nbsp;&nbsp;</option>
            <option value="date" <?php if($orderby=='date') echo 'selected';?>>Mới nhất</option>
            <option value="title_asc" <?php if($orderby=='title_asc') echo 'selected';?>>Sắp xếp tiêu đề: A-Z</option>
            <option value="title_desc" <?php if($orderby=='title_desc') echo 'selected';?>>Sắp xếp tiêu đề: Z-A</option>
            <option value="price" <?php if($orderby=='price') echo 'selected';?>>Sắp xếp giá: Tăng dần</option>
            <option value="price_desc" <?php if($orderby=='price_desc') echo 'selected';?>>Sắp xếp giá: Giảm dần</option>
        </select>
        <?php
		if(isset($max_price) && $max_price!=0)
		{
			?>
            <input type="hidden" value="<?php echo $min_price;?>" id="min_price" name="min_price" />
            <input type="hidden" value="<?php echo $max_price;?>" id="max_price" name="max_price" />
            <?php
		}
		if(isset($cat_id) && $cat_id!=0)
		{
			?>
			<input type="hidden" name="cat_id2" value="<?php echo $cat_id;?>" />
			<?php
		}
        ?>
    </form>
    
    <form id="form_cat" class="woocommerce_ordering woocommerce-ordering" method="get" action="<?php echo $this->linkCanoncical;?>">
    	<select style="width:179px;" name="cat_id2" id="cat_id2" onchange="$('#form_cat').submit();">
            <option value="0" selected="selected">&nbsp;&nbsp;Chọn danh mục&nbsp;&nbsp;</option>
            <?php
			$cats = $this->array_category;
            if($cats)
            foreach($cats as $row)
            {
                if($row['parent_id']==0 && $row['cat_type']==1)
                {
                    $selected='';
                    if($cat_id==$row['id']) $selected='selected';
                    ?>
                    <option value="<?php echo $row['id'];?>" <?php echo $selected;?>><?php echo $row['title'];?></option>
                    <?php
                    foreach($cats as $row2)
                    {
                        if($row2['parent_id']==$row['id'])
                        {
                            $selected='';
                            if($cat_id==$row2['id']) $selected='selected';
                            ?>
                            <option value="<?php echo $row2['id'];?>" <?php echo $selected;?>>--<?php echo $row2['title'];?></option>
                            <?php
							/*
                            foreach($cats as $row3)
                            {
                                if($row3['parent_id']==$row2['id'])
                                {
                                    $selected='';
                                    if($cat_id==$row3['id']) $selected='selected';
                                    ?>
                                    <option value="<?php echo $row3['id'];?>" <?php echo $selected;?> >----<?php echo $row3['title'];?></option>
                                    <?php
                                }
                            }
							*/
                        }
                    }
                }
            }
            ?>
        </select>
        
        <?php
		if(isset($max_price) && $max_price!=0)
		{
			?>
            <input type="hidden" value="<?php echo $min_price;?>" id="min_price" name="min_price" />
            <input type="hidden" value="<?php echo $max_price;?>" id="max_price" name="max_price" />
            <?php
		}
		if(isset($orderby) && $orderby!='')
		{
			?>
            <input type="hidden" name="orderby" value="<?php echo $orderby;?>" />
            <?php
		}
        ?>
    </form>
    <div class="categorytopbar">
        <div class="widget-1 widget-first widget woocommerce widget_price_filter">
            <h3>Filter by price</h3>
            <form method="get" action="<?php echo $this->linkCanoncical;?>">
                <div class="price_slider_wrapper">
                    <div class="price_slider" style="display:none;"></div>
                    <div class="price_slider_amount">
                        <input type="text" id="min_price" name="min_price" value="<?php if(isset($min_price)) echo $min_price;?>" data-min="0" placeholder="Min price" />
                        <input type="text" id="max_price" name="max_price" value="<?php if(isset($max_price)) echo $max_price;?>" data-max="100" placeholder="Max price" />
                        <?php
						if(isset($orderby) && $orderby!='')
						{
							?>
                            <input type="hidden" value="<?php echo $orderby;?>" name="orderby" />
                            <?php
						}
						if(isset($cat_id) && $cat_id!=0)
						{
							?>
							<input type="hidden" name="cat_id2" value="<?php echo $cat_id;?>" />
							<?php
						}
						?>
						
                        <button type="submit" class="button">Filter</button>
                        <div class="price_label" style="display:none;"> Price: <span class="from"></span> &mdash; <span class="to"></span> </div>
                        <div class="clear"></div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>