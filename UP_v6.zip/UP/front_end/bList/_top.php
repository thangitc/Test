<?php
$cats =  $this->array_category;
$k = 0;
foreach($cats as $row)
{
	if($row['parent_id']==$cat_info['id'])
	{
		$link_cat = Url::createUrl('bList/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
		$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
		$class = '';
		if(($k+1)%4==0) $class = " last";
		?>
        <div class="one_fourth categories<?php echo $class;?>">
            <a href="<?php echo $link_cat;?>">
                <img width="280" height="180" alt="<?php echo $row['title'];?>" src="<?php echo $src_img;?>">
                <h3>
                    <?php echo $row['title'];?>
                    <?php if($row['num_p']!=0) { ?>
                    <mark class="count"><?php echo $row['num_p'];?></mark>
                    <?php } ?>
                </h3>
            </a>
            <?php if($row['price']!='') { ?>
            <div class="recentPrice" style="margin-left:75px;"><span class="price"> <ins><span class="amount"><?php echo $row['price'];?></span></ins></span></div>
            <?php } ?>
        </div>
        <?php
		$k++;
	}
}
?>