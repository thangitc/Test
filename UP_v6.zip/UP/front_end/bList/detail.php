<style>
.disabled {
	pointer-events: none;
	cursor: default;
	opacity: 0.6;
}
</style>
<?php
$start_day = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
$this->renderPartial('application.views.cart.js') ;
if($detail['status_new']==0)
	$title_product = $detail['title'].' 2nd(#'.$detail['seri'].')';
else
	$title_product = $detail['title'];
?>

<div id="t-main" data-selenium="tContent" class="borderBoxBlock">
    <div class="breadcrums-cont clearfix new-page-width" data-selenium="breadcrumbs">
        <ul id="breadcrumbs" class="page-width twelve">
            <li class="first"><a href="<?php echo Yii::app()->params['baseUrl'];?>">Home</a></li>
            <?php if(!empty($cat_info)) {?>
            <li><a href="<?php echo Url::createUrl('bList/cat', array('cat_id'=>$cat_info['id'], 'alias'=>$cat_info['alias']));?>"><?php echo $cat_info['title'];?></a></li>
            <?php } ?>
            <li class="detailCrumb"> <a href="<?php echo $this->linkCanoncical?>"><?php echo $title_product;?></a> </li>
        </ul>
    </div>
    <div id="tMain" class="clearfix" itemtype="http://schema.org/Product" itemscope="" data-selenium="mainItem">
        <div class="topWrapper clearfix js-item new-page-width js-bhItemObj" data-selenium="topPage" >           
			<div class="pinned-header js-itemPinnedHeader">
                <div class="pinned-inner-wrapper new-page-width full-width table">
                    <div class="pinned-header-productImage table-cell">
                    	<img alt="<?php echo $title_product;?>" src="<?php echo Common::getImage($detail['picture'], 'camera', '', 'smallest');?>" height="50" width="50"> 
                    </div>
                    <div class="product-name-container table-cell">
                        <h1 class="ph-product-name smbold c31"> <span><?php if(isset($brand_info)) echo $brand_info['title'];?></span> <span> <?php echo $title_product;?> </span> </h1>
                    </div>
                    <div class="pinned-header-mapMessage fs16"></div>
                    <div class="pinned-header-atcContainer table-cell">
                        <!--FormAddToCart-->
                    </div>
                </div>
            </div>
            <div class="pProductNameContainer">
                <h1 class="pProductName bold c31 js-main-product-name"><!-- <span itemprop="brand"><?php if(isset($brand_info)) echo $brand_info['title'];?></span> --><span itemprop="name"> <?php echo $title_product;?> </span> </h1>
			</div>
            
            <div class="full-width table">
                <!-- Start topLeft -->
                <script>
				(function(){
				var BH = window.BH || {};
				BH.globals = BH.globals || {};
				BH.globals.detailPageGlobals = BH.globals.detailPageGlobals || {};
				BH.globals.detailPageGlobals.demoVideo = {};
				})()
				</script>
                <div class="left-2-sections table-cell">
                    <div class="top-left js-topLeft left ">
                    	<?php if(!empty($brand_info)) {?>
                        <h2 class="mfrLogo" data-selenium="mfrLogo"> <a href="javascript:" data-selenium="itemLogoLink" class="noUnderline"> <img src="<?php echo Common::getImage($brand_info['picture'], 'brand', '');?>" alt="<?php echo $brand_info['title'];?>" data-selenium="itemLogo" border="0"> </a> </h2>
                        <?php } ?>
                        
                        <?php
						if(!empty($model_info) && $model_info['model_video']!='')
						{
							?>
                            <div id="main-image-video">
                            	<a id="mainImage1" class="noUnderline clearfix enlargeMain" name="enlarge" href="<?php echo Common::getImage($detail['picture'], 'camera', '');?>" data-selenium="enlargeMain" itemprop="image" data-cmelemtag='{"elemId":"CAEDRT5L1-REG","elemCat":"MAIN:Image`Zoom`Dtl"}'> <img id="mainImage" data-image-folder="images500x500" class="main-image"  src="<?php echo Common::getImage($detail['picture'], 'camera', '');?>" alt="<?php if(!empty($brand_info['title'])) echo $brand_info['title'].' '; echo $title_product;?>" data-selenium="mainImage" border="0">
                                <p style="visibility: visible;" class="productDescription message-under-image fs14 c31 underline-on-hover"></p>
                                <p class="message-under-image fs14 c31 underline-on-hover noteDescription displayNone"></p>
                                </a>
                                
                                <div data-type="b" id="demo-video" style="display: none;">
                                    <div class="video-container">
                                        <div id="mainVideo"class="video-js vjs-mouse vjs-controls-enabled vjs-workinghover bc-player-N1cfLQmFe_default vjs-contextmenu vjs-contextmenu-ui vjs-player-info vjs-errors vjs-plugins-ready vjs-user-inactive vjs-playing vjs-has-started" style="width: 100%; height: 100%; position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px; background:#fff" role="region" aria-label="video player" data-embed="default">
                                        
                                            <?php
											$model_video = $model_info['model_video'];
											preg_match('/v=(.*)/si', $model_video, $match);
											$youtube_key = isset($match[1]) ? $match[1]:'';
											if($youtube_key=='')
											{
												preg_match('/youtu.be\/(.*)/si', $model_video, $match);
												$youtube_key = isset($match[1]) ? $match[1]:'';
											}
											echo Common::embedYoutube($youtube_key);
                                            ?>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <?php
						}
						else
						{
							?>
                            <a class="noUnderline clearfix enlargeMain" name="enlarge" href="<?php echo Common::getImage($detail['picture'], 'camera', '');?>" data-selenium="enlargeMain" itemprop="image" data-cmelemtag='{"elemId":"CAEDRT5L1-REG","elemCat":"MAIN:Image`Zoom`Dtl"}'>
                            	 <img id="mainImage" data-image-folder="images500x500" class="main-image"  src="<?php echo Common::getImage($detail['picture'], 'camera', '');?>" alt="<?php if(!empty($brand_info['title'])) echo $brand_info['title'].' '; echo $title_product;?>" data-selenium="mainImage" border="0">
                            	<p style="visibility: visible;" class="productDescription message-under-image fs14 c31 underline-on-hover"></p>
                            	<p class="message-under-image fs14 c31 underline-on-hover noteDescription displayNone"></p>
                            </a>
                            <?php
						}
                        ?>
                        <div class="image-thumbs js-imageThumbs js-close" data-selenium="productThumbnail">
                        	<?php if(!empty($model_info) && $model_info['model_video']!='') { ?>
                        	<a class="watch-demo-video cursor-pointer smImgLink" onclick="$('#demo-video').show(); $('#mainImage').removeClass('invisible').addClass('invisible');">
                            <svg preserveAspectRatio="xMidYMid" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg">
                              <image height="49" width="49" xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAADEAAAAxCAMAAABEQrEuAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAA9lBMVEUAAAAaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIgaWIg+cpuDpb+5zNvf5+7y9fj///+6zdsbWYhvlrTO2+VokbHb5eyWsshgi6w6cJknYo9fiqy3y9pZhqmfuc1/obx+obyeuM1Ug6aVsshGeJ9Vg6dTgqZulbPe5+7W4epYhajM2uS1ydk3bZf4+vuMq8MiXozi6vBkjq6Epb/B0t/7/P2YtMknYY/y9vjp7/RulrTG1eEmYY7z9vk/c5u2ytlpkrFTgaVwl7XP3OYAAAAVTDc9AAAAF3RSTlMAFIbS+NCCU/Dx/hUW+fPRVPLT+vTOg5rGqNEAAAABYktHRACIBR1IAAAACXBIWXMAAAsSAAALEgHS3X78AAABzUlEQVRIx6WWd0PCMBDFA4o4cOC6Qn0UbCkURavgXlVxgCB+/09jy+pI6ND3V0d+Te/u5RLGGEulFxYpWouZpRQbKbscY/hYK9kRsBobIFq1kbWVBIA9S44tJQKI0iyTkFhgcbLk1TpLCBAJCKlQlA9wIJcKUhxCKVfgqlJWoohDe5iqVfUa1fS6ptp3h+GEBhgNz33DALQw4gg4DrxvAkfziRPglPvtU+BkHmECZ4LcnAGmmLCDPhcWoOUPf0YofAxTHQOKgGjDmFxdXF4FEANtAXGNaVrtItzc+ogGrnlCgkougbv7By+iQuKIglupsUEenzyECYsjiqj6CeDZ/W4VRY6QoQcJvLx2Jo90yBzxhg5HAO8f47R28MYRAAkI4JN7HT7HlOiiFysO969EcQhy5YlclCvLNegsu1+h9QjUPFBBUc2p4vVVwCVCX1F55l0b6PudKPauuz44tzfF64MGQItE+gYGJCKc1jNnnfsa0L96yR/6Fd8Tr/oRPXEUPlSzrnepq9dNp+8OKJwgZfjjceLPMLK3O5KsktxDTy5ZsfaPaCXeBzcS77Wbf9jPc4nPDMnPJYxt5WMD+ez4uJRKb+/EGL67t++cr34BWDLqkHHPNNIAAAAASUVORK5CYII="/>
                            </svg>
                            </a>
                            <?php } ?>
							<?php
                            $k=0;
                            if($camera_pic)
                            foreach($camera_pic as $row)
                            {
                                $src_img_smallest = Common::getImage($row['picture'], 'camera', '' ,'smallest');
								$src_img = Common::getImage($row['picture'], 'camera', '');
								?>
								<a onclick="$('#demo-video').hide(); $('#mainImage').removeClass('invisible'); " class="cursor-pointer smImgLink <?php if($k==0) echo 'selected';?>" data-selenium="smallImgLink"> <img class="js-lazyImage" src="<?php echo $src_img_smallest;?>" data-src="<?php echo $src_img;?>" alt="<?php echo $title_product;?>">
									<!--<p class="displayNone"><?php echo $title_product;?></p>-->
								</a>
								<?php
                                $k++;
                            }
                            ?>                         
                            <p class="js-toggleShow fs14 c31 cursor-pointer toggle-more-image-thumbs js-show" data-toggleshow=".js-imageThumbs">Show <span class="js-show">More</span><span class="js-hide">Less</span></p>
                        </div>
                        <div class="media-links fs14 clearfix"> </div>
                        <?php $this->renderPartial('_screenshot', array('detail'=>$detail, 'camera_pic'=>$camera_pic));?>
                        <!--
                        <div id="moreImages" data-selenium="moreImagesWrapper" data-imagessrc="https://www.bhphotovideo.com/find/getImages.jsp/sku/1274705/is/REG/cm_sp/ZoomImgs-_-DTLpg-_-MainImg" data-scriptsrc="https://static.bhphoto.com/FrameWork/js/zooom.js?v=release20160824v10t160134160135" >
                            <div class="close" data-selenium="close">Close</div>
                            <div id="miNavWrapper" data-selenium="moreImagesNavWrapper">
                                <div id="miNav" data-selenium="moreImagesNav"></div>
                            </div>
                            <div id="miContent" data-selenium="moreImagesContent">
                                <div id="zoomContent" data-selenium="zoomContent">
                                    <div id="zoomPages" data-selenium="zoomPages">
                                        <div class="prev" data-selenium="prev"><span> </span></div>
                                        <div class="next" data-selenium="next"><span> </span></div>
                                    </div>
                                    <div id="zoomContainer" data-selenium="zoomContainer">
                                        <svg class="circle-loader circle-loader100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                            <g>
                                                <circle class="fixed" cx="50%" cy="50%" r="40%"></circle>
                                            </g>
                                            <g>
                                                <circle class="rotate" cx="50%" cy="50%" r="40%"></circle>
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="imageBtmText">
                                        <div class="imageDesc" data-selenium="imageDesc"></div>
                                    </div>
                                    <div id="zoomControls" data-selenium="zoomControls">
                                        <ul>
                                            <li id="zoomIn" title="zoom in" data-selenium="zoomIn"></li>
                                            <li id="zoomOut" title="zoom out" data-selenium="zoomOut"></li>
                                            <li id="zoomReset" title="reset zoom" data-selenium="zoomReset"></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div id="kitItemBar" data-selenium="kitItem">
                                <div id="kitItemsWrapper" data-selenium="kitItemsWrapper">
                                    <div id="kitItemImageSelector" data-selenium="kitItemImageSelector"></div>
                                    <div id="kitItemOpener" data-selenium="kitItemOpener"></div>
                                </div>
                                <p id="kitItemDescriptionCont"> <span>Now Viewing: </span> <b id="kitItemDescription" data-selenium="kitItemDescription"></b> </p>
                            </div>
                        </div>
						-->
                        <ul class="social-share-links js-social-share-links" data-selenium="productSharing">
                            <li> <a title="Share on Facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $this->linkCanoncical;?>" class="social-link" data-selenium="shareFaceBook" data-width="700" data-height="400">
                                <svg class="facebook-share-icon">
                                    <use xlink:href="#facebook"></use>
                                </svg>
                                </a> </li>
                            <li> <a title="Share on Twitter" href="https://twitter.com/intent/tweet?url=<?php echo $this->linkCanoncical;?>" class="social-link js-twitter-share-link" data-selenium="shareTwitter" data-width="700" data-height="400">
                                <svg class="twitter-share-icon">
                                    <use xlink:href="#twitter"></use>
                                </svg>
                                </a> </li>
                            <li> <a title="Share on Google+" href="https://plus.google.com/share?url=<?php echo $this->linkCanoncical;?>" class="social-link" data-selenium="shareGooglePlus" data-width="700" data-height="500">
                                <svg class="google-share-icon">
                                    <use xlink:href="#gplus"></use>
                                </svg>
                                </a> </li>
                            <li> <a title="Share on Pinterest" href="http://pinterest.com/pin/create/button/?url=<?php echo $this->linkCanoncical;?>&amp;media=<?php echo $this->srcImg;?>&amp;description=<?php echo $title_product;?>" class="social-link js-pinterest-share-link" data-selenium="sharePinterest" data-width="720" data-height="570">
                                <svg class="pinterest-share-icon">
                                    <use xlink:href="#pintrest"></use>
                                </svg>
                                </a>
							</li>
                        </ul>
                    </div>
                    <!-- End topLeft -->
                    <!-- Start topRight -->
                    <div class="top-center left" data-selenium="topCenter">
						<div class="c28 fs14 salesComments" data-selenium="salesComments">
                        	<?php
							if($detail['is_sale']==0)
							{
								?>
                                <span class="c33 fs16 bold upper" style="color:#0A92CA;">Còn hàng</span>
                                <?php
							}
							else if($detail['is_sale']==1)
							{
								?>
                                <span class="c33 fs16 bold upper" style="color:#990000;">Hết hàng</span>
                                <?php
							}
							else
							{
								?>
                                <span class="c33 fs16 bold upper" style="color:#018D72;">Order</span>
                                <?php
							}
                            ?>                        	
                        </div>
                        
                        <!--Access Free-->
                        <?php if($access_free) {?>
                        <div data-selenium="IncludesFreeContainer" class="include-free">
                            <div class="clearfix">
                                <h3 class="OpenSans-600-normal left upper c28 fs16">
                                    Quà tặng kèm
                                </h3>
                                <p class="fs14 c27 right upper fs14">
                                Tổng giá trị: <span class="fs14 c32"></span><span class="fs16 c32">
                                	<?php
									$total_val = 0;
									foreach($access_free as $row)
									{
										$total_val+=$row['price'];
									}
									echo Common::formatNumber($total_val);
                                    ?>
                                    VND
                                </span>                
                                </p>
                            </div>
                            <?php
                            foreach($access_free as $row)
							{
								$src_img = Common::getImage($row['picture'], 'access', '', 'small');
								?>
									<a onclick="loadPopAccess(<?php echo $row['id'];?>,1);" href="javascript:" class="js-miniProdLayer underline-on-hover c31"><img src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>" width="80px" height="80px" /></a>                                            
                                <?php
							}
							?>
                        </div>
                        <?php } ?>
                        <div class="js-highlightsAndReviews">
                            <div class="js-productHighlights product-highlights c28 fs14 js-close" data-selenium="ProductHighlight">
                                <p class="fs16 OpenSans-600-normal upper product-highlights-header"> Thông tin nổi bật </p>
                                <div id="highlightList" data-selenium="highlightList" class="top-section-list show_hide_class" >
                                	<?php echo $model_info['introtext'];?>
                                </div>
                                <span class="js-toggleShow js-viewAllHighlights c31 cursor-pointer view-all-highlights underline-on-hover js-show" data-toggleshow=".js-productHighlights"><span class="js-show" onclick="$('#highlightList').removeClass('show_hide_class');">Show more</span><span class="js-hide" onclick="$('#highlightList').addClass('show_hide_class');">Show less</span></span>
							</div>
                            <div class="reviews fs14 c28" data-selenium="productRating" itemtype="http://schema.org/AggregateRating" itemscope="" itemprop="aggregateRating">
                            	<span class="reviews-link">
                                    <meta content="4.5" itemprop="ratingValue">
                                    <a href="javascript:" data-selenium="readReviewsLink" class="js-readReviewsLink review-stars-medium underline-on-hover c31"> 
                                    <!--
                                    <span class="review-stars">
                                        <svg class="review-stars-grey">
                                            <use xlink:href="#stars"></use>
                                        </svg>
                                        <span class="review-stars-inner" style="width:90%;">
                                        <svg class="review-stars-green">
                                            <use xlink:href="#stars"></use>
                                        </svg>
                                        </span> </span> 
                                        -->
                                        <?php
										$arr_rating = LoadConfig::$arr_rating;
										$rating_name = isset($arr_rating[$detail['rating']]) ? $arr_rating[$detail['rating']].'' : '';
										$rating_img_name = $rating_name.'.png';
										if($rating_name!='')
										{
											?>
                                            <img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_img_name;?>" />
                                            <?php
										}
                                        ?>
                                        
                                    </a>
                                    <?php if($rating_name!='') { ?>
                                    (Xếp hạng: <strong><?php echo $rating_name;?></strong>)
                                    <?php } ?>
                                </span>
                                <span onmousemove="$('.popover').show();" data-animation="true" data-trigger="hover" data-popover-content-container=".js-scLongDescription" class="ship-time-popover-opener js-popover-opener" data-original-title="" title="">
                                    <svg class="orange-info small">
                                        <use xlink:href="#info-light"/>
                                    </svg>
                                </span>
                                <div class="popover top in" style="display: none;top:609px; left:550px;">
                                    <div class="arrow tooltip-arrow"></div>
                                    <h3 class="popover-title"></h3>
                                    <div class="popover-content">
                                        <div class="fs11" style="width:250px;">
                                        <strong>S:</strong> Hàng mới 100%, chưa sử dụng.
                                        <br />
                                        <strong>AA:</strong> Hàng mới nhưng đã mở ra kiểm tra, đánh giá, trưng bày.
                                        <br />
                                        <strong>A:</strong> Hàng đẹp như mới, không có cảm giác đã qua sử dụng.
                                        <br />
                                        <strong>AB+:</strong> Hàng ít sử dụng, có 1 số tiêu hao nhỏ nhưng nó là hàng rất đẹp.
                                        <br />
                                        <strong>AB:</strong> Hàng thường xuyên sử dụng 1 cách cẩn thận, có xuất hiện bóng và các vết trầy xước nhẹ.
                                        <br />
                                        <strong>B:</strong> Hàng sử dụng với tần suất cao, có các vết trầy xước lớn, nhưng không ảnh hưởng đến hoạt động của máy.
                                        <br />
                                        <strong>C:</strong> Hàng có 1 số hạn chế về chức năng sử dụng.
                                        <br />
                                        <strong>J:</strong> Rác, không thể xác nhận hoạt động.
                                        </div>
                                    </div>
                                </div>

                                <?php if($detail['time_bh']!='') { ?>
                                <span style="float:right;">Bảo hành: <strong><?php echo $detail['time_bh'];?></strong></span>
                                <?php } ?>
							</div>
                            <?php
                            if($detail['status_new']==0 && $detail['introtext']!='')
							{
								?>
                                <div class="js-productHighlights product-highlights c28 fs14 js-close" data-selenium="ProductHighlight">
                                    <div id="introtext" data-selenium="highlightList" class="top-section-list show_hide_class" >
                                        <?php echo $detail['introtext'];?>
                                    </div>
                                    <span class="js-toggleShow js-viewAllHighlights c31 cursor-pointer view-all-highlights underline-on-hover js-show" data-toggleshow=".js-productHighlights"><span class="js-show" onclick="$('#introtext').removeClass('show_hide_class');">Show more</span><span class="js-hide" onclick="$('#introtext').addClass('show_hide_class');">Show less</span></span>
                                </div>
                                <?php
							}
							?>
                        </div>
                        <?php if($detail['status_new']==1) { ?>
                        <div class="groups">
                        	
                        	<?php 
							if(!empty($model_info) && ($model_info['is_chinh_hang']==1 || $model_info['is_cong_ty']==1))
							{
								$link_chinh_hang = 'javascript:';
								$link_nhap_khau = 'javascript:';
								$link_cong_ty = 'javascript:';
								$is_chinh_hang = $model_id.'_1_'.$color_id.'_'.$body_id.'_'.$kit_id;
								$is_nhap_khau = $model_id.'_0_'.$color_id.'_'.$body_id.'_'.$kit_id;
								$is_cong_ty = $model_id.'_2_'.$color_id.'_'.$body_id.'_'.$kit_id;
								$class_chinh_hang = 'disabled';
								$class_nhap_khau = 'disabled';
								$class_cong_ty = 'disabled';
								$text_chinh_hang = isset($model_info['text_chinh_hang']) && $model_info['text_chinh_hang']!='' ? $model_info['text_chinh_hang']:'Chính hãng';
								if(in_array($is_chinh_hang,$list_product))
								{
									$link_chinh_hang = Url::createUrl('bList/detail', array('model_id'=>$detail['model_id'], 'body_id'=>$body_id, 'kit_id'=>$kit_id, 'color_id'=>$color_id, 'chinh_hang'=>1));
									$class_chinh_hang = '';
								}
								if(in_array($is_nhap_khau,$list_product))
								{
									$link_nhap_khau = Url::createUrl('bList/detail', array('model_id'=>$detail['model_id'], 'body_id'=>$body_id, 'kit_id'=>$kit_id, 'color_id'=>$color_id, 'chinh_hang'=>0));
									$class_nhap_khau = '';
								}
								if(in_array($is_cong_ty,$list_product))
								{
									$link_cong_ty = Url::createUrl('bList/detail', array('model_id'=>$detail['model_id'], 'body_id'=>$body_id, 'kit_id'=>$kit_id, 'color_id'=>$color_id, 'chinh_hang'=>2));
									$class_cong_ty = '';
								}
								?>
								<div data-selected="<?php if($detail['chinh_hang']==1) echo $text_chinh_hang; else if($detail['chinh_hang']==2) echo 'Công ty'; else echo 'Nhập khẩu'?>" data-selenium="pColors" class="items-group js-itemsGroup c28 fs14 tag clearfix">
									<p class="fs16 truncate-ellipsis">
										Sản phẩm:
										<span class="OpenSans-600-normal js-itemValue"><?php if($chinh_hang==1 || $detail['chinh_hang']==1) echo $text_chinh_hang; else echo 'Nhập khẩu'?></span>
									</p>
									<a alt="<?php echo $title_product;?>" data-selenium="thumbLink" href="<?php echo $link_chinh_hang;?>" title="<?php echo $title_product;?> (<?php echo $text_chinh_hang;?>)" data-itemvalue="<?php echo $text_chinh_hang;?>" class="group-item js-groupItem c28 noUnderline truncate-ellipsis <?php echo $class_chinh_hang;?> <?php if($chinh_hang==1 || $detail['chinh_hang']==1) echo 'selcted-item';?>">
										 <?php echo $text_chinh_hang;?>
									</a>
                                    <?php
									if($model_info['is_cong_ty']==1)
									{
										?>
                                        <a alt="<?php echo $title_product;?>" data-selenium="thumbLink" href="<?php echo $link_cong_ty;?>" title="<?php echo $title_product;?> (Công ty)" data-itemvalue="Công ty" class="group-item js-groupItem c28 noUnderline truncate-ellipsis <?php echo $class_cong_ty;?> <?php if($chinh_hang==2 || $detail['chinh_hang']==2) echo 'selcted-item';?>">
                                             Công ty
                                        </a>
                                        <?php
									}
                                    ?>
									<a alt="<?php echo $title_product;?>" data-selenium="thumbLink" href="<?php echo $link_nhap_khau;?>" title="<?php echo $title_product;?> (Nhập khẩu)" data-itemvalue="Nhập khẩu" class="group-item js-groupItem c28 noUnderline truncate-ellipsis <?php echo $class_nhap_khau;?> <?php if($chinh_hang==0 || $detail['chinh_hang']==0) echo 'selcted-item';?>">
										 Nhập khẩu
									</a>
                                    
								</div>
								<?php
                            	} 
							?>
                            
                            <?php
							if($list_color)
							{
								?>
                                <div data-selected="<?php if(!empty($color_info)) echo $color_info['title'];?>" data-selenium="pColors" class="items-group js-itemsGroup c28 fs14 tag clearfix">
                                    <p class="fs16 truncate-ellipsis">
                                        Color:
                                        <span class="OpenSans-600-normal js-itemValue"><?php if(!empty($color_info)) echo $color_info['title'];?></span>
                                    </p>
                                    <?php
                                    foreach($list_color as $row)
                                    {
										$is_color = $model_id.'_'.$chinh_hang.'_'.$row['id'].'_'.$body_id.'_'.$kit_id;
										$class_color = 'disabled';
										$link_color = 'javascript:';
										if(in_array($is_color,$list_product))
										{
											$link_color = Url::createUrl('bList/detail', array('model_id'=>$model_id, 'body_id'=>$body_id, 'kit_id'=>$kit_id, 'color_id'=>$row['id'], 'chinh_hang'=>$chinh_hang));
											$class_color = '';
										}
										
                                        $selected = '';
                                        if($row['id']==$color_id || $row['id']==$detail['color_id']) $selected ='selcted-item';
                                        ?>
                                        <a alt="<?php echo $title_product;?> (<?php echo $row['title'];?>)" data-selenium="thumbLink" href="<?php echo $link_color;?>" title="<?php echo $title_product;?> (<?php echo $row['title'];?>)" data-itemvalue="<?php echo $row['title'];?>" class="group-item js-groupItem c28 noUnderline truncate-ellipsis <?php echo $class_color;?> <?php echo $selected;?>">                    
                                             <?php echo $row['title'];?>
                                        </a>
                                        <?php
                                    }
                                    ?>
                                </div>
                            	<?php
                                } 
							?>
                            
                        	<?php if($list_body) { ?>
                            <div data-selected="<?php if(!empty($body_info)) echo $body_info['title'];?>" data-selenium="pColors" class="items-group js-itemsGroup c28 fs14 tag clearfix">
                                <p class="fs16 truncate-ellipsis">
                                    Style:
                                    <span class="OpenSans-600-normal js-itemValue"><?php if(!empty($body_info)) echo $body_info['title'];?></span>
                                </p>
                                <?php
								foreach($list_body as $row)
								{
									$is_style = $model_id.'_'.$chinh_hang.'_'.$color_id.'_'.$row['id'].'_'.$kit_id;
									$class_style = 'disabled';
									$link_style = 'javascript:';
									if(in_array($is_style,$list_product))
									{
										$link_style = Url::createUrl('bList/detail', array('model_id'=>$model_id, 'body_id'=>$row['id'],'kit_id'=>$kit_id ,'color_id'=>$color_id, 'chinh_hang'=>$chinh_hang));
										$class_style = '';
									}
									
									$selected = '';
									if($row['id']==$body_id || $row['id']==$detail['body_id']) $selected ='selcted-item';
									?>
                                    <a alt="<?php echo $title_product;?> (<?php echo $row['title'];?>)" data-selenium="thumbLink" href="<?php echo $link_style;?>" title="<?php echo $title_product;?> (<?php echo $row['title'];?>)" data-itemvalue="<?php echo $row['title'];?>" class="group-item js-groupItem c28 noUnderline truncate-ellipsis <?php echo $class_style;?> <?php echo $selected;?>">                    
                                         <?php echo $row['title'];?>
                                    </a>
                                    <?php
								}
                                ?>
                            </div>
							<?php } ?>
                            
                            <?php if($list_kit) { ?>
                            <div data-selected="<?php if(!empty($kit_info)) echo $kit_info['title']; else echo 'Tiêu chuẩn';?>" data-selenium="pColors" class="items-group js-itemsGroup c28 fs14 tag clearfix">
                                <p class="fs16 truncate-ellipsis">
                                    Configuration:
                                    <span class="OpenSans-600-normal js-itemValue"><?php if(!empty($kit_info)) echo $kit_info['title']; else echo 'Tiêu chuẩn';?></span>
                                </p>
                                <a alt="<?php echo $title_product;?> (Tiêu chuẩn)" data-selenium="thumbLink" href="<?php echo Url::createUrl('bList/detail', array('model_id'=>$model_id, 'body_id'=>$body_id, 'kit_id'=>0, 'color_id'=>$color_id, 'chinh_hang'=>$chinh_hang));?>" title="<?php echo $title_product;?> (Tiêu chuẩn)" data-itemvalue="Tiêu chuẩn" class="group-item js-groupItem c28 noUnderline truncate-ellipsis <?php if($kit_id==0) echo 'selcted-item';?>">                    
									 Tiêu chuẩn
                                </a>
                                <?php
								foreach($list_kit as $row)
								{
									$is_kit = $model_id.'_'.$chinh_hang.'_'.$color_id.'_'.$body_id.'_'.$row['id'];
									$class_kit = 'disabled';
									$link_kit = 'javascript:';
									if(in_array($is_kit,$list_product))
									{
										$link_kit = Url::createUrl('bList/detail', array('model_id'=>$model_id, 'body_id'=>$body_id, 'kit_id'=>$row['id'], 'color_id'=>$color_id, 'chinh_hang'=>$chinh_hang));
										$class_kit = '';
									}
									
									$selected = '';
									if($row['id']==$kit_id || $row['id']==$detail['kit_id']) $selected ='selcted-item';
									?>
                                    <a alt="<?php echo $title_product;?> (<?php echo $row['title'];?>)" data-selenium="thumbLink" href="<?php echo $link_kit;?>" title="<?php echo $title_product;?> (<?php echo $row['title'];?>)" data-itemvalue="<?php echo $row['title'];?>" class="group-item js-groupItem c28 noUnderline truncate-ellipsis <?php echo $class_kit;?> <?php echo $selected;?>">                    
                                         <?php echo $row['title'];?>
                                    </a>
                                    <?php
								}
                                ?>
                            </div>
                            <?php } ?>
                        </div>
						<?php } ?>
                        <?php if($model_info['note_public']!='' || $detail['note_public']!='') { ?>
                        <div class="c28 fs14">
							<?php 
							echo $model_info['note_public'].'<br />';
							echo $detail['note_public'];
							?>
                        </div>
                        <?php } ?>
                        <div class="rebate-lists"> </div>
                    </div>
                </div>
                <!-- end left-2-sections -->
                <div class="top-right table-cell">                
                	<?php if($detail['is_special']==1) { ?>
                	<div data-selenium="small-banner" class="fs16 c21 upper bold item-flag-message" style="background:#92a673 none repeat scroll 0 0;"> SP sắp về</div>
                    <?php } ?>
                    
                    <?php if($detail['is_special']==2) { ?>
                	<div data-selenium="small-banner" class="fs16 c21 upper bold item-flag-message" style="background:#805590 none repeat scroll 0 0;"> SP bán chạy </div>
                    <?php } ?>
                    
                    <?php if($detail['is_special']==3) { ?>
                	<div data-selenium="small-banner" class="fs16 c21 upper bold item-flag-message" style="background:#D82424 none repeat scroll 0 0;"> SP đang Hot </div>
                    <?php } ?>
                    <?php if($detail['is_special']==4) { ?>
                	<div data-selenium="small-banner" class="fs16 c21 upper bold item-flag-message" style="background:#72969C none repeat scroll 0 0;"> SP giá tốt </div>
                    <?php } ?>
                    <?php if($detail['is_special']==5) { ?>
                	<div data-selenium="small-banner" class="fs16 c21 upper bold item-flag-message" style="background:#696B9A none repeat scroll 0 0;"> SP khuyến mại </div>
                    <?php } ?>
                    
                    <div class="pPriceZoneRight fs14 c28 js-priceZone " data-selenium="PriceZoneRight" itemtype="http://schema.org/Offer" itemscope="" itemprop="offers">
                        <meta content="NewCondition" href="http://schema.org/OfferItemCondition" itemprop="itemCondition">
                        <?php
						if($detail['price_sale']!=0 && $detail['time_sale']!=0 && $detail['time_sale']>=time())
						{
							$price_deal_show = $detail['price'];
							$price_deal = $detail['price_sale'];
							$saving = Common::formatNumber($price_deal_show-$price_deal);
							?>
                            <div data-selenium="ProductPrice" class="pPrice">
                                <p>Giá: <?php echo Common::formatNumber($price_deal_show);?> VND</p>
                                <p>
                                Giảm giá: 
                                <span class="c32 OpenSans-600-normal">
                                    <?php echo $saving;?> VND
                                </span>
                                </p>				
                            </div>
                            <div class="youPay" data-selenium="youPayPrice">
                                <meta itemprop="priceCurrency" content="VNĐ">
                                <p class="fs16 clearfix"> <span class="you-pay-final"> Giá KM: </span> <span class="ypYouPay c32 right fs24 OpenSans-600-normal"><?php echo Common::formatNumber($price_deal);?> VND
                                    <meta itemprop="price" content="<?php echo Common::formatNumber($price_deal);?>">
                                    </span>
								</p>
                                <p>
                                	Thời gian KM: <?php echo date('d/m/Y', $detail['time_sale']);?>
                                </p>
                            </div>
                            <?php
						}
						else
						{
							$price_show = $detail['price'];
							?>
                            <div class="youPay" data-selenium="youPayPrice">
                                <meta itemprop="priceCurrency" content="USD">
                                <p class="fs16 clearfix"> <span class="you-pay-final"> Giá: </span> <span class="ypYouPay c32 right fs24 OpenSans-600-normal"><?php echo Common::formatNumber($price_show);?> VND
                                    <meta itemprop="price" content="<?php echo Common::formatNumber($price_show);?>">
                                    </span>
                                </p>
                            </div>
                            <?php
						}
                        ?>
                        <div>
                            <form name="addItemToCart" class="atcForm clearfix dotted-border submitToOnePopup">
                                
                                <label class="fs14 quantity-label upper">Số lượng</label>
                                <input type="text" size="2" value="1" name="q" class="atcForminput quantity js-mqQty fs20">
                                
                                <div data-selenium="addToCartButton" class="addToCartButton addToCart ">
                                    <button type="button" onclick="addCart(<?php echo $detail['id'];?>, 0, $('#qty').val(),<?php if($detail['price_sale']!=0 && $detail['time_sale']!=0 && $detail['time_sale']>=time())  echo $detail['price_sale']; else echo $detail['price'];?>);" class="atc-btn atcImage blueBtn pill-shaped-button fs26 cursor-pointer one-line borderBox"><?php if($detail['is_sale']==2) echo 'Preorder'; else echo 'Thêm vào giỏ hàng';?></button>
                                    <?php if($detail['is_sale']!=2) { ?>
                                    <button type="button" onclick="addCart2(<?php echo $detail['id'];?>, 0, $('#qty').val(),<?php if($detail['price_sale']!=0 && $detail['time_sale']!=0 && $detail['time_sale']>=time())  echo $detail['price_sale']; else echo $detail['price'];?>);" class="atc-btn atcImage blueBtn pill-shaped-button fs26 cursor-pointer one-line borderBox">Mua ngay</button>
                                    <?php } ?>
                            	</div>
                            </form>
                            
                        </div>
                        <!-- End add to cart form -->
                        <!-- End Price Zone -->
                    </div>
                    <!--
                    <div class="ask-experts c28 chatTypes_4" data-selenium="AskExperts">
                        <p class="fs16 OpenSans-600-normal chatTypeBlack">Liên hệ để có giá tốt nhất:</p>
                        <p class="ask-experts-links"> <span class="call-experts c28 fs14" href="tel:8006066969">
                            <svg class="phone">
                                <use xlink:href="#phone"></use>
                            </svg>
                            0965.505.515 </span> <a class="c31 noUnderline openInPopup fs14" href="https://www.facebook.com/vn.japan"> <span class="underline-on-hover chatType_4">Live Chat</span> </a> </p>
                    </div>
                    -->
                    <?php
					$ads_detail = Ads::getAdsByDetail(-2);
					if($ads_detail)
					{
						$src_img = Common::getImage($ads_detail['picture'], 'ads', '');
						?>
						<div>
						<a href="<?php echo $ads_detail['ads_link'];?>"><img style="max-width:320px;" src="<?php echo $src_img;?>" /></a>
						</div>
						<?php												
					}
					//Contact
					$this->renderPartial('_contact', array('contact'=>$contact, 'one_cheap'=>$one_cheap));
					?>
                </div>                				
                
            </div>
            <div class="print-email right fs14" data-selenium="productPrintEmail"> <a class="openInOnePopupLayer email underline-on-hover" href="mailto:vnjapancamera@gmail.com" data-selenium="productEmail" target="email">
                <svg class="envelope">
                    <use xlink:href="#envelope"></use>
                </svg>
                <span>Email</span></a> <a class="print js-print underline-on-hover" href="javascript:" onclick="window.print();" data-selenium="productPrint">
                <svg class="printer">
                    <use xlink:href="#printer"></use>
                </svg>
                <span>Print</span> </a> </div>
            <!-- End topRight -->
        </div>
        <div style="min-height: 230px;" class="section-wrapper freq-rec-accessories kf-fadeIn" id="freq-rec-accessories">
            <div class="freqBoughtContainer">
                <div class="freqBought-innerWrapper new-page-width clearfix">
                    <div class="freqBoughtHeader">Phụ kiện liên quan<span class="freqRecViewAll underline-on-hover js-acc-view-all">Xem thêm
                        <svg>
                            <use xlink:href="#right-arrow"></use>
                        </svg>
                        </span></div>
                    <div class="freqBoughtItems clearfix twoGridAccssories">                        
                        <?php
						$total_access = sizeof($access_related);
						$style = '';
						if($total_access==1) $style = 'style="width:100%"';
						if($total_access==2) $style = 'style="width:48%"';
						if($total_access==3) $style = 'style="width:33%"';
						if($total_access>=4) $style = 'style="width:24%"';
						$k = 0;
						if($access_related)
						foreach($access_related as $row)
						{
							$src_img = Common::getImage($row['picture'], 'access', '', 'small');
							$link_access = Url::createUrl('access/detail', array('access_id'=>$row['id'], 'alias'=>$row['alias']));
							$class = '';							
							
							?>
                            <div class="freqBoughtItem js-item  js-bhItemObj" <?php echo $style;?>>
                                <div class="freqBoughtItemImageContainer"> <img src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>"> </div>
                                <div class="freqBoughtItemDescription"> <a style="height:38px;" onclick="loadPopAccess(<?php echo $row['id'];?>,0);" class="freqBoughtItemTitle multiline underline-on-hover cursor-pointer js-miniProdLayer"> <?php echo $row['title'];?> </a>
                                    <div class="freqBoughtItemPrice fs16"> <span class="c7 bold"><?php echo Common::formatNumber($row['price']);?></span> VND </div>
                                    <div class="freqBoughtItemAtc">
                                        <div class="freqBoughtItemAtcLink underline-on-hover fs14 bold c31"> <a class="atc-link fs16 smbold c5 noUnderline" href="javascript:" onclick="addCart(<?php echo $row['id'];?>, 1, 1,<?php echo $row['price'];?>)">Thêm vào giỏ hàng</a> </div>
                                    </div>
                                </div>
                            </div>
							
							<?php
							$k++;
						}
						?>
                        
                    </div>
                </div>
            </div>
        </div>
        <div id="bottomWrapper" class="clearfix ui-tabs ui-widget ui-widget-content ui-corner-all" data-selenium="bottomPage">
            <div id="greenNav" class="nav-tabs-outer-wrapper js-nav-tabs-outer-wrapper stick-nav--bottom">
                <div id="navTabs" class="nav-tabs-inner-wrapper">
                    <ul role="tablist" id="nav" class="findLast new-page-width ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" data-selenium="prodNav">
                    	<?php if($model_info['description']!='') {?>
                        <li aria-selected="true" aria-labelledby="ui-id-6" aria-controls="ov" tabindex="0" role="tab" class="cursor-pointer   current ui-state-default ui-corner-top ui-tabs-active ui-state-active" id="navOverView" data-sectiontab="overview" data-selenium="navOverView"> <a id="ui-id-6" tabindex="-1" role="presentation" class="ui-tabs-anchor" href="#ov" onclick="cmCreateElementTag('MATB200GR-REG', 'MAIN:Prod:Tab Overview');" data-selenium="OverviewTab"> <span>Mô tả</span> <span class="navDownArrowIcon">
                            <svg>
                                <use xlink:href="#arrow-down-light"></use>
                            </svg>
                            </span> </a>
						</li>
                        <?php } ?>
                        <?php if($model_info['specs']!='') {?>
                        <li aria-selected="false" aria-labelledby="ui-id-7" aria-controls="sp" tabindex="-1" role="tab" class="cursor-pointer ui-state-default ui-corner-top" id="navSpecifications" data-sectiontab="specifications" data-selenium="navSpecifications"> <a id="ui-id-7" tabindex="-1" role="presentation" class="ui-tabs-anchor" href="#sp" onclick="cmCreateElementTag('MATB200GR-REG', 'MAIN:Prod:Tab Specifications');" data-selenium="SpecificationTab"> <span>Thông số kỹ thuật</span> <span class="navDownArrowIcon">
                            <svg>
                                <use xlink:href="#arrow-down-light"></use>
                            </svg>
                            </span> </a>
						</li>
                        <?php } ?>
                        <?php if($model_info['pic_product']!='') {?>
                        <li aria-selected="false" aria-labelledby="ui-id-10" aria-controls="ac" tabindex="-1" role="tab" id="navAccessories" class="cursor-pointer  ui-state-default ui-corner-top" data-sectiontab="accessories" data-selenium="navAccessories"> <a id="ui-id-10" tabindex="-1" role="presentation" href="#ac" rel="nofollow" data-selenium="accessoryIntermediateTab" onclick="cmCreateElementTag('MATB200GR-REG','MAIN:Prod:Tab Accessories');" class="ui-tabs-anchor"> <span>Ảnh chụp từ <?php echo $model_info['title'];?></span> <span class="navDownArrowIcon">
                            <svg>
                                <use xlink:href="#arrow-down-light"></use>
                            </svg>
                            </span> </a>
						</li>
						<?php } ?>
                        <?php if (!empty($combo_info)) { ?>
                        <li id="navAddOnAcc" class="cursor-pointer ui-state-default ui-corner-top" data-sectiontab="addonacc" data-selenium="addOnAcc" role="tab" tabindex="0" aria-controls="addOnAcc" aria-labelledby="ui-id-6" aria-selected="false">
                            <a href="#addOnAcc" rel="nofollow" data-selenium="addOnAccessoryTab" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="ui-id-6">
                                <span>ADD-ON SAVINGS</span>
                            </a>
                        </li>
                        <?php } ?>
                        <li aria-selected="false" aria-disabled="true" aria-labelledby="scrollTop" aria-controls="ui-tabs-1" tabindex="-1" role="tab" class="empty-li ui-state-default ui-corner-top ui-state-disabled last"> <a onclick="cmCreateElementTag('MATB200GR-REG','MAIN:Prod:Tab Accessories');" tabindex="-1" role="presentation" id="scrollTop" class="scrollTop-wrapper right clearfix cursor-pointer ui-tabs-anchor" href="javascript:void(0)"> <span class="scrollTopIcon">
                            <svg>
                                <use xlink:href="#arrow-up-light"></use>
                            </svg>
                            </span> <span class="smbold upper fs14">to top</span> </a>
						</li>
                    </ul>
                </div>
            </div>
            <!-- Start bottomBodyWrapper -->
            <div class="bottomBodyWrapper clearfix" data-selenium="bottomBodyWrapperPage">
            	<?php if($model_info['description']!='') {?>
                <div aria-hidden="false" aria-expanded="true" role="tabpanel" aria-labelledby="ui-id-6" id="ov" class="section-wrapper mainTabs  removeSectionHeaders  ui-tabs-panel ui-widget-content ui-corner-bottom" data-section="overview">
                    <div id="Overview" class="section-inner-wrapper new-page-width noTimeline" data-selenium="OverviewBody">
                        <div class="toggleFadeWrap"> <span class="toggleButton toggle-more-less"> <span class="toggle-show-more">Show more</span> <span class="toggle-show-less">Show less</span> </span> </div>
                        <div class="inner-wrapper clearfix ">
                            <div class="sectionHeader">Mô tả</div>
                            <div class="leftTimeline  js-leftOverviewTimeline">
                                <ul class="tickerList">
                                    <li data-tickertrigger="ov-ft-1"><span>1</span><span class="trWrap"><span class="ticker">Description</span></span></li>
                                </ul>
                            </div>
                            <div class="leftPanel">
                                <div class="featureWrapper bulletlist clearfix" data-selenium="featureWrapper">
                                	<!--
                                    <div class="primaryExploraBanner">
                                        <div class="detailPageBanners"> <a href="https://www.bhphotovideo.com/explora/photography/hands-review/magnus-tripods-offer-support-and-versatility" class="js-openSlideInTray">
                                            <div class="bannerSqImgLeft"> <img class="js-lazyImage" src="detail_phukien_files/explora_sidebar_placeholder.jpg" data-src="/images/explora_sidebar_placeholder.jpg"> </div>
                                            <div class="bannerDescRight">
                                                <p>Magnus Tripods Offer Support and Versatility</p>
                                                <div><span class="readMoreButton">Read More <span class="readMoreRightArrow">
                                                    <svg>
                                                        <use xlink:href="#right-arrow"></use>
                                                    </svg>
                                                    </span></span></div>
                                            </div>
                                            </a> </div>
                                    </div>
                                    -->
                                    <div class="ov-wrapper js-overview-desc">
                                        <p class="ov-desc">
                                        <?php echo $model_info['description'];?>
                                        </p>
                                    </div>
                                    
                                </div>
                                
                            </div>
                            <div class="rightPanel">
                            	<?php if ($detail['in_the_box']!='') { ?>
                                <div class="whatsInTheBoxWrapper">
                                    <div class="toggleFadeWrap"> <span class="toggleButton smallToggle invert-color"><span class="minus"></span>
                                        <svg>
                                            <use xlink:href="#plus"></use>
                                        </svg>
                                        </span> </div>
                                    <div class="whatsInTheBoxHeader"> In the Box </div>
                                    <div class="whatsInTheBoxBody">
                                        <div class="c2 fs14 " data-selenium="itemIncTitle">
                                            <div class="completeItemName"> <?php echo $title_product;?></div>
                                        </div>
                                        <?php echo $detail['in_the_box'];?>
                                    </div>
                                </div>
                                <?php } ?>
                                <?php
								if(!empty($model_info) && $model_info['user_manual']!='')
								{
									$src = Common::getImage($model_info['user_manual'], 'model', '');
									$path_parts = pathinfo($src);
									$extension = $path_parts['extension'];
									$list_extension_img = array('jpg', 'jpeg', 'png', 'gif');
									
									?>
                                    <div class="itemBanners">
                                        <div class="itemBannersInnerWrapper">
                                            <div class="itemLinks">
                                                <div class="itemLink"> <a href="<?php echo $src; ?>" target="_blank">
                                                    <div class="squareImage blueColoured"><span class="bannerIcon">
                                                        <svg>
                                                            <use xlink:href="#book"/>
                                                        </svg>
                                                        </span></div>
                                                    <div class="itemLinkDesc">
                                                    <?php
													if(!in_array(strtolower($extension), $list_extension_img))
													{
														?>
                                                        <span>Hướng dẫn sử dụng</span>
                                                        <span class="pdfFileSize">
                                                            <?php
                                                            echo strtoupper($extension).' ';
															echo Common::getRemoteFilesize($src, true);
                                                            ?>
                                                            
                                                        </span>
                                                        <?php
													}
													else
													{
														?>
                                                        <img src="<?php echo $src;?>" />
                                                        <?php
													}
                                                    ?>
                                                    	
                                                    </div>
                                                    </a>
												</div>            
                                            </div>
                                        </div>
                                    </div>
                                    <?php
								}
                                ?>
                                <div class="rightTimeline">
                                    <div class="js-rightOverviewTimeline rightTimelineContainer">
                                        <div class="timelineHeader">Table of Contents</div>
                                        <ul class="tickerList">
                                            <li data-tickertrigger="ov-ft-1"><span>1</span><span class="trWrap"><span class="ticker">Description</span></span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
                <?php if($model_info['specs']!='') {?>
                <div aria-hidden="true" aria-expanded="false" style="display: none;" role="tabpanel" aria-labelledby="ui-id-7" id="sp" class="section-wrapper mainTabs  removeSectionHeaders  ui-tabs-panel ui-widget-content ui-corner-bottom" data-section="specifications">
                    <div id="Specification" class="section-inner-wrapper new-page-width " data-selenium="SpecificationBody">
                        <div class="toggleFadeWrap"> <span class="toggleButton toggle-more-less"> <span class="toggle-show-more">Show more</span> <span class="toggle-show-less">Show less</span> </span> </div>
                        <div class="inner-wrapper clearfix">
                            <div class="sectionHeader">Thông số kỹ thuật</div>
                            <div class="leftPanel">
                                <div data-selenium="specWrapper" class="specWrapper">
                                    <?php echo $model_info['specs'];?>
                                </div>
                            </div>
                            <div class="rightPanel">
                                <script>//lazyLoad.lazyCss("https://www.bhphotovideo.com/find/stylesheet.jsp?files=brightcove_icons.css&min=Y&vr=327372615",300);</script>
                                
                            </div>
                        </div>
                    </div>
                </div>
				<?php } ?>
                <?php if($model_info['pic_product']!='') {?>
                <div aria-hidden="true" aria-expanded="false" style="display: none;" role="tabpanel" aria-labelledby="ui-id-10" id="ac" class="section-wrapper mainTabs  removeSectionHeaders  ui-tabs-panel ui-widget-content ui-corner-bottom" data-section="accessories">
                    <div id="accSection" class="section-inner-wrapper clearfix new-page-width">
                        <div class="inner-wrapper clearfix">
                            <div class="sectionHeader">Ảnh chụp từ <?php echo $model_info['title'];?></div>
                            <div class="leftPanel">
                                <div data-selenium="specWrapper" class="specWrapper">
                                    <?php echo $model_info['pic_product'];?>
                                </div>
                            </div>
                            <div class="rightPanel">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
				<?php if (!empty($combo_info)) { ?>
                <div id="addOnAcc" class="section-wrapper mainTabs  ui-tabs-panel ui-widget-content ui-corner-bottom" data-section="addOnAccessories" aria-labelledby="ui-id-6" role="tabpanel" style="display: block;" aria-expanded="true" aria-hidden="true">
                    <div id="addOnAccSection" class="section-inner-wrapper clearfix new-page-width">
                        <div class="inner-wrapper">
                            <div class="h2-title new-page-width c45"><h2><?php echo $detail['title'];?> add-on savings</h2></div>

                            <div class="aosHeader">The more you Add-On the more you save <span class="aosHeaderItemDesc">(when you buy the <?php echo $detail['title'];?> (Body Only))</span></div>
                            <div id="addOnAccContent" class="">
                                <div class="aosLayoutWrapper">                                
                                    <div class="aosRow">
                                        <div class="aosMainItemImage " data-price="3299.00">
                                        	<img src="<?php echo Common::getImage($detail['picture'], 'camera', '' ,'smallest');?>" title="<?php echo $detail['title'];?> (Body Only)">
										</div>
                                        <?php
										$total_price_old = $detail['price'];
										$total_price_new = 0;
										foreach($list_products as $row)
										{
											if($row['product_id']!=$detail['id'])
											{
												$total_price_old = $total_price_old + $row['price_old'];
												$total_price_new = $total_price_new + $row['price_new'];
												if($row['product_type']==0){
													$row_camera = isset($list_camera[$row['product_id']]) ? $list_camera[$row['product_id']] : array();
													if(!empty($row_camera)){
														$link_p = Url::createUrl('bList/detail', array('camera_id'=>$row_camera['id'], 'alias'=>$row_camera['alias']));
														$img_camera = Common::getImage($row_camera['picture'], 'camera', '' ,'smallest');;
														?>
														<div class="aosItemImgWrapper js-miniProdLayer" data-detailonly="true">
															<a target="_blank" href="<?php echo $link_p;?>"><img title="<?php echo $row_camera['title'];?>" src="<?php echo $img_camera;?>"></a>
														</div>
														<?php
													}
													
												}else{
													$row_access = isset($list_access[$row['product_id']]) ? $list_access[$row['product_id']] : array();

													if(!empty($row_access)){
														$link_access = Url::createUrl('access/detail', array('access_id'=>$row_access['id'], 'alias'=>$row_access['alias']));
														$img_access = Common::getImage($row_access['picture'], 'access', '' ,'smallest');;
														?>
														<div class="aosItemImgWrapper js-miniProdLayer" data-detailonly="true">
															<a target="_blank" href="<?php echo $link_access;?>"><img title="<?php echo $row_access['title'];?>" src="<?php echo $img_access;?>"></a>
														</div>
														<?php
													}
												}
											}
											else{
												$total_price_new += $row['price_new'];
											}
										}
                                        ?>
                                        
                                        <div class="aosTotalWrapper">
                                            <div class="aosSavingsCircleWrapper">
                                                <div class="aosSavingsCircle"><span>Tiết kiệm <br><b><?php echo Common::formatNumber($total_price_old-$total_price_new);?></b></span></div>
                                            </div>
                                            <div class="aosTotalAmountWrapper">
                                                <div class="aosTotalAmount"><span>Tổng:</span><span><?php echo Common::formatNumber($total_price_new);?></span>
                                                </div>
                                                <!--<div class="aosAddBundleToCartBtnWrapper"><span>Add to Cart</span> <span>View Cart</span></div>-->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="aosRow">
                                        <div class="aosMainItemTitleWrapper"> <?php echo $detail['title'];?> (Body Only)</div>
                                    </div>
                                    
                                    <?php
									
									foreach($list_products as $row)
									{
										if($row['product_id']!=$detail['id'])
										{
											
											if($row['product_type']==0){
												$row_camera = isset($list_camera[$row['product_id']]) ? $list_camera[$row['product_id']] : array();
												if(!empty($row_camera)){
													$link_p = Url::createUrl('bList/detail', array('camera_id'=>$row_camera['id'], 'alias'=>$row_camera['alias']));
													?>
													<div class="aosRow aosSelectors ">
                                                        <div class="aosItemSelectorWrapper">
                                                            <div class="aosItemSelector aosItemSelected" data-sku="1109799_REG" data-bundleid="14838"></div>
                                                        </div>
                                                        <div class="aosItemName"><?php echo $row_camera['title'];?>
                                                            <div class="aosItemLevelPricingWrapper">
                                                            	<span class="aosPriceBeforeSavings">
																	<?php echo Common::formatNumber($row['price_old']);?>
                                                                </span>
                                                            	<span class="aosFinalPrice">
                                                                	<?php echo Common::formatNumber($row['price_new']);?>

                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
													<?php
												}
												
											}else{
												$row_access = isset($list_access[$row['product_id']]) ? $list_access[$row['product_id']] : array();

												if(!empty($row_access)){
													$link_access = Url::createUrl('access/detail', array('access_id'=>$row_access['id'], 'alias'=>$row_access['alias']));
													?>
													<div class="aosRow aosSelectors ">
                                                        <div class="aosItemSelectorWrapper">
                                                            <div class="aosItemSelector aosItemSelected" data-sku="1109799_REG" data-bundleid="14838"></div>
                                                        </div>
                                                        <div class="aosItemName"><?php echo $row_access['title'];?>
                                                            <div class="aosItemLevelPricingWrapper">
                                                            	<span class="aosPriceBeforeSavings">
																	<?php echo Common::formatNumber($row['price_old']);?>
                                                                </span>
                                                            	<span class="aosFinalPrice">
                                                                	<?php echo Common::formatNumber($row['price_new']);?>

                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
													<?php
												}
											}
										}
									}
									?>
                                </div>
                                <br />
                                <div class="aosAllSavingsWrapper">
                                 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<?php } ?>
                <div aria-hidden="true" aria-expanded="false" style="display: none;" role="tabpanel" aria-labelledby="scrollTop" aria-live="polite" class="ui-tabs-panel ui-widget-content ui-corner-bottom" id="ui-tabs-1"></div>
            </div>
            <!-- end bottomWrapper -->
        </div>
        <!-- End tMain -->
    </div>
    
</div>
<script>//lazyLoad.lazyCss("https://www.bhphotovideo.com/find/stylesheet.jsp?currPage=productDetail&loadon=bottom&lang=en&site=reg&min=Y&vr=2009437100");</script>
<script>lazyLoad.lazyCss("<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_lazy.css");</script>
<script type="text/javascript">
	lazyLoad.setOdUrl("<?php  echo Yii::app()->params['static_url']; ?>/images/javascripts.js");
</script>
<script>
function loadPopAccess(access_id,is_deal)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/loadPopAccess');?>',
		type: "POST",
		data:({
			access_id:access_id,
			is_deal:is_deal
		}),
		success: function(resp){
			$('#pop_access').show();
			$('#pop_access').html(resp);
		}
	});
}
$(document).on('click', function (e) {
    if ($(e.target).closest("#pop_access").length === 0) {
		$("#miniprodLayerOverlay").removeClass();
        $("#pop_access").hide();
    }
});

$(function(){
	$(window).click(function() {
		$('.popover').hide();
	});		   
});
</script>
<div id="pop_access" style="display:none;">
</div>
<style>
    #bottomWrapper .bottomBodyWrapper .removeBullet, .KitIncludes ul {
        list-style: outside none none;
    }
    .page-width {
        width: 960px;
    }
    .new-page-width {
        border-left: 20px solid transparent;
        border-right: 20px solid transparent;
        max-width: 1350px;
        min-width: 1004px;
    }
    .new-page-width .new-page-width {
        border-left: 0 none;
        border-right: 0 none;
    }

    .h2-title {
        color: #4c4c4c;
        font-size: 34px;
        line-height: 51px;
        padding-bottom: 45px;
        text-transform: capitalize;
    }

    .aosHeader {
        color: #000;
        font-size: 30px;
        line-height: 1;
        padding-bottom: 15px;
    }
    .aosHeaderItemDesc {
        font-size: 16px;
    }
    .aosLayoutWrapper {
        margin-bottom: 20px;
        margin-top: 40px;
        padding-bottom: 40px;
    }
    .aosLayoutWrapper:first-child {
        border-bottom: 1px solid #e6e7e8;
    }
    .aosItemImgWrapper, .aosMainItemImage {
        float: left;
        position: relative;
        text-align: center;
        width: 17.5%;
    }
    .aosItemImgWrapper.aosItemInCart::after, .aosMainItemImage.aosMainItemInCart::before {
        background: rgba(0, 0, 0, 0) url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAkCAMAAAA5HAOUAAAAbFBMVEVMaXF3ni13ni12ni12ni52ni12ni12ni12ni38/fn9/vz///93ni12ni3///92ny12ni3///////+pwX92niz///93ni6Ssl3F1qmGqUixx4q80Jzn7dv09++cuWylv3rV4cF9ozjd583O3LcP9aXaAAAAFHRSTlMAQttlVJcnDbP7lM337C94glMawH5M41kAAAG5SURBVBgZfcEJYqJAFATQzw7umamqbnbU+99xGoHE0STv2W/+7Pbc7072q4+KDx/2Ik+TJI0Km50qrk72pUjKg6BZfMnN9tzsbFNcjoIgQAFU7vhpb6soBgS4cWxGB0kNn9jiLEHuXnFxcyOf7O0hE1RP/MnOZmcIruOr3rcdZycLIkEN31QOqBl8WFDEkuO7AcCV5M5mZ6ju+KZBcCf3NiuO0MQ3HkFDViebpZLjm0kABpJ/7aGUPF91VwB1TzaHwmZHqOeLvgZ07cgJiizIpZoLf61vnFUOgG4kGymxIBIGLq5A3TMYEHgGHsosSKGRixrCQLJB0HB2lzILUmnk4iYILT0AuYqzu5RZEEEDVy2CBkHd88FLmQU55LgZEAi4dly00tlmB6niqq8BCJi4ckJks1K4c9MJQctVJamwWSI5fvIARm68UNpDcZBu/ORdU3FTS6ktMsDxW60U26o4Qi2/MQFKbZNI8nxzk1Tal0xSyxcThLiwJ6Uk1/FJ1Uo65vasKBUMHVe9ryXEub04HwShHlvv28YJgMrC3uSlACEQFMSpfSvPjoIC6FCm9rM8vWTZJYkK+98/D3VPC8pMKcUAAAAASUVORK5CYII=") no-repeat scroll 0 0;
        content: "";
        height: 36px;
        position: absolute;
        right: 0;
        top: 30px;
        width: 37px;
    }
    .aosItemImgWrapper.aosItemInCart::after {
        background-size: 45% auto;
        right: 10px;
        top: 54px;
    }
    .aosItemImgWrapper {
        max-height: 100%;
        max-width: 17.5%;
        opacity: 1;
        padding-left: 20px;
        transition: all 0.4s ease-in-out 0s;
        visibility: visible;
    }
    .aosItemHidden {
        max-height: 0;
        max-width: 0;
        opacity: 0;
        transition: all 0.4s ease-in-out 0s;
        visibility: hidden;
    }
    .aosItemImgWrapper::before {
        color: #939393;
        content: "+";
        font-size: 33px;
        left: 10px;
        position: absolute;
        top: 100px;
    }
    .aosLayoutWrapper img {
        height: auto;
        max-width: 130px;
        padding-top: 60px;
        width: 100%;
    }
    .aosLayoutWrapper .aosMainItemImage img {
        max-width: 250px;
        padding-top: 0;
    }
    .aosTotalWrapper {
        float: left;
        padding-left: 50px;
        width: 30%;
    }
    .aosSavingsCircle {
        background-color: #f93;
        border-radius: 50%;
        color: #fff;
        float: left;
        height: 80px;
        position: relative;
        text-align: center;
        top: 80px;
        width: 80px;
    }
    .aosSavingsCircle::before {
        color: #939393;
        content: "=";
        font-size: 33px;
        left: -50px;
        position: absolute;
        top: 20px;
    }
    .aosSavingsCircle span {
        line-height: 17px;
        position: relative;
        top: 23px;
    }
    .aosSavingsCircle b {
        font-size: 16px;
    }
    .aosSavingsCircleBig {
        height: 100px;
        width: 100px;
    }
    .aosTotalAmount {
        float: left;
        font-size: 22px;
    }
    .aosTotalAmount span:first-child {
        color: #474747;
        padding-right: 10px;
    }
    .aosTotalAmount span:last-child {
        color: #769e2d;
        font-weight: 700;
    }
    .aosSavingsCircleWrapper {
        float: left;
        width: 40%;
    }
    .aosTotalAmountWrapper {
        float: left;
        padding-top: 70px;
        width: 60%;
    }
    .aosAddBundleToCartBtnWrapper {
        background-color: #5490c5;
        border-radius: 500px;
        color: #fff;
        float: left;
        font-size: 16px;
        height: 30px;
        margin-top: 10px;
        padding-top: 3px;
        text-align: center;
        width: 80%;
    }
    .aosAddBundleToCartBtnWrapper.aosItemsInCart {
        background-color: #fff;
        border: 1px solid #0a92ca;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.14);
        color: #165485;
    }
    .aosAddBundleToCartBtnWrapper span:first-child {
        display: block;
    }
    .aosAddBundleToCartBtnWrapper span:last-child, .aosAddBundleToCartBtnWrapper.aosItemsInCart span:first-child {
        display: none;
    }
    .aosAddBundleToCartBtnWrapper.aosItemsInCart span:last-child {
        display: block;
    }
    .aosAddBundleToCartBtnWrapper:hover:not(.disabled):not(.aosItemsInCart) {
        background-color: #0875a2;
        border-color: #0875a2;
        cursor: pointer;
    }
    .aosAddBundleToCartBtnWrapper.disabled, .aosItemImgWrapper.disabled {
        opacity: 0.3;
    }
    .aosItemName, .aosMainItemTitleWrapper {
        color: #595959;
        float: left;
        font-size: 18px;
        font-weight: lighter;
        width: 100%;
    }
    .aosMainItemTitleWrapper {
        font-weight: 700;
        margin-bottom: 10px;
    }
    .aosItemSelectorWrapper {
        float: left;
        width: 3%;
    }
    .aosItemSelector {
        border: 2px solid #9e9ea0;
        float: left;
        height: 20px;
        position: relative;
        top: 8px;
        width: 20px;
    }
    .aosSelectors.disabled {
        opacity: 0.5;
    }
    .aosItemSelector.aosItemSelected::before {
        background: rgba(0, 0, 0, 0) url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAWCAMAAADto6y6AAAAVFBMVEVMaXH///////////////////////////////////////////////94ny92ni2Bpjz4+vTi69Lt8+OsxX+Zt2LS37mNrk/H2KmjvnG2y4/a5cXA0525XyfRAAAADHRSTlMAMhglCb23mqXOW95ovOyNAAAA20lEQVQoz22R3QKCIAyFrUytDhugAuL7v2cbapa2O84Z+/ZTVcd4wEUHnPQ73MA8nowOfiBjenvQW9jeiDHZkz4bIhNcKVXXHx0jywdBPMoL7WIALhiJGbiqboHuCyxkzZSsebS4bGCiwZc8OCaOaKoaiMJVcFPqRjLEHu0deQerMWrfvXTgBUxmUvDSSZI3Z9ikEyS7tdgiB/mS/KT5K7hM94IugRNLo7yCSzxlnYpRN67g7QBRRFrAty/jIgMrl3Zwta1IV0dhB/8cIWT8O9vUZxwKaTRlxT/6GycKEPy+qRI+AAAAAElFTkSuQmCC") no-repeat scroll 0 0;
        content: "";
        height: 22px;
        position: absolute;
        right: -9px;
        top: -6px;
        width: 24px;
    }
    .aosItemName {
        float: left;
        line-height: 33px;
        width: 97%;
    }
    .aosItemLevelPricingWrapper {
        display: inline;
        padding-left: 40px;
    }
    .aosPriceBeforeSavings {
        color: #9e9e9e;
        font-size: 18px;
        font-weight: 400;
        text-decoration: line-through;
    }
    .aosFinalPrice {
        color: #708f3f;
        font-size: 18px;
        font-weight: 700;
        padding-left: 10px;
    }
    .aosAllSavingsWrapper {
        float: left;
        margin-bottom: 30px;
        margin-top: 30px;
        width: 100%;
    }
    .aosAllSavingsBtn {
        background-color: #3b4554;
        border-radius: 4px;
        color: #fff;
        float: none;
        font-size: 16px;
        height: 50px;
        margin-left: auto;
        margin-right: auto;
        padding-top: 12px;
        text-align: center;
        width: 290px;
    }
    .aosAllSavingsBtn:hover {
        opacity: 0.8;
    }
</style>