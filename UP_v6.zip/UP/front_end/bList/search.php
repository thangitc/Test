<?php
$this->renderPartial('application.views.cart.js') ;
?>
<?php $time_sale_expired = mktime(0,0,0, date('m'),date('d'), date('Y'))-86400;?>
<script>
$(document).on("click", ".js-filter h6", function(t) {
    if ($(t.target).is("h6")) {
        $(this).parent(".js-filter").toggleClass("js-shown js-hidden");
    }
});
$(document).on("click", ".js-toggleShow", function(e) {
    var t = $(this);
    t.toggleClass("js-show js-hide");
    $(t.data("toggleshow")).toggleClass("js-open js-close");
	$('.price-range').toggle();
});
/*
$(function(){
	$('.show-range').click(function(){
		$(".price-range").toggleClass("js-open js-close");
	});
});
*/
</script>
<?php
$current_url = Common::genCurrentUrl();
preg_match('/\?(.*)/si', $current_url, $match);
$cond_cat = isset($match[1]) ? $match[1]:'';
?>
<div class="t-main js-t-main page-width full-width clearfix" data-selenium="t-main">
    <ul id="breadcrumbs" class="page-width twelve">
        <li class="first"><a href="<?php echo Yii::app()->params['baseUrl'];?>">Trang chủ</a></li>
        <?php
		$parent_info = isset($cats[$cat_info['parent_id']]) ? $cats[$cat_info['parent_id']] : array();
		if(!empty($parent_info))
		{
			?>
            <li> <a href="<?php echo Url::createUrl('bList/cat',array('alias'=>$parent_info['alias'],'cat_id'=>$parent_info['id']));?>"> <?php echo $parent_info['title'];?> </a> </li>
            <?php
		}
        ?>
        <li> <a href="<?php echo Url::createUrl('bList/cat',array('alias'=>$cat_info['alias'],'cat_id'=>$cat_info['id']));?>"> <?php echo $cat_info['title'];?> </a> </li>
    </ul>
    <div class="side nav left js-sideNav" data-selenium="sideNav">
        <div class="bold twelve get-help" data-selenium="get-help">
            <p class="c5">Hotline</p>
            <p class="elevn"> <span class="call"> 0965.505.515</span> <a data-selenium="liveChat" href="https://www.facebook.com/vn.japan" class="chat c2" target="livechat"> Live Chat </a> </p>
        </div>
        <div class="js-filters-cont filters-cont elevn" data-selenium="filters-container">
        	<?php if($cats) {?>
            <div class="catgory js-clickOne bold" data-selenium="catgory">
                <h5 class="filter-head twelve" data-selenium="filter-head">Danh mục</h5>
                <ul>
                <?php
				if($cat_info['sub_id']!=$cat_info['id'])
				{
					if($cats)
					foreach($cats as $row)
					{
						if($row['parent_id']==$cat_info['id'])
						{
							$link_cat = Url::createUrl('bList/search',array('cat_id'=>$row['id']));
							if($cond_cat!='') $link_cat .= '?'.$cond_cat;
							?>
							<li class="first clearfix" data-selenium="loadSubCat"> <a href="<?php echo $link_cat;?>" class="c5 fs12" data-selenium="loadSubCatLink"><?php echo $row['title'];?><span class="amt"> (<?php echo $row['num_p'];?>)</span></a> </li>
							<?php
						}
					}
				}
				else
				{
					if($cats)
					foreach($cats as $row)
					{
						if($row['parent_id']==$cat_info['parent_id'] && $cat_info['parent_id']!=0)
						{
							$link_cat = Url::createUrl('bList/search',array('cat_id'=>$row['id']));
							if($cond_cat!='') $link_cat .= '?'.$cond_cat;
							?>
							<li class=" first clearfix " data-selenium="loadSubCat"> <a href="<?php echo $link_cat;?>" class="c5 fs12" data-selenium="loadSubCatLink"><?php echo $row['title'];?><span class="amt"> (<?php echo $row['num_p'];?>)</span></a> </li>
							<?php
						}
					}
				}
                ?>
                </ul>
            </div>
            <?php } ?>
            <div class="narrow js-narrow twelve" data-selenium="narrowResults">
                <h5 class="filter-head twelve bold" data-selenium="filter-head">Tìm kiếm</h5>
                <?php
				preg_match('/(.*?)s=(.*)/si', $current_url, $match);
				$cond = isset($match[2]) ? $match[2]:'';
				$link_root = isset($match[1]) ? $match[1]:'';
				$list_hang_moi_id = $list_hang_moi_id!='' ? explode(',',$list_hang_moi_id) : array();
				$link_moi = $current_url.'+12351';
				$link_cu = $current_url.'+12350';
				
				$class_moi = '';
				$class_cu = '';
				if(in_array(1,$list_hang_moi_id))
				{
					$class_moi = 'active';
					$cond_match = preg_replace('/12351\+|\+12351\+|12351\+12351/si', '+', $cond);
					if(preg_match('/\?/si',$link_root))
						$link_moi = $link_root.'&s='.$cond_match;
					else
						$link_moi = $link_root.'?s='.$cond_match;
				}
				$link_moi = preg_replace('/s=\+/si','s=', $link_moi);
				$link_moi = rtrim($link_moi,'+');
				$link_moi = str_replace('?&', '?',$link_moi);
				$link_moi = str_replace('&&', '&',$link_moi);
				//Link cu
				if(in_array(0,$list_hang_moi_id))
				{
					$class_cu = 'active';
					$cond_match = preg_replace('/12350\+|\+12350\+|12350\+12350/si', '+', $cond);
					if(preg_match('/\?/si',$link_root))
						$link_cu = $link_root.'&s='.$cond_match;
					else
						$link_cu = $link_root.'?s='.$cond_match;
				}
				$link_cu = preg_replace('/s=\+/si','s=', $link_cu);
				$link_cu = rtrim($link_cu,'+');
				$link_cu = str_replace('?&', '?',$link_cu);
				$link_cu = str_replace('&&', '&',$link_cu);
                ?>
                <div class="js-shown js-filter filter js-clickMultiple js-brands " data-selenium="filter">
                    <h6 class="fs14 bold c11" data-selenium="allbrands">Loại hàng</h6>                    
                    <ul class="js-brandsList" data-selenium="brandsList">
                    	<li> <a href="<?php echo $link_moi;?>" class="checkbox <?php echo $class_moi;?>"><img title="Hàng mới" style="width:19px; height:17px" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/moi.jpg" /> Hàng mới<span class="amt"> <?php if(isset($list_total_new_old[1]) && $list_total_new_old[1]!=0 && !in_array(1,$list_hang_moi_id)) echo '('.$list_total_new_old[1].')';?></span></a> </li>
                        <li> <a href="<?php echo $link_cu;?>" class="checkbox <?php echo $class_cu;?>"><img title="Hàng cũ" style="width:19px; height:17px" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/cu.jpg" /> Hàng cũ<span class="amt"> <?php if(isset($list_total_new_old[0]) && $list_total_new_old[0]!=0 && !in_array(0,$list_hang_moi_id)) echo '('.$list_total_new_old[0].')';?></span></a> </li>
                    </ul>
                </div>
                
                <div class="js-shown js-filter filter js-clickMultiple js-brands " data-selenium="filter">
                    <h6 class="fs14 bold c11" data-selenium="allbrands">Thương hiệu</h6>
                    <!--
                    <div class="filter-form clearfix full-width" data-selenium="filter-form">
                        <input name="brand" placeholder="Tìm thương hiệu" class="search elevn" data-selenium="filterSearch" type="text">
                        <button type="button" class="search" data-selenium="searchBtn" disabled="disabled">Search</button>
                        <div class="ui-front" data-selenium="ui-front" style="display:none;"></div>
                    </div>
                    -->
                    <ul class="js-brandsList" data-selenium="brandsList">
                    <?php
					preg_match('/(.*?)s=(.*)/si', $current_url, $match);
					$cond = isset($match[2]) ? $match[2]:'';
					$link_root = isset($match[1]) ? $match[1]:'';
					$list_brand_id = $list_brand_id!='' ? explode(',',$list_brand_id) : array();
					$list_brand_active = '';
					$list_brand_unactive = '';
					if($brands)
					foreach($brands as $row)
					{
						if($row['brand_type']==0)
						{
							$link_brand = $current_url.'+3456'.$row['id'];
							$class = '';
							if(in_array($row['id'],$list_brand_id))
							{
								$class = 'active';
								$cond_match = preg_replace('/3456'.$row['id'].'\+|\+3456'.$row['id'].'\+|3456'.$row['id'].'|\+3456'.$row['id'].'/si', '+', $cond);
								if(preg_match('/\?/si',$link_root))
									$link_brand = $link_root.'&s='.$cond_match;
								else
									$link_brand = $link_root.'?s='.$cond_match;
							}
							$link_brand = preg_replace('/s=\+/si','s=', $link_brand);
							$link_brand = rtrim($link_brand,'+');
							$link_brand = str_replace('?&', '?',$link_brand);
							$link_brand = str_replace('&&', '&',$link_brand);
							
							$total_brand_one = isset($list_total_brand[$row['id']]) ? $list_total_brand[$row['id']]:0;
							
							if(in_array($row['id'],$list_brand_id))
							{
								$list_brand_active.='<li> <a data-nvalue="'.$row['id'].'" href="'.$link_brand.'" class="checkbox '.$class.'">'.$row['title'].' </a> </li>';
							}
							else
							{
								$count_brand = '';
								//if($total_brand_one!=0) $count_brand = '<span class="amt">('.$total_brand_one.') </span>';
								if($total_brand_one!=0)
								{
									$count_brand = '<span class="amt">('.$total_brand_one.') </span>';
									$list_brand_unactive.='<li> <a data-nvalue="'.$row['id'].'" href="'.$link_brand.'" class="checkbox">'.$row['title'].' '.$count_brand.' </a> </li>';
								}
							}
						}
					}
					echo $list_brand_active.$list_brand_unactive;
                    ?>
                    </ul>
                </div>
                
                <?php if($list_models) { ?>
                <div class="js-shown js-filter filter js-clickMultiple js-brands " data-selenium="filter">
                    <h6 class="fs14 bold c11" data-selenium="allbrands">Model</h6>
                    
                    <ul class="js-brandsList" data-selenium="brandsList">
                    <?php
					preg_match('/(.*?)s=(.*)/si', $current_url, $match);
					$cond = isset($match[2]) ? $match[2]:'';
					$link_root = isset($match[1]) ? $match[1]:'';
					$list_model_id = $list_model_id!='' ? explode(',',$list_model_id):array();
					$list_model_active = '';
					$list_model_unactive = '';
                    if($list_models)
                    foreach($list_models as $row)
                    {
						$link_model = $current_url.'+6789'.$row['id'];
                        $class = '';
						if(in_array($row['id'],$list_model_id))
						{
							$class = 'active';
							$cond_match = preg_replace('/6789'.$row['id'].'\+|\+6789'.$row['id'].'\+|6789'.$row['id'].'|\+6789'.$row['id'].'/si', '+', $cond);
							if(preg_match('/\?/si',$link_root))
								$link_model = $link_root.'&s='.$cond_match;
							else
								$link_model = $link_root.'?s='.$cond_match;
						}
						$link_model = preg_replace('/s=\+/si','s=', $link_model);
						$link_model = rtrim($link_model,'+');
						$link_model = str_replace('?&', '?',$link_model);
						$link_model = str_replace('&&', '&',$link_model);
						$total_model_one = isset($list_total_model[$row['id']]) ? $list_total_model[$row['id']]:0;
						if(in_array($row['id'],$list_model_id))
						{
							$list_model_active.='<li> <a data-nvalue="'.$row['id'].'" href="'.$link_model.'" class="checkbox '.$class.'">'.$row['title'].' </a> </li>';
						}
						else
						{
							$count_model = '';
							if($total_model_one!=0) $count_model = '<span class="amt">('.$total_model_one.') </span>';
							$list_model_unactive.='<li> <a data-nvalue="'.$row['id'].'" href="'.$link_model.'" class="checkbox">'.$row['title'].' '.$count_model.'</a> </li>';
						}
                    }
					echo $list_model_active.$list_model_unactive;
                    ?>
                    </ul>
                </div>
                <?php } ?>
                <div class="js-shown js-filter js-clickOne filter" data-selenium="filter">
                    <h6 class="fs14 bold c11">Khoảng giá</h6>
                    <?php					
					if($price1!=0 || $price2!=0)
					{
						$link_remove = preg_replace('/\+VND'.$price1.'\+'.$price2.'VND\+|VND'.$price1.'\+'.$price2.'VND\+|\+VND'.$price1.'\+'.$price2.'VND|VND'.$price1.'\+'.$price2.'VND/si', '+', $current_url);
						$link_remove = rtrim($link_remove,'+');
						$link_remove = str_replace('?&', '?',$link_remove);
						?>
                        <div data-selenium="selected" class="selected">
							<ul>                        
                            	<li><a class="remove-filter" href="<?php echo $link_remove;?>"><?php echo Common::formatNumber($price1);?> &ndash; <?php echo Common::formatNumber($price2);?></a></li>
                            </ul>
                        </div>
                        <?php
					}
					?>
                    <ul class="price-range" data-selenium="price-range" <?php if($price1==0 && $price2==0) echo 'style="display:block;"'; else echo 'style="display:none;"';?>>
                    	<?php if('VND'.$price1.'+'.$price2.'VND'!='VND1000000+5000000VND') {?>
                        <li><a href="<?php $url = $current_url.'+VND1000000+5000000VND'; echo $url;?>">1.000.000 &ndash; 5.000.000 <span class="amt"> <?php if($total_price_1!=0) echo '('.$total_price_1.')';?></span></a> </li>
                        <?php } ?>
                        <?php if('VND'.$price1.'+'.$price2.'VND'!='VND5000000+10000000VND') {?>
                        <li><a href="<?php $url = $current_url.'+VND5000000+10000000VND'; echo $url;?>">5.000.000 &ndash; 10.000.000 <span class="amt"> <?php if($total_price_2!=0) echo '('.$total_price_2.')';?></span></a> </li>
                        <?php } ?>
                        <?php if('VND'.$price1.'+'.$price2.'VND'!='VND10000000+15000000VND') {?>
                        <li><a href="<?php $url = $current_url.'+VND10000000+15000000VND'; echo $url;?>">10.000.000 &ndash; 15.000.000 <span class="amt"> <?php if($total_price_3!=0) echo '('.$total_price_3.')';?></span></a> </li>
                        <?php } ?>
                        <?php if('VND'.$price1.'+'.$price2.'VND'!='VND15000000+20000000VND') {?>
                        <li><a href="<?php $url = $current_url.'+VND15000000+20000000VND'; echo $url;?>">15.000.000 &ndash; 20.000.000 <?php if($total_price_4!=0) echo '('.$total_price_4.')';?></span></a> <span class="amt"> </li>
                        <?php } ?>
                        <?php if('VND'.$price1.'+'.$price2.'VND'!='VND20000000+100000000VND') {?>
                        <li><a href="<?php $url = $current_url.'+VND20000000+100000000VND'; echo $url;?>">20.000.000 &ndash; 100.000.000 <span class="amt"> <?php if($total_price_5!=0) echo '('.$total_price_5.')';?></span></a> </li>
                        <?php } ?>
                    </ul>
                    <form action="<?php echo $current_url;?>" method="get" class="filter-form clearfix full-width price-form js-price-form">
                        
                        <span>Nhập khoảng giá:</span>
                        <label>VND
                            <input name="min_price" id="min_price" class="elevn js-mnp" value="<?php if($min_price!=0) echo $min_price;?>" data-selenium="minPrice" type="text">
                            &nbsp;&nbsp;-&nbsp;&nbsp; </label>
                        <label>VND
                            <input name="max_price" id="max_price" class="elevn js-mxp" value="<?php if($max_price!=0) echo $max_price;?>" data-selenium="maxPrice" type="text">
                        </label>
                        <script>
						function searchByPrice()
						{
							var min_price = $('#min_price').val();
							var max_price = $('#max_price').val();
							if(min_price=='' || max_price=='')
							{
								alert('Vui lòng nhập khoảng giá cần tìm');
								return false;
							}
							<?php
							$link_price = preg_replace('/min_price=(.*?)&max_price=(.*?)&|min_price=(.*?)&max_price=(.*?)/si','', $current_url);
							$link_price = rtrim($link_price, '&');
							?>
							var link_p = '<?php echo $link_price;?>';
							var cond = '';
							if(min_price!=0 || min_price!='')
								cond += '&min_price='+min_price;
							if(min_price!=0 || min_price!='')
								cond += '&max_price='+max_price+'&';
							link_p = link_p.replace('?','?'+cond);
							link_p = link_p.replace('?&','?');
							link_p = link_p.replace('&&','&');
							
							window.location.href = link_p;
						}
						</script>
                        <button type="button" class="go litGrayBtn" data-selenium="pricerangeBtn" onclick="searchByPrice();">Go</button>
                    </form>
                    <button class="show-range bold js-show toggleShow js-toggleShow" data-selenium="show-range">
                        <span data-selenium="displayShown" class="js-show">
                            Tất cả khoảng giá<span data-selenium="pricearrow" class="arrow">‹</span>
                        </span>
                        <span data-selenium="filterHide" class="js-hide">
                            Ẩn khoảng giá<span data-selenium="pricearrow" class="arrow">›</span>
                        </span>
                    </button>
                </div>
                <div class="no-filter js-clickOne" data-selenium="no-filter">
                    <h6 class="therteen bold c11">Tìm theo tên sản phẩm</h6>
                    <form action="<?php echo $current_url;?>" method="get" id="search-within-form" class="filter-form clearfix full-width js-filterForm">
                        <input name="keyword" id="keyword" value="<?php echo $keyword;?>" placeholder="Tên sản phẩm" class="search elevn js-searchInput" data-selenium="searchWithin" type="text">
                        <script>
						function searchByKeyword()
						{
							var keyword = $('#keyword').val();
							if(keyword=='')
							{
								alert('Vui lòng nhập từ khóa cần tìm');
								return false;
							}
							<?php
							$link_keyword = preg_replace('/keyword=(.*?)&|keyword=(.*)/si','', $current_url);
							$link_keyword = rtrim($link_keyword, '&');
							?>
							var link_p = '<?php echo $link_keyword;?>';
							var cond = '';
							if(keyword!='')
							{
								cond = '&keyword='+keyword+'&';
							}
							link_p = link_p.replace('?','?'+cond);
							link_p = link_p.replace('?&','?');
							link_p = link_p.replace('&&','&');
							window.location.href = link_p;
						}
						</script>
                        <button type="button" class="search js-searchButton" data-selenium="searchBtn" onclick="searchByKeyword();">Search</button>
                    </form>
                </div>
            </div>
        </div>
        <div id="adv">
        	<?php
            $ads_info = Ads::getAdsCatByPos($cat_id,3);
			if($ads_info)
			{
				$src_img = Common::getImage($ads_info['picture'], 'ads', '');
				?>
                <img style="max-width:252px;" src="<?php echo $src_img;?>" />
                <?php
			}
			?>
        </div>
    </div>
    
    <div class="right main-content js-main-content" data-selenium="main-content">
    	<?php if($cats) {?>
        <div class="page-banner-zone full-width" data-selenium="page-banner-zone">
        	<?php
			$ads_cat = Ads::getAdsCatByPos($cat_id, 1);
			if($ads_cat)
			{
				$src_img = Common::getImage($ads_cat['picture'], 'ads', '');
				?>
				<div class="js-externalAdContainer externalAdContainer">
					<div class="externalAd"> <a style="text-align: center" class="overlay-on-hover" href="<?php echo $ads_cat['ads_link'];?>"> <img style="vertical-align: bottom; max-width: 100%;" src="<?php echo $src_img;?>"> </a> </div>
				</div>
				<?php
			} 
			?>
            <div id="searchTermBannerMain" data-selenium="searchTermBannerMain">
                <div id="searchTermBannerHead" data-selenium="searchTermBannerHead">
                    <h1><?php echo $h1;?></h1>
                </div>
                <div id="searchTermBody" data-selenium="searchTermBody">
                    <div id="searchTermLinksWrap" data-selenium="searchTermLinksWrap">
                    <?php
					if($cat_info['sub_id']!=$cat_info['id'])
					{
						$list_sub_id = $cat_info['sub_id'];
						$list_sub_id = explode(',',$list_sub_id);
						$total = sizeof($list_sub_id)-1;
						$style = '';
						if($total==1) $style = 'style="width:100%"';
						if($total==2) $style = 'style="width:48%"';
						if($total==3) $style = 'style="width:33%"';
						if($total==4) $style = 'style="width:24%"';
						if($total>=5) $style = 'style="width:19%"';
						
						foreach($cats as $row)
						{
							if($row['parent_id']==$cat_info['id'])
							{
								$link_cat = Url::createUrl('bList/cat',array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
								$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
								$class='';
								if($row['id']==$cat_id) $class = 'border_bottom';
								?>
                        		<a <?php echo $style;?> data-selenium="searchTermLink" href="<?php echo $link_cat;?>" class="searchTermLink <?php echo $class;?>"> <span class="searchLinkImage" data-selenium="searchLinkImage"><img src="<?php echo $src_img;?>" border="0"></span> <span class="searchLinkName" data-selenium="searchLinkName"><?php echo $row['title'];?></span> </a>
								<?php
							}
						}
					}
					else
					{
						$style = '';
						if($cat_info['parent_id']!=0)
						{
							$parent_info = isset($cats[$cat_info['parent_id']]) ? $cats[$cat_info['parent_id']]:array();
							$list_sub_id = $parent_info['sub_id'];
							$list_sub_id = explode(',',$list_sub_id);
							$total = sizeof($list_sub_id)-1;
							if($total==1) $style = 'style="width:100%"';
							if($total==2) $style = 'style="width:48%"';
							if($total==3) $style = 'style="width:33%"';
							if($total==4) $style = 'style="width:24%"';
							if($total>=5) $style = 'style="width:19%"';
						}
						foreach($cats as $row)
						{
							if($row['parent_id']==$cat_info['parent_id'] && $cat_info['parent_id']!=0)
							{
								$link_cat = Url::createUrl('bList/cat',array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
								$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
								$class='';
								if($row['id']==$cat_id) $class = 'border_bottom';
								?>
                        		<a <?php echo $style;?> data-selenium="searchTermLink" href="<?php echo $link_cat;?>" class="searchTermLink <?php echo $class;?>"> <span class="searchLinkImage" data-selenium="searchLinkImage"><img src="<?php echo $src_img;?>" border="0"></span> <span class="searchLinkName" data-selenium="searchLinkName"><?php echo $row['title'];?></span> </a>
								<?php
							}
						}
					}
					?>
					</div>
                </div>
            </div>
        </div>
        <?php } ?>
        <div class="page-info top full-width c2" data-selenium="page-info">
            <div class="search-caution elevn c1" data-selenium="search-caution"> </div>
            <div class="pagination top" data-selenium="pagination">
                <div class="top c1 fs24 clearfix">
                    <h1 class="left"><?php echo $h1;?></h1> : 
                    <span class="fs16 bold"> &nbsp;&nbsp;&nbsp;&nbsp;<?php echo ($page-1)*$num_per_page+1;?> - <?php if($total_product<=$page*$num_per_page) echo $total_product; else echo $page*$num_per_page;?> <span class="fs12">của</span> <?php echo $total_product;?> sản phẩm </span>
				</div>
                <div class="page-opts c1 clearfix elevn" data-selenium="page-opts">
                	<!--
                    <div class="sect first" data-selenium="pageSect"> <strong>Sort By:</strong>
                        <div tabindex="0" style="display: inline-block; cursor: default; position: relative;" class="selectbox borderBtn style1 ns-select elevn sort-by ns-close" data-selenium="selectBox">
                            <p style="margin: 0px; display: inline-block;" class="ns-selected-text ns-selected-option" data-selenium="selected-text"> Best Sellers
                                <svg style="width:10px;height:5px;">
                                    <use xlink:href="#arrow-down-light"></use>
                                </svg>
                            </p>
                            <ul class="ns-dropdown" style="display: none; list-style: outside none none; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; position: absolute; z-index: 11111;">
                                <li style="list-style: outside none none;" class="ns-option first" data-selenium="bestSellers"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_POPULARITY%7c1&amp;ci=9811&amp;setNs=p_POPULARITY%7c1&amp;N=4288586282&amp;srtclk=sort">Best Sellers</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="priceLowtoHigh"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_PRICE_2%7c0&amp;ci=9811&amp;setNs=p_PRICE_2%7c0&amp;N=4288586282&amp;srtclk=sort">Price: Low to High</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="priceHightoLow"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_PRICE_2%7c1&amp;ci=9811&amp;setNs=p_PRICE_2%7c1&amp;N=4288586282&amp;srtclk=sort">Price: High to Low</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="userrating"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_OVER_ALL_RATE%7c1&amp;ci=9811&amp;setNs=p_OVER_ALL_RATE%7c1&amp;N=4288586282&amp;srtclk=sort">Top Rated</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="mostRated"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_REVIEWS%7c1&amp;ci=9811&amp;setNs=p_REVIEWS%7c1&amp;N=4288586282&amp;srtclk=sort">Most Rated</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="brandAtoZ"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_PRODUCT_SHORT_DESCR%7c0&amp;ci=9811&amp;setNs=p_PRODUCT_SHORT_DESCR%7c0&amp;N=4288586282&amp;srtclk=sort">Brand: A to Z</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="brandZtoA"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_PRODUCT_SHORT_DESCR%7c1&amp;ci=9811&amp;setNs=p_PRODUCT_SHORT_DESCR%7c1&amp;N=4288586282&amp;srtclk=sort">Brand: Z to A</a></li>
                                <li style="list-style: outside none none;" class="ns-option last" data-selenium="newestSort"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_NEWEST_SORT%7c1&amp;ci=9811&amp;setNs=p_NEWEST_SORT%7c1&amp;N=4288586282&amp;srtclk=sort">Newest</a></li>
                            </ul>
                        </div>
                        <strong>Display:</strong>
                        <div tabindex="0" style="display: inline-block; cursor: default; position: relative;" class="selectbox  borderBtn style1 ns-select elevn ns-close" data-selenium="selectBox">
                            <p style="margin: 0px; display: inline-block;" class="ns-selected-text ns-selected-option" data-selenium="selected-text">24 per page
                                <svg style="width:10px;height:5px;">
                                    <use xlink:href="#arrow-down-light"></use>
                                </svg>
                            </p>
                            <ul class="ns-dropdown" style="display: none; list-style: outside none none; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; position: absolute; z-index: 11111;">
                                <li style="list-style: outside none none;" class="ns-option first"><a data-selenium="view24" class="c2" href="https://www.bhphotovideo.com/c/search?ipp=24&amp;ci=9811&amp;N=4288586282&amp;setIPP=24&amp;srtclk=itemspp">24</a></li>
                                <li style="list-style: outside none none;" class="ns-option"><a data-selenium="view48" class="c2" href="https://www.bhphotovideo.com/c/search?ipp=48&amp;ci=9811&amp;N=4288586282&amp;setIPP=48&amp;srtclk=itemspp">48</a></li>
                                <li style="list-style: outside none none;" class="ns-option"><a data-selenium="view72" class="c2" href="https://www.bhphotovideo.com/c/search?ipp=72&amp;ci=9811&amp;N=4288586282&amp;setIPP=72&amp;srtclk=itemspp">72</a></li>
                                <li style="list-style: outside none none;" class="ns-option last"><a data-selenium="view100" class="c2" href="https://www.bhphotovideo.com/c/search?ipp=100&amp;ci=9811&amp;N=4288586282&amp;setIPP=100&amp;srtclk=itemspp">100</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="sect page-view" data-selenium="page-view"> <a data-selenium="btnList" href="https://www.bhphotovideo.com/c/search?setView=LIST&amp;catName=Digital-Cameras&amp;ci=9811&amp;N=4288586282&amp;view=LIST" class="pn-btn borderBtn first list-view active"><span>List View</span></a> <a data-selenium="btnGrid" href="https://www.bhphotovideo.com/c/search?setView=GRID&amp;catName=Digital-Cameras&amp;ci=9811&amp;N=4288586282&amp;view=GRID" class="pn-btn borderBtn grid-view "><span>Grid View</span></a> <a data-selenium="btnGallery" href="https://www.bhphotovideo.com/c/search?setView=GALLERY&amp;catName=Digital-Cameras&amp;ci=9811&amp;N=4288586282&amp;view=GALLERY" class="pn-btn borderBtn last gallery-view "><span>Gallery View</span></a> </div>
                    <div class="displayNone js-compareBtn">
                        <div class="sect last bold left" data-selenium="compareSect"> <strong class="left">Compare:</strong>
                            <div class="borderBtn left compare-sec"> <span data-selenium="compareItems" class="twelve c5 js-compareItems compareItems  yes-compare js-yes-compare">Compare <span class="js-inCompareTTL inCompareTTL ">0</span> Items</span> <span data-selenium="no-compare" class="no-compare js-no-compare c3">Add Items To Compare</span> <span data-selenium="one-compare" class="one-compare  js-one-compare c3">Add 1 More Item</span> <span data-selenium="clearCompare" class="x c2 clearCompare js-clearCompare yes-compare js-yes-compare">X</span> </div>
                        </div>
                    </div>
                    -->
                </div>
            </div>
        </div>
        <div class="items full-width list-view elevn c2" data-selenium="items">
            <!-- list of items -->
            <?php
			$start_day = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
			$arr_rating = LoadConfig::$arr_rating;
			if($products)
			foreach($products as $row)
			{
				$src_img = Common::getImage($row['picture'], 'camera', '', 'medium');
				$link_detail = Url::createUrl('bList/detail', array('camera_id'=>$row['id'], 'alias'=>$row['alias']));
				
				if($row['status_new']==0)
					$title_product = $row['title'].' 2nd(#'.$row['seri'].')';
				else
					$title_product = $row['title'];
					
				$rating_name = isset($arr_rating[$row['rating']]) ? $arr_rating[$row['rating']].'.png' : 'A.png';
				$class = '';
				if($row['is_special']==1) $class = 'new-realese'; //SP sap ve
				if($row['is_special']==2) $class = 'new-arrival'; //SP ban chay
				if($row['is_special']==3) $class = 'on-special'; //SP dang hot
				if($row['is_special']==4) $class = 'top-seller'; //SP gia tot
				if($row['is_special']==5) $class = 'edu-special'; //SP Khuyen mai
				
				//Qua tang
				$access_free_price_one = isset($access_free_price[$row['id']]) ? $access_free_price[$row['id']]:0;
				?>
                <div data-selenium="itemDetail" class="item clearfix js-item <?php echo $class;?> js-bhItemObj" itemscope="" itemtype="http://schema.org/Product">
                    <div class="img-zone zone" data-selenium="img-zone">
                        <div class="padding"> <a name="image" class="itemImg" href="<?php echo $link_detail;?>" data-selenium="itemImg"> <img data-selenium="imgLoad" src="<?php echo $src_img;?>" itemprop="image" alt="<?php echo $row['title'];?>" height="150" width="150"> </a> </div>
                        <p><a href="<?php echo $link_detail;?>" data-selenium="itemReviews" class="listDetailStars review-stars-medium ten c2">
                        	<!-- 
                        	<span class="review-stars">
                            <svg class="review-stars-grey">
                                <use xlink:href="#stars"></use>
                            </svg>
                            <span class="review-stars-inner" style="width:90%;">
                            <svg class="review-stars-green">
                                <use xlink:href="#stars"></use>
                            </svg>
                            </span> </span>(121)
                            -->
                            <img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_name;?>" />
                            </a>
						</p>
                    </div>
                    <div class="desc-zone zone" data-selenium="itemInfo-zone">
                        <div class="headder sect clearfix" data-selenium="itemHeader">
                            <h3 data-selenium="itemHeading" class="bold fourteen"> <a href="<?php echo $link_detail;?>" class="c5" data-selenium="itemHeadingLink" itemprop="url"> <?php echo $title_product;?></a> </h3>
                            <!--<p class="skus full-width c1 left" data-selenium="skus"> <span>B&amp;H # <span class="sku" data-selenium="sku">SOA7S2</span></span> <span class="mfrBullet">MFR # <span class="sku" data-selenium="sku">ILCE7SM2/B</span></span> </p>-->
                            <p class="src right twelve bold" data-selenium="itemSrc"> <span></span> </p>
                        </div>
                        <div class="sect highlights" data-selenium="highlights">
                            <div class="sellingPoints">
                                <h4 class="sellingPointsTitle show-for-standard-res-only">Thông tin nổi bật</h4>
                                <?php
								$model_info = isset($models[$row['model_id']]) ? $models[$row['model_id']] : array();
                                if($row['status_new']==1)
								{
									if(!empty($model_info)) echo $model_info['introtext']; else echo $row['introtext'];
								}
								if($row['status_new']==0)
								{
									if($row['introtext']!='')
										echo $row['introtext'];
									else if(!empty($model_info))
										echo $model_info['introtext'];
									else
										echo '';
								}
								?>
                            </div>
                        </div>
                        <div class="sect add-info twelve" data-selenium="itemSection">
                            <!-- Sales Comments -->
                            <div class="salesComments scAvailability_scShipTime clearfix " data-selenium="salesComments">
                                <p class="scAvailability fs11" data-selenium="CommentAvailability"> <strong class="c2">Trạng thái: </strong> <span class="upper c5 bold " data-selenium="popoverContent">
                                <?php
								if($row['is_sale']==1)
									echo '<strong style="color:#990000">Hết hàng</strong>';
								else if($row['is_sale']==0)
									echo 'Còn hàng';
								else echo '<strong style="color:#018D72">Order</strong>';
								?>
                                </span>                                
                                </p>
                                <p class="scAvailability fs11" style="width:100%; float:right;"><?php if($row['status_new']==0) { ?>Bảo hành:<strong><?php echo $row['time_bh'];?></strong><?php }?></p>
                            </div>
                            
                        </div>
                    </div>
                    <div class="conversion-zone zone" data-selenium="conversion-zone">
                        <div class="price-zone " data-selenium="price-zone">
                            <?php 
							if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired)
							{
								$price_deal_show = $row['price'];
								$price_deal = $row['price_sale'];
								$saving = Common::formatNumber($price_deal_show-$price_deal);
								?>
                                <div data-selenium="prices" class="prices">
                                    <p> Giá: <span> <?php echo Common::formatNumber($price_deal_show);?> VND </span> </p>
                                    <p> Giảm giá: <span class="c7"> <?php echo $saving;?> VND </span> </p>
                                    <?php
									if($access_free_price_one!=0)
									{
										?>
                                        <p> Quà tặng kèm trị giá: <span class="c7"> <?php echo Common::formatNumber($access_free_price_one);?> VND </span> </p>
                                        <?php
									}
                                    ?>
                                </div>
    
                                <div class="atc-price " data-selenium="addToCartPrice">
                                    <p data-selenium="finalPrice" class="clearfix twelve"> <span class="youpay">Giá KM: </span> <span data-selenium="price" class="price  bold sixteen c7"><?php echo Common::formatNumber($row['price_sale']);?> VNĐ</span> </p>
                                    <p>Thời gian KM: <?php echo date('d/m/Y', $row['time_sale']);?></p>
                                </div>
                                <?php
							}
							else
							{
								?>
                                <div data-selenium="prices" class="prices"> </div>
                                <div class="atc-price " data-selenium="addToCartPrice">
                                    <p data-selenium="finalPrice" class="clearfix twelve"> <span class="youpay">Giá: </span> <span data-selenium="price" class="price  bold sixteen c7"><?php echo Common::formatNumber($row['price']);?> VNĐ</span> </p>
                                    <?php
									if($access_free_price_one!=0)
									{
										?>
                                        <p> Quà tặng kèm trị giá: <span class="c7"> <?php echo Common::formatNumber($access_free_price_one);?> VND </span> </p>
                                        <?php
									}
                                    ?>
                                </div>
                                <?php
							}
							?>
                            <div class="atc-zone clearfix" data-selenium="addToCartZone">
                            	<!--
                                <div class="acMapMessageCont clearfix"> </div>
                                <form class="clearfix submitToOnePopup" action="<?php echo Url::createUrl('cart/index');?>" method="post">
                                    <input id="qty<?php echo $row['id'];?>" value="1" class="qty-box js-mqQty" data-mq="3" type="text">
                                    <button type="button" onclick="addCart(<?php echo $row['id'];?>, 0, $('#qty<?php echo $row['id'];?>').val(),<?php if($row['price_sale']!=0 && $row['time_sale']!=0  && $row['time_sale']>=$time_sale_expired) echo $row['price_sale']; else echo $row['price'];?>);" class="addToCart right blueBtn cursor-pointer pill-shaped-button fs14 one-line"><?php if($row['is_sale']==2) echo 'Preorder'; else echo 'Thêm vào giỏ hàng';?></button>
                                    <a href="<?php echo Url::createUrl('cart/index');?>" data-selenium="inCartBtn" class="right inCart inc-btn  pill-shaped-button whiteBlueBtn fs14 ">Giỏ hàng</a>
                                </form>
                                -->
                                <button onclick="window.location.href='<?php echo $link_detail;?>';" style="width:100%;" class="addToCart right blueBtn cursor-pointer pill-shaped-button fs14 one-line">Xem chi tiết</button>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <?php
			}
			
            ?>
            
        </div>
        <!-- end list of items -->
        
    </div>
    <!-- end main-content -->
    <div class="bottomSection js-bottomSection clearfix full-width left" data-selenium="bottomSection">
        <div class="bottom pagination js-pagination clearfix left" data-selenium="pagination">
            <div class="back-to-top js-backToTop right bold fs12 c2">Back to top</div>
            <div class="pagination-zone  twelve" data-selenium="pagination-zone"> <?php echo $paging;?></div>
            <div class="twelve c2">
                <p class="pageNuber"> Page <?php echo $page;?> of <?php echo $total_product;?> <span class="c3 eighteen">&nbsp; | &nbsp;</span> <?php echo ($page-1)*$num_per_page;?> - <?php echo $page*$num_per_page;?> of <?php echo $total_product;?> Items </p>
            </div>
        </div>
    </div>
    <!-- BEGIN COREMETRICS This must be before the Coremetrics.jsp include below.-->
    <!-- END COREMETRICS -->
</div>