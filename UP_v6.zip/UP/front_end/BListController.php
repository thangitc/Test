﻿<?php
class BListController extends Controller
{
	public function actionIndex()
	{
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$hot_news = News::getHotNews(5);
		
		$this->pageTitle = !empty($cat_info ) && $cat_info['meta_title']!='' ? $cat_info['meta_title'] : $cat_info['title'];
		$this->metaKeywords = !empty($cat_info ) && $cat_info['meta_keyword']!='' ? $cat_info['meta_keyword'] : $cat_info['title'];
		$this->metaDescription = !empty($cat_info ) && $cat_info['meta_description']!='' ? $cat_info['meta_description'] : $cat_info['title'];
		
		$this->render('index', 
				array('cat_info'=>$cat_info, 'cats'=>$cats, 'cat_id'=>$cat_id,
					  'hot_news'=>$hot_news
		));
	}
	
	public function actionCat()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
		
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
		$alias = isset($_GET['alias']) ? $_GET['alias'] : '';
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$sub_id = isset($cat_info['sub_id']) ? $cat_info['sub_id']:'';
		list($products, $paging, $total_product, $models, $list_total_model, $list_total_brand, $list_total_new_old, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5, $access_free_price) = BList::getListByCat($cat_id, $sub_id, $alias, $page, $num_per_page);
			
		$h1 = $cat_info['title'];
		
		//Brand
		$brands = BBrand::getAllBrand();
		//Model
		$list_models = BModel::getModelByCat($cat_id, $sub_id);
		//Seo
		$metaTitle = $h1;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = isset($cat_info['meta_description']) && $cat_info['meta_description']!='' ? $cat_info['meta_description'] : $h1;
		$metaDes .= $tag_page;
		$metaKeyword = isset($cat_info['meta_keyword']) && $cat_info['meta_keyword']!='' ? $cat_info['meta_keyword'] : $metaTitleKD;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		if($cat_id==0)
		{
			$this->linkCanoncical = Url::createUrl('bList/cat');
		}
		else
		{
			$this->linkCanoncical = Url::createUrl('bList/cat', array('cat_id'=>$cat_id, 'alias'=>$cat_info['alias']));
		}
		
		$render = 'cat';
		
		$this->render($render, 
				array('products'=>$products, 'paging'=>$paging, 'total_product'=>$total_product, 'page'=>$page, 'num_per_page'=>$num_per_page,
					  'cats'=>$cats,'cat_info'=>$cat_info, 'models'=>$models,
					  'alias' => $alias, 'cat_id'=>$cat_id,
					  'h1'=>$h1,
					  'page'=>$page, 'num_pert_page'=>$num_per_page,
					  'brands'=>$brands, 'list_models'=>$list_models,
					  'list_total_model'=>$list_total_model,'list_total_brand'=>$list_total_brand, 'list_total_new_old'=>$list_total_new_old, 'total_price_1'=>$total_price_1, 'total_price_2'=>$total_price_2, 'total_price_3'=>$total_price_3, 'total_price_4'=>$total_price_4, 'total_price_5'=>$total_price_5,
					  'access_free_price'=>$access_free_price
		));
	}
	
	public function actionDetail()
	{
		$camera_id = isset($_GET['camera_id']) ? intval($_GET['camera_id']) : 0;
		$model_id = isset($_GET['model_id']) ? intval($_GET['model_id']) : 0;
		$body_id = isset($_GET['body_id']) ? intval($_GET['body_id']) : 0;
		$color_id = isset($_GET['color_id']) ? intval($_GET['color_id']) : 0;
		$kit_id = isset($_GET['kit_id']) ? intval($_GET['kit_id']) : 0;
		$chinh_hang = isset($_GET['chinh_hang']) ? intval($_GET['chinh_hang']) : '';
		if($model_id==0 && $body_id==0 && $color_id==0 &&  $kit_id==0 && $chinh_hang=='')
		{
			$detail = BList::getListInfoById($camera_id);
		}
		else
		{
			$detail = BList::getListById($model_id, $body_id, $kit_id,$color_id, $chinh_hang);
			if(!empty($detail) && $camera_id==0)
			{
				$link_redirect = Url::createUrl('bList/detail', array('camera_id'=>$detail['id'], 'alias'=>$detail['alias']));
				$this->redirect($link_redirect);
				exit();
			}
		}
		if(!empty($detail))
		{
			
			if($body_id==0 && $color_id==0 &&  $kit_id==0 && $chinh_hang=='' && $model_id==0)
			{
				$body_id = $detail['body_id'];
				$kit_id = $detail['kit_id'];
				$color_id = $detail['color_id'];
				$chinh_hang = $detail['chinh_hang'];
				$model_id = $detail['model_id'];
			}
			
			$model_info  = BModel::getModelById($model_id);

			$cat_id = $detail['cat_id'];
			$cats = $this->array_category;
			$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
			
			//Phu kien lien quan
			//$access_related = Access::getAccessByCameraID($camera_id);
			$access_related = Access::getAccessByModelID($model_id);
			//Phu kien free
			$access_free = Access::getAccessFreeByCameraID($camera_id);
			//Picture
			$camera_pic = BListPic::getPicById($camera_id);
			//Cap nhat hit
			BList::updateHit($camera_id);
			
			//Brand
			$brand_info = BBrand::getBrandById($detail['brand_id']);
			//List Body, Kit, Color, Chinh hang
			$list_body = BBody::getBodyByModel($model_id);
			$list_kit = BKit::getKitByModel($model_id);
			$list_color = BColor::getColorByModel($model_id);
			$body_info = BBody::getBodyById($body_id);
			$kit_info = BKit::getKitById($kit_id);
			$color_info = BColor::getColorById($color_id);
			//Danh sach san pham thuoc Model
			$list_product = BList::getAllProductByModel($model_id);
			//Contact
			$contact = Contact::getContactById(1);
			//Gia re nhat cung model
			$one_cheap = BList::getOneCheap($model_id);

			//Saving
            $combo_info = Combos::getComboByProductId($detail['id']);
            $list_products = array();
            $list_camera = array();
            $list_access = array();
            if(!empty($combo_info)){
                list($list_products, $list_camera, $list_access) = Combos::getProductsByCombo($combo_info['id']);
            }

			//SEO
			$metaTitle = isset($detail['meta_title']) && $detail['meta_title']!='' ? $detail['meta_title'] : $detail['title'];
			$metaTitleKD = Common::change($metaTitle);
			$introtext = !empty($model_info['introtext']) ? trim(strip_tags($model_info['introtext'])) : trim(strip_tags($detail['introtext']));
			$metaDes = isset($detail['meta_description']) && $detail['meta_description']!='' ? $detail['meta_description'] : $detail['title'].':'.$introtext;
			$metaKeyword = isset($detail['meta_keyword']) && $detail['meta_keyword']!='' ? $detail['meta_keyword'] : $metaTitleKD;
			$metaTitleKD = Common::change($metaTitle);
			$this->pageTitle = $metaTitle;
			$this->metaKeywords = $metaKeyword;
			$this->metaDescription = $metaDes;
			$this->linkCanoncical = Yii::app()->params['baseUrl'].Url::createUrl('bList/detail', array('camera_id'=>$detail['id'], 'alias'=>$detail['alias']));
			if(!empty($cat_info))
			{
				$this->linkRss = '<link rel="alternate" title="RSS - '.$cat_info['title'].'"  href="'.Url::createUrl('bList/rssCat', array('cat_id'=>$cat_info['id'], 'alias'=>$cat_info['alias'])).'" type="application/rss+xml" />';
			}
			$this->srcImg = Common::getImage($detail['picture'], 'camera', '');
			
			$render = 'detail';
			
			$this->render($render,
					array('camera_id'=>$camera_id,'model_id'=>$model_id, 'body_id'=>$body_id, 'kit_id'=>$kit_id, 'color_id'=>$color_id, 'chinh_hang'=>$chinh_hang,
						  'detail'=>$detail, 'cat_info'=>$cat_info, 'access_related'=>$access_related, 'access_free'=>$access_free,
						  'camera_pic'=>$camera_pic,'cats'=>$cats,
						  'brand_info'=>$brand_info, 'model_info'=>$model_info,
						  'list_body'=>$list_body, 'list_kit'=>$list_kit, 'list_color'=>$list_color,
						  'body_info'=>$body_info, 'kit_info'=>$kit_info, 'color_info'=>$color_info,
						  'list_product'=>$list_product,
						  'contact'=>$contact, 'one_cheap'=>$one_cheap,
                          'combo_info'=>$combo_info, 'list_products'=>$list_products, 'list_camera'=>$list_camera, 'list_access'=>$list_access
			));
		}
		else
		{
			$this->redirect(Url::createUrl('home/index'));
			exit();
		}
	}
	
	public function actionPostS()
	{
		$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';	
		$url = Url::createUrl('bList/search',array('keyword'=>$keyword));
		$this->redirect($url);
		exit();
	}
	
	public function actionSearch()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
				
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;		
		$min_price = isset($_GET['min_price']) ? $_GET['min_price'] : 0;
		$max_price = isset($_GET['max_price']) ? $_GET['max_price'] : 0;
		$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : '';
		$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$list_brand_id = '';
		$list_model_id = '';
		$list_hang_moi_id = '';
		$list_price = array();
		$s = isset($_GET['s']) ? $_GET['s'] : '';
		$list_filter = explode(' ',$s);
		if(!empty($list_filter))
		foreach($list_filter as $value)
		{
			//Thuong hieu
			if(is_numeric($value) && preg_match('/3456/si', $value))
			{
				$list_brand_id.=str_replace('3456','',$value).',';
			}
			//Model
			if(is_numeric($value) && preg_match('/6789/si', $value))
			{
				$list_model_id.=str_replace('6789','',$value).',';
			}
			//Hang moi cu
			if($value==12350)
				$list_hang_moi_id.='0,';
			if($value==12351)
				$list_hang_moi_id.='1,';
			//Gia
			if(preg_match('/VND/si',$value))
			{
				$list_price[] = str_replace('VND','', $value);
			}
		}
		$list_brand_id = rtrim($list_brand_id, ',');
		$list_model_id = rtrim($list_model_id, ',');
		$list_hang_moi_id = rtrim($list_hang_moi_id, ',');
		$price1 = 0;
		$price2 = 0;
		$min_price_search = 0;
		$max_price_search = 0;
		if(!empty($list_price))
		{
			$price1 = isset($list_price[0]) ? $list_price[0]:0;
			$price2 = isset($list_price[1]) ? $list_price[1]:0;
			if($price1<$price2)
			{
				$min_price_search = $price1;
				$max_price_search = $price2;
			}
			else
			{
				$min_price_search = $price2;
				$max_price_search = $price1;
			}
		}
		if($min_price!=0) $min_price_search = $min_price;
		if($max_price!=0) $max_price_search = $max_price;
		
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$sub_id = isset($cat_info['sub_id']) ? $cat_info['sub_id']:'';
		//Brand
		$brands = BBrand::getAllBrand();
		//Model
		$list_models = BModel::getModelByCatBrand($cat_id, $sub_id, $list_brand_id);
		//Url rewrite
		$url_rewrite=Common::genUrlRewrite();
		list($products, $paging, $total_product, $models, $list_total_model, $list_total_brand, $list_total_new_old, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5, $access_free_price) = BList::getListFilter($cat_id, $sub_id, $list_model_id, $list_brand_id, $list_hang_moi_id, $min_price_search, $max_price_search, $keyword, $orderby, $page, $num_per_page, $url_rewrite);
		//Seo
		$h1 = $cat_info['title'];
		$metaTitle = $h1;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = $h1;
		$metaDes .= $tag_page;
		$metaKeyword = $h1;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		
		$this->linkCanoncical = Url::createUrl('bList/search', array('cat_id'=>$cat_id,'alias'=>$cat_info['alias']));
		
		$render = 'search';
		
		$this->render($render, 
				array('products'=>$products, 'paging'=>$paging, 'total_product'=>$total_product, 'page'=>$page, 'num_per_page'=>$num_per_page,
					  'cat_id'=>$cat_id, 'list_brand_id'=>$list_brand_id, 'list_model_id'=>$list_model_id, 'list_hang_moi_id'=>$list_hang_moi_id,
					  'min_price'=>$min_price, 'max_price'=>$max_price, 'orderby'=>$orderby, 'price1'=>$price1, 'price2'=>$price2,'keyword'=>$keyword,
					  'h1'=>$h1,
					  'cat_info'=>$cat_info, 'cats'=>$cats, 'brands'=>$brands, 'models'=>$models, 'list_models'=>$list_models,
					  'list_total_model'=>$list_total_model,'list_total_brand'=>$list_total_brand, 'list_total_new_old'=>$list_total_new_old, 'total_price_1'=>$total_price_1, 'total_price_2'=>$total_price_2, 'total_price_3'=>$total_price_3, 'total_price_4'=>$total_price_4, 'total_price_5'=>$total_price_5,
					  'access_free_price'=>$access_free_price
		));
	}
	
	public function actionDeal()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';

		$cats = $this->array_category;
		$h1 = 'Sản phẩm giá sốc';
		$products_deal = BList::getListSales(50);
		$row_soc = BList::getOneSoc();
		$camera_id = isset($row_soc['id']) ? $row_soc['id'] : 0;
		$model_id = isset($row_soc['model_id']) ? $row_soc['model_id'] : 0;
		$model_info  = BModel::getModelById($model_id);
		
		$camera_pic = BListPic::getPicById($camera_id);
		//Cap nhat hit
		BList::updateHit($camera_id);
		//Seo
		$metaTitle = $h1;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = $h1;
		$metaDes .= $tag_page;
		$metaKeyword = $h1;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		
		$this->linkCanoncical = Url::createUrl('bList/deal');
		
		$render = 'deal';
		
		$this->render($render, 
				array('products_deal'=>$products_deal, 'row_soc'=>$row_soc, 'model_info'=>$model_info,
					  'camera_pic'=>$camera_pic,
					  'h1'=>$h1
		));
	}
	
	public function actionDealList()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
		
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$sub_id = isset($cat_info['sub_id']) ? $cat_info['sub_id']:'';
		list($products_deal, $total, $access_free) = BList::getDealList($cat_id, $sub_id, $page, $num_per_page);
		
		//Feature
		list($products_feature, $access_free_feature) = BList::getDealListFeature(12);
		$h1 = empty($cat_info) ? 'Sản phẩm giảm giá' : $cat_info['title'].' giảm giá';
		$metaTitle = $h1;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = $h1;
		$metaDes .= $tag_page;
		$metaKeyword = $h1;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		
		$this->linkCanoncical = Url::createUrl('bList/dealList');
		
		$render = 'deal_list';
		
		$this->render($render, 
				array('products_deal'=>$products_deal, 'total'=>$total, 'access_free'=>$access_free,
					  'products_feature'=>$products_feature, 'access_free_feature'=>$access_free_feature,
					  'page'=>$page, 'num_per_page'=>$num_per_page,
					  'cat_id'=>$cat_id,'cats'=>$cats, 'cat_info'=>$cat_info,
					  'h1'=>$h1
		));
	}
	
	public function actionSearchTop()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=12;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
				
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;		
		$min_price = isset($_GET['min_price']) ? $_GET['min_price'] : 0;
		$max_price = isset($_GET['max_price']) ? $_GET['max_price'] : 0;
		$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : '';
		$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_top = isset($_GET['keyword_top']) ? $_GET['keyword_top'] : '';
		$list_brand_id = '';
		$list_model_id = '';
		$list_hang_moi_id = '';
		$list_price = array();
		$s = isset($_GET['s']) ? $_GET['s'] : '';
		$list_filter = explode(' ',$s);
		if(!empty($list_filter))
		foreach($list_filter as $value)
		{
			//Thuong hieu
			if(is_numeric($value) && preg_match('/3456/si', $value))
			{
				$list_brand_id.=str_replace('3456','',$value).',';
			}
			//Model
			if(is_numeric($value) && preg_match('/6789/si', $value))
			{
				$list_model_id.=str_replace('6789','',$value).',';
			}
			//Hang moi cu
			if($value==12350)
				$list_hang_moi_id.='0,';
			if($value==12351)
				$list_hang_moi_id.='1,';
			//Gia
			if(preg_match('/VND/si',$value))
			{
				$list_price[] = str_replace('VND','', $value);
			}
		}
		$list_brand_id = rtrim($list_brand_id, ',');
		$list_model_id = rtrim($list_model_id, ',');
		$list_hang_moi_id = rtrim($list_hang_moi_id, ',');
		$price1 = 0;
		$price2 = 0;
		$min_price_search = 0;
		$max_price_search = 0;
		if(!empty($list_price))
		{
			$price1 = isset($list_price[0]) ? $list_price[0]:0;
			$price2 = isset($list_price[1]) ? $list_price[1]:0;
			if($price1<$price2)
			{
				$min_price_search = $price1;
				$max_price_search = $price2;
			}
			else
			{
				$min_price_search = $price2;
				$max_price_search = $price1;
			}
		}
		if($min_price!=0) $min_price_search = $min_price;
		if($max_price!=0) $max_price_search = $max_price;
		
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$sub_id = isset($cat_info['sub_id']) ? $cat_info['sub_id']:'';
		//Brand
		$brands = BBrand::getAllBrand();
		//Model
		$list_models = BModel::getModelByCatBrand($cat_id, $sub_id, $list_brand_id);
		//Url rewrite
		$url_rewrite=Common::genUrlRewrite();
		list($products, $paging, $total_product, $models, $list_total_model, $list_total_brand, $list_total_new_old, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5, $access_free_price) = BList::getListBySearchTop($cat_id, $sub_id, $list_model_id, $list_brand_id, $list_hang_moi_id, $min_price_search, $max_price_search, $keyword, $keyword_top, $orderby, $page, $num_per_page, $url_rewrite);
		
		if(empty($products))
		{
			$link_redirect = Url::createUrl('access/searchTop').'?keyword_top='.$keyword_top.'&s=';
			$this->redirect($link_redirect);
			exit();
		}
		
		//Seo
		$h1 = $keyword_top;
		$metaTitle = 'Kết quả tìm kiếm từ khóa: '.$keyword_top;
		$metaTitle .= $tag_page;
		$metaTitleKD = Common::change($metaTitle);
		$metaDes = $h1;
		$metaDes .= $tag_page;
		$metaKeyword = $h1;
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		
		$this->linkCanoncical = Url::createUrl('bList/searchTop', array('keyword_top'=>$keyword_top));
		
		$render = 'search_top';
		
		$this->render($render, 
				array('products'=>$products, 'paging'=>$paging, 'total_product'=>$total_product, 'page'=>$page, 'num_per_page'=>$num_per_page,
					  'cat_id'=>$cat_id, 'list_brand_id'=>$list_brand_id, 'list_model_id'=>$list_model_id, 'list_hang_moi_id'=>$list_hang_moi_id,
					  'min_price'=>$min_price, 'max_price'=>$max_price, 'orderby'=>$orderby, 'price1'=>$price1, 'price2'=>$price2,'keyword'=>$keyword,'keyword_top'=>$keyword_top,
					  'h1'=>$h1,
					  'cat_info'=>$cat_info, 'cats'=>$cats, 'brands'=>$brands, 'models'=>$models, 'list_models'=>$list_models,
					  'list_total_model'=>$list_total_model,'list_total_brand'=>$list_total_brand, 'list_total_new_old'=>$list_total_new_old, 'total_price_1'=>$total_price_1, 'total_price_2'=>$total_price_2, 'total_price_3'=>$total_price_3, 'total_price_4'=>$total_price_4, 'total_price_5'=>$total_price_5,
					  'access_free_price'=>$access_free_price
		));
	}
	
	public function actionRssCat()
    {
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
		$cat_info = Cats::getCatInfo($cat_id);
		if(!empty($cat_info))
		{
			$sub_cat_id = $cat_info['sub_id'];
			header("Content-Type: application/xml; charset=UTF-8");
			echo '<?xml version="1.0" encoding="UTF-8" ?>
			<rss version="2.0">
			<channel>
			<title>'.$cat_info['title'].'</title>
			<description>'.$cat_info['meta_description'].'</description>
			<link>'.Yii::app()->params['baseUrl'].'/'.$cat_info['alias'].'-c'.$cat_id.'.html</link>
			';
			$list = BList::getListByCatRss($cat_id, $sub_cat_id, 15);
			if($list)
			{
				foreach($list as $row) 
				{
					$link=Yii::app()->params['baseUrl'].'/'.$row['alias'].'-'.'b'.$row['id'].'.html';
					echo '<item>';
					echo '<title>'.htmlspecialchars($row['title']).'</title>';
					echo '<link>'.$link.'</link>';
					echo '<description>'.htmlspecialchars(strip_tags($row['introtext'])).'</description>';
					echo '<pubDate>'.date('r', $row['publish_date']).'</pubDate>';
					echo '<guid>'.$link.'</guid>';
					echo '</item>';
				}
			}
			echo '</channel></rss>';
			exit();
		}
		else
		{
			$this->redirect('home/index');
		}
    }
	
}
?>