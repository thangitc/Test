<?php $this->renderPartial('js');?>
<div class="body_pages clearfix">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
<tbody>
<tr>
    <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
    <td valign="top" class="last">
        <div class="content_pages">
        <?php //$this->renderPartial('application.views.eExam._box_tab');?>
        <div class="box_form">
          
        <div class="box bottom30 clearfix">
        <div class="box bottom30 clearfix">
        <p>
        	<strong class="s14 clblue">Thêm Sản phẩm cho Combo: <a href="<?php echo Url::createUrl('combos/index');?>"><?php echo $detail['title'];?></a></strong></p>
            <ul class="form4">

                <li class="clearfix"><label><strong>Loại SP :</strong> </label>
                    <div class="filltext">
                        <select id="type" name="type">
                            <option value="0" selected>Sản phẩm</option>
                            <option value="1">Phụ kiện</option>
                        </select>
                    </div>
                </li>
                <li class="clearfix"><label><strong>Tìm kiếm :</strong> </label>
                    <div class="filltext">
                    <input type="text" id="title" style="width:370px" placeholder="Nhập sản phẩm" onkeyup="findProduct($('#type').val());">
                    </div>
                </li>
                <li class="clearfix"><label><strong>&nbsp;</strong> </label>
                    <div class="filltext" id="result_search">
                    </div>
                </li>
                <li class="clearfix"><label><strong>&nbsp;</strong> </label>
                    <div class="filltext" id="result_select">
                    </div>
                </li>
                <li class="clearfix"><label><strong>Giá theo Combo :</strong> </label>
                    <div class="filltext">
                        <input type="text" style="width:120px" placeholder="Giá theo Combo" id="price_new" name="price_new" onkeyup="$(this).next('em').html(format_number($(this).val()));"><em style="color:red;"></em> VND
                    </div>
                </li>
                <li class="clearfix"><label>&nbsp;</label>
                    <div class="filltext">
                    <input type="button" class="buton-radi" value="Thêm mới" onclick="addProductCombo(<?php echo $detail['id']?>);">
                    </div>
                </li>
                <li style="color:red;" id="result"></li>

                <input type="hidden" id="product_type" value="0">
                <input type="hidden" id="product_id" value="0">
                <input type="hidden" id="price_old" value="0">
            </ul>
        
        </div>
        </div>
        
        </div> 
            <?php $this->renderPartial('application.views.static.footer');?>
        </div>
    </td>
</tr>
</tbody>
</table>
</div>
<?php $this->renderPartial('application.views.bBody.js_model');?>