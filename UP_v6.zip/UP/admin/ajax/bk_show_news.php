<script>
$(function(){    
    $(".search_news").keypress(function(e){
        switch(e.which)
        {
            case 13: 
                pagingNews(1);
                break;
            default:
                break; 
        }
    });     
});

function pagingNews(page)
{
    var keyword = $("#keyword_news").val();
    var cat_id = $("select[name='cat_id'] option:selected").val();
    var numperpage = $("select[name='numperpage'] option:selected").val();
    $.ajax({
        type: "POST",
        url: "<?php echo Url::createUrl('ajax/pagingNews');?>",
        data: "page=" + page + "&keyword=" + keyword + "&cat_id=" + cat_id + "&numperpage=" + numperpage,
        dataType: "text",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("Ajax-Request", "true");
        },
        success: function(response) {
            $("#NewsData").replaceWith(response);
        },
        error: function(){}
    });   
}

function chooseNews()
{
    var news_name = '';
    var news_id = '';
	var ListNewsId = $("#ListNewsId").val();
    if(ListNewsId == '') {
    	alert("Bạn chưa chọn tin bai.");
    	return false;
    }
    
    ListNewsId = ListNewsId.split(",");
    var html = '';
    for(i in ListNewsId)
	{
        news_name = $("#news_name_value_"+ListNewsId[i]).text();
        html += '<div class="fl  ArticleView_'+ListNewsId[i]+'" style="margin-right:10px;">';
		html +=     '<textarea name="news_name_'+ListNewsId[i]+'" style="display:none;">'+unescape(news_name)+'</textarea>';
        html += 	'<a href="#">';
        html +=		 	unescape(news_name);
        html += 	'</a>';
        html += 	'<a href="javascript:" onclick="deleteArticleRelated('+ListNewsId[i]+')" class="ic_del">&nbsp;</a>';
        html += '</div>';
    }
    
    list_news_id = $("#list_news_id").val();
    if(list_news_id == "")
	{
    	list_news_id = ListNewsId;
    }
	else
	{
    	list_news_id += ","+ListNewsId;
    }        
    $("#list_news_id").val(list_news_id)
    
    $("#news_view").append(html);
    $.fn.colorbox.close();
}

function insertNews() 
{
	var list_articles_id = $("#list_id").val();
	var list_news_id = $("#list_news_id").val();
	
	if(list_news_id != '') {
		$.ajax({
	        url:'<?php echo Url::createUrl('ajax/insertRelatedNews');?>',
	        type:"POST",
	        data:({
	        	list_articles_id:list_articles_id
	        	, list_news_id:list_news_id
	        }),
	        success:function(response){
	            var result = eval( "(" + response + ")" );
	            if(result.status !== "noPermis"){
	            	/*alert("Cập nhật thành công.");*/
	            } else {
	                alert("Bạn không đủ quyền thực hiện hành động này.");    
	            }
	            closeLoadingAjax();
	            $.fn.colorbox.close();
	            location.reload();
	        },
	        error:function(){
	            alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
	            closeLoadingAjax();
	        }
	    });
	}
	else {
		alert("Bạn chưa chọn sự kiên. Hãy làm lại.");
	}
}

</script>
<div style="width:770px; height:430px; display: block; padding: 10px;" class="popup">
	<p align="center"><strong class="clblue s18">Chọn tin liên quan</strong></p>
	<div class="popup-cont clearfix">
		<div class="box">
			<p>
				<input type="text" id="keyword_news" class="search_news" style="width: 430px;" />
            	<input type="button" onclick="pagingNews(1);" value="Tìm" class="btn-orange">
				&nbsp;
				<select name="cat_id" style="width:258px">
					<option value="0">-- Chọn chuyên mục --</option>
					<?php 
					foreach ($cat as $row) 
					{
						if($row['parent_id']==0)
						{
							?>
                            <option value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
							<?php
							foreach($cat as $row2)
							{
								if($row2['parent_id']==$row['id'])
								{
								?>
                                <option value="<?php echo $row2['id'];?>">----<?php echo $row2['title'];?></option>
                                <?php
								}
							}
						}
					}
					?>
				</select>
			</p>
			<input type="hidden" id="ListNewsId" />
		</div>
		<div class="box" id="NewsData">
			<div class="fillter clearfix" style="border-bottom:1px solid #ccc">
				<?php if($num_page > 1) { ?>
				<div class="fl">
					<ul class="pages fl magT5 clearfix">
						<?php echo Paging::show_paging_ajax("pagingNews", array(), $num_page, $page, 9, ''); ?>						
					</ul>
				</div>
				<?php } ?>
				<div class="fr"> Hiển thị
					<select style="width:44px" name="numperpage">
						<option value="10" <?php if($num_per_page == 10) echo ("selected");?>>10 tin</option>
						<option value="20" <?php if($num_per_page == 20) echo ("selected");?>>20 tin</option>
						<option value="30" <?php if($num_per_page == 30) echo ("selected");?>>30 tin</option>
					</select>
				</div>
				<br/>&nbsp;
			</div>
			<?php foreach($news as $row) { ?>
			<p>
				<input type="checkbox" class="articleIdValue" onclick="doCheckMuti('articleIdValue', 'ListNewsId');" name="articleIdValue_<?php echo $row["id"];?>" value="<?php echo $row["id"];?>"/>
				<span id="news_name_value_<?php echo $row["id"];?>"><?php echo $row["title"];?></span>
				</p>
			<?php } ?>			
		</div>
		<p align="center">
			<?php if(empty($boolean)) { ?>
				<input type="submit" onclick="chooseNews();" value="Lưu" class="btn-orange">
			<?php }?>
		</p>
	</div>
</div>