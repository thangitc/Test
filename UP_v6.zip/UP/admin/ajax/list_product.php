<?php
foreach($list_product as $row)
{
    if($type==0){
        ?>
        <p>
            <a href="javascript:" onclick="selectProduct(<?php echo $row['id'];?>,<?php echo $row['price'];?>,<?php echo $type;?>); $('#result_select').html('SP: ' + $(this).html() + ' -' + '<?php echo Common::formatNumber($row['price']);?> VND');"><?php echo $row['title'];?></a> - Giá HT: <strong style="color:red;"><?php echo Common::formatNumber($row['price']);?></strong> VND - Giá DK: <strong style="color:red;"><?php echo Common::formatNumber($row['price_dk']);?></strong> VND
        </p>
        <?php
    }
    else{
        ?>
        <p>
            <a href="javascript:" onclick="selectProduct(<?php echo $row['id'];?>,<?php echo $row['price'];?>,<?php echo $type;?>); $('#result_select').html('PK: ' + $(this).html() + ' - ' + '<?php echo Common::formatNumber($row['price']);?> VND');"><?php echo $row['title'];?></a> - Giá HT: <strong style="color:red;"><?php echo Common::formatNumber($row['price']);?></strong> VND
        </p>
        <?php
    }

}
?>