<?php
class AccessPic extends CActiveRecord
{
	public function insertPic($sub_sql)
	{
		$connect=Yii::app()->db;
		$sql = "INSERT IGNORE INTO b_accessories_picture(access_id, picture, create_date) VALUES ".$sub_sql."";
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	public function deletePic($access_id)
	{
		$connect=Yii::app()->db;
		$sql = "DELETE FROM b_accessories_picture WHERE access_id=".$access_id;
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function getPicById($access_id)
	{
		//Cache
		$cacheService = new CacheService("AccessPic","getPicById", $access_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT access_id, picture FROM b_accessories_picture WHERE access_id=".$access_id." ORDER BY id ASC";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
}
?>