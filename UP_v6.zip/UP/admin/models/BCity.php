<?php
class BCity extends CActiveRecord
{		
	public function getCity()
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_city WHERE parent_id=0";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	public function getCityById($city_id)
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_city WHERE id=".$city_id;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}
?>