<?php
class Ads extends CActiveRecord
{
	public function getAds($cat_id,$keyword,$keyword_in ,$from_date,$to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND id = "'.$keyword.'"';
		}
		if($from_date!=0) $cond.=' AND create_date >= '.$from_date;
		if($to_date!=0) $cond.=' AND create_date <= '.$to_date;
		if($cat_id!=0) $cond.=' AND cat_id = '.$cat_id;
		
		
		$sql = "SELECT count(*) as total FROM b_ads WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
        $exam_total=array();
		$sql = "SELECT * FROM b_ads WHERE ".$cond." ORDER BY id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$list_cat_id=array();
        $list_id='0,';
		if($rows)
		foreach($rows as $row)
		{
			$list_cat_id[]=$row['cat_id'];
            $list_id=$list_id.',';
		}
        $list_id=rtrim($list_id,',');
		
		//Danh muc lien quan
		$cat_ads=array();
		if(!empty($list_cat_id))
		{
			$list_cat_id=implode(',',$list_cat_id);
			$array = Cat::getCatByListId($list_cat_id);
			foreach($array as $row)
			{
				$cat_ads[$row['id']] = $row;
			}
		}
		
		$a = array($rows,$paging,$total,$cat_ads);
		return $a;
	}
	public function getAdsByDistrictId($district_id)
	{
		$connect = Yii::app()->db;
		$sql = "SELECT * FROM b_ads WHERE district_id=".$district_id." ORDER BY id ASC";
		$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	public function getAdsById($ads_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_ads WHERE id=".$ads_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
}
?>