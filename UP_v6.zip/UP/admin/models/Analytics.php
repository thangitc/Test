<?php
class Analytics extends CActiveRecord
{
	//San pham
	public function getListAnalytics($cat_id, $seri,$keyword,$keyword_in,$tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 AND t1.camera_id=t2.id AND (t2.status_new=0 || t2.status_new=2)';
		$cond_in = '1 AND t1.camera_id=t2.id AND (t2.status_new=0 || t2.status_new=2)'; //Dieu kien tinh tong gia tri nhap
		if($keyword!='')
		{
			if($keyword_in==1)
			{
				$cond.=' AND (t2.title LIKE "%'.$keyword.'%" || t2.user_post LIKE "%'.$keyword.'%")';
				$cond_in.=' AND (t2.title LIKE "%'.$keyword.'%" || t2.user_post LIKE "%'.$keyword.'%")';
			}
			if($keyword_in==2)
			{
				$cond.=' AND t2.user_post LIKE "%'.$keyword.'%"';
				$cond_in.=' AND t2.user_post LIKE "%'.$keyword.'%"';
			}
			if($keyword_in==3)
			{
				$cond.=' AND t2.id ="'.$keyword.'"';
				$cond_in.=' AND t2.id ="'.$keyword.'"';
			}
		}
		
		if($cat_id!=0)
		{
			$cond.=' AND t2.cat_id='.$cat_id;
			$cond_in.=' AND t2.cat_id='.$cat_id;
		}
		if($seri!='')
		{
			$cond.=' AND t2.seri LIKE "%'.$seri.'%"';
			$cond_in.=' AND t2.seri LIKE "%'.$seri.'%"';
		}
		
		if($from_date!=0)
		{
			$cond.=' AND t1.time_buy >= '.$from_date;
			$cond_in.=' AND t1.time_buy >= '.$from_date;
		}
		if($to_date!=0)
		{
			$cond.=' AND t1.time_buy <= '.$to_date;
			$cond_in.=' AND t1.time_buy <= '.$to_date;
		}
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		if($tab==1)//Hom nay
		{
			$cond.=' AND t1.time_buy>='.$today.' AND t1.time_buy<'.($today+86400);
			$cond_in.=' AND t1.time_buy>='.$today.' AND t1.time_buy<'.($today+86400);
		}
		if($tab==2)//Hom qua
		{
			$cond.=' AND t1.time_buy>='.($today-86400).' AND t1.time_buy<'.$today;
			$cond_in.=' AND t1.time_buy>='.($today-86400).' AND t1.time_buy<'.$today;
		}
		if($tab==3)//Thang nay
		{
			$from = mktime(0,0,0,date('m'),1,date('Y'));
			$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
			$cond.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
			$cond_in.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
		}
		if($tab==4)//Thang truoc
		{
			$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
			$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
			$cond.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
			$cond_in.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
		}
		
		$cond_order = "ORDER BY t1.id DESC";
		
		$sql = "SELECT count(t1.id) as total FROM b_camera_sale t1, b_camera t2 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.*,t2.title, t2.alias, t2.picture, t2.user_post, t2.is_sale, t2.cat_title, t2.num_shot, t2.code, t2.seri, t2.admin_id, t2.admin_name, t2.price, t2.price_sale, t2.create_date, t2.fee_vn FROM b_camera_sale t1, b_camera t2  WHERE ".$cond." ".$cond_order." LIMIT ".$begin.",".$num_per_page." ";
		$command = $connect->createCommand($sql);
		$rows= $command->queryAll();
		//Tong tien ban duoc
		$sql = "SELECT sum(t1.price_buy) as total_buy FROM b_camera_sale t1, b_camera t2 WHERE ".$cond."";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_buy = $row['total_buy']; //Tong tien ban
		//Tong phi
		$sql = "SELECT sum(t2.fee_vn) as total_fee_vn FROM b_camera t2, b_camera_sale t1 WHERE ".$cond."";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_fee_vn = $row['total_fee_vn'];
		//Tong tien nhap
		$sql = "SELECT sum(t2.price_in) as total_in FROM b_camera t2, b_camera_sale t1 WHERE ".$cond."";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_in = $row['total_in']; //Tong tien ban
		if($total_in!=0)
		{
			$percent = ($total_buy-$total_in-$total_fee_vn)*100/$total_in;
			$percent = ceil($percent);
		}
		else	
			$percent = 0;
		//Ton hang cu
		$sql = "SELECT sum(price_in+fee_vn) as total_in_ton_cu FROM b_camera WHERE is_sale=0 AND status_new=0";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_in_ton_cu = $row['total_in_ton_cu']; //Tong tien ton
		//Ton hang moi
		$sql = "SELECT sum(price_in) as total_in_ton_moi FROM b_camera WHERE is_sale=0 AND status_new=2";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_in_ton_moi = $row['total_in_ton_moi']; //Tong tien ton
		$a=array($rows,$paging,$total, $total_buy, $total_in, $percent, $total_in_ton_cu, $total_in_ton_moi, $total_fee_vn);
		return $a;
	}
	
	public function getLazadaAnalytics($cat_id, $seri,$keyword,$keyword_in,$tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 AND t1.camera_id=t2.id AND (t2.status_new=0 || t2.status_new=2) AND t1.is_lazada=1';
		$cond_in = '1 AND t1.camera_id=t2.id AND (t2.status_new=0 || t2.status_new=2) AND t1.is_lazada=1'; //Dieu kien tinh tong gia tri nhap
		if($keyword!='')
		{
			if($keyword_in==1)
			{
				$cond.=' AND (t2.title LIKE "%'.$keyword.'%" || t2.user_post LIKE "%'.$keyword.'%")';
				$cond_in.=' AND (t2.title LIKE "%'.$keyword.'%" || t2.user_post LIKE "%'.$keyword.'%")';
			}
			if($keyword_in==2)
			{
				$cond.=' AND t2.user_post LIKE "%'.$keyword.'%"';
				$cond_in.=' AND t2.user_post LIKE "%'.$keyword.'%"';
			}
			if($keyword_in==3)
			{
				$cond.=' AND t2.id ="'.$keyword.'"';
				$cond_in.=' AND t2.id ="'.$keyword.'"';
			}
		}
		
		if($cat_id!=0)
		{
			$cond.=' AND t2.cat_id='.$cat_id;
			$cond_in.=' AND t2.cat_id='.$cat_id;
		}
		if($seri!='')
		{
			$cond.=' AND t2.seri LIKE "%'.$seri.'%"';
			$cond_in.=' AND t2.seri LIKE "%'.$seri.'%"';
		}
		
		if($from_date!=0)
		{
			$cond.=' AND t1.time_buy >= '.$from_date;
			$cond_in.=' AND t1.time_buy >= '.$from_date;
		}
		if($to_date!=0)
		{
			$cond.=' AND t1.time_buy <= '.$to_date;
			$cond_in.=' AND t1.time_buy <= '.$to_date;
		}
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		if($tab==1)//Hom nay
		{
			$cond.=' AND t1.time_buy>='.$today.' AND t1.time_buy<'.($today+86400);
			$cond_in.=' AND t1.time_buy>='.$today.' AND t1.time_buy<'.($today+86400);
		}
		if($tab==2)//Hom qua
		{
			$cond.=' AND t1.time_buy>='.($today-86400).' AND t1.time_buy<'.$today;
			$cond_in.=' AND t1.time_buy>='.($today-86400).' AND t1.time_buy<'.$today;
		}
		if($tab==3)//Thang nay
		{
			$from = mktime(0,0,0,date('m'),1,date('Y'));
			$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
			$cond.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
			$cond_in.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
		}
		if($tab==4)//Thang truoc
		{
			$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
			$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
			$cond.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
			$cond_in.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
		}
		
		$cond_order = "ORDER BY t1.id DESC";
		
		$sql = "SELECT count(t1.id) as total FROM b_camera_sale t1, b_camera t2 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.*,t2.title, t2.alias, t2.picture, t2.user_post, t2.is_sale, t2.cat_title, t2.num_shot, t2.code, t2.seri, t2.admin_id, t2.admin_name, t2.price, t2.price_sale, t2.create_date, t2.fee_vn FROM b_camera_sale t1, b_camera t2  WHERE ".$cond." ".$cond_order." LIMIT ".$begin.",".$num_per_page." ";
		$command = $connect->createCommand($sql);
		$rows= $command->queryAll();
		//Tong tien ban duoc
		$sql = "SELECT sum(t1.price_buy) as total_buy FROM b_camera_sale t1, b_camera t2 WHERE ".$cond."";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_buy = $row['total_buy']; //Tong tien ban
		//Tong phi
		$sql = "SELECT sum(t2.fee_vn) as total_fee_vn FROM b_camera t2, b_camera_sale t1 WHERE ".$cond."";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_fee_vn = $row['total_fee_vn'];
		//Tong tien nhap
		$sql = "SELECT sum(t2.price_in) as total_in FROM b_camera t2, b_camera_sale t1 WHERE ".$cond."";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_in = $row['total_in']; //Tong tien ban
		if($total_in!=0)
		{
			$percent = ($total_buy-$total_in-$total_fee_vn)*100/$total_in;
			$percent = ceil($percent);
		}
		else	
			$percent = 0;
		//Ton hang cu

		$sql = "SELECT sum(price_in+fee_vn) as total_in_ton_cu FROM b_camera WHERE is_sale=0 AND status_new=0";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_in_ton_cu = $row['total_in_ton_cu']; //Tong tien ton
		//Ton hang moi
		$sql = "SELECT sum(price_in) as total_in_ton_moi FROM b_camera WHERE is_sale=0 AND status_new=2";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_in_ton_moi = $row['total_in_ton_moi']; //Tong tien ton
		$a=array($rows,$paging,$total, $total_buy, $total_in, $percent, $total_in_ton_cu, $total_in_ton_moi, $total_fee_vn);
		return $a;
	}
	public function getTotal()
	{
		$connect=Yii::app()->db;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		//Hom nay
		$sql = 'SELECT count(distinct(camera_id)) as total FROM b_camera_sale WHERE time_buy>='.$today.' AND time_buy<'.($today+86400);
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_1 = isset($row['total']) ? intval($row['total']):0;
		
		//Hom qua
		$sql = 'SELECT count(distinct(camera_id)) as total FROM b_camera_sale WHERE time_buy>='.($today-86400).' AND time_buy<'.$today;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_2 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang nay
		$from = mktime(0,0,0,date('m'),1,date('Y'));
		$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
		$sql = 'SELECT count(distinct(camera_id)) as total FROM b_camera_sale WHERE time_buy>='.$from.' AND time_buy<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_3 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang truoc
		$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
		$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
		$sql = 'SELECT count(distinct(camera_id)) as total FROM b_camera_sale WHERE time_buy>='.$from.' AND time_buy<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_4 = isset($row['total']) ? intval($row['total']):0;
		//Total
		$sql = 'SELECT count(distinct(camera_id)) as total FROM b_camera_sale';
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_0 = isset($row['total']) ? intval($row['total']):0;
		
		return array($total_0, $total_1, $total_2, $total_3, $total_4);
	}
	
	public function getTotalLazada()
	{
		$connect=Yii::app()->db;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		//Hom nay
		$sql = 'SELECT count(distinct(camera_id)) as total FROM b_camera_sale WHERE is_lazada=1 AND time_buy>='.$today.' AND time_buy<'.($today+86400);
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_1 = isset($row['total']) ? intval($row['total']):0;
		
		//Hom qua
		$sql = 'SELECT count(distinct(camera_id)) as total FROM b_camera_sale WHERE is_lazada=1 AND time_buy>='.($today-86400).' AND time_buy<'.$today;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_2 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang nay
		$from = mktime(0,0,0,date('m'),1,date('Y'));
		$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
		$sql = 'SELECT count(distinct(camera_id)) as total FROM b_camera_sale WHERE is_lazada=1 AND time_buy>='.$from.' AND time_buy<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_3 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang truoc
		$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
		$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
		$sql = 'SELECT count(distinct(camera_id)) as total FROM b_camera_sale WHERE is_lazada=1 AND time_buy>='.$from.' AND time_buy<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_4 = isset($row['total']) ? intval($row['total']):0;
		//Total
		$sql = 'SELECT count(distinct(camera_id)) as total FROM b_camera_sale WHERE is_lazada=1';
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_0 = isset($row['total']) ? intval($row['total']):0;
		
		return array($total_0, $total_1, $total_2, $total_3, $total_4);
	}
	//Phu kien
	
	public function getAnalyticsAccess($cat_id,$keyword,$keyword_in,$tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 AND t1.access_id=t2.id';
		$cond_in = '1 AND t1.access_id=t2.id'; //Dieu kien tinh tong gia tri nhap
		if($keyword!='')
		{
			if($keyword_in==1)
			{
				$cond.=' AND (t2.title LIKE "%'.$keyword.'%" || t2.user_post LIKE "%'.$keyword.'%")';
			}
			if($keyword_in==2)
			{
				$cond.=' AND t2.user_post LIKE "%'.$keyword.'%"';
			}
			if($keyword_in==3)
			{
				$cond.=' AND t2.id ="'.$keyword.'"';
			}
		}
		
		if($cat_id!=0)
		{
			$cond.=' AND t2.cat_id='.$cat_id;
		}
		
		if($from_date!=0)
		{
			$cond.=' AND t1.time_buy >= '.$from_date;
			$cond_in.=' AND t1.time_buy >= '.$from_date;
		}
		if($to_date!=0)
		{
			$cond.=' AND t1.time_buy <= '.$to_date;
			$cond_in.=' AND t1.time_buy <= '.$to_date;
		}
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		if($tab==1)//Hom nay
		{
			$cond.=' AND t1.time_buy>='.$today.' AND t1.time_buy<'.($today+86400);
			$cond_in.=' AND t1.time_buy>='.$today.' AND t1.time_buy<'.($today+86400);
		}
		if($tab==2)//Hom qua
		{
			$cond.=' AND t1.time_buy>='.($today-86400).' AND t1.time_buy<'.$today;
			$cond_in.=' AND t1.time_buy>='.($today-86400).' AND t1.time_buy<'.$today;
		}
		if($tab==3)//Thang nay
		{
			$from = mktime(0,0,0,date('m'),1,date('Y'));
			$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
			$cond.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
			$cond_in.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
		}
		if($tab==4)//Thang truoc
		{
			$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
			$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
			$cond.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
			$cond_in.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
		}
		
		$cond_order = "ORDER BY t1.id DESC";
		
		$sql = "SELECT count(t1.id) as total FROM b_accessories_sale t1, b_accessories t2 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.*,t2.title, t2.alias, t2.picture,t2.price, t2.create_date, t2.status_buy, t2.price_deal FROM b_accessories_sale t1, b_accessories t2  WHERE ".$cond." ".$cond_order." LIMIT ".$begin.",".$num_per_page." ";
		$command = $connect->createCommand($sql);
		$access= $command->queryAll();
		//Mau
		$colors = array();
		$list_color_id = '0';
		if($access)
		foreach($access as $row)
		{
			$list_color_id .=', '.$row['color_id'];
		}
		$sql = "SELECT * FROM b_accessories_color WHERE id IN (".$list_color_id.")";
		$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		if($rows)
		foreach($rows as $row)
		{
			$colors[$row['id']] = $row;
		}
		//Tong tien ban duoc
		$sql = "SELECT sum(t1.price_buy*t1.num_buy) as total_buy FROM b_accessories_sale t1, b_accessories t2 WHERE ".$cond."";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_buy = $row['total_buy']; //Tong tien ban
		//Tong tien nhap
		$sql = "SELECT sum(t1.num_buy*t1.price_in) as total_in FROM b_accessories t2, b_accessories_sale t1 WHERE ".$cond_in."";
	   	$command = $connect->createCommand($sql);
		$row = $command->queryRow();
		$total_in = $row['total_in']; //Tong gia nhap
		//Tong ton
		$sql = "SELECT t2.id, t2.price_in, t2.num_p, t2.num_buy FROM b_accessories t2";
	   	$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		$total_in_ton = 0; //Tong gia nhap ton
		if($rows)
		foreach($rows as $row)
		{
			$access_color = AccessColor::getAllColorByAccess($row['id']);
			if($access_color)
			{
				foreach($access_color as $row2)
				{
					$total_in_ton+=$row2['price_in']*($row2['num_p']-$row2['num_buy']);
				}
			}
			else
			{
				$total_in_ton+=$row['price_in']*($row['num_p']-$row['num_buy']);
			}
		}
		
		if($total_in!=0)
		{
			$percent = ($total_buy-$total_in)*100/$total_in;
			$percent = ceil($percent);
		}
		else	
			$percent = 0;
		
		$a=array($access, $colors,$paging,$total, $total_buy, $total_in, $percent, $total_in_ton);
		return $a;
	}
	public function getTotalAccess()
	{
		$connect=Yii::app()->db;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		//Hom nay
		$sql = 'SELECT count(id) as total FROM b_accessories_sale WHERE time_buy>='.$today.' AND time_buy<'.($today+86400);
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_1 = isset($row['total']) ? intval($row['total']):0;
		
		//Hom qua
		$sql = 'SELECT count(id) as total FROM b_accessories_sale WHERE time_buy>='.($today-86400).' AND time_buy<'.$today;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_2 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang nay
		$from = mktime(0,0,0,date('m'),1,date('Y'));
		$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
		$sql = 'SELECT count(id) as total FROM b_accessories_sale WHERE time_buy>='.$from.' AND time_buy<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_3 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang truoc
		$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
		$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
		$sql = 'SELECT count(id) as total FROM b_accessories_sale WHERE time_buy>='.$from.' AND time_buy<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_4 = isset($row['total']) ? intval($row['total']):0;
		//Total
		$sql = 'SELECT count(id) as total FROM b_accessories_sale';
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_0 = isset($row['total']) ? intval($row['total']):0;
		
		return array($total_0, $total_1, $total_2, $total_3, $total_4);
	}
	
	public function getChart($month)
	{
		$connect=Yii::app()->db;
		$cond='1 AND status_p=0 AND MONTH(FROM_UNIXTIME(time_buy))='.$month.' AND YEAR(FROM_UNIXTIME(time_buy))='.date('Y');
		//Tinh tong tien
		$sql = "SELECT sum(price_buy) as total_buy,sum(price_in) as total_in, DAY(FROM_UNIXTIME(time_buy)) as day_buy FROM b_camera WHERE ".$cond." GROUP BY DAY(FROM_UNIXTIME(time_buy))";
	   	$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		
		$data_report_buy = array();
		$data_report_lai = array();
		for($i=1; $i<=31; $i++)
		{
			$data_report_buy[$i] = 0;
			$data_report_lai[$i] = 0;
		}
		
		foreach($rows as $row)
		{
			$data_report_buy[$row['day_buy']] = $row['total_buy'];
			$data_report_lai[$row['day_buy']] = $row['total_buy'] - $row['total_in'];
		}
		$data_report_buy = implode(',', $data_report_buy);
		$data_report_lai = implode(',', $data_report_lai);
		$a = array($data_report_buy, $data_report_lai);
		return $a;
	}
	
	public function getChartAll($month, $year)
	{
		$connect=Yii::app()->db;
		//Lai ban buon, ban le theo thang
		$revenue_product_ban_le = 0;
		$revenue_product_ban_buon = 0;
		$total_lai_ban_le = 0;
		$total_lai_ban_buon = 0;
		$data_report_product = array();
		$data_report_access = array();
		$total_lai_thang_product = 0; //Tong lai thang san pham
		$total_lai_thang_access = 0; //Tong lai thang phu kien
		$revenue_product = 0;
		$revenue_access = 0;
		for($i=1; $i<=31; $i++)
		{
			$data_report_product[$i] = 0;
			$data_report_access[$i] = 0;
		}
		
		//$sql = "SELECT sum(t1.price_buy) as total_buy,sum(t1.price_in) as total_in, t2.status_sale FROM b_camera_sale t1, b_camera t2 WHERE t1.camera_id=t2.id AND t1.month=".$month." AND t1.year=".date('Y')." GROUP BY t2.status_sale";
		//San pham
		//Danh sach product ban hang trong thang
		$sql = "SELECT * FROM b_camera WHERE id IN (SELECT camera_id FROM b_camera_sale WHERE month=".$month." AND year=".$year.")";
		$command = $connect->createCommand($sql);
		$a = $command->queryAll();
		$list_product = array();
		if($a)
		foreach($a as $row)
		{
			$list_product[$row['id']] = $row;
		}
		$sql = "SELECT t1.* FROM b_camera_sale t1 WHERE t1.month=".$month." AND t1.year=".$year."";
		$command = $connect->createCommand($sql);
		$a2 = $command->queryAll();
		if($a2)
		foreach($a2 as $row)
		{
			$row_product = isset($list_product[$row['camera_id']]) ? $list_product[$row['camera_id']]:array();
			if(!empty($row_product) && $row_product['status_sale']==0) //Ban le
			{
				$revenue_product_ban_le += $row['price_buy'];
				$total_lai_ban_le += $row['price_buy'] - $row['price_in'] - $row_product['fee_vn'];
				$data_report_product[$row['day']] += $row['price_buy'];
				$revenue_product += $row['price_buy'];
			}
			
			if(!empty($row_product) && $row_product['status_sale']==1) //Ban buon
			{
				$revenue_product_ban_buon += $row['price_buy'];
				$total_lai_ban_buon += $row['price_buy'] - $row['price_in'] - $row_product['fee_vn'];
				//$data_report_product[$row['day']] += $row['price_buy'];
				$revenue_product += $row['price_buy'];
			}
		}
		
		$total_lai_thang_product += $total_lai_ban_le+$total_lai_ban_buon;
		$data_report_product = implode(',', $data_report_product);
		
		//Phu kien
		$sql = "SELECT sum(price_buy*num_buy) as total_buy, day FROM b_accessories_sale WHERE month=".$month." AND year=".$year." GROUP BY day";
	   	$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		
		if($rows)
		foreach($rows as $row)
		{
			$data_report_access[$row['day']] = $row['total_buy'];
			$revenue_access += $row['total_buy'];
		}
		$data_report_access = implode(',', $data_report_access);
		
		$sql = "SELECT sum((price_buy-price_in)*num_buy) as total_lai FROM b_accessories_sale WHERE month=".$month." AND year=".$year."";
	   	$command = $connect->createCommand($sql);
		$row = $command->queryRow();
		$total_lai_thang_access = $row['total_lai'];
		//Thong ke ngay
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		$sql = "SELECT t1.*, t2.title, t2.fee_vn FROM b_camera_sale t1, b_camera t2 WHERE t1.camera_id=t2.id AND t1.time_buy>=".$today." AND t1.time_buy<".($today+86400);
		$command = $connect->createCommand($sql);
		$products_day = $command->queryAll();
		
		$sql = "SELECT t1.*, t2.title FROM b_accessories_sale t1, b_accessories t2 WHERE t1.access_id=t2.id AND t1.time_buy>=".$today." AND t1.time_buy<".($today+86400);
		$command = $connect->createCommand($sql);
		$access_day = $command->queryAll();		
		//Hom qua
		$sql = "SELECT t1.*, t2.title, t2.fee_vn FROM b_camera_sale t1, b_camera t2 WHERE t1.camera_id=t2.id AND t1.time_buy>=".($today-86400)." AND t1.time_buy<".$today;
		$command = $connect->createCommand($sql);
		$products_last = $command->queryAll();
		
		$sql = "SELECT t1.*, t2.title FROM b_accessories_sale t1, b_accessories t2 WHERE t1.access_id=t2.id AND t1.time_buy>=".($today-86400)." AND t1.time_buy<".$today;
		$command = $connect->createCommand($sql);
		$access_last = $command->queryAll();
				
		$a = array($data_report_product, $data_report_access, $total_lai_thang_product, $total_lai_thang_access, $revenue_product, $revenue_access, $products_day, $access_day, $products_last, $access_last, $revenue_product_ban_le, $revenue_product_ban_buon, $total_lai_ban_le, $total_lai_ban_buon);
		return $a;
	}
	
	
	public function getListExportCamera($cat_id, $seri,$keyword,$keyword_in,$tab, $from_date, $to_date)
	{
		$connect=Yii::app()->db;
		$cond='1 AND t1.camera_id=t2.id AND (t2.status_new=0 || t2.status_new=2)';
		$cond_in = '1 AND t1.camera_id=t2.id AND (t2.status_new=0 || t2.status_new=2)'; //Dieu kien tinh tong gia tri nhap
		if($keyword!='')
		{
			if($keyword_in==1)
			{
				$cond.=' AND (t2.title LIKE "%'.$keyword.'%" || t2.user_post LIKE "%'.$keyword.'%")';
				$cond_in.=' AND (t2.title LIKE "%'.$keyword.'%" || t2.user_post LIKE "%'.$keyword.'%")';
			}
			if($keyword_in==2)
			{
				$cond.=' AND t2.user_post LIKE "%'.$keyword.'%"';
				$cond_in.=' AND t2.user_post LIKE "%'.$keyword.'%"';
			}
			if($keyword_in==3)
			{
				$cond.=' AND t2.id ="'.$keyword.'"';
				$cond_in.=' AND t2.id ="'.$keyword.'"';
			}
		}
		
		if($cat_id!=0)
		{
			$cond.=' AND t2.cat_id='.$cat_id;
			$cond_in.=' AND t2.cat_id='.$cat_id;
		}
		if($seri!='')
		{
			$cond.=' AND t2.seri LIKE "%'.$seri.'%"';
			$cond_in.=' AND t2.seri LIKE "%'.$seri.'%"';
		}
		
		if($from_date!=0)
		{
			$cond.=' AND t1.time_buy >= '.$from_date;
			$cond_in.=' AND t1.time_buy >= '.$from_date;
		}
		if($to_date!=0)
		{
			$cond.=' AND t1.time_buy <= '.$to_date;
			$cond_in.=' AND t1.time_buy <= '.$to_date;
		}
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		if($tab==1)//Hom nay
		{
			$cond.=' AND t1.time_buy>='.$today.' AND t1.time_buy<'.($today+86400);
			$cond_in.=' AND t1.time_buy>='.$today.' AND t1.time_buy<'.($today+86400);
		}
		if($tab==2)//Hom qua
		{
			$cond.=' AND t1.time_buy>='.($today-86400).' AND t1.time_buy<'.$today;
			$cond_in.=' AND t1.time_buy>='.($today-86400).' AND t1.time_buy<'.$today;
		}
		if($tab==3)//Thang nay
		{
			$from = mktime(0,0,0,date('m'),1,date('Y'));
			$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
			$cond.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
			$cond_in.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
		}
		if($tab==4)//Thang truoc
		{
			$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
			$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
			$cond.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
			$cond_in.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
		}
		
		$cond_order = "ORDER BY t1.time_buy DESC";
		
		$sql = "SELECT t1.*,t2.title, t2.alias, t2.picture, t2.user_post, t2.is_sale, t2.cat_title, t2.num_shot, t2.code, t2.seri, t2.admin_id, t2.admin_name, t2.price, t2.price_sale, t2.create_date, t2.fee_vn FROM b_camera_sale t1, b_camera t2  WHERE ".$cond." ".$cond_order."";
		$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		//Get List camera_id
		$list_customer = array();
		$list_camera_id = array();
		if($rows)
		foreach($rows as $row)
		{
			$list_camera_id[] = $row['camera_id'];
		}
		if(!empty($list_camera_id))
		{
			$list_camera_id = implode(',', $list_camera_id);
			$sql_cus = 'SELECT t1.camera_id, t1.customer_id, t2.* FROM b_customer_camera t1, b_customer t2 WHERE t1.customer_id = t2.id  AND t1.camera_id IN ('.$list_camera_id.')';
			$command = $connect->createCommand($sql_cus);
			$rows2 = $command->queryAll();
			if(!empty($rows2))
			foreach($rows2 as $row)
			{
				$list_customer[$row['camera_id']] = $row;
			}
		}
		$a = array($rows, $list_customer);
		return $a;
	}
	
	
	public function getListExportAccess($cat_id,$keyword,$keyword_in, $tab, $from_date, $to_date)
	{
		$connect=Yii::app()->db;
		$cond='1 AND t1.access_id=t2.id';
		$cond_in = '1 AND t1.access_id=t2.id'; //Dieu kien tinh tong gia tri nhap
		if($keyword!='')
		{
			if($keyword_in==1)
			{
				$cond.=' AND (t2.title LIKE "%'.$keyword.'%" || t2.user_post LIKE "%'.$keyword.'%")';
			}
			if($keyword_in==2)
			{
				$cond.=' AND t2.user_post LIKE "%'.$keyword.'%"';
			}
			if($keyword_in==3)
			{
				$cond.=' AND t2.id ="'.$keyword.'"';
			}
		}
		
		if($cat_id!=0)
		{
			$cond.=' AND t2.cat_id='.$cat_id;
		}
		
		if($from_date!=0)
		{
			$cond.=' AND t1.time_buy >= '.$from_date;
		}
		if($to_date!=0)
		{
			$cond.=' AND t1.time_buy <= '.$to_date;
		}
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		if($tab==1)//Hom nay
		{
			$cond.=' AND t1.time_buy>='.$today.' AND t1.time_buy<'.($today+86400);
		}
		if($tab==2)//Hom qua
		{
			$cond.=' AND t1.time_buy>='.($today-86400).' AND t1.time_buy<'.$today;
		}
		if($tab==3)//Thang nay
		{
			$from = mktime(0,0,0,date('m'),1,date('Y'));
			$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
			$cond.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
		}
		if($tab==4)//Thang truoc
		{
			$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
			$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
			$cond.=' AND t1.time_buy>='.$from.' AND t1.time_buy<='.$to;
		}
		
		$cond_order = "ORDER BY t1.time_buy DESC";		
		
		
		$sql = "SELECT t1.*,t2.title, t2.alias, t2.picture,t2.price, t2.create_date, t2.status_buy, t2.price_deal FROM b_accessories_sale t1, b_accessories t2  WHERE ".$cond." ".$cond_order." ";
	
		$command = $connect->createCommand($sql);
		$access= $command->queryAll();
		//Mau
		$colors = array();
		$list_color_id = '0';
		$list_access_id = array();
		if($access)
		foreach($access as $row)
		{
			$list_color_id .=', '.$row['color_id'];
			$list_access_id[] = $row['access_id'];
		}
		$sql = "SELECT * FROM b_accessories_color WHERE id IN (".$list_color_id.")";
		$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		if($rows)
		foreach($rows as $row)
		{
			$colors[$row['id']] = $row;
		}
		
		//Get List camera_id
		$list_customer = array();
		
		if(!empty($list_access_id))
		{
			$list_access_id = implode(',', $list_access_id);
			$sql_cus = 'SELECT t1.access_id, t1.customer_id, t2.* FROM b_customer_access t1, b_customer t2 WHERE t1.customer_id = t2.id  AND t1.access_id IN ('.$list_access_id.')';
			$command = $connect->createCommand($sql_cus);
			$rows2 = $command->queryAll();
			if(!empty($rows2))
			foreach($rows2 as $row)
			{
				$list_customer[$row['access_id']] = $row;
			}
		}
		$a = array($access, $colors, $list_customer);
		return $a;
	}
	
	public function getListExport()
	{
		$list_cus_access = array();
		$list_customer_id = array();
		$list_camera = array();
		$list_cus_camera = array();
		
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_customer ORDER BY id DESC";
		$command = $connect->createCommand($sql);
		$list_customer = $command->queryAll();		
			
		if($list_customer)
		foreach($list_customer as $row)
		{
			$list_customer_id[] = $row['id'];
		}
		if(!empty($list_customer_id))
		{
			$list_customer_id = implode(',', $list_customer_id);
			//San pham duoc ban
			$sql = "SELECT t1.*,t2.title, t2.alias, t2.picture, t2.user_post, t2.is_sale, t2.cat_title, t2.num_shot, t2.code, t2.seri, t2.admin_id, t2.admin_name, t2.price, t2.price_sale, t2.create_date, t2.fee_vn FROM b_camera_sale t1, b_camera t2 WHERE t1.camera_id=t2.id AND t2.id IN (SELECT camera_id FROM b_customer_camera WHERE customer_id IN (".$list_customer_id.")) ORDER BY t1.time_buy DESC";
			//echo $sql;exit();
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			
			foreach($rows as $row)
			{
				$list_camera[$row['camera_id']] = $row;
			}
			
			$sql_cus_camera = "SELECT * FROM b_customer_camera";
			$command = $connect->createCommand($sql_cus_camera);
			$rows_cus_camera = $command->queryAll();
			if(!empty($rows_cus_camera))
			foreach($rows_cus_camera as $row)
			{
				$camera_row = isset($list_camera[$row['camera_id']]) ? $list_camera[$row['camera_id']] :  array();
				if(!empty($camera_row))
				{
					$list_cus_camera[$row['customer_id']][] = $camera_row;
				}
			}
			//Phu kien duoc ban
			
			$sql = "SELECT t1.*,t2.title, t2.alias, t2.picture,t2.price, t2.create_date, t2.status_buy, t2.price_deal FROM b_accessories_sale t1, b_accessories t2  WHERE t1.access_id=t2.id AND t2.id IN (SELECT access_id FROM b_customer_access WHERE customer_id IN (".$list_customer_id.")) ORDER BY t1.time_buy DESC";
			
			$command = $connect->createCommand($sql);
			$rows_access = $command->queryAll();
			
			foreach($rows_access as $row)
			{
				$list_access[$row['access_id']] = $row;
			}
			
			$sql_cus_access = "SELECT * FROM b_customer_access";
			$command = $connect->createCommand($sql_cus_access);
			$rows_cus_access = $command->queryAll();
			if(!empty($rows_cus_access))
			foreach($rows_cus_access as $row)
			{
				$access_row = isset($list_access[$row['access_id']]) ? $list_access[$row['access_id']] :  array();
				if(!empty($access_row))
				{
					$list_cus_access[$row['customer_id']][] = $access_row;
				}
			}
			
			
		}
		
		
		$a = array($list_customer, $list_cus_camera, $list_cus_access);
		return $a;
	}
}
?>