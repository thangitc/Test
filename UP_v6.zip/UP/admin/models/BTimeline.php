<?php
class BTimeline extends CActiveRecord
{
	public function getTimeline($keyword,$keyword_in,$tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';		
		
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND (t1.title LIKE "%'.$keyword.'%")';
			if($keyword_in==2) $cond.=' AND t1.id ="'.$keyword.'"';
		}
		
		
		if($tab==1) $cond.=' AND t1.status="active"';
		if($tab==2) $cond.=' AND t1.status="pending"';
		
		$cond_order = "ORDER BY t1.ordering DESC,t1.create_date DESC";
		
		$sql = "SELECT count(*) as total FROM b_timeline t1 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.* FROM b_timeline t1 WHERE ".$cond." ".$cond_order." LIMIT ".$begin.",".$num_per_page." ";
		$command = $connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$a=array($rows,$paging,$total);
		return $a;
	}
	
	
	public function getTimelineById($timeline_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_timeline WHERE id=".$timeline_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	public function countTabTimeline()
	{
		$connect=Yii::app()->db;
		//Tong so ban ghi
		$sql = "SELECT count(id) as total FROM b_timeline";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total = isset($row['total']) ? intval($row['total']):0;
		//Public
		$sql = "SELECT count(id) as total FROM b_timeline WHERE status='active'";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_active = isset($row['total']) ? intval($row['total']):0;
		//Pending
		$sql = "SELECT count(id) as total FROM b_timeline WHERE status='pending'";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total_pending=isset($row['total']) ? intval($row['total']):0;
		
		$a=array($total, $total_active, $total_pending);
		return $a;
	}
	
	public function quickUpdateTimeline($quick_type,$list_id)
	{
		$connect = Yii::app()->db;
		if($quick_type==1)//Kich hoat tin
		{
    		$sql = "UPDATE b_timeline SET status='active' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==2)//Bo kich hoat
		{
			$sql = "UPDATE b_timeline SET status='pending' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==3)//Xoa tin bai
		{
			$sql = "DELETE FROM b_timeline WHERE id IN (".$list_id.")";
		}
		
		$command = $connect->createCommand($sql);
        $result = $command->execute();				
        return $result;	
    }
	
	public function updateOrderTimeline($id,$order)
	{
		$connect=Yii::app()->db;
		$sql="UPDATE b_timeline SET ordering=".$order." WHERE id=".$id;
		$command = $connect->createCommand($sql);
		$ok = $command->execute();
		return $ok;
	}
}
?>