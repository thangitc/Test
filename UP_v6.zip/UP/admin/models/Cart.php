<?php
class Cart extends CActiveRecord
{
	public function getOrder($order_status, $keyword,$keyword_in, $from_date, $to_date, $tab,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			//if($keyword_in==1) $cond.=' AND t2.title LIKE "%'.$keyword.'%"';
			if($keyword_in==1) $cond.=' AND t1.id = "'.$keyword.'"';
		}
		
		if($from_date!=0) $cond.=' AND created >= '.$from_date;
		if($to_date!=0) $cond.=' AND created <= '.$to_date;
		
		if($order_status!='') $cond.=' AND order_status = "'.$order_status.'"';
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		if($tab==1)//Hom nay
		{
			$cond.=' AND t1.created>='.$today.' AND t1.created<'.($today+86400);		
		}
		if($tab==2)//Hom qua
		{
			$cond.=' AND t1.created>='.($today-86400).' AND t1.created<'.$today;
		}
		if($tab==3)//Thang nay
		{
			$from = mktime(0,0,0,date('m'),1,date('Y'));
			$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
			$cond.=' AND t1.created>='.$from.' AND t1.created<='.$to;
		}
		if($tab==4)//Thang truoc
		{
			$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
			$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
			$cond.=' AND t1.created>='.$from.' AND t1.created<='.$to;
		}
		
		$sql = "SELECT count(*) as total FROM tbl_order t1 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.* FROM tbl_order t1 WHERE ".$cond." ORDER BY t1.id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$list_products = array();
		$list_order_id = '';
		if($rows)
		foreach($rows as $row)
		{
			$list_order_id .= $row['id'].',';
		}
		$list_order_id = rtrim($list_order_id, ',');
		if($list_order_id!='')
		{
			$sql = "SELECT * FROM tbl_order_products WHERE order_id IN (".$list_order_id.") ";
			$command=$connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_products[$row['order_id']][] = $row;
			}
		}
		$a = array($rows,$paging,$total, $list_products);
		return $a;
	}
	
	public function getTotalOrder()
	{
		$connect=Yii::app()->db;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		//Hom nay
		$sql = 'SELECT count(id) as total FROM tbl_order WHERE  created>='.$today.' AND created<'.($today+86400);
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_1 = isset($row['total']) ? intval($row['total']):0;
		
		//Hom qua
		$sql = 'SELECT count(id) as total FROM tbl_order WHERE  created>='.($today-86400).' AND created<'.$today;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_2 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang nay
		$from = mktime(0,0,0,date('m'),1,date('Y'));
		$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
		$sql = 'SELECT count(id) as total FROM tbl_order WHERE  created>='.$from.' AND created<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_3 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang truoc
		$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
		$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
		$sql = 'SELECT count(id) as total FROM tbl_order WHERE  created>='.$from.' AND created<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_4 = isset($row['total']) ? intval($row['total']):0;
		//Total
		$sql = 'SELECT count(id) as total FROM tbl_order';
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_0 = isset($row['total']) ? intval($row['total']):0;
		
		return array($total_0, $total_1, $total_2, $total_3, $total_4);
	}
	public function getOrderById($order_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM tbl_order WHERE id=".$order_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function countOrder()
	{
		$connect=Yii::app()->db;
		$sql = "SELECT count(id) as total, order_status FROM tbl_order GROUP BY order_status";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		return $rows;
	}
}
?>