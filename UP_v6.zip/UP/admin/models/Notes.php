<?php
class Notes extends CActiveRecord
{
	public function getNotes()
	{
		$connect=Yii::app()->db;		
		$sql = "SELECT notes FROM tbl_notes";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$notes = $row['notes'];
		return $notes;
	}
	
	
}
?>