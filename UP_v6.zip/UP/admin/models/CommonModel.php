<?php
class CommonModel extends CActiveRecord
{
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }
   /*Insert, Update, Delete*/
	public function insertObject($array_input,$table)
	{
		$sql='';
		foreach($array_input as $key=>$value)
		{
			$sql.=$key."='".$value."',"; 
		}
		$sql='INSERT IGNORE INTO '.$table.' SET '.$sql;
		$sql=rtrim($sql,',');
		$connect = Yii::app()->db;
		$command = $connect->createCommand($sql);
		$command->execute();
		$record_id=Yii::app()->db->getLastInsertID();  
		return $record_id;
	}
	public function updateObject($array_input,$key_id,$key_value,$table)
	{
		$sql='';
		foreach($array_input as $key=>$value)
		{
			$sql.=$key."='".$value."',"; 
		}
		$sql=rtrim($sql,',');
		if($sql!='')
		{
			$sql='UPDATE '.$table.' SET '.$sql.' WHERE '.$key_id.'='.$key_value;
			$connect = Yii::app()->db;
			$command = $connect->createCommand($sql);
			$a=$command->execute();
			return $a;
		}
		return -1;
	}
	public function deleteObject($array_input,$table)
	{
		$sql=' 1 ';
		foreach($array_input as $key=>$value)
		{
			$sql.=" AND ".$key."='".$value."'"; 
		}
		$sql=rtrim($sql,',');
		if($sql!='')
		{
			$sql='delete from '.$table.' where '.$sql.'';
			$connect = Yii::app()->db;
			$command = $connect->createCommand($sql);
			$a=$command->execute();
			if($a) return 1;
			else return 0;
		}
		else return 0;
			
	}
	/*Select */
	public function getObject($array_input,$table)
	{
		$connect =Yii::app()->db;
		$sub_sql='1 ';
		foreach($array_input as $key=>$value)
		{
			$sub_sql.=" AND ".$key."='".$value."'";
		}
		$sql="SELECT * FROM ".$table." WHERE ".$sub_sql."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	public function insertMultiObject($sub_sql,$table)
	{
		$connect =Yii::app()->db;
		$sql="INSERT IGNORE INTO ".$table." VALUES ".$sub_sql."";
		$command=$connect->createCommand($sql);
		$a= $command->execute();
		return $a;
	}
	
	/*Update Anh len server*/
	public function updateContentImg($create_date,$content,$alias,$url_post,$folder)
	{
		/*Update Content*/
		if(isset($create_date) && $create_date!='')
		{
			$path = date("Y/md/",$create_date);
		}
		else
		{
			$path = date("Y/md/");
		}
		//$content=stripslashes($content);
		$text_find=$content;
		$text_find=preg_replace('/<iframe(.*?)<\/iframe>/si','',$text_find);
		$text_find=preg_replace('/<object(.*?)<\/object>/si','',$text_find);
		preg_match_all('/src=["](.*?)["]/si',$text_find,$matches);
		//preg_match_all('/src=["](.*?)["]/si',$content,$matches);
		if(!isset($matches[1]))
		{
			preg_match_all("/src=['](.*?)[']/si",$text_find,$matches);
		}
		$is_update=0;
		if(isset($matches[1]))
		{
			$k=1;
			foreach($matches[1] as $value)
			{
				if(!preg_match('/vn-japan.com/si',$value))
				{
					$file_name=$alias.'_'.$k.'.jpg';
					$url_update=Common::getImage($file_name,$folder,$create_date,'');
					$content=str_replace($value,$url_update,$content);
					/*Save Anh*/
					Common::saveImgCurl($url_post,$value,$path.$file_name);
					$is_update=1;
				}
				$k++;
			}
		}
		return array($content,$is_update);
	}
	
	
	public function saveImgToServer($description,$camera_id,$path,$dir_upload, $folder)
	{
		preg_match_all('/src=["](.*?)["]/si',$description,$matches);
		if(!isset($matches[1]))
		{
			preg_match_all("/src=['](.*?)[']/si",$description,$matches);
		}
		if(isset($matches[1]))
		{
			$k=1;
			foreach($matches[1] as $value)
			{
				if(!preg_match('/vn-japan.com|localhost/si',$value))
				{
					$value = preg_replace('/&space;|space;|&amp;|amp;/si','',$value);
					$file_name = $camera_id.'_'.rand(1,1000000).'_'.$k.'.jpg';
					$url_update = Common::getImage($path.$file_name, $folder ,'');
					$description = str_replace($value,$url_update,$description);
					/*Save Anh*/
					Common::save_image($value,$dir_upload.'/'.$path,$file_name);
				}
				$k++;
			}
		}
		return $description;
	}
}
?>
