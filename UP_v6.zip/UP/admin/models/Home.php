<?php
class Home extends CActiveRecord
{    
   
    public function getQuestionHome($search){
        $cond = " 1 ";
        $connect = Yii::app()->db_learning;

        if($search['from_date'] != ''){
            $search['from_date'] = DateUtils::convertDateTime($search['from_date'],'0:0:0');
            $cond .= " AND create_date > ".$search['from_date'];
        }
        if($search['to_date'] != ''){
            $search['to_date'] = DateUtils::convertDateTime($search['to_date'],'23:59:59');
            $cond .= " AND create_date < ".$search['to_date'];
        }
        if($search['from_date'] == '' && $search['to_date'] == ''){
            $time_today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $cond .= " AND create_date > ".$time_today;            
        }
        
        $sql = "SELECT count(id) as total FROM e_question WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $question_total= $command->queryRow();
        $question_total=$question_total['total'];
        
        $sql = "SELECT count(id) as total FROM e_question WHERE ".$cond." AND status=1 ";
        $command=$connect->createCommand($sql);
        $question_active= $command->queryRow();
        $question_active=$question_active['total'];
        
        $sql = "SELECT count(id) as total FROM e_question WHERE ".$cond." AND approved=1 ";
        $command=$connect->createCommand($sql);
        $question_approved= $command->queryRow();
        $question_approved=$question_approved['total'];
        
        $sql = "SELECT count(id) as total FROM e_question_comment WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $cm_question_total= $command->queryRow();
        $cm_question_total=$cm_question_total['total'];
        
        $sql = "SELECT count(id) as total FROM e_question_comment WHERE ".$cond." AND status=1 ";
        $command=$connect->createCommand($sql);
        $cm_question= $command->queryRow();
        $cm_question=$cm_question['total'];
        
        $sql = "SELECT count(id) as total FROM e_question_answer WHERE ".$cond." AND status=1 ";
        $command=$connect->createCommand($sql);
        $answer= $command->queryRow();
        $answer=$answer['total'];
        
        $sql = "SELECT count(id) as total FROM e_question_answer WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $answer_total= $command->queryRow();
        $answer_total=$answer_total['total'];
        
        $sql = "SELECT count(id) as total FROM e_question_answer_vote WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $vote= $command->queryRow();
        $vote=$vote['total'];
               
        return array($question_active,$question_total,$question_approved,$cm_question,$cm_question_total,$answer,$answer_total,$vote);   
    }
    
    public function getQaHome($search){
        $cond = " 1 ";
        $connect = Yii::app()->db_learning;

        if($search['from_date'] != ''){
            $search['from_date'] = DateUtils::convertDateTime($search['from_date'],'0:0:0');
            $cond .= " AND create_date > ".$search['from_date'];
        }
        if($search['to_date'] != ''){
            $search['to_date'] = DateUtils::convertDateTime($search['to_date'],'23:59:59');
            $cond .= " AND create_date < ".$search['to_date'];
        }
        if($search['from_date'] == '' && $search['to_date'] == ''){
            $time_today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $cond .= " AND create_date > ".$time_today;            
        }
        
        $sql = "SELECT count(id) as total FROM e_qa WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $qa_total= $command->queryRow();
        $qa_total=$qa_total['total'];
        
        $sql = "SELECT count(id) as total FROM e_qa WHERE ".$cond." AND status=1 ";
        $command=$connect->createCommand($sql);
        $qa_active= $command->queryRow();
        $qa_active=$qa_active['total'];
        
        $sql = "SELECT count(id) as total FROM e_qa WHERE ".$cond." AND status=1 AND parent_id!=0 ";
        $command=$connect->createCommand($sql);
        $qa_reply= $command->queryRow();
        $qa_reply=$qa_reply['total'];
               
        return array($qa_total,$qa_active,$qa_reply);   
    }
    
    public function getUserHome($search){
        $cond = " 1 ";
        $connect = Yii::app()->db_learning;

        if($search['from_date'] != ''){
            $search['from_date'] = DateUtils::convertDateTime($search['from_date'],'0:0:0');
            $cond .= " AND create_date > ".$search['from_date'];
        }
        if($search['to_date'] != ''){
            $search['to_date'] = DateUtils::convertDateTime($search['to_date'],'23:59:59');
            $cond .= " AND create_date < ".$search['to_date'];
        }
        if($search['from_date'] == '' && $search['to_date'] == ''){
            $time_today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $cond .= " AND create_date > ".$time_today;            
        }
        
        $sql = "SELECT count(id) as total FROM e_user WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $user_total= $command->queryRow();
        $user_total=$user_total['total'];
        
        $sql = "SELECT count(id) as total FROM e_user WHERE ".$cond." AND fbid!='' ";
        $command=$connect->createCommand($sql);
        $user_fb= $command->queryRow();
        $user_fb=$user_fb['total'];
        
        $sql = "SELECT count(id) as total FROM e_suggest WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $suggest= $command->queryRow();
        $suggest=$suggest['total'];
        
        $sql = "SELECT count(id) as total FROM e_suggest WHERE ".$cond." AND feedback!='' ";
        $command=$connect->createCommand($sql);
        $suggest_done= $command->queryRow();
        $suggest_done=$suggest_done['total'];
               
        return array($user_total,$user_fb,$suggest,$suggest_done);   
    }
    
    public function getArticlesHome($search){
        $cond = " 1 ";
        $connect = Yii::app()->db_news;

        if($search['from_date'] != ''){
            $search['from_date'] = DateUtils::convertDateTime($search['from_date'],'0:0:0');
            $cond .= " AND create_date > ".$search['from_date'];
        }
        if($search['to_date'] != ''){
            $search['to_date'] = DateUtils::convertDateTime($search['to_date'],'23:59:59');
            $cond .= " AND create_date < ".$search['to_date'];
        }
        if($search['from_date'] == '' && $search['to_date'] == ''){
            $time_today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $cond .= " AND create_date > ".$time_today;            
        }
        
        $sql = "SELECT count(id) as total FROM tbl_articles WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $articles_total= $command->queryRow();
        $articles_total=$articles_total['total'];
        
        $sql = "SELECT count(id) as total FROM tbl_articles WHERE ".$cond." AND status='active' ";
        $command=$connect->createCommand($sql);
        $articles_active= $command->queryRow();
        $articles_active=$articles_active['total'];
        
        $sql = "SELECT count(id) as total FROM tbl_comments WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $articles_cm= $command->queryRow();
        $articles_cm=$articles_cm['total'];
        
        $sql = "SELECT count(id) as total FROM tbl_comments WHERE ".$cond." AND  status='active' ";
        $command=$connect->createCommand($sql);
        $articles_cm_active= $command->queryRow();
        $articles_cm_active=$articles_cm_active['total'];
               
        return array($articles_total,$articles_active,$articles_cm,$articles_cm_active);   
    }
    
    public function getExamHome($search){
        $cond = " 1 ";
        $cond2 = " 1 ";
        $connect = Yii::app()->db_learning;

        if($search['from_date'] != ''){
            $search['from_date'] = DateUtils::convertDateTime($search['from_date'],'0:0:0');
            $cond .= " AND create_date > ".$search['from_date'];
            $cond2 .= " AND time_begin > ".$search['from_date'];            
        }
        if($search['to_date'] != ''){
            $search['to_date'] = DateUtils::convertDateTime($search['to_date'],'23:59:59');
            $cond .= " AND create_date < ".$search['to_date'];
            $cond2 .= " AND time_end < ".$search['to_date'];
        }
        if($search['from_date'] == '' && $search['to_date'] == ''){
            $time_today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $time_today2 = mktime(23, 59, 59, date("m")  , date("d"), date("Y"));
            $cond .= " AND create_date > ".$time_today;            
            $cond2 .= " AND time_begin > ".$time_today." AND time_end < ".$time_today2;            
        }
        
        $sql = "SELECT count(id) as total FROM e_exam WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $exam_total= $command->queryRow();
        $exam_total=$exam_total['total'];
        
        $sql = "SELECT count(id) as total FROM e_exam WHERE ".$cond." AND status=1 ";
        $command=$connect->createCommand($sql);
        $exam_active= $command->queryRow();
        $exam_active=$exam_active['total'];
        
        $sql = "SELECT count(id) as total FROM e_exam WHERE ".$cond2." AND is_online_day=1 ";
        $command=$connect->createCommand($sql);
        $exam_online= $command->queryRow();
        $exam_online=$exam_online['total'];
               
        return array($exam_total,$exam_active,$exam_online);   
    }
    
    public function getLessonHome($search){
        $cond = " 1 ";
        $cond2 = " 1 ";
        $connect = Yii::app()->db_learning;

        if($search['from_date'] != ''){
            $search['from_date'] = DateUtils::convertDateTime($search['from_date'],'0:0:0');
            $cond .= " AND create_date > ".$search['from_date'];
            $cond2 .= " AND release_time > ".$search['from_date'];
        }
        if($search['to_date'] != ''){
            $search['to_date'] = DateUtils::convertDateTime($search['to_date'],'23:59:59');
            $cond .= " AND create_date < ".$search['to_date'];
            $cond2 .= " AND release_time < ".$search['to_date'];
        }
        if($search['from_date'] == '' && $search['to_date'] == ''){
            $time_today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $time_today2 = mktime(23, 59, 59, date("m")  , date("d"), date("Y"));
            $cond .= " AND create_date > ".$time_today;            
            $cond2 .= " AND release_time > ".$time_today." AND release_time < ".$time_today2;            
        }
        
        $sql = "SELECT count(id) as total FROM e_lesson WHERE ".$cond2." ";
        $command=$connect->createCommand($sql);
        $lesson_release= $command->queryRow();
        $lesson_release=$lesson_release['total'];
        
        $lesson_vote=0;
        
        $sql = "SELECT count(id) as total FROM e_qa_lesson WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $lesson_qa= $command->queryRow();
        $lesson_qa=$lesson_qa['total'];
               
        return array($lesson_release,$lesson_vote,$lesson_qa);   
    }
    
    public function getDocHome($search){
        $cond = " 1 ";
        $connect = Yii::app()->db_learning;

        if($search['from_date'] != ''){
            $search['from_date'] = DateUtils::convertDateTime($search['from_date'],'0:0:0');
            $cond .= " AND create_date > ".$search['from_date'];
        }
        if($search['to_date'] != ''){
            $search['to_date'] = DateUtils::convertDateTime($search['to_date'],'23:59:59');
            $cond .= " AND create_date < ".$search['to_date'];
        }
        if($search['from_date'] == '' && $search['to_date'] == ''){
            $time_today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $cond .= " AND create_date > ".$time_today;            
        }
        
        $sql = "SELECT count(id) as total FROM e_doc WHERE ".$cond." ";
        $command=$connect->createCommand($sql);
        $doc_total= $command->queryRow();
        $doc_total=$doc_total['total'];
        
        $sql = "SELECT count(id) as total FROM e_doc WHERE ".$cond." AND status=1 ";
        $command=$connect->createCommand($sql);
        $doc_active= $command->queryRow();
        $doc_active=$doc_active['total'];
        
        $sql = "SELECT count(id) as total FROM e_doc WHERE ".$cond." AND user_id!=0 ";
        $command=$connect->createCommand($sql);
        $doc_user_total= $command->queryRow();
        $doc_user_total=$doc_user_total['total'];
        
        $sql = "SELECT count(id) as total FROM e_doc WHERE ".$cond." AND user_id!=0 AND status=1 ";
        $command=$connect->createCommand($sql);
        $doc_user_active= $command->queryRow();
        $doc_user_active=$doc_user_active['total'];
               
        return array($doc_total,$doc_active,$doc_user_total,$doc_user_active);   
    }
    
    public function getTranHome($search){
        $cond = " 1 ";
        $connect = Yii::app()->db_learning;
        $id_test=LoadConfig::$list_id_test;

        if($search['from_date'] != ''){
            $search['from_date'] = DateUtils::convertDateTime($search['from_date'],'0:0:0');
            $cond .= " AND create_time > ".$search['from_date'];
        }
        if($search['to_date'] != ''){
            $search['to_date'] = DateUtils::convertDateTime($search['to_date'],'23:59:59');
            $cond .= " AND create_time < ".$search['to_date'];
        }
        if($search['from_date'] == '' && $search['to_date'] == ''){
            $time_today = mktime(0, 0, 0, date("m") , date("d"), date("Y"));
            $cond .= " AND create_time > ".$time_today;            
        }
        $cond_type=" AND (type=5 || type=7 || type=8 || type=9 || type=10) AND user_id NOT IN (".$id_test.") ";
        $time_yesterday1= mktime(0, 0, 0, date("m")  , date("d")-1, date("Y"));
        $time_yesterday2= mktime(23, 59, 59, date("m")  , date("d")-1, date("Y"));
        $time_week_yesterday1= mktime(0, 0, 0, date("m")  , date("d")-8, date("Y"));
        $time_week_yesterday2= mktime(23, 59, 59, date("m")  , date("d")-8, date("Y"));
        
        $time_month= mktime(0, 0, 0, date("m")  , 1, date("Y"));
        $time_last_month_day1= mktime(0, 0, 0, date("m")-1  ,1 , date("Y"));
        $time_last_month_day2= mktime(23, 59, 59, date("m")-1  ,date("d"), date("Y"));
        
        $time_last_month1= mktime(0, 0, 0, date("m")-1  ,1 , date("Y"));
        $time_last_month2= mktime(0, 0, 0, date("m") ,1 , date("Y"));
        $time_last_month3= mktime(0, 0, 0, date("m")-2 ,1 , date("Y"));
        $time_last_month4= mktime(0, 0, 0, date("m")-1 ,1 , date("Y"));
        
        $sql = "SELECT id,money,telco,type FROM e_transaction WHERE ".$cond." ".$cond_type."";
        $command=$connect->createCommand($sql);
        $tran_time= $command->queryAll();

        $sql = "SELECT id,money,telco,type FROM e_transaction WHERE create_time < ".$time_yesterday2." AND create_time > ".$time_yesterday1." ".$cond_type." ";
        $command=$connect->createCommand($sql);
        $tran_yesterday= $command->queryAll();
        
        $sql = "SELECT id,money,telco,type FROM e_transaction WHERE create_time < ".$time_yesterday2." AND create_time > ".$time_yesterday1." ".$cond_type." ";
        $command=$connect->createCommand($sql);
        $tran_week_yesterday= $command->queryAll();
        
        // tu dau thang
        $sql = "SELECT id,money,telco,type FROM e_transaction WHERE create_time > ".$time_month." ".$cond_type." ";
        $command=$connect->createCommand($sql);
        $tran_month= $command->queryAll();
        
        //cung ky thang truoc
        $sql = "SELECT id,money,telco,type FROM e_transaction WHERE create_time > ".$time_last_month_day1." AND create_time < ".$time_last_month_day2." ".$cond_type." ";
        $command=$connect->createCommand($sql);
        $tran_last_month_day= $command->queryAll();
        
        //thang trươc
        $sql = "SELECT id,money,telco,type FROM e_transaction WHERE create_time > ".$time_last_month1." AND create_time < ".$time_last_month2." ".$cond_type." ";
        $command=$connect->createCommand($sql);
        $tran_last_month1= $command->queryAll();
        
        //thang trươc nưa
        $sql = "SELECT id,money,telco,type FROM e_transaction WHERE create_time > ".$time_last_month3." AND create_time < ".$time_last_month4." ".$cond_type." ";
        $command=$connect->createCommand($sql);
        $tran_last_month2= $command->queryAll();
               
        return array($tran_time,$tran_yesterday,$tran_week_yesterday,$tran_month,$tran_last_month_day,$tran_last_month1,$tran_last_month2);   
    }
}
?>