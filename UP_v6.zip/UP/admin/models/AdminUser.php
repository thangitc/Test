<?php

/**
* This is the model class for table "tbl_user".
*/
class AdminUser extends CActiveRecord
{
    /**
    * The followings are the available columns in table 'tbl_user':
    * @var integer $id
    * @var string $email
    * @var string $username
    * @var string $password
    * @var string $last_login_time
    * @var string $create_time
    * @var integer $create_user_id
    * @var string $update_time
    * @var integer $update_user_id
    */
    public $allowAutoLogin = true;
    public $loginUrl="/adminUser/login";
    public $returnUrl="/admin/category/list";
    public $password_repeat;
    private $_identity;


    const ACTIVE_STATUS_VALUE = 1;
    const ACTIVE_STATUS_TEXT = 'Active';
    const NOACTIVE_STATUS_VALUE = 0;
    const NOACTIVE_STATUS_TEXT = 'inActive';

    /**
    * Returns the static model of the specified AR class.
    * @return User the static model class
    */
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    /**
    * @return string the associated database table name
    */
    public function tableName()
    {
        return 'b_admin_user';
    }

    /**
    * @return array validation rules for model attributes.
    */
    public function rules()
    {

        return array(
        array('email, username, password', 'required'),
        array('email, username, password', 'length', 'max'=>256),
        array('email, username', 'unique'),
        array('email', 'email'),
        array('info', 'length','max'=>4000),
        array('password', 'compare'),
        array('password_repeat', 'safe'),
        array('id, email, username, password, last_login_time, create_time, create_user_id, update_time, update_user_id,active', 'safe', 'on'=>'search'),
        );
    }

    /**
    * @return array relational rules.
    */
    public function relations()
    {

        return array(
        //'issues' => array(self::HAS_MANY, 'Issue', 'requester_id'),
        //'projects' => array(self::MANY_MANY, 'Project', 'tbl_project_user_assignment(project_id, user_id)'),
        );
    }

    /**
    * @return array customized attribute labels (name=>label)
    */
    public function attributeLabels()
    {
        return array(
        'id' => 'ID',
        'email' => 'Email',
        'username' => 'Username',
        'password' => 'Password',
        'last_login_time' => 'Last Login Time',
        'create_time' => 'Create Time',
        'create_user_id' => 'Create User',
        'update_time' => 'Update Time',
        'update_user_id' => 'Update User',
        );
    }

    public function getAllData(){
        $connect = Yii::app()->db;
        $sql = "SELECT id,username FROM b_admin_user";
        $command = $connect->createCommand($sql);
        $data = $command->queryAll();
        return $data;
    }

    public function getCountDataByUsername($username){
        $sql = "SELECT count(*) as count FROM b_admin_user WHERE username = '".$username."'";       
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);
        $data = $command->queryRow();
    }
    
    public function getDataById($id){
    	$cacheService = new CacheService("AdminUser","getDataById","",$id);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
	        $sql ="SELECT id,username,email,full_name,password,type_admin,info, active FROM b_admin_user WHERE id=".$id;
	        $connect = Yii::app()->db;
	        $command = $connect->createCommand($sql);
	        $data = $command->queryRow();
	        Yii::app()->cache->set($key,$data,ConstantsUtil::TIME_CACHE_900);
		}
		else
		{
			$data=$cache;
		}
		return $data;
    }

    public function getCountDataAdmin($name =""){
        $str = "";
        if($name !=""){
            $str = " AND username LIKE '%".$name."%' ";
        }
        $sql = "SELECT count(*) as count FROM b_admin_user WHERE 1 ".$str."";
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);
        $data = $command->queryRow();
        return $data;
    }

    public function getDataAdmin($keyword,$in_keyword,$status,$type_admin,$from_date,$to_date,$page,$num_per_page)
	{
        $connect =yii::app()->db;
		$url = Yii::app ()->urlManager;
		
		/*Xác định điều kiện*/
		$cond_sql=" 1 ";
		$cond_order='';
		if($keyword!='')
		{
			if($in_keyword==1)
				$cond_sql.=' AND t1.username like "%'.$keyword.'%"';
			else if ($in_keyword==2)	
				$cond_sql.=' AND t1.id = "'.$keyword.'"';
			else $cond_sql.=' AND t1.full_name like "%'.$keyword.'%"';
		}
		if($status!='-1')
			$cond_sql.=' AND t1.status='.$status;
		if($type_admin!=0)
			$cond_sql.=' AND t1.type_admin='.$type_admin;	
		
		if($from_date!=0)	
			$cond_sql.=' AND t1.create_date>='.$from_date.'';
		if($to_date!=0)	
			$cond_sql.=' AND t1.create_date<='.$to_date.'';
            
        $cond_sql.=' AND t1.id!=1';
		
		//End kiem tra dieu kien
		$sql="SELECT count(id) as total FROM b_admin_user t1 WHERE ".$cond_sql."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		
		//Phân trang
		$num_per_page = $num_per_page;
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		
		$sql = "SELECT * FROM b_admin_user t1 WHERE ".$cond_sql." LIMIT ".$begin.",".$num_per_page."";
			
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		$iSEGSIZE = 9;
		$url_rewrite = $url->createUrl('admin/index').'/';
		$url_rewrite1=$url->createUrl('admin/index').'/';
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite1);
		
		$a=array($rows,$total,$paging);
			
		return $a;
    }

    public function insertData($data,$create_user){
        $connect = Yii::app()->db;
        $sql ="INSERT INTO `b_admin_user`(`email`,`username`,`password`,`full_name`,`active`,`create_date`,`create_user`)
        VALUES ('".$data["email"]."','".$data["username"]."','".$data["password"]."','".$data["full_name"]."',
        '".$data["active"]."','".time()."','".$create_user."')";

        $command = $connect->createCommand($sql);

        $result = $command->execute();

        $last_id = Yii::app()->db->getLastInsertId();
        return $last_id;
    }

    public function deleteAdmin($id){
        $sql = "DELETE FROM b_admin_user WHERE id = ".$id;
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);       
        $result = $command->execute();
        return $result;
    }
	public function deleteAdminPermit($user_id)
	{
		$sql = "DELETE FROM b_authassignment WHERE user_id = ".$user_id;
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);       
        $result = $command->execute();
        return $result;
	}
    public function updateLastLogin($id,$last_login){
        $sql = "UPDATE b_admin_user SET last_login_time = '".$last_login."' WHERE id=".$id;
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);       
        $result = $command->execute();
        return $result;
    }
    public function updatePass($id,$new_pass){
        $sql = "UPDATE b_admin_user SET password = '".$new_pass."' WHERE id=".$id;
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);       
        $result = $command->execute();
        return $result;
    }
    public function updateProfile($user_id,$full_name,$email,$infor,$type_admin){
        $sql = "UPDATE b_admin_user SET full_name = '".$full_name."', email ='".$email."',`info`='".$infor."',type_admin=".$type_admin." WHERE id=".$user_id;
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);       
        $result = $command->execute();
        return $result;
    }
    public function updateStatus($id,$old_status){
        if($old_status==1){
            $sql = "UPDATE b_admin_user SET `active` = 0 WHERE id=".$id;
        }else{
            $sql = "UPDATE b_admin_user SET `active` = 1 WHERE id=".$id; 
        }
        //echo $sql;die;
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);       
        $result = $command->execute();
        return $result;
    }
	
	public function ActiveAdminUser($option) {
    	$sql = "UPDATE b_admin_user SET 
		            active=:active
		       	WHERE id=:id            
        ";
        
        $command = Yii::app()->db->createCommand($sql);
    	$command->bindValues($option);
    	$result = $command->execute();
        
        return $result;
    }
    
    /**
    * Logs in the user using the given username and password in the model.
    * @return boolean whether login is successful
    */    
    public function login()
    {
        if($this->_identity===null)
        {
            $this->_identity=new UserIdentity($this->username,$this->password);
            $this->_identity->authenticate();
        }
        if($this->_identity->errorCode===UserIdentity::ERROR_NONE)
        {
            $duration=$this->rememberMe ? 3600*24*30 : 0; // 30 days
            Yii::app()->user->login($this->_identity,$duration);
            AdminUser::model()->updateByPk($this->_identity->id, array('last_login_time'=>new CDbExpression('NOW()')));
            return true;
        }
        else
            return false;
    }

    public function getStatusOptions() {
        return array(
        self::ACTIVE_STATUS_VALUE => self::ACTIVE_STATUS_TEXT,
        self::NOACTIVE_STATUS_VALUE => self::NOACTIVE_STATUS_TEXT,
        );
    }

    public function getStatusText() {
        $options = $this->getStatusOptions();
        return isset($options[$this->active]) ? $options[$this->active] : 'Unknown '.$this->active;
    } 
    
	public function getAllUser()
	{
        $sql = "SELECT * FROM b_admin_user WHERE id!=1";
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);       
       	$rows = $command->queryAll();
        return $rows;
    }
    
	public function getDataPermitByAdmin($adminId){
        $sql = "SELECT module_id,permit_id FROM b_authassignment WHERE user_id = ".intval($adminId);
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);
        $rows = $command->queryAll();
        for($i=0;$i<count($rows);$i++){
            $data[$rows[$i]["module_id"]] = $rows[$i]["permisId"];
        }
        return isset($data) ? $data:array();
    }
    
    public function getDataByAdminModulePermit($adminId,$module,$permisId)
	{
        $sql = "SELECT * FROM b_authassignment 
        WHERE 
        user_id = ".intval($adminId)." AND module_id = ".intval($module)." 
        AND permit_id & ".intval($permisId)." = ".intval($permisId)."";
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);
        $data = $command->queryRow();
        return $data; 
    }
}