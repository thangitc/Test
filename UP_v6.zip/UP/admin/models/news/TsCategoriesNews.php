<?php
class TsCategoriesNews extends CActiveRecord
{
	public function getCateById($category_id,$array_category)
	{
		if($array_category)
		{
			foreach($array_category as $row)
			{
				if($row['id']==$category_id)
					return $row;
			}
		}
		return '';
		
	}
	public function getCateInfor($id)
	{
		$cacheService = new CacheServiceNews("TsCategoriesNews","getCateInfor",$id);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			$connect =yii::app()->db_news;
			$sql="SELECT * FROM tbl_categories WHERE id=".$id;
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();	
			Yii::app()->cache->set($key, $row,0);
		}
		else
		{
			$row=$cache;
		}
		return $row;
	}
	public function loadCate($categories,$parent_id,$level)
	{
		$html='';
		$html_sub='';
		if($categories)
		{
			$html_sub='';
			foreach($categories as $row)
			{
				if($row['parent_id']==0)
					$level=1;
				else
					$level=2;
				$html_sub.='<li rel='.$row['id'].' onclick="loadSubCate('.$row['id'].','.$city_id.','.$level.'); $(this).removeClass().addClass(\'active\');"><a href="javascript:">'.$row['title'].'</a> </li>';	
				
			}
		}
		$html='<div class="box-bor pad10 clearfix">
					<ul class="list-dot scoll2">
						'.$html_sub.'
					</ul>
				</div>
				<p align="center">[<a onclick="showFormAdd('.$parent_id.');" href="javascript:" id="add_'.$level.'">Thêm</a>] &nbsp; [<a href="javascript:" onclick="showFormEdit($(this).attr(\'rel\'),'.$city_id.');" id="edit_'.$level.'">Sửa</a>] &nbsp; [<a href="javascript:" id="delete_'.$level.'" onclick="deleteCate($(this).attr(\'rel\'),'.$city_id.');">Xóa</a>] &nbsp;[<a href="javascript:" onclick="saveOrder('.$level.')">Save Order</a>]</p>';
		$html.='<script>
				$(function(){
					$("#level'.$level.'").children(\'div\').children(\'ul\').sortable({disable:true});
				});
				</script>';				
		return $html;
	}
	/*Lấy tất cả các danh mục*/
	public function getAllCategory()
	{
		//Cache
		$cacheService = new CacheServiceNews("TsCategoriesNews","getAllCategory");
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			$connect =yii::app()->db_news;
			$sql = "SELECT * FROM tbl_categories ORDER BY ordering ASC";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();			
			Yii::app()->cache->set($key, $rows,0);
		}
		else
		{
			$rows=$cache;
		}
		return $rows;
	}
	public function getSubCategory($parent_id,$array_category)
	{
		$cacheService = new CacheServiceNews("TsCategoriesNews","getSubCategory",$parent_id,$array_category);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			$array=array();
			foreach($array_category as $row)
			{
				if($row['parent_id']==$parent_id)
				{
					$array[]=$row;
				}
			}
			Yii::app()->cache->set($key, $array,0);
		}
		else
		{
			$array=$cache;
		}
		return $array;
	}
	public function updateOrder($id,$ordering)
	{
		$connect =yii::app()->db_news;
		$sql="UPDATE tbl_categories SET ordering='".$ordering."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a= $command->execute();
		return $a;
	}
	
	public function genPathway($array_category,$row)
	{
		$path_way='';
		if(isset($row))
		while($row['level']>1)
		{
			$path_way='<strong><a href="javascript:" rel='.$row['id'].' onclick="showFormEdit('.$row['id'].')"> &gt;&gt; '.$row['title'].' (Mã: '.$row['id'].')</a></strong>'.$path_way;
			foreach($array_category as $value)
			{
				if($value['id']==$row['parent_id'])
				{
					$row=$value;
					break;
				}
			}
		}
		if($row['level']==1)
		{
			$path_way='<strong><a href="javascript:" rel='.$row['id'].' onclick="showFormEdit('.$row['id'].')">'.$row['title'].' (Mã: '.$row['id'].')</a></strong>'.$path_way;
		}
		$path_way='<strong>Bạn đang chọn danh mục:</strong>'.$path_way;
		return $path_way;
	}
	
	public function getCateChildById($category_id,$array_category)
	{
		$rowChild = array();
		if($array_category)
		{
			foreach($array_category as $row)
			{
				if($row['parent_id']==$category_id)
					$rowChild[] = $row;
			}
		}
		return $rowChild;
	}
	public function genPathCate($cat_id,$array_category)
	{
		$path_way='';
		if($cat_id!=0)
		{
			$infor=TsCategoriesNews::getCateById($cat_id,$array_category);
			$path_way.=$infor['title'].' >';
		}
		$path_way='<div class="text11 fl">- Danh mục: '.$path_way.'</div>';
		return $path_way;
	}
	public function getCatByArticleId($article_id)
	{
		$cacheService = new CacheServiceNews("TsCategories","getCatByArticleId",$article_id);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			$connect = Yii::app()->db_news;
			$sql="SELECT * FROM tbl_categories WHERE id IN (SELECT cat_id FROM tbl_articles_categories WHERE article_id=".$article_id." AND type=1)";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			Yii::app()->cache->set($key,$rows,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows=$cache;
		}
		return $rows;
	}
	public function getLevelByArticleId($article_id)
	{
		$cacheService = new CacheServiceNews("TsCategoriesNews","getLevelByArticleId",$article_id);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			$connect = Yii::app()->db_news;
			$sql="SELECT cat_id FROM tbl_articles_categories WHERE article_id=".$article_id." AND type=2";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			Yii::app()->cache->set($key,$rows,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows=$cache;
		}
		return $rows;
	}
	public function getCatMenuHot()
	{
		$connect =yii::app()->db_news;
		//Cache
		$cacheService = new CacheServiceNews("TsCategoriesNews","getCatMenuHot");
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			$sql = "SELECT * FROM tbl_categories WHERE is_menu_hot=1 ORDER BY order_menu_hot ASC";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();			
			Yii::app()->cache->set($key, $rows,0);
		}
		else
		{
			$rows=$cache;
		}
		return $rows;
	}
	public function getCatMenu()
	{
		$connect =yii::app()->db_news;
		//Cache
		$cacheService = new CacheServiceNews("TsCategoriesNews","getCatMenu");
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			$sql = "SELECT * FROM tbl_categories WHERE is_menu=1 ORDER BY order_menu ASC";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();			
			Yii::app()->cache->set($key, $rows,0);
		}
		else
		{
			$rows=$cache;
		}
		return $rows;
	}
	public function updateOrderMenuHot($id,$order_menu_hot)
	{
		$connect =yii::app()->db_news;
		$sql="UPDATE tbl_categories SET order_menu_hot='".$order_menu_hot."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a= $command->execute();
		return $a;
	}
	public function updateOrderMenu($id,$order_menu)
	{
		$connect =yii::app()->db_news;
		$sql="UPDATE tbl_categories SET order_menu='".$order_menu."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a= $command->execute();
		return $a;
	}
	public function getCategories($page,$num_per_page,$url_rewrite)
	{
		$cacheService = new CacheServiceNews("TsCategoriesNews","getCategories",$page);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db_news;
			$sql = "SELECT count(*) as total FROM tbl_categories";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			$total=$row['total'];
			
			//Phân trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			
			$sql = "SELECT * FROM tbl_categories ORDER BY id DESC LIMIT ".($page-1)*$num_per_page.",".$num_per_page."";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			$a=array($rows,$paging,$total);
			Yii::app()->cache->set($key,$a,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
}
?>