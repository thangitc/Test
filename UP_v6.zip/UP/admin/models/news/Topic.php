<?php
class Topic extends CActiveRecord
{
	public function getTopic($cat_id,$keyword,$keyword_in,$tab,$from_date,$to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND id = "'.$keyword.'"';
		}
		if($from_date!=0) $cond.=' AND create_date >= '.$from_date;
		if($to_date!=0) $cond.=' AND create_date <= '.$to_date;
		if($cat_id!=0) $cond.=' AND cat_id = '.$cat_id;
		if($tab!=-1)
		{
			if($tab==1) $cond.=' AND status = "active"';
			if($tab==2) $cond.=' AND status = "pending"';//Pending
		}
		
		$sql = "SELECT count(*) as total FROM b_topic WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		        
		$sql = "SELECT * FROM b_topic WHERE ".$cond." ORDER BY create_date DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$list_cat_id=array();
        $list_id='0,';
		if($rows)
		foreach($rows as $row)
		{
			$list_cat_id[]=$row['cat_id'];
            $list_id=$row['id'].',';
		}
        $list_id=rtrim($list_id,',');
        //tin
		$news_total = array();
		if(!empty($list_id))
		{
			$sql = "SELECT count(news_id) as total,topic_id FROM b_topic_news WHERE topic_id IN (".$list_id.") GROUP BY topic_id ";
			$command=$connect->createCommand($sql);
			$array = $command->queryAll();
			foreach($array as $row)
			{
				$news_total[$row['topic_id']] = $row['total'];
			}
		}
		//Danh muc lien quan
		$cat_topic=array();
		if(!empty($list_cat_id))
		{
			$list_cat_id=implode(',',$list_cat_id);
			$array = Cat::getCatByListId($list_cat_id);
			foreach($array as $row)
			{
				$cat_topic[$row['id']] = $row;
			}
		}
		
		$a = array($rows,$paging,$total,$cat_topic,$news_total);
		return $a;
	}
	public function getTopicById($topic_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_topic WHERE id=".$topic_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	public function insertNewsTopic($sub_sql)
	{
		$connect=Yii::app()->db;
		$sql="INSERT IGNORE INTO b_topic_news(`news_id`, `topic_id`, `create_date`) VALUES ".$sub_sql."";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function getTopicByListId($list_id)
	{
		$connect = Yii::app()->db;
		$sql="SELECT * FROM b_topic WHERE id IN (".$list_id.")";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		$array=array();
		if($rows)
		foreach($rows as $row)
		{
			$array[$row['id']]=$row;
		}
		return $array;
	}
	public function updateOrderTopic($topic_id,$order)
	{
		$connect=Yii::app()->db;
		$sql="UPDATE b_topic SET ordering=".$order." WHERE id=".$topic_id;
		$command = $connect->createCommand($sql);
		$ok = $command->execute();
		return $ok;
	}
	
	public function getTopicByListNewsId($list_news_id)
	{
		$connect = Yii::app()->db;
		$sql="SELECT t1.id, t1.title, t1.alias,t2.news_id FROM b_topic t1, b_topic_news t2 WHERE t2.news_id IN (".$list_news_id.") AND t1.id=t2.topic_id";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		$array=array();
		if($rows)
		foreach($rows as $row)
		{
			$array[$row['news_id']][] = $row;
		}
		return $array;
	}
	public function getTopicByNewsId($news_id)
	{
		$connect = Yii::app()->db;
		$sql="SELECT t1.id, t1.title, t1.alias FROM b_topic t1 WHERE t1.id IN (SELECT topic_id FROM b_topic_news WHERE news_id=".$news_id.")";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		return $rows;
	}
	
	public function updateOrderTopicNews($id,$order)
	{
		$connect=Yii::app()->db;
		$sql="UPDATE b_topic_news SET ordering=".$order." WHERE article_id=".$id;
		$command = $connect->createCommand($sql);
		$ok = $command->execute();
		return $ok;
	}
	
	public function countTabTopic()
	{
		$connect=Yii::app()->db;
		//Tong so ban ghi
		$sql = "SELECT count(id) as total FROM b_topic";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=isset($row['total']) ? intval($row['total']):0;
		//Public
		$sql = "SELECT count(id) as total FROM b_topic WHERE status='active'";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total_publish=isset($row['total']) ? intval($row['total']):0;
		//Co de thi lien quan
		$sql = "SELECT count(id) as total FROM b_topic WHERE status='pending'";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total_pending=isset($row['total']) ? intval($row['total']):0;
		
		$a=array($total,$total_publish,$total_pending);
		return $a;
	}
	
	public function quickUpdateTopic($quick_type,$list_id)
	{
		$connect = Yii::app()->db;
		if($quick_type==1)//Kich hoat tin
		{
    		$sql1 = "UPDATE b_topic SET status='active' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==2)//Bo kich hoat
		{
			$sql1 = "UPDATE b_topic SET status='pending' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==3)//Xoa tin bai
		{
			$sql1 = "DELETE FROM b_topic WHERE id IN (".$list_id.")";
		}
		$command = $connect->createCommand($sql1);
        $result1 = $command->execute();
		if($result1>=0)
			$result=true;
		else
			$result=false;
        return $result;	
    }
	
	public function getTopicPopup($keyword,$cat_id,$page,$num_per_page)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			$cond.= ' AND title LIKE "%'.$keyword.'%"';
		}
		if($cat_id!=0) $cond.= ' AND cat_id = "'.$cat_id.'"';
		$sql = "SELECT count(*) as total FROM b_topic WHERE ".$cond."";
		$command = $connect->createCommand($sql);
		$row = $command->queryRow();
		$total = $row['total'];
		$sql = "SELECT * FROM b_topic WHERE ".$cond." ORDER BY create_date DESC LIMIT ".($page-1)*$num_per_page.",".$num_per_page."";
		$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		$a = array($rows,$total);
		return $a;
	}
	
	public function deleteTopicRelated($news_id)
	{
		$connect=Yii::app()->db;
		$sql="DELETE FROM b_topic_news WHERE news_id ='".$news_id."'";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
}  
?>