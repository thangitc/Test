<?php
class TsTagsNews extends CActiveRecord
{
	public function insertTags($keyword)
	{
		$connect = Yii::app()->db_news;
		$keyword=explode(',',$keyword);
		$sql_insert='';
		if($keyword)
		foreach($keyword as $value)
		{
			if($value!='')
			{
				$tag=Common::gen_title_kodau($value);
				$alias=Common::generate_slug($value);
				$sql_insert.="('".mysql_escape_string(trim($tag))."','".mysql_escape_string($alias)."'),";
			}
		}
		if($sql_insert!='')
		{
			$sql_insert=rtrim($sql_insert,',');
			$sql="INSERT IGNORE INTO tbl_tags_news(`tags`,`alias`) VALUES ".$sql_insert."";
			$command = $connect->createCommand($sql);
		    $result = $command->execute();
		}
		return true;
	}
	public function getTagsNews($keyword,$keyword_in,$page,$num_per_page,$url_rewrite)
	{
		$cacheService = new CacheService("TsTagsNews","getTagsNews",$keyword,$page);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db_news;
			$cond='1 ';
			if($keyword!='')
			{
				if($keyword_in==1) $cond.=' AND tags LIKE "%'.$keyword.'%"';
				if($keyword_in==2) $cond.=' AND tag_define LIKE "%'.$keyword.'%"';
			}
			
			$sql = "SELECT count(*) as total FROM tbl_tags_news WHERE ".$cond."";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			$total=$row['total'];
			//Ph�n trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			
			$sql = "SELECT * FROM tbl_tags_news WHERE ".$cond." ORDER BY create_date DESC LIMIT ".$begin.",".$num_per_page." ";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			$a=array($rows,$paging,$total);
			Yii::app()->cache->set($key,$a,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	public function getTagsById($tag_id)
	{
		$cacheService = new CacheService("TsTagsNews","getTagsById",$tag_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if($cache == false)
		{
	    	$sql = "SELECT * FROM tbl_tags_news WHERE id=".$tag_id;
	    	$command = Yii::app()->db_news->createCommand($sql);
		    $row = $command->queryRow();
		    Yii::app()->cache->set($key,$row,ConstantsUtil::TIME_CACHE_86400);
		}
		else
		{
			$row=$cache;
		}
	    return $row;
	}
}
?>
