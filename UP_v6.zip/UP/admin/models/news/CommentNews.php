<?php
class CommentNews extends CActiveRecord
{
	public function getComment($keyword,$keyword_in,$from_date,$to_date,$page,$num_per_page,$url_rewrite)
	{
		$cacheService = new CacheServiceNews("TsQaComment","getTsQaComment",$keyword,$page);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db;
			$cond='1 ';
			if($keyword!='')
			{
				if($keyword_in==1) $cond.=' AND t2.title LIKE "%'.$keyword.'%"';
				if($keyword_in==2) $cond.=' AND t1.username LIKE "%'.$keyword.'%"';
			}
			if($from_date!=0) $cond.=' AND t1.create_date >='.$from_date;
			if($to_date!=0) $cond.=' AND t1.create_date <='.$to_date;
			$sql = "SELECT count(*) as total FROM tbl_qa_comments t1 WHERE ".$cond."";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			$total=$row['total'];
			//Ph�n trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			
			$sql = "SELECT t1.*,t2.title,t2.alias FROM tbl_qa_comments t1,tbl_qa t2 WHERE ".$cond." AND t1.qa_id=t2.id ORDER BY t1.create_date DESC LIMIT ".$begin.",".$num_per_page." ";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			/*Dem so Reply cua tung comment*/
			$list_comment_id=array();
			if($rows)
			foreach($rows as $row)
			{
				$list_comment_id[]=$row['id'];
			}
			$list_comment_id=implode(',',$list_comment_id);
			if($list_comment_id!='')
			{
				$total_reply=TsQaComment::getTotalRepy($list_comment_id);
			}
			else
			{
				$total_reply=array();
			}
			$a=array($rows,$paging,$total,$total_reply);
			Yii::app()->cache->set($key,$a,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	public function getAllReply($keyword,$keyword_in,$from_date,$to_date,$page,$num_per_page,$url_rewrite)
	{
		$cacheService = new CacheServiceNews("TsQaComment","getAllReply",$keyword,$page);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db;
			$cond='1 ';
			if($keyword!='')
			{
				if($keyword_in==1) $cond.=' AND description LIKE "%'.$keyword.'%"';
				if($keyword_in==2) $cond.=' AND username LIKE "%'.$keyword.'%"';
			}
			if($from_date!=0) $cond.=' AND t1.create_date >='.$from_date;
			if($to_date!=0) $cond.=' AND t1.create_date <='.$to_date;
			$sql = "SELECT count(*) as total FROM tbl_qa_comments_reply t1 WHERE ".$cond."";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			$total=$row['total'];
			//Ph�n trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			
			$sql = "SELECT t1.* FROM tbl_qa_comments_reply t1 WHERE ".$cond." ORDER BY t1.create_date DESC LIMIT ".$begin.",".$num_per_page." ";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			$a=array($rows,$paging,$total);
			Yii::app()->cache->set($key,$a,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	public function getCommentById($comment_id)
	{
		$cacheService = new CacheServiceNews("TsQaComment","getCommentById",$comment_id);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db;
			$sql = "SELECT * FROM tbl_qa_comments WHERE id=".$comment_id;
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			Yii::app()->cache->set($key,$row,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row=$cache;
		}
		return $row;
	}
	public function getReplyById($reply_id)
	{
		$cacheService = new CacheServiceNews("TsQaComment","getReplyById",$reply_id);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db;
			$sql = "SELECT * FROM tbl_qa_comments_reply WHERE id=".$reply_id;
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			Yii::app()->cache->set($key,$row,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row=$cache;
		}
		return $row;
	}
	public function getReply($comment_id)
	{
		$cacheService = new CacheServiceNews("TsQaComment","getReply",$comment_id);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db;
			$sql = "SELECT * FROM tbl_qa_comments_reply WHERE comment_id = ".$comment_id."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key,$rows,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows=$cache;
		}
		return $rows;
	}
	public function getTotalRepy($list_comment_id)
	{
		$cacheService = new CacheServiceNews("TsQaComment","getRepyByComment",$list_comment_id);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db;
			$sql = "SELECT count(id) as total,comment_id FROM tbl_qa_comments_reply WHERE comment_id IN (".$list_comment_id.") GROUP BY comment_id";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			$output=array();
			foreach($rows as $row)
			{
				$output[$row['comment_id']]=$row['total'];
			}
			Yii::app()->cache->set($key,$output,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$output=$cache;
		}
		return $output;
	}
	public function deleteComment($comment_id)
	{
		$connect=Yii::app()->db;
		$sql = "DELETE FROM tbl_qa_comments_reply WHERE comment_id=".$comment_id;
		$command=$connect->createCommand($sql);
		$result= $command->execute();
		$sql = "DELETE FROM tbl_qa_comments WHERE id=".$comment_id;
		$command=$connect->createCommand($sql);
		$result= $command->execute();
	}
	public function deleteCommentByNews($news_id)
	{
		$connect=Yii::app()->db;
		$sql = "DELETE FROM b_comment WHERE news_id=".$news_id;
		$command=$connect->createCommand($sql);
		$result= $command->execute();
		return $result;
	}
}
?>