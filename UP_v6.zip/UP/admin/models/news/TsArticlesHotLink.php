<?php
class TsArticlesHotLink extends CActiveRecord
{
	public function getHotLink($keyword,$keyword_in,$cat_id,$from_date,$to_date,$page,$num_per_page,$url_rewrite)
	{
		$cacheService = new CacheServiceNews("TsArticlesHotLink","getHotLink",$keyword.$keyword_in.$cat_id.$from_date.$to_date.$page);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db_news;
			$cond='1 ';
			if($keyword!='')
			{
				if($keyword_in==1)
				{
					$cond.= ' AND t1.title like "%'.$keyword.'%"';
				}
				if($keyword_in==2)
				{
					$cond.= ' AND t1.id = "'.$keyword.'"';
				}
			}
			$cond.= $cat_id!=0 ? ' AND t1.cat_id = "'.$cat_id.'"' : '';
			$cond.= $from_date!=0 ? ' AND t1.create_date >= "'.$from_date.'"' : '';
			$cond.= $to_date!=0 ? ' AND t1.create_date <= "'.$to_date.'"' : '';
			
			$sql = "SELECT count(*) as total FROM tbl_hot WHERE ".$cond."";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			$total=$row['total'];
			//Ph�n trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			
			$sql = "SELECT t1.*,t2.title as cat_title FROM tbl_hot t1 LEFT JOIN tbl_categories t2 ON t1.cat_id=t2.id WHERE ".$cond."  ORDER BY ordering ASC LIMIT ".$begin.",".$num_per_page."";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			$a=array($rows,$paging,$total);
			Yii::app()->cache->set($key,$a,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	public function getHotLinkById($id)
	{
		$cacheService = new CacheServiceNews("TsArticlesHotLink","getHotLinkById",$id);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db_news;
			$sql = "SELECT * FROM tbl_hot WHERE id=".$id;
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			Yii::app()->cache->set($key,$row,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row=$cache;
		}
		return $row;
	}
	public function updateOrder($id,$ordering)
	{
		$connect =Yii::app()->db_news;
		$sql="UPDATE tbl_hot SET ordering='".$ordering."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a= $command->execute();
		return $a;
	}
}
?>