<?php
class TsArticlesAutoLink extends CActiveRecord
{    
    public function tableName()
    {
        return 'tbl_autolink';
    }
	
	public function getAutoLink($page,$num_per_page,$url_rewrite)
	{
		$connect =yii::app()->db_news;
		$url = Yii::app ()->urlManager;
		//Cache
		$cacheService = new CacheServiceNews("TsArticlesAutoLink","getAutoLink",$page.$num_per_page);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache = false;
        if ($cache == false) 
		{
			//End kiem tra dieu kien	
			
			$sql="SELECT count(id) as total FROM tbl_autolink t1";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			$total=$row['total'];
			//Phân trang
			$num_per_page = $num_per_page;
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$sql = "SELECT * FROM tbl_autolink t1 ORDER BY created_date DESC LIMIT ".$begin.",".$num_per_page."";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			$iSEGSIZE = 9;
			$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			$a=array($rows,$total,$paging);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_300);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	public function getAutoLinkDetail($id)
	{
		$connect =Yii::app()->db_news;
		$sql="SELECT * FROM  tbl_autolink WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$row=$command->queryRow();
		return $row;
	}
	public function insertAutoLink($title,$url,$created_date)
	{
		$connect =Yii::app()->db_news;
		$sql="INSERT INTO tbl_autolink SET title='".$title."',url='".$url."',created_date='".$created_date."'";
		$command=$connect->createCommand($sql);
		$command->execute();
		$record_id=Yii::app()->db_news->getLastInsertID();  
		return $record_id;
	}
	public function updateAutoLink($id,$title,$url)
	{
		$connect =Yii::app()->db_news;
		$sql="UPDATE tbl_autolink SET title='".$title."',url='".$url."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a=$command->execute();
		return $a;
	}
	public function deleteAutoLink($id)
	{
		$connect =Yii::app()->db_news;
		$sql="DELETE FROM tbl_autolink WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a=$command->execute();
		return $a;
	}
	public function deleteMultiAutoLink($list_id)
	{
		if($list_id!='')
		{
			$connect =Yii::app()->db_news;
			$sql="DELETE FROM tbl_autolink WHERE id IN (".$list_id.")";
			$command=$connect->createCommand($sql);
			$a=$command->execute();
			return $a;
		}
		else return -1;
	}
}
?>