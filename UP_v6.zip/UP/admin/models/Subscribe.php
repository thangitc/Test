<?php
class Subscribe extends CActiveRecord
{
	public function getSubscribe($keyword,$keyword_in, $from_date, $to_date, $tab,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==2) $cond.=' AND t2.email LIKE "%'.$keyword.'%"';
			if($keyword_in==1) $cond.=' AND t1.id = "'.$keyword.'"';
		}
		
		if($from_date!=0) $cond.=' AND create_date >= '.$from_date;
		if($to_date!=0) $cond.=' AND create_date <= '.$to_date;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		if($tab==1)//Hom nay
		{
			$cond.=' AND t1.create_date>='.$today.' AND t1.create_date<'.($today+86400);		
		}
		if($tab==2)//Hom qua
		{
			$cond.=' AND t1.create_date>='.($today-86400).' AND t1.create_date<'.$today;
		}
		if($tab==3)//Thang nay
		{
			$from = mktime(0,0,0,date('m'),1,date('Y'));
			$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
			$cond.=' AND t1.create_date>='.$from.' AND t1.create_date<='.$to;
		}
		if($tab==4)//Thang truoc
		{
			$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
			$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
			$cond.=' AND t1.create_date>='.$from.' AND t1.create_date<='.$to;
		}
		
		$sql = "SELECT count(*) as total FROM b_subscribe t1 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.* FROM b_subscribe t1 WHERE ".$cond." ORDER BY t1.id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$a = array($rows,$paging,$total);
		return $a;
	}
	
	public function getTotalSubscribe()
	{
		$connect=Yii::app()->db;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		//Hom nay
		$sql = 'SELECT count(id) as total FROM b_subscribe WHERE  create_date>='.$today.' AND create_date<'.($today+86400);
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_1 = isset($row['total']) ? intval($row['total']):0;
		
		//Hom qua
		$sql = 'SELECT count(id) as total FROM b_subscribe WHERE  create_date>='.($today-86400).' AND create_date<'.$today;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_2 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang nay
		$from = mktime(0,0,0,date('m'),1,date('Y'));
		$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
		$sql = 'SELECT count(id) as total FROM b_subscribe WHERE  create_date>='.$from.' AND create_date<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_3 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang truoc
		$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
		$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
		$sql = 'SELECT count(id) as total FROM b_subscribe WHERE  create_date>='.$from.' AND create_date<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_4 = isset($row['total']) ? intval($row['total']):0;
		//Total
		$sql = 'SELECT count(id) as total FROM b_subscribe';
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_0 = isset($row['total']) ? intval($row['total']):0;
		
		return array($total_0, $total_1, $total_2, $total_3, $total_4);
	}
}
?>