<?php
class Customer extends CActiveRecord
{
	public function getCustomer($keyword,$keyword_in,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND mobile = "'.$keyword.'"';
			if($keyword_in==3) $cond.=' AND city_title = "'.$keyword.'"';
		}
		
		$sql = "SELECT count(*) as total FROM b_customer WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT * FROM b_customer WHERE ".$cond." ORDER BY id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$a = array($rows,$paging,$total);
		return $a;
	}
	
	
	public function getCustomerByProduct($camera_id,$keyword,$keyword_in,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 AND t1.id=t2.customer_id AND t2.camera_id='.$camera_id.'';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND t1.title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND t1.mobile = "'.$keyword.'"';
			if($keyword_in==3) $cond.=' AND t1.city_title = "'.$keyword.'"';
		}
		
		$sql = "SELECT count(*) as total FROM b_customer t1, b_customer_camera t2 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT * FROM b_customer t1, b_customer_camera t2 WHERE ".$cond." ORDER BY t1.id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$a = array($rows,$paging,$total);
		return $a;
	}
	
	public function getCustomerByAccess($access_id,$keyword,$keyword_in,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 AND t1.id=t2.customer_id AND t2.access_id='.$access_id.'';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND t1.title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND t1.mobile = "'.$keyword.'"';
			if($keyword_in==3) $cond.=' AND t1.city_title = "'.$keyword.'"';
		}
		
		$sql = "SELECT count(*) as total FROM b_customer t1, b_customer_access t2 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT * FROM b_customer t1, b_customer_access t2 WHERE ".$cond." ORDER BY t1.id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$a = array($rows,$paging,$total);
		return $a;
	}
	
	public function getCustomerById($customer_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_customer WHERE id=".$customer_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function getAllCustomer()
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_customer ORDER BY id DESC";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function getListCustomer($camera_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT t1.*, t2.* FROM b_customer t1, b_customer_camera t2 WHERE t1.id=t2.customer_id AND t2.camera_id=".$camera_id;
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function getListCustomerAccess($access_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT t1.*, t2.* FROM b_customer t1, b_customer_access t2 WHERE t1.id=t2.customer_id AND t2.access_id=".$access_id;
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function getCustomerByMobile($mobile)
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_customer WHERE (mobile LIKE '%".$mobile."%' || title LIKE '%".$mobile."%')";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
}
?>