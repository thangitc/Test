<?php
class BModelContent extends CActiveRecord
{
	public function getContentById($camera_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_model_content WHERE camera_id=".$camera_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
}
?>