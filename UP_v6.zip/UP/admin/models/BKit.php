<?php
class BKit extends CActiveRecord
{
	public function getKit($model_id,$keyword,$keyword_in,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND id = "'.$keyword.'"';
		}
		if($model_id!=0) $cond.=' AND model_id = "'.$model_id.'"';
		$sql = "SELECT count(*) as total FROM b_combo_kit WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
        $exam_total=array();
		$sql = "SELECT * FROM b_combo_kit WHERE ".$cond." ORDER BY id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		//Danh sach models
		$list_model_id = '0';
		if($rows)
		foreach($rows as $row)
		{
			$list_model_id.=','.$row['model_id'];
		}
		$sql = "SELECT * FROM b_model WHERE  id IN (".$list_model_id.")";
		$command=$connect->createCommand($sql);
		$array= $command->queryAll();
		$models = array();
		if($array)
		foreach($array as $row)
		{
			$models[$row['id']] = $row;
		}
		
		$a = array($rows,$paging,$total, $models);
		return $a;
	}
	
	public function getKitById($kit_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_combo_kit WHERE id=".$kit_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function getAllKit()
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_combo_kit";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function getKitByModel($model_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_combo_kit WHERE model_id=".$model_id;
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
}
?>