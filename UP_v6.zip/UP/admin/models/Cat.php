<?php
class Cat extends CActiveRecord
{   
	/* HungNT */
	public function getCateById($category_id,$array_category)
	{
		if($array_category)
		{
			foreach($array_category as $row)
			{
				if($row['id']==$category_id)
					return $row;
			}
		}
		return '';

	}
	public function getCateInfor($id)
	{
		$connect =Yii::app()->db;
		$sql="SELECT * FROM b_cat WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();    

		return $row;
	}
	public function loadCate($categories,$parent_id,$level)
	{
		$html='';
		$html_sub='';
		if($categories)
		{
			$html_sub='';
			foreach($categories as $row)
			{
				if($row['parent_id']==0)
					$level=1;
				else
					$level=2;
				$html_sub.='<li rel='.$row['id'].' onclick="loadSubCate('.$row['id'].','.$city_id.','.$level.'); $(this).removeClass().addClass(\'active\');"><a href="javascript:">'.$row['title'].'</a> </li>';    

			}
		}
		$html='<div class="box-bor pad10 clearfix">
		<ul class="list-dot scoll2">
		'.$html_sub.'
		</ul>
		</div>
		<p align="center">[<a onclick="showFormAdd('.$parent_id.');" href="javascript:" id="add_'.$level.'">Thêm</a>] &nbsp; [<a href="javascript:" onclick="showFormEdit($(this).attr(\'rel\'),'.$city_id.');" id="edit_'.$level.'">Sửa</a>] &nbsp; [<a href="javascript:" id="delete_'.$level.'" onclick="deleteCate($(this).attr(\'rel\'),'.$city_id.');">Xóa</a>] &nbsp;[<a href="javascript:" onclick="saveOrder('.$level.')">Save Order</a>]</p>';
		$html.='<script>
		$(function(){
		$("#level'.$level.'").children(\'div\').children(\'ul\').sortable({disable:true});
		});
		</script>';                
		return $html;
	}
	public function getCats()
	{
		//Cache
		$cacheService = new CacheService("Cat","getCats");
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		$a=array();
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT * FROM b_cat ORDER BY ordering ASC";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			if($rows)
			foreach($rows as $row)
			{
				$a[$row['id']]=$row;
			}
			Yii::app()->cache->set($key, $a, 0);
		}
		else
		{
			$a=$cache;
		}           
		return $a;
	}
	public function getSubCategory($parent_id,$array_category)
	{

		$array=array();
		foreach($array_category as $row)
		{
			if($row['parent_id']==$parent_id)
			{
				$array[]=$row;
			}
		}

		return $array;
	}
	public function updateOrder($id,$ordering)
	{
		$connect = Yii::app()->db;
		$sql="UPDATE b_cat SET ordering='".$ordering."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a= $command->execute();
		return $a;
	}

	public function genPathway($array_category,$row)
	{
		$path_way='';
		if(is_array($row)){
			while($row['level']>1)
			{
				$path_way='<strong><a href="javascript:" rel='.$row['id'].' onclick="showFormEdit('.$row['id'].')"> &gt;&gt; '.$row['title'].' (Mã: '.$row['id'].')</a></strong>'.$path_way;
				foreach($array_category as $value)
				{
					if($value['id']==$row['parent_id'])
					{
						$row=$value;
						break;
					}
				}
			}
			if($row['level']==1)
			{
				$path_way='<strong><a href="javascript:" rel='.$row['id'].' onclick="showFormEdit('.$row['id'].')">'.$row['title'].' (Mã: '.$row['id'].')</a></strong>'.$path_way;
			}
			$path_way='<strong>Bạn đang chọn danh mục:</strong>'.$path_way;
		}
		return $path_way;          
	}

	public function getCateChildById($category_id,$array_category)
	{
		$rowChild = array();
		if($array_category)
		{
			foreach($array_category as $row)
			{
				if($row['parent_id']==$category_id)
					$rowChild[] = $row;
			}
		}
		return $rowChild;
	}
	public function getCatMenu()
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_cat WHERE is_menu=1 ORDER BY order_menu ASC";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();            
		return $rows;
	}
	
	public function getCatHome()
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_cat WHERE is_hot=1 ORDER BY order_hot ASC";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();            
		return $rows;
	}
	public function getCatHomeBottom()
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_cat WHERE is_home_bottom=1 ORDER BY order_home_bottom ASC";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();            
		return $rows;
	}
	public function updateOrderMenu($id,$order_menu)
	{
		$connect =Yii::app()->db;
		$sql="UPDATE b_cat SET order_menu='".$order_menu."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a= $command->execute();
		return $a;
	}
	
	public function updateOrderCatHome($id,$order_hot)
	{
		$connect =Yii::app()->db;
		$sql="UPDATE b_cat SET order_hot='".$order_hot."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a= $command->execute();
		return $a;
	}
	
	public function updateOrderCatHomeBottom($id,$order_hot)
	{
		$connect =Yii::app()->db;
		$sql="UPDATE b_cat SET order_home_bottom='".$order_hot."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a= $command->execute();
		return $a;
	}
	/*ThangLQ*/
	public function getCatByListId($list_id)
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_cat WHERE id IN (".$list_id.")";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		return $rows;
	}
	public function updateSubCat()
	{
		$connect =Yii::app()->db;
		$cats=Cat::getCats();
		//Level 1
		foreach($cats as $row)
		{
			if($row['parent_id']==0)
			{
				$list_sub=$row['id'].',';
				foreach($cats as $row2)
				{
					if($row2['parent_id']==$row['id'])
					{
						$list_sub.=$row2['id'].',';
						foreach($cats as $row3)
						{
							if($row3['parent_id']==$row2['id'])
							{
								$list_sub.=$row3['id'].',';
							}
						}
					}
				}
				$list_sub=rtrim($list_sub,',');
				$sql="UPDATE b_cat SET sub_id='".$list_sub."' WHERE id=".$row['id'];
				$command=$connect->createCommand($sql);
				$result = $command->execute();
			}
		}
		//Level 2
		foreach($cats as $row)
		{
			if($row['parent_id']==0)
			{
				foreach($cats as $row2)
				{
					if($row2['parent_id']==$row['id'])
					{
						$list_sub=$row2['id'].',';
						foreach($cats as $row3)
						{
							if($row3['parent_id']==$row2['id'])
							{
								$list_sub.=$row3['id'].',';
							}
						}
						$list_sub=rtrim($list_sub,',');
						$sql="UPDATE b_cat SET sub_id='".$list_sub."' WHERE id=".$row2['id'];
						$command=$connect->createCommand($sql);
						$result = $command->execute();
					}						
				}
			}
		}
		//Level 3
		$sql="UPDATE b_cat SET sub_id=id WHERE level=3";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
	}
	/*END*/
	
	public function updateNumProduct()
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_cat";
		$command=$connect->createCommand($sql);
		$cats = $command->queryAll();
		//Cap nhat san pham		
		foreach($cats as $row)
		{
			if($row['cat_type']==1)
			{
				$sub_id = $row['sub_id'];
				if($sub_id!='')
				{
					$sql = "UPDATE b_cat SET num_p=(SELECT count(id) FROM b_camera WHERE cat_id IN (".$sub_id.") AND status='active' AND is_show=1 AND status_new IN (0,1)) WHERE id=".$row['id'];
					$command=$connect->createCommand($sql);
					$result = $command->execute();
				}
			}
		}
		//Cap nhat phu kien
		foreach($cats as $row)
		{
			if($row['cat_type']==3)
			{
				$sub_id = $row['sub_id'];
				if($sub_id!='')
				{
					$sql = "UPDATE b_cat SET num_p=(SELECT count(id) FROM b_accessories WHERE cat_id IN (".$sub_id.") AND status='active') WHERE id=".$row['id'];
					//echo $sql;
					$command=$connect->createCommand($sql);
					$result = $command->execute();
				}
			}
		}
		
	}
}
?>