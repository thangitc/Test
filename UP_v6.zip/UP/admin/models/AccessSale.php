<?php
class AccessSale extends CActiveRecord
{
	public function getAccessSale($access_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_accessories_sale WHERE access_id=".$access_id;
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function updateAccessSale($price_buy, $price_in, $access_id, $color_id)
	{
		$connect=Yii::app()->db;
		$sql="UPDATE b_accessories_sale SET price_buy=".$price_buy.", price_in=".$price_in." WHERE access_id=".$access_id." AND color_id=".$color_id;
		$command = $connect->createCommand($sql);
		$ok = $command->execute();
		return $ok;
	}
	public function getAccessSaleById($sale_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_accessories_sale WHERE id=".$sale_id;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}
?>