<?php
class AjaxController extends Controller
{
	public $layout = false;
	public $output = array();
	
	public function actionEditCat()
	{
		$error='';
		$id=isset($_POST['cid'])?$_POST['cid']:0;
        $title=isset($_POST['title'])?$_POST['title']:'';
        $alias=isset($_POST['alias'])?$_POST['alias']:'';		
        if($alias=='') $alias=Common::generate_slug($title);
		$parent_id=isset($_POST['parent_id'])?$_POST['parent_id']:0;
		$ordering=isset($_POST['ordering'])?$_POST['ordering']:0;
		$status=isset($_POST['status'])?$_POST['status']:1;
		$description=isset($_POST['description'])?$_POST['description']:'';
		$is_hot=isset($_POST['is_hot']) ? intval($_POST['is_hot']):0;
		$is_home_bottom=isset($_POST['is_home_bottom']) ? intval($_POST['is_home_bottom']):0;
		$is_menu=isset($_POST['is_menu'])? intval($_POST['is_menu']):0;		
		$is_link=isset($_POST['is_link'])? intval($_POST['is_link']):0;
		$links=isset($_POST['links'])? $_POST['links']:'';
		$cat_type=isset($_POST['cat_type']) ? intval($_POST['cat_type']) : 0;
		$is_layout = isset($_POST['is_layout']) ? intval($_POST['is_layout']) : 0;
		$icon = isset($_POST['icon']) ? $_POST['icon'] : '';
		$picture = isset($_POST['picture']) ? $_POST['picture'] : '';
		$price = isset($_POST['price']) ? $_POST['price'] : '';
		/*
		$focus = isset($_POST['c_focus']) ? intval($_POST['c_focus']) : 0;
		$description = isset($_POST['description']) ? $_POST['description'] : '';
		$camera_type = isset($_POST['camera_type']) ? intval($_POST['camera_type']) : 0;
		$info_kt = isset($_POST['info']) ? $_POST['info'] : '';
		$info_other = isset($_POST['info_other']) ? $_POST['info_other'] : '';
		$file = isset($_POST['file']) ? $_POST['file'] : '';
		*/
		$sub_id = '';
		if($parent_id==0)
		{
			$level=1;
		}
		else
		{
			$array_category = $this->cats;
			$info = isset($array_category[$parent_id]) ? $array_category[$parent_id] : array();
			if(isset($info))
				$level=intval($info['level'])+1;
			else
				$level=1;
		}

		$array_input=array('title'=>$title,'alias'=>$alias,'parent_id'=>$parent_id,'status'=>$status,'ordering'=>$ordering,'level'=>$level,'description'=>$description,'is_hot'=>$is_hot, 'is_home_bottom'=>$is_home_bottom,'is_link'=>$is_link,'links'=>mysql_escape_string(trim($links)),'is_menu'=>$is_menu,'cat_type'=>$cat_type, 'is_layout'=>$is_layout, 'icon'=>mysql_escape_string($icon), 'picture'=>mysql_escape_string($picture), 'price'=>mysql_escape_string($price));
		if(isset($id) && $id!=0)
		{
			$ok = CommonModel::updateObject($array_input,'id',$id,'b_cat');
			if($ok>=0)
			{
				$error='Cập nhật dữ liệu thành công!';
				//Cap nhat sub_id cho cha
				/*
				if(!empty($info))
				{
					if($info['level']==1 && $info['sub_id']=='')
					{
						$sub_id_2 = $info['sub_id'].','.$id;
						CommonModel::updateObject(array('sub_id'=>$sub_id_2),'id',$info['id'],'b_cat');
					}
					if($info['level']==2 && $info['sub_id']=='')
					{
						//Cap nhat cho thang cha thu nhat
						$sub_id_2 = $info['sub_id'].','.$id;
						CommonModel::updateObject(array('sub_id'=>$sub_id_2),'id',$info['id'],'b_cat');
						//Cap nhat cho thang cha thu 2 (cha goc)
						$row_parent_3 = isset($array_category[$info['parent_id']]) ? $array_category[$info['parent_id']] : array();
						$sub_id_3 = !empty($row_parent_3) ? $row_parent_3['sub_id'].','.$id : $id;
						CommonModel::updateObject(array('sub_id'=>$sub_id_3),'id',$row_parent_3['id'],'b_cat');
					}
				}
				else
				{
					$sub_id = $id;
					CommonModel::updateObject(array('sub_id'=>$sub_id),'id',$id,'b_cat');
				}
				*/
				/*Log*/
				$user_id=Yii::app()->user->id;
				$user_name=Yii::app()->user->name;
				$object_log['input']=array('id'=>$id);    
				$module_log = 3;
				$name_action='Sửa';
				$object_log['output']=$array_input;
				header('Content-Type: text/html; charset=utf-8');
				$object_log=json_encode($object_log);
				$object_log=trim(mysql_escape_string($object_log));
				$content_log='<strong>'.$user_name.'</strong> Sửa danh mục. Mã danh mục: <strong>'.$id.'</strong>';
				$content_log=trim(mysql_escape_string($content_log));
				Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
				/*End log*/
			}
			else $error='Cập nhật dữ liệu lỗi!';
		}
		else
		{
			$ok = CommonModel::insertObject($array_input,'b_cat');
			if($ok>=0) 
			{
				$id = $ok;
				$error='Cập nhật dữ liệu thành công!';
				//Cap nhat sub_id cho cha
				/*
				if(!empty($info))
				{
					if($info['level']==1)
					{
						$sub_id_2 = $info['sub_id'].','.$id;
						CommonModel::updateObject(array('sub_id'=>$sub_id_2),'id',$info['id'],'b_cat');
					}
					if($info['level']==2)
					{
						//Cap nhat cho thang cha thu nhat
						$sub_id_2 = $info['sub_id'].','.$id;
						CommonModel::updateObject(array('sub_id'=>$sub_id_2),'id',$info['id'],'b_cat');
						//Cap nhat cho thang cha thu 2 (cha goc)
						$row_parent_3 = isset($array_category[$info['parent_id']]) ? $array_category[$info['parent_id']] : array();
						$sub_id_3 = !empty($row_parent_3) ? $row_parent_3['sub_id'].','.$id : $id;
						CommonModel::updateObject(array('sub_id'=>$sub_id_3),'id',$row_parent_3['id'],'b_cat');
					}
				}
				else
				{
					$sub_id = $ok;
					CommonModel::updateObject(array('sub_id'=>$sub_id),'id',$id,'b_cat');
				}
				*/
				/*Log*/
				$user_id=Yii::app()->user->id;
				$user_name=Yii::app()->user->name;
				$object_log['input']=$array_input;    
				$module_log = 3;
				$name_action='Thêm';
				$object_log['output']='Success!';
				header('Content-Type: text/html; charset=utf-8');
				$object_log=json_encode($object_log);
				$object_log=trim(mysql_escape_string($object_log));
				$content_log='<strong>'.$user_name.'</strong> Thêm danh mục . Mã danh mục: <strong>'.$ok.'</strong>';
				$content_log=trim(mysql_escape_string($content_log));
				Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
				/*End log*/
			}
			else $error='Cập nhật dữ liệu lỗi!';
		}

		$output=array('error'=>$error,'level'=>$level);
		$output=json_encode($output);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}
	public function actionLoadSubCate()
	{
		$cid = isset($_POST["cid"])?$_POST["cid"]:0;
		$level = isset($_POST["level"])?$_POST["level"]:1;
		$html='';
		$path_way='';
		if(isset($cid))
		{
			$array_category = $this->cats;
			$info=Cat::getCateById($cid,$array_category);
			$path_way='';//Cat::genPathway($array_category,$info);
			//$path_way='';
			if($array_category)
				foreach($array_category as $row)
				{
					if($row['parent_id']==$cid)
					{
						$html.='<li rel='.$row['id'].' onclick="loadSubCate('.$row['id'].','.$row['level'].');"><a href="javascript:">'.$row['title'].'(mã: '.$row['id'].')</a> </li>';
						$level=$row['level'];
					}
			}
			if($html!='')
			{
				$html='<div class="itemt" id="itemt'.$level.'">
				<div class="box-bor pad10 clearfix">
				<ul class="list-dot scoll2" id="list_cate'.$level.'">
				'.$html.'
				</ul>
				</div>
				<p align="center"><a id="add_'.$level.'" rel='.$cid.' href="javascript:" onclick="showFormAdd($(this).attr(\'rel\'))">[Thêm]</a> <a id="edit_'.$level.'" href="javascript:" onclick="showFormEdit($(this).attr(\'rel\'))">[Sửa]</a><a href="javascript:" onclick="saveOrder('.$level.')">[Save Order]</a>&nbsp;<a id="delete_'.$level.'" href="javascript:" onclick="deleteCate($(this).attr(\'rel\'))">[Delete]</a></p>
				</div>
				';
				$html.='<script>
				$(function(){
				$("#list_cate'.$level.'").sortable({disable:true});
				});
				</script>';
			}
		}

		$output=array('html'=>$html,'path_way'=>$path_way,'cid'=>$cid);
		$output=json_encode($output);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}
    //+SaveOrderCate
    public function actionSaveOrderCate()
    {
        $list_cate_order=$_POST['list_cate_order'];
        $list_cate_order=rtrim($list_cate_order,',');
        $list_cate_order=explode(',',$list_cate_order);
        $sub_sql='';
        $ok=true;
        if($list_cate_order)
        {
            foreach($list_cate_order as $row)
            {
                $value=explode('|',$row);
                $cat_order=$value[1];
                $cat_id=$value[0];
                $result=Cat::updateOrder($cat_id,$cat_order);
                if($result>=0)
                    $ok=$ok and true;
                else
                    $ok=$ok and false;
            }
        }
        if($ok) {
            /*Log*/
            $user_id=Yii::app()->user->id;
            $user_name=Yii::app()->user->name;
            $object_log['input']=array('list_cate_order'=>$list_cate_order);    
            $module_log=51;
            $name_action='Sửa';
            $object_log['output']='Success!';
            header('Content-Type: text/html; charset=utf-8');
            $object_log=json_encode($object_log);
            $object_log=trim(mysql_escape_string($object_log));
            $content_log='<strong>'.$user_name.'</strong> Sửa đổi thứ tự danh mục .';
            $content_log=trim(mysql_escape_string($content_log));
            Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
            /*End log*/
            echo 1;
        }
        else
            echo 0;
        
    }
	public function actionLoadSubCateForm()
	{
		$cid = isset($_POST['cid'])?intval($_POST['cid']):0;
		$html='';
		$html_subject='';
		$html_faculty='';
		if(isset($cid))
		{
			$array_category=$this->array_category_news;
			foreach($array_category as $row)
			{                        
				if($row['parent_id']==$cid)
				{                    
					$html.='<option value='.$row['id'].'>'.$row['title'].'</option>';
				}
			}
		}
		$output=array('html'=>$html,'cid'=>$cid);
		$output=json_encode($output);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}
	public function actionShowFormEditCate()
	{
		$cid=$_POST['cid'];
		$info=Cat::getCateInfor($cid);
		$output=json_encode($info);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}
	
	/*
	public function actionDeleteCate()
	{
		if(isset($_POST['cid']))
		{
			$cid=$_POST['cid'];
			$info=Cat::getCateInfor($cid);
			$array_input=array('id'=>$cid);
			$ok1=CommonModel::deleteObject($array_input,'b_cat');

			if($ok1>=0) {
				//
				$user_id=Yii::app()->user->id;
				$user_name=Yii::app()->user->name;
				$object_log['input']=array('id'=>$cid);    
				$module_log=3;
				$name_action='Sửa';
				$object_log['output']='Success!';
				header('Content-Type: text/html; charset=utf-8');
				$object_log=json_encode($object_log);
				$object_log=trim(mysql_escape_string($object_log));
				$content_log='<strong>'.$user_name.'</strong> Xóa danh mục . Mã danh mục <strong>'.$cid.'</strong>';
				$content_log=trim(mysql_escape_string($content_log));
				Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
				
				$error='Xóa dữ liệu thành công!';
			}
			else
				$error='Xóa dữ liệu lỗi!';
			$array=array('status'=>1,'error'=>$error,'parent_id'=>$info['parent_id'],'level'=>$info['level']);    
		}
		else
		{
			$error='Bạn chưa chọn danh mục để xóa!';
			$array=array('status'=>0,'error'=>$error);
		}

		$output=json_encode($array);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}
	*/
	public function actionSeoCat()
	{
		$error='';
		$status='false';
		if (!isset($_POST['cid']) || ($_POST['cid']==0)) $error.="*Vui lòng chọn danh mục! <br/>";
		if(!$error)
		{
			$array_input['meta_keyword']=mysql_escape_string(trim($_POST['meta_keyword']));
			$array_input['meta_title']=mysql_escape_string(trim($_POST['meta_title']));
            $array_input['meta_description']=mysql_escape_string(trim($_POST['meta_description']));
            $array_input['bottom_des']=mysql_escape_string(trim($_POST['bottom_des']));
			$array_input['top_des']=mysql_escape_string(trim($_POST['top_des']));
			$ok=CommonModel::updateObject($array_input,'id',$_POST['cid'],'b_cat');
			if($ok>=0)
			{
				/*Log*/
				$user_id=Yii::app()->user->id;
				$user_name=Yii::app()->user->name;
				$object_log['input']=$array_input;    
				$module_log=3;
				$name_action='Sửa';
				$object_log['output']='Success!';
				header('Content-Type: text/html; charset=utf-8');
				$object_log=json_encode($object_log);
				$object_log=trim(mysql_escape_string($object_log));
				$content_log='<strong>'.$user_name.'</strong> Sửa đổi SEO danh mục . Mã danh mục: <strong>'.$_POST['cid'].'</strong>';
				$content_log=trim(mysql_escape_string($content_log));
				Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);

				$error.='Cập nhật thành công';
				$status='true';

				//Bao lai cache
				$row_cache=array();
				SynCache::setCacheCat($row_cache);
			}
			else $error.='Cập nhật lỗi';    
		}
		$output=json_encode(array('error'=>$error,'status'=>$status));
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}
	public function actionSaveOrderCatMenu()
	{
		$list_cat_order=$_POST['list_cat_order'];
		$list_cat_order=rtrim($list_cat_order,',');
		$list_cat_order=explode(',',$list_cat_order);
		$sub_sql='';
		$ok=true;
		if($list_cat_order)
		{
			foreach($list_cat_order as $row)
			{
				$value=explode('|',$row);
				$cat_order=$value[1];
				$cat_id=$value[0];
				$result=Cat::updateOrderMenu($cat_id,$cat_order);
				if($result>=0)
					$ok=$ok and true;
				else
					$ok=$ok and false;
			}
		}
		if($ok) {
			/*Log*/
			$user_id=Yii::app()->user->id;
			$user_name=Yii::app()->user->name;
			$object_log['input']=array('list_cat_order'=>$list_cat_order);    
			$module_log=51;
			$name_action='Sửa';
			$object_log['output']='Success!';
			header('Content-Type: text/html; charset=utf-8');
			$object_log=json_encode($object_log);
			$object_log=trim(mysql_escape_string($object_log));
			$content_log='<strong>'.$user_name.'</strong> Sửa đổi thứ tự Menu Ngang .';
			$content_log=trim(mysql_escape_string($content_log));
			Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
			/*End log*/
			echo 1;
		}
		else
			echo 0;
		/*Thông báo lại cache lấy toàn bộ danh mục*/
	}
	
	public function actionSaveOrderCatHome()
	{
		$list_cat_order=$_POST['list_cat_order'];
		$list_cat_order=rtrim($list_cat_order,',');
		$list_cat_order=explode(',',$list_cat_order);
		$sub_sql='';
		$ok=true;
		if($list_cat_order)
		{
			foreach($list_cat_order as $row)
			{
				$value=explode('|',$row);
				$cat_order=$value[1];
				$cat_id=$value[0];
				$result=Cat::updateOrderCatHome($cat_id,$cat_order);
				if($result>=0)
					$ok=$ok and true;
				else
					$ok=$ok and false;
			}
		}
		if($ok) {
			echo 1;
		}
		else
			echo 0;
		/*Thông báo lại cache lấy toàn bộ danh mục*/
	}
	
	public function actionSaveOrderCatHomeBottom()
	{
		$list_cat_order=$_POST['list_cat_order'];
		$list_cat_order=rtrim($list_cat_order,',');
		$list_cat_order=explode(',',$list_cat_order);
		$sub_sql='';
		$ok=true;
		if($list_cat_order)
		{
			foreach($list_cat_order as $row)
			{
				$value=explode('|',$row);
				$cat_order=$value[1];
				$cat_id=$value[0];
				$result=Cat::updateOrderCatHomeBottom($cat_id,$cat_order);
				if($result>=0)
					$ok=$ok and true;
				else
					$ok=$ok and false;
			}
		}
		if($ok) {
			echo 1;
		}
		else
			echo 0;
		/*Thông báo lại cache lấy toàn bộ danh mục*/
	}
	public function actionAddNews()
	{
		$news_id=isset($_POST['news_id']) ? intval($_POST['news_id']):0;		
		$cat_id=isset($_POST['cat_id']) ? intval($_POST['cat_id']):0;
		$is_hot=isset($_POST['is_hot']) ? intval($_POST['is_hot']):0;
		$title = isset($_POST['title']) ? $_POST['title']:'';
		$status = isset($_POST['status']) ? $_POST['status']:'';
		$alias = Common::generate_slug($title);
		$introtext = isset($_POST['introtext']) ? $_POST['introtext']:'';
		$description = isset($_POST['description']) ? $_POST['description']:'';
		$picture = isset($_POST['picture']) ? $_POST['picture']:'';
		$author_name = isset($_POST['author_name']) ? $_POST['author_name']:'';
		$list_news_id=isset($_POST['list_news_id']) ? $_POST['list_news_id']:'';
		$list_topic_id=isset($_POST['list_topic_id']) ? $_POST['list_topic_id']:'';
		$related_link=isset($_POST['related_link']) ? $_POST['related_link']:'';
		$related_title=isset($_POST['related_title']) ? $_POST['related_title']:'';
		$list_news_id=explode(',',$list_news_id);
		$list_topic_id=explode(',',$list_topic_id);
		$related_link=explode(',',$related_link);
		$related_title=explode(',',$related_title);
		
		$create_date=time();
		
		$day=isset($_POST['day']) ? intval($_POST['day']):date('d');
		$month=isset($_POST['month']) ? intval($_POST['month']):date('m');
		$year=isset($_POST['year']) ? intval($_POST['year']):date('Y');
		$hour=isset($_POST['hour']) ? intval($_POST['hour']):date('H');
		$minute=isset($_POST['minute']) ? intval($_POST['minute']):date('i');
		
		$publish_date=mktime($hour,$minute,0,$month,$day,$year);
		
		$original_link = isset($_POST['original_link']) ? $_POST['original_link']:'';
		$keyword = isset($_POST['keyword']) ? $_POST['keyword']:'';
		
		$array_input=array('title'=>mysql_escape_string($title),'alias'=>mysql_escape_string($alias),'introtext'=>mysql_escape_string($introtext),'picture'=>mysql_escape_string($picture),'description'=>mysql_escape_string($description),'cat_id'=>mysql_escape_string($cat_id),'status'=>$status,'publish_date'=>$publish_date, 'is_hot'=>$is_hot, 'original_link'=>mysql_escape_string($original_link), 'keyword'=>mysql_escape_string($keyword),'author_name'=>mysql_escape_string($author_name));
		
		if($news_id==0)
		{
			$array_input['create_date']=$create_date;
			$array_input['edit_date']=$create_date;
			$news_id=CommonModel::insertObject($array_input,'b_news');
            /*Log*/
            $user_id=Yii::app()->user->id;
            $user_name=Yii::app()->user->name;
            $object_log['input']=$array_input;    
            $module_log=2;
            $name_action='Thêm';
            $object_log['output']='Success!';
            header('Content-Type: text/html; charset=utf-8');
            $object_log=json_encode($object_log);
            $object_log=trim(mysql_escape_string($object_log));
            $content_log='<strong>'.$user_name.'</strong> Thêm Tin. Title: <strong>'.$title.'</strong>';
            $content_log=trim(mysql_escape_string($content_log));
            Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
            /*End log*/
		}
		else
		{
			$array_input['edit_date']=$create_date;
			CommonModel::updateObject($array_input,'id',$news_id,'b_news');
            /*Log*/
            $user_id=Yii::app()->user->id;
            $user_name=Yii::app()->user->name;
            $object_log['input']=array('news_id'=>$news_id);    
            $module_log=2;
            $name_action='Sửa';
            $object_log['output']=$array_input;
            header('Content-Type: text/html; charset=utf-8');
            $object_log=json_encode($object_log);
            $object_log=trim(mysql_escape_string($object_log));
            $content_log='<strong>'.$user_name.'</strong> sửa trang Tin. Mã: <strong>'.$news_id.'</strong>';
            $content_log=trim(mysql_escape_string($content_log));
            Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
            /*End log*/
			
		}
		
		//Chuyen de lien quan lien quan
		Topic::deleteTopicRelated($news_id);
		$sub_sql='';
		$list_id=array();
		if(isset($list_topic_id) && !empty($list_topic_id))
		foreach($list_topic_id as $value)
		{
			if(!in_array($value,$list_id) && $value!='')
			{
				$sub_sql.='('.$news_id.',"'.$value.'",'.$create_date.'),';
				$list_id[]=$value;
			}
		}
		if($sub_sql!='')
		{
			$sub_sql=rtrim($sub_sql,',');
			Topic::insertNewsTopic($sub_sql);
		}
		/*Insert tin bai lien quan lien quan*/
		News::deleteNewsRelated($news_id);
		$sub_sql='';
		$list_id=array();
		if(isset($list_news_id) && !empty($list_news_id))
		foreach($list_news_id as $value)
		{
			if(!in_array($value,$list_id) && $value!='')
			{
				$sub_sql.='('.$news_id.',"'.$value.'","","",'.$create_date.'),';
				$list_id[]=$value;
			}
		}		
		if(isset($related_link) && !empty($related_link))
		{
			$k=0;
			foreach($related_link as $value)
			{
				if($value!='' && $value!='Link')
				{
					$title=isset($related_title[$k]) ? $related_title[$k]:'';
					if($title!='Tiêu đề' && $title!='')
					$sub_sql.='('.$news_id.',0,"'.mysql_escape_string($title).'","'.mysql_escape_string($value).'",'.$create_date.'),';
				}
				$k++;
			}
		}
		if($sub_sql!='')
		{
			$sub_sql=rtrim($sub_sql,',');
			News::insertNewsRelated($sub_sql);
		}
		
		if($news_id!=0)
		{
			if(isset($create_date) && $create_date!=0)
			{
				$path = date("Y/md/",$create_date);
			}
			else
			{
				$path = date("Y/md/");
			}
			//Save anh ve server (server anh cung server code)
			$folder = 'news';
			$dir_upload = Yii::app()->params['dir_upload'].$folder;
			$description = CommonModel::saveImgToServer($description,$news_id,$path,$dir_upload, $folder);
			$array_update = array('description'=>mysql_escape_string($description));
			CommonModel::updateObject($array_update,'id',$news_id,'b_news');
		}
		echo $news_id;
	}
	/*
	public function actionDeleteNews()
	{
		$news_id=isset($_POST['news_id']) ? intval($_POST['news_id']):0;
		$ok=CommonModel::deleteObject(array('id'=>$news_id),'b_news');
        //Log
        $user_id=Yii::app()->user->id;
        $user_name=Yii::app()->user->name;
        $object_log['input']=array('news_id'=>$news_id);    
        $module_log=2;
        $name_action='Xóa';
        $object_log['output']='Success!';
        header('Content-Type: text/html; charset=utf-8');
        $object_log=json_encode($object_log);
        $object_log=trim(mysql_escape_string($object_log));
        $content_log='<strong>'.$user_name.'</strong> Xóa Tư vấn (Trang Tin). Mã: <strong>'.$news_id.'</strong>';
        $content_log=trim(mysql_escape_string($content_log));
        Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
		//Xoa comment binh luan
		$ok=CommentNews::deleteCommentByNews($news_id);
		echo $ok;
	}
	*/
	public function actionSeoNews()
	{
		$news_id=isset($_POST['news_id']) ? intval($_POST['news_id']):0;
		$array_input['meta_keyword'] = isset($_POST['meta_keyword']) ? mysql_escape_string($_POST['meta_keyword']):'';
		$array_input['meta_title']= isset($_POST['meta_title']) ? mysql_escape_string($_POST['meta_title']):'';
		$array_input['meta_description']= isset($_POST['meta_description']) ? mysql_escape_string($_POST['meta_description']):'';
		$ok=CommonModel::updateObject($array_input,'id',$news_id,'b_news');
        /*Log*/
        $user_id=Yii::app()->user->id;
        $user_name=Yii::app()->user->name;
        $object_log['input']=array('news_id'=>$news_id);    
        $module_log=2;
        $name_action='Seo';
        $object_log['output']=$array_input;
        header('Content-Type: text/html; charset=utf-8');
        $object_log=json_encode($object_log);
        $object_log=trim(mysql_escape_string($object_log));
        $content_log='<strong>'.$user_name.'</strong> Sửa Seo Tư vấn (Trang Tin). Mã: <strong>'.$news_id.'</strong>';
        $content_log=trim(mysql_escape_string($content_log));
        Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
        /*End log*/
		echo $ok;
	}
	public function actionChangeStatusNews()
	{
		$news_id=isset($_POST['news_id']) ? intval($_POST['news_id']):0;
		$detail=TsArticlesQa::getQaById($news_id);
		if($detail['status']=='active') $status='pending';
		else $status='active';
		$array_input=array('status'=>$status);
		$ok=CommonModel::updateObject($array_input,'id',$news_id,'b_news');
        /*Log*/
        $user_id=Yii::app()->user->id;
        $user_name=Yii::app()->user->name;
        $object_log['input']=array('news_id'=>$news_id);    
        $module_log=2;
        $name_action='Sửa';
        $object_log['output']=$array_input;
        header('Content-Type: text/html; charset=utf-8');
        $object_log=json_encode($object_log);
        $object_log=trim(mysql_escape_string($object_log));
        $content_log='<strong>'.$user_name.'</strong> Sửa Tư vấn (Trang Tin). Mã: <strong>'.$news_id.'</strong>';
        if($status == 'active') {
            $content_log .= '. Kích hoạt';
        }
        else {
            $content_log .= '. Bỏ kích hoạt';
        }
        $content_log=trim(mysql_escape_string($content_log));
        Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
        /*End log*/
		echo $ok;
	}
	public function actionSetHotNews()
	{
		$news_id=isset($_POST['news_id']) ? intval($_POST['news_id']):0;
		$detail=News::getNewsById($news_id);
		if($detail['is_hot']==0) $is_hot=1;
		else $is_hot=0;
		$array_input=array('is_hot'=>$is_hot);
		$ok=CommonModel::updateObject($array_input,'id',$news_id,'b_news');
        /*Log*/
        $user_id=Yii::app()->user->id;
        $user_name=Yii::app()->user->name;
        $object_log['input']=array('news_id'=>$news_id);    
        $module_log=2;
        $name_action='Sửa';
        $object_log['output']=$array_input;
        header('Content-Type: text/html; charset=utf-8');
        $object_log=json_encode($object_log);
        $object_log=trim(mysql_escape_string($object_log));
        $content_log='<strong>'.$user_name.'</strong> Sửa tin tức. Mã: <strong>'.$news_id.'</strong>';
        if($is_hot == 1) {
            $content_log .= '. Set Hot';
        }
        else {
            $content_log .= '. Bỏ Hot';
        }
        $content_log=trim(mysql_escape_string($content_log));
        Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
        /*End log*/
		echo $ok;
	}
	public function actionDeleteAllNews()
	{
		/*Xoa noi dung cau hoi va tra loi*/
		$list_news_id=isset($_POST['list_news_id']) ? $_POST['list_news_id']:'';
		$list_news_id=explode(',',$list_news_id);
		if($list_news_id)
		foreach($list_news_id as $news_id)
		{
			$ok = CommonModel::deleteObject(array('id'=>$news_id),'b_news');
			/*Xoa comment binh luan*/
			$ok=CommentNews::deleteCommentByNews($news_id);
		}
        /*Log*/
        $user_id=Yii::app()->user->id;
        $user_name=Yii::app()->user->name;
        $object_log['input']=array('list_news_id'=>$_POST['list_news_id']);    
        $module_log=2;
        $name_action='Xóa';
        $object_log['output']='Success!';
        header('Content-Type: text/html; charset=utf-8');
        $object_log=json_encode($object_log);
        $object_log=trim(mysql_escape_string($object_log));
        $content_log='<strong>'.$user_name.'</strong> Xóa Tin tuc. Mã: <strong>'.$list_news_id.'</strong>';
        $content_log=trim(mysql_escape_string($content_log));
        Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
        /*End log*/
		echo 1;
	}
	
	public function actionPagingTopic()
    {
    	if(isset($_POST["keyword"]))
		{
	        /* Lay danh sach chuyen muc */
			$cats = $this->cats;
			$keyword = isset($_POST["keyword"]) ? trim(strip_tags($_POST["keyword"])) : '';
			$cat_id = isset($_POST["cat_id"]) ? intval($_POST["cat_id"]) : 0;
	        $page = intval($_POST["page"]);
	        $num_per_page = intval($_POST["numperpage"]);
	        
	        /* Lấy danh sách su kien */
	        list($topic, $total) = Topic::getTopicPopup($keyword,$cat_id,$page,$num_per_page);
	        $num_page = ceil($total/$num_per_page);
	        
	        $this->render(
	            "paging_topic"
		            , array(
	            	"cats"=>$cats
	                , "topic"=>$topic
	                , 'num_page'=>$num_page
	                , 'page'=>$page
	                , 'num_per_page'=>$num_per_page
	            )
	        );
    	}     	   
    }
	/*
    public function actionPagingTopic()
    {
    	if(isset($_POST["keyword"])){
	        // Lay danh sach chuyen muc
			$cats = $this->cats;
			
			$search['keyword'] = trim(strip_tags($_POST["keyword"]));
    		$search['cat_id'] = trim(strip_tags($_POST["cat_id"]));
	        $currentPage = intval($_POST["page"]);
	        $numberRecordPerPage = intval($_POST["numperpage"]);
	        
	        $topic = Topic::getTopicActive($numberRecordPerPage, $currentPage, $search);
	        $totalTopic = Topic::getTotalTopicActive($search);
	        $numberPage = ceil($totalTopic / $numberRecordPerPage);
	        
	        $this->render(
	            "paging_topic"
		            , array(
	            	"cats"=>$cats
	                , "topic"=>$topic
	                , 'numberPage'=>$numberPage
	                , 'currentPage'=>$currentPage
	                , 'numberRecordPerPage'=>$numberRecordPerPage
	            )
	        );
    	}
    }
	*/
	public function actionShowNews()
    {
    	/* Lay danh sach chuyen muc */
		$cat = $this->cats;
		$keyword='';
		$cat_id=0;
		
		$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $num_per_page = 10;
     	$boolean = isset($_GET['bool']) ? $_GET['bool'] : "";
        /* Lấy danh sách su kien */
		list($news,$total) = News::getNewsPopup($keyword,$cat_id,$page,$num_per_page);
		$num_page=ceil($total/$num_per_page);
        $this->render("show_news"
            , array(
            	"cat"=>$cat
                , "news"=>$news
                ,'page'=>$page,'num_per_page'=>$num_per_page,'total'=>$total,'num_page'=>$num_page
                , 'boolean'=>$boolean
            )
        );
         	
    }
	public function actionPagingNews()
    {
    	if(isset($_POST["keyword"]))
		{
	        /* Lay danh sach chuyen muc */
			$cat = $this->cats;
			$keyword = isset($_POST["keyword"]) ? trim(strip_tags($_POST["keyword"])) : '';
			$cat_id = isset($_POST["cat_id"]) ? intval($_POST["cat_id"]) : 0;
	        $page = intval($_POST["page"]);
	        $num_per_page = intval($_POST["numperpage"]);
	        
	        /* Lấy danh sách su kien */
	        list($news,$total) = News::getNewsPopup($keyword,$cat_id,$page,$num_per_page);
	        $num_page = ceil($total/$num_per_page);
	        
	        $this->render(
	            "paging_news"
		            , array(
	            	"cat"=>$cat
	                , "news"=>$news
	                , 'num_page'=>$num_page
	                , 'page'=>$page
	                , 'num_per_page'=>$num_per_page
	            )
	        );
    	}     	   
    }
	
	public function actionSaveOrderNews()
	{
		$list_order=isset($_POST['list_order']) ? $_POST['list_order']:'';
		$list_order=rtrim($list_order,',');
		$list_order=explode(',',$list_order);
		$ok=true;
		if($list_order)
		{
			foreach($list_order as $row)
			{
				$value=explode('|',$row);
				$ok=News::updateOrderNews($value[0],$value[1]);
				if($ok>=0)
					$ok=$ok and true;
				else
					$ok=$ok and false;
			}
		}
        /*Log*/
        $user_id=Yii::app()->user->id;
        $user_name=Yii::app()->user->name;
        $object_log['input']=array('list_order'=>$_POST['list_order']);    
        $module_log=2;
        $name_action='Sửa';
        $object_log['output']='Success!';
        header('Content-Type: text/html; charset=utf-8');
        $object_log=json_encode($object_log);
        $object_log=trim(mysql_escape_string($object_log));
        $content_log='<strong>'.$user_name.'</strong> Thay đổi thứ tự bài viết';
        $content_log=trim(mysql_escape_string($content_log));
        Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
        /*End log*/
		
		if($ok)
			echo "Cập nhật thứ tự thành công!";
		else
			echo "Cập nhật thứ tự lỗi!";
	}
	
	public function actionQuickUpdateNews()
	{
		$list_id=isset($_POST["list_id"]) ? $_POST["list_id"]:'';//Danh sach ID
		$quick_type=isset($_POST["quick_type"]) ? intval($_POST["quick_type"]):0;
		$result=News::quickUpdateNews($quick_type,$list_id);
		if($result)
		{
			/*Bao lai cache*/
			/*
			$list_id_array=explode(',',$list_id);
			if($list_id_array)
			foreach($list_id_array as $value)
			{
				$cache['id'] = $value;
				SynCache::setCacheArticles($cache);
			}
			*/
			/*Log*/
			$user_id=Yii::app()->user->id;
			$user_name=Yii::app()->user->name;
			$object_log['input']=array('list_id'=>$list_id,'quick_type'=>$quick_type);
			$module_log=2;
			$name_action='Sửa';
			$object_log['output']='Success!';
			header('Content-Type: text/html; charset=utf-8');
			$object_log=json_encode($object_log);
			$object_log=trim(mysql_escape_string($object_log));
			$content_log='<strong>'.$user_name.'</strong> Sửa tin tức . Mã tin bài: <strong>'.$list_id.'</strong>';

			$content_log .= ". Quicktype:".$quick_type;
			
			$content_log=trim(mysql_escape_string($content_log));
			Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
			/*End log*/
			$this->output["status"] = true;
		}
		else
		{
			$this->output["status"] = false;
		}
		echo json_encode($this->output);
	}
	
	public function actionMoveCatNews()
	{
		$list_id=isset($_POST["list_id"]) ? $_POST["list_id"]:'';//Danh sach ID
		$cat_id=isset($_POST["cat_id"]) ? $_POST["cat_id"]:'';//ID danh muc
		$info = Cat::getCateById($cat_id,$this->cats);
		if($info)
		{
			
			$result=News::moveCatNews($list_id,$cat_id);
			if($result)
			{
				/*Bao lai cache*/
				/*
				$list_id_array=explode(',',$list_id);
				if($list_id_array)
				foreach($list_id_array as $value)
				{
					$cache['id'] = $value;
					SynCache::setCacheArticles($cache);
				}
				*/
				/*Log*/
				$user_id=Yii::app()->user->id;
				$user_name=Yii::app()->user->name;
				$object_log['input']=array('list_id'=>$list_id,'cat_id'=>$cat_id);
				$module_log=2;
				$name_action='Sửa';
				$object_log['output']='Success!';
				header('Content-Type: text/html; charset=utf-8');
				$object_log=json_encode($object_log);
				$object_log=trim(mysql_escape_string($object_log));
				$content_log='<strong>'.$user_name.'</strong> Sửa tin tức (Trang Tin). Mã tin bài: <strong>'.$list_id.'</strong>';
	
				$content_log .= ". Quicktype:".$cat_id;
				
				$content_log=trim(mysql_escape_string($content_log));
				Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
				/*End log*/
				$this->output["status"] = true;
			}
		}
		else
		{
			$this->output["status"] = false;
		}
		echo json_encode($this->output);
	}
	/*
	//Them tin cho nhieu chuyen de
	public function actionInsertNewsTopic()
	{
		if (isset($_POST["list_news_id"]))
		{
			$list_news_id = $_POST["list_news_id"];
			$list_topic_id = $_POST["list_topic_id"];

			$list_news_id = explode(",", $list_news_id);
			$list_topic_id = explode(",", $list_topic_id);
			$result = 0;
			$sub_sql = '';
			$create_date = time();
			foreach ($list_news_id as $row)
			{
				foreach ($list_topic_id as $r)
				{
					$news_id = $row;
                    $topic_id = $r;
					$sub_sql .= "(".$news_id.", ".$topic_id.", ".$create_date."),";
				}
			}
			$result = 0;
			if($sub_sql!='')
			{
				$sub_sql = rtrim($sub_sql, ',');
				$result = Topic::insertNewsTopic($sub_sql);
			}
			if($result > 0)
			{
				$user_id=Yii::app()->user->id;
				$user_name=Yii::app()->user->name;
				$object_log['input']=array('list_news_id'=>$list_news_id, 'list_topic_id'=>$list_topic_id);	
				$module_log = 2;
				$name_action='Thêm';
				$object_log['output']='Success!';
				header('Content-Type: text/html; charset=utf-8');
				$object_log=json_encode($object_log);
				$object_log=trim(mysql_escape_string($object_log));
				$content_log='<strong>'.$user_name.'</strong> Thêm mới tin tức vào chuyên đề (Trang Tin). Mã tin tức: <strong>'.$list_news_id.'</strong>. Mã chuyên đề: <strong>'. $list_topic_id .'</strong>';
				$content_log=trim(mysql_escape_string($content_log));
				Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
				
				$this->output["status"] = true;
			} else {
				$this->output["status"] = false;
			}                    
		} else {
			$this->output["status"] = false;
		}
		echo json_encode($this->output);
	}
	*/
	//Them su kien
	public function actionAddTopicNews()
	{
		$topic_id=isset($_POST["topic_id"]) ? intval($_POST["topic_id"]) : 0;
		$cat_id=isset($_POST["cat_id"]) ? intval($_POST["cat_id"]) : 0;
		$title=isset($_POST["title"]) ? $_POST["title"]:'';
		$alias=Common::generate_slug($title);
		$title_short=isset($_POST["title_short"]) ? $_POST["title_short"]:'';
		$picture=isset($_POST["picture"]) ? $_POST["picture"]:'';
		$introtext=isset($_POST["introtext"]) ? $_POST["introtext"]:'';
		$is_link=isset($_POST["is_link"]) ? intval($_POST["is_link"]) : 0;
		$links=isset($_POST["links"]) ? $_POST["links"]:'';
		$keyword = isset($_POST["keyword"]) ? $_POST["keyword"]:'';
		if($is_link==0) $links='';
		$create_date=time();
		$edit_date=$create_date;
		$publish_date=$create_date;

		$admin_id=Yii::app()->user->id;
		$admin_name=Yii::app()->user->name;

		$array_input=array('title'=>mysql_escape_string($title),'alias'=>mysql_escape_string($alias),'title_short'=>mysql_escape_string($title_short),'cat_id'=>$cat_id,'picture'=>mysql_escape_string($picture),'introtext'=>mysql_escape_string($introtext),'is_link'=>$is_link,'links'=>mysql_escape_string($links),'keyword'=>mysql_escape_string($keyword),'status'=>1,'admin_name'=>mysql_escape_string($admin_name));
		if($topic_id!=0)
		{
			$array_input['edit_date']=$edit_date;
            $array_input['edit_name']=$admin_name;
			CommonModel::updateObject($array_input,'id',$topic_id,'b_topic');
            /*Log*/
            $user_id=Yii::app()->user->id;
            $user_name=Yii::app()->user->name;
            $object_log['input']=array('id'=>$topic_id);  
            $module_log=4;
            $name_action='Sửa';
            $object_log['output']=$array_input;
            header('Content-Type: text/html; charset=utf-8');
            $object_log=json_encode($object_log);
            $object_log=trim(mysql_escape_string($object_log));
            $content_log='<strong>'.$user_name.'</strong> Sửa Chuyên đề. Mã Chuyên đề : <strong>'.$topic_id.'</strong>';
            $content_log=trim(mysql_escape_string($content_log));
            Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
            /*End log*/
		}
		else
		{
			$array_input['create_date']=$create_date;
			$array_input['edit_date']=$edit_date;
			$array_input['publish_date']=$publish_date;
            $array_input['admin_name']=$admin_name;
			$topic_id = CommonModel::insertObject($array_input,'b_topic');
            
            /*Log*/
            $user_id=Yii::app()->user->id;
            $user_name=Yii::app()->user->name;
            $object_log['input']=$array_input;   
            $module_log=4;
            $name_action='Sửa';
            $object_log['output']='Success!';
            header('Content-Type: text/html; charset=utf-8');
            $object_log=json_encode($object_log);
            $object_log=trim(mysql_escape_string($object_log));
            $content_log='<strong>'.$user_name.'</strong> Thêm Chuyên đề. Mã Chuyên đề : <strong>'.$topic_id.'</strong>';
            $content_log=trim(mysql_escape_string($content_log));
            Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
            /*End log*/
		}
		echo $topic_id;
	}

	public function actionIsActiveTopicNews()
	{
		$topic_id=isset($_POST['topic_id']) ? intval($_POST['topic_id']) : 0;
		if($topic_id!=0)
		{
			$detail = Topic::getTopicById($topic_id);
			if($detail['status']=='active') $status = 'pending';
			else $status = 'pending';
			$array_input=array('status'=>$status);
			$result=CommonModel::updateObject($array_input,'id',$topic_id,'b_topic');
            /*Log*/
            $user_id=Yii::app()->user->id;
            $user_name=Yii::app()->user->name;
            $object_log['input']=array('id'=>$topic_id); ;    
            $module_log=4;
            $name_action='Sửa';
            $object_log['output']=$array_input;
            header('Content-Type: text/html; charset=utf-8');
            $object_log=json_encode($object_log);
            $object_log=trim(mysql_escape_string($object_log));
            if($status==1){
            $content_log='<strong>'.$user_name.'</strong> Kích hoạt Chuyên đề. Mã Chuyên đề: <strong>'.$topic_id.'</strong>';
            }else $content_log='<strong>'.$user_name.'</strong> Bỏ Kích hoạt Chuyên đề. Mã Chuyên đề: <strong>'.$topic_id.'</strong>';
            $content_log=trim(mysql_escape_string($content_log));
            Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
            /*End log*/
		}
		echo $topic_id;
	}

	public function actionIsHotTopicNews()
	{
		$topic_id=isset($_POST['topic_id']) ? intval($_POST['topic_id']) : 0;
		if($topic_id!=0)
		{
			$detail = Topic::getTopicById($topic_id);
			if($detail['is_hot']==1) $is_hot=0;
			else $is_hot=1;
			$array_input=array('is_hot'=>$is_hot);
			$result=CommonModel::updateObject($array_input,'id',$topic_id,'b_topic');
            /*Log*/
            $user_id=Yii::app()->user->id;
            $user_name=Yii::app()->user->name;
            $object_log['input']=array('id'=>$topic_id); ;    
            $module_log=4;
            $name_action='Sửa';
            $object_log['output']=$array_input;
            header('Content-Type: text/html; charset=utf-8');
            $object_log=json_encode($object_log);
            $object_log=trim(mysql_escape_string($object_log));
            if($is_hot==1){
            $content_log='<strong>'.$user_name.'</strong> Set Hot Chuyên đề. Mã Chuyên đề: <strong>'.$topic_id.'</strong>';
            }else $content_log='<strong>'.$user_name.'</strong> Bỏ Set Hot Chuyên đề. Mã Chuyên đề: <strong>'.$topic_id.'</strong>';
            $content_log=trim(mysql_escape_string($content_log));
            Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
            /*End log*/
		}
		echo $topic_id;
	}
	/*
	public function actionDeleteTopicNews()
	{
		$topic_id=isset($_POST['topic_id']) ? intval($_POST['topic_id']) : 0;
		if($topic_id!=0)
		{
			//Xoa su kien
			CommonModel::deleteObject(array('id'=>$topic_id),'b_topic');
			//Xoa bai viet su kien
			CommonModel::deleteObject(array('topic_id'=>$topic_id),'b_topic_news');
            //Log
            $user_id=Yii::app()->user->id;
            $user_name=Yii::app()->user->name;
            $object_log['input']=array('id'=>$topic_id);   
            $module_log=4;
            $name_action='Xóa';
            $object_log['output']='Success!';
            header('Content-Type: text/html; charset=utf-8');
            $object_log=json_encode($object_log);
            $object_log=trim(mysql_escape_string($object_log));
            $content_log='<strong>'.$user_name.'</strong> Xóa Chuyên đề. Mã Chuyên đề : <strong>'.$topic_id.'</strong>';
            $content_log=trim(mysql_escape_string($content_log));
            Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
		}
		echo $topic_id;
	}
    */
    public function actionUpdateOrderTopicNews()
    {            
		$list_order=isset($_POST['list_order']) ? $_POST['list_order']:'';
		$list_order=rtrim($list_order,',');
		$list_order=explode(',',$list_order);
		$ok=true;
					
		if($list_order)
		{
			foreach($list_order as $row)
			{
				$value=explode('|',$row);
				$ok = Topic::orderTopicNews($value[0],$value[1]);             
			}
			if($ok>=0)
			{
				$ok=$ok and true;
				/*Log*/
				$user_id=Yii::app()->user->id;
				$user_name=Yii::app()->user->name;
				$object_log['input']=array('list_order'=>$list_order);    
				$module_log=4;
				$name_action='Sửa';
				$object_log['output']='Success!';
				header('Content-Type: text/html; charset=utf-8');
				$object_log=json_encode($object_log);
				$object_log=trim(mysql_escape_string($object_log));
				$content_log='<strong>'.$user_name.'</strong> Sửa thứ tự Chuyên đề đề thi';
				$content_log=trim(mysql_escape_string($content_log));
				Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
				/*End log*/  
			}   
			else
				$ok=$ok and false;
		}
    }
	public function actionQuickUpdateTopicNews()
	{
		$list_id=isset($_POST["list_id"]) ? $_POST["list_id"]:'';//Danh sach ID
		$quick_type=isset($_POST["quick_type"]) ? intval($_POST["quick_type"]):0;
		$result = Topic::quickUpdateTopic($quick_type,$list_id);
        /*Log*/
        $user_id=Yii::app()->user->id;
        $user_name=Yii::app()->user->name;
        $object_log['input']=array('quick_type'=>$quick_type,'list_id'=>$list_id);    
        $module_log=4;
        $name_action='Sửa';
        $object_log['output']='Success!';                                           
        header('Content-Type: text/html; charset=utf-8');
        $object_log=json_encode($object_log);
        $object_log=trim(mysql_escape_string($object_log));
        if($quick_type==1){
            $content_log='<strong>'.$user_name.'</strong> Kích hoạt Chuyên đề. Mã Chuyên đề : <strong>'.$list_id.'</strong>';
        }else if($quick_type==2){
			$content_log='<strong>'.$user_name.'</strong> Bỏ kích hoạt Chuyên đề. Mã Chuyên đề : <strong>'.$list_id.'</strong>';    
		}else if($quick_type==3){
			$content_log='<strong>'.$user_name.'</strong> Xóa Chuyên đề. Mã Chuyên đề : <strong>'.$list_id.'</strong>';
		}
                    
        $content_log=trim(mysql_escape_string($content_log));
        Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
        /*End log*/
		echo $result;
	}
	
	public function actionDeleteNewsOfTopic()
	{
		$news_id=isset($_POST["news_id"]) ? $_POST["news_id"]:'';//Danh sach ID
		$topic_id=isset($_POST["topic_id"]) ? intval($_POST["topic_id"]):0;
        $ok = CommonModel::deleteObject(array('news_id'=>$news_id,'topic_id'=>$topic_id), 'b_topic_news');
		echo $ok;
	}
	//Them nhieu tin cho nhieu chuyen de
	public function actionInsertTopicNews()
	{
		$list_news_id = isset($_POST["list_news_id"]) ? $_POST["list_news_id"] : '';
		$list_topic_id = isset($_POST["list_topic_id"]) ? $_POST["list_topic_id"] : '';

		$list_news_id = explode(",", $list_news_id);
		$list_topic_id = explode(",", $list_topic_id);
		
		$result = 0;
		if(!empty($list_news_id))
		foreach ($list_news_id as $news_id) 
		{
			foreach ($list_topic_id as $topic_id)
			{
				$array_input  = array('news_id'=>$news_id, 'topic_id'=>$topic_id, 'create_date'=>time());
				$result  = CommonModel::insertObject($array_input, 'b_topic_news');
			}
		}
		return $result;
	}
	
	//Them moi tin BDS
	public function actionLoadProductCat()
	{
		$type = isset($_POST['type']) ? intval($_POST['type']) : 0;
		$cats = $this->cats;
		$html = '<option value="0" selected="selected">--Danh mục--</option>';
		foreach($cats as $row)
		{
			if($row['cat_type']==$type)
			{
				$html .= '<option value="'.$row['id'].'">'.$row['title'].'</option>';
			}
		}
		echo $html;
	}
	
	public function actionLoadDistrict()
	{
		$city_id = isset($_POST['city_id']) ? intval($_POST['city_id']) : 0;
		$citys = City::getCity();
		$html = '<option value="0">--Quận huyện--</option>';
		foreach($citys as $row)
		{
			if($row['parent_id']==$city_id)
			{
				$html .= '<option value="'.$row['id'].'">'.$row['title'].'</option>';
			}
		}
		echo $html;
	}
	
	public function actionLoadWard()
	{
		$district_id = isset($_POST['district_id']) ? intval($_POST['district_id']) : 0;
		$wards = Ward::getWardByDistrictId($district_id);
		$html = '<option value="0">--Phường Xã--</option>';
		foreach($wards as $row)
		{
			if($row['district_id']==$district_id)
			{
				$html .= '<option value="'.$row['id'].'" rel="'.$row['pre'].'">'.$row['title'].'</option>';
			}
		}
		echo $html;
	}
	
	public function actionLoadStreet()
	{
		$district_id = isset($_POST['district_id']) ? intval($_POST['district_id']) : 0;
		$street = Street::getStreetByDistrictId($district_id);
		$html = '<option value="0">--Đường phố--</option>';
		foreach($street as $row)
		{
			if($row['district_id']==$district_id)
			{
				$html .= '<option value="'.$row['id'].'" rel="'.$row['pre'].'">'.$row['title'].'</option>';
			}
		}
		echo $html;
	}
	
	public function actionLoadProject()
	{
		$district_id = isset($_POST['district_id']) ? intval($_POST['district_id']) : 0;
		$project = Project::getProjectByDistrictId($district_id);
		$html = '<option value="0" lat="0" lng="0">--Dự án--</option>';
		foreach($project as $row)
		{
			if($row['district_id']==$district_id)
			{
				$html .= '<option value="'.$row['id'].'" lat="'.$row['lat'].'" lng="'.$row['lng'].'">'.$row['title'].'</option>';
			}
		}
		echo $html;
	}
	
	public function actionAddList()
	{
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		$model_id = isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
		$brand_id = isset($_POST['brand_id']) ? intval($_POST['brand_id']) : 0;
		$model_info = BModel::getModelById($model_id);
		$model_title = isset($model_info['title']) ? $model_info['title'] : '';
		$cat_id = isset($model_info['cat_id']) ? intval($model_info['cat_id']) : 0;
		$info_cat = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$cat_title = isset($info_cat['title']) ? $info_cat['title'] : '';
		
		$title = isset($_POST['title']) ? $_POST['title'] : '';
		//$introtext = isset($_POST['introtext']) ? $_POST['introtext'] : '';
		$introtext = isset($_POST['introtext']) ? $_POST['introtext'] : '';
		$introtext = preg_replace('/\n/si', '<br>', $introtext);
		//$title_other = isset($_POST['title_other']) ? $_POST['title_other'] : '';
		$alias = Common::generate_slug($title);
		$publish_date = isset($_POST['publish_date']) ? $_POST['publish_date'] : '';
		
		$list_access_id = isset($_POST['list_access_id']) ? $_POST['list_access_id']: '';
		$list_access_id=explode(',',$list_access_id);
		
		$create_date = time();
		if($publish_date!='')
		{
			$publish_date=explode('/',$publish_date);
			$publish_date=mktime(0,0,0,$publish_date[1],$publish_date[0],$publish_date[2]);
		}
		else
		{
			$publish_date = $create_date;
		}
		
		$picture = isset($_POST['picture']) ? $_POST['picture'] : '';
		$html_img=isset($_POST['html_img']) ? $_POST['html_img']:'';
		
		$camera_source = isset($_POST['camera_source']) ? $_POST['camera_source'] : '';
		$keyword = isset($_POST['keyword']) ? $_POST['keyword'] : '';		
		$status = isset($_POST['status']) ? $_POST['status'] : 'active';		
		
		//Info
		$price = isset($_POST['price']) ? $_POST['price'] : '';//Gia hien thi
		$price_in = isset($_POST['price_in']) ? $_POST['price_in'] : '';//Gia nhap VN
		$fee_vn = isset($_POST['fee_vn']) ? $_POST['fee_vn'] : '';//Phi van chuyen VN
		$price_dk = isset($_POST['price_dk']) ? $_POST['price_dk'] : '';//Gia du kien
		$price_in_japan = isset($_POST['price_in_japan']) ? $_POST['price_in_japan'] : '';//Gia nhap Japan
		//$fee_japan = isset($_POST['fee_japan']) ? $_POST['fee_japan'] : '';//Phi van chuyen Japan
		$rate_japan = isset($_POST['rate_japan']) ? $_POST['rate_japan'] : '';//Ty gia
		
		$price_sale = isset($_POST['price_sale']) ? $_POST['price_sale'] : '';//Gia khuyen mai
		
		
		$price_buy = isset($_POST['price_buy']) ? $_POST['price_buy'] : '';
		
		//$info_customer = isset($_POST['info_customer']) ? $_POST['info_customer'] : '';
		//$phu_kien = isset($_POST['phu_kien']) ? $_POST['phu_kien'] : '';
		$xuat_xu = isset($_POST['xuat_xu']) ? $_POST['xuat_xu'] : '';
		$sale_add = isset($_POST['sale_add']) ? $_POST['sale_add'] : '';
		$num_shot = isset($_POST['num_shot']) ? intval($_POST['num_shot']) : 0;
		$code = isset($_POST['code']) ? $_POST['code'] : '';
		$seri = isset($_POST['seri']) ? $_POST['seri'] : '';
		$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
		$note_shot = isset($_POST['note_shot']) ? $_POST['note_shot'] : '';
		$info_note = isset($_POST['info_note']) ? $_POST['info_note'] : '';
		$note_private = isset($_POST['note_private']) ? $_POST['note_private'] : '';
		$note_public = isset($_POST['note_public']) ? $_POST['note_public'] : '';
		$chinh_hang = isset($_POST['chinh_hang']) ? intval($_POST['chinh_hang']) : 1;
		//$text_chinh_hang = isset($_POST['text_chinh_hang']) ? $_POST['text_chinh_hang'] : '';
		$is_seri = isset($_POST['is_seri']) ? intval($_POST['is_seri']) : 0;
		$is_new = isset($_POST['is_new']) ? intval($_POST['is_new']) : 0;
		$is_special = isset($_POST['is_special']) ? intval($_POST['is_special']) : 0;
		$dot_hang = isset($_POST['dot_hang']) ? $_POST['dot_hang'] : '';
		$branch = isset($_POST['list_branch']) ? $_POST['list_branch'] : '';
		
		$time_sale = isset($_POST['time_sale']) ? $_POST['time_sale'] : '';
		$time_buy = isset($_POST['time_buy']) ? $_POST['time_buy'] : '';
		$time_bh = isset($_POST['time_bh']) ? $_POST['time_bh'] : '';
		if($time_sale!='')
		{
			$time_sale=explode('/',$time_sale);
			$time_sale=mktime(0,0,0,$time_sale[1],$time_sale[0],$time_sale[2]);
		}
		else
		{
			$time_sale = 0;
		}
		
		if($time_buy!='')
		{
			$time_buy=explode('/',$time_buy);
			$time_buy=mktime(date('H'),date('i'),date('s'),$time_buy[1],$time_buy[0],$time_buy[2]);
		}
		else
		{
			$time_buy = $create_date;
		}
		
		$admin_id=Yii::app()->user->id;
		$admin_name=Yii::app()->user->name;
		
		//Anh
		preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
		if(!empty($matches))
		{
			$picture = isset($matches[1][0]) ? $matches[1][0] : '';
		}
		else
		{
			$picture = '';
		}
		
		$array_input = array('model_id'=>$model_id, 'brand_id'=>$brand_id,'cat_id'=>$cat_id,'model_title'=>mysql_escape_string($model_title),'cat_title'=>mysql_escape_string($cat_title), 'title'=>mysql_escape_string($title),'introtext'=>mysql_escape_string($introtext), 'alias'=>mysql_escape_string($alias), 'publish_date'=>$publish_date, 'picture'=>mysql_escape_string($picture), 'camera_source'=>mysql_escape_string($camera_source),  'status'=>mysql_escape_string($status), 'admin_id'=>$admin_id, 'admin_name'=>mysql_escape_string($admin_name), 'keyword'=>mysql_escape_string($keyword), 'price'=>mysql_escape_string($price), 'price_sale'=>$price_sale, 'price_in'=>$price_in, 'price_buy'=>$price_buy, 'fee_vn'=>$fee_vn, 'price_dk'=>$price_dk, 'price_in_japan'=>$price_in_japan, 'rate_japan'=>$rate_japan,'xuat_xu'=>mysql_escape_string($xuat_xu),'num_shot'=>$num_shot,'code'=>mysql_escape_string($code),'seri'=>mysql_escape_string($seri),'rating'=>$rating, 'time_buy'=>$time_buy,'time_sale'=>$time_sale,'time_bh'=>$time_bh, 'note_shot'=>mysql_escape_string($note_shot), 'is_seri'=>$is_seri, 'chinh_hang'=>$chinh_hang, 'info_note'=>mysql_escape_string($info_note), 'is_special'=>$is_special, 'note_private'=>mysql_escape_string($note_private), 'note_public'=>mysql_escape_string($note_public), 'dot_hang'=>mysql_escape_string($dot_hang), 'branch'=>mysql_escape_string($branch));
		
		if($camera_id!=0)
		{
			$edit_date = time();
			$array_input['edit_date'] = $edit_date;
			$array_input['edit_name'] = $admin_name;
			CommonModel::updateObject($array_input, 'id', $camera_id, 'b_camera');
			
			//Delete Anh
			BListPic::deletePic($camera_id);
			//Cap nhat anh
			$sub_sql = '';
			preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
			if(!empty($matches))
			{
				$k = 0;
				$create_date = time();
				
				if(isset($matches[1]))
				foreach($matches[1] as $value)
				{
					$value = mysql_escape_string(trim(strip_tags($value)));
					$sub_sql .= "(".$camera_id.", '".$value."', '".$create_date."'),";
				}
				
			}
			if($sub_sql!='')
			{
				$sub_sql = rtrim($sub_sql, ',');
				BListPic::insertPic($sub_sql);
			}
			//Cap nhat gia ban cho khach hang
			CommonModel::updateObject(array('price_buy'=>$price_buy, 'price_in'=>$price_in), 'camera_id', $camera_id, 'b_camera_sale');
		}
		else
		{
			$array_input['create_date'] = $create_date;
			$array_input['status_new'] = 0; //San pham thuc
			$camera_id = CommonModel::insertObject($array_input, 'b_camera');
			if($camera_id>0)
			{
				//Cap nhat anh
				$sub_sql = '';
				preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
				if(!empty($matches))
				{
					$k = 0;
					$create_date = time();
					
					if(isset($matches[1]))
					foreach($matches[1] as $value)
					{
						$value = mysql_escape_string(trim(strip_tags($value)));
						$sub_sql .= "(".$camera_id.", '".$value."', '".$create_date."'),";
					}
					
				}
				if($sub_sql!='')
				{
					$sub_sql = rtrim($sub_sql, ',');
					BListPic::insertPic($sub_sql);
				}
			}
		}
		
		//Phu kien Free
		Access::deleteAccessFree($camera_id);
		$sub_sql='';
		$list_id=array();
		if(isset($list_access_id) && !empty($list_access_id))
		foreach($list_access_id as $value)
		{
			if(!in_array($value,$list_id) && $value!='')
			{
				$sub_sql.='('.$camera_id.',"'.$value.'"),';
				$list_id[]=$value;
			}
		}
		if($sub_sql!='')
		{
			$sub_sql=rtrim($sub_sql,',');
			Access::insertCameraAccessFree($sub_sql);
		}
		
		echo $camera_id;
	}
	
	public function actionLoadTitle()
	{
		$model_id = isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
		$brand_id = isset($_POST['brand_id']) ? intval($_POST['brand_id']) : 0;
		$body_id = isset($_POST['body_id']) ? intval($_POST['body_id']) : 0;
		$kit_id = isset($_POST['kit_id']) ? intval($_POST['kit_id']) : 0;
		$color_id = isset($_POST['color_id']) ? intval($_POST['color_id']) : 0;
		$model_info = BModel::getModelById($model_id);
		$brand_info = BBrand::getBrandById($brand_id);
		$body_info = BBody::getBodyById($body_id);
		$kit_info = BKit::getKitById($kit_id);
		$color_info = BColor::getColorById($color_id);
		$model_title = isset($model_info['title']) ? $model_info['title'] : '';
		$cat_title = isset($info_cat['title']) ? $info_cat['title'] : '';
		$brand_title = isset($brand_info['title']) ? $brand_info['title'] : '';
		$body_title = isset($body_info['title']) ? $body_info['title'] : '';
		$kit_title = isset($kit_info['title']) ? $kit_info['title'] : '';
		$color_title = isset($color_info['title']) ? $color_info['title'] : '';
		
		$title = '';
		if($brand_title!='') $title .= $brand_title;		
		if($model_title!='') $title .= ' '.$model_title;
		if($body_title!='') $title .= ' '.$body_title;
		if($kit_title!='') $title .= ' '.$kit_title;
		if($color_title!='') $title .= ' '.$color_title;
		echo $title;
	}
	
	public function actionLoadInfo()
	{
		$model_id = isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
		//$model_info = BModel::getModelById($model_id);
		$bodys = BBody::getBodyByModel($model_id);
		$kits = BKit::getKitByModel($model_id);
		$colors = BColor::getColorByModel($model_id);
		$html_body = '<option value="0" selected="selected">--Chọn Body--</option>';
		if($bodys)
		foreach($bodys as $row)
		{
			$html_body.='<option value="'.$row['id'].'" >'.$row['title'].'</option>';
		}
		
		$html_kit = '<option value="0" selected="selected">--Chọn Kit--</option>';
		if($kits)
		foreach($kits as $row)
		{
			$html_kit.='<option value="'.$row['id'].'" >'.$row['title'].'</option>';
		}
		
		$html_color = '<option value="0" selected="selected">--Chọn Color--</option>';
		if($colors)
		foreach($colors as $row)
		{
			$html_color.='<option value="'.$row['id'].'" >'.$row['title'].'</option>';
		}
		
		$output = array('html_body'=>$html_body, 'html_kit'=>$html_kit, 'html_color'=>$html_color);
				
		$output=json_encode($output);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
		
	}
	
	//San pham moi ao
	public function actionAddListNew()
	{
		$cats = $this->cats;
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		$model_id = isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
		$brand_id = isset($_POST['brand_id']) ? intval($_POST['brand_id']) : 0;
		$body_id = isset($_POST['body_id']) ? intval($_POST['body_id']) : 0;
		$kit_id = isset($_POST['kit_id']) ? intval($_POST['kit_id']) : 0;
		$color_id = isset($_POST['color_id']) ? intval($_POST['color_id']) : 0;
		$model_info = BModel::getModelById($model_id);
		$brand_info = BBrand::getBrandById($brand_id);
		$body_info = BBody::getBodyById($body_id);
		$kit_info = BKit::getKitById($kit_id);
		$color_info = BColor::getColorById($color_id);
		$model_title = isset($model_info['title']) ? $model_info['title'] : '';
		$cat_id = isset($model_info['cat_id']) ? intval($model_info['cat_id']) : 0;
		$info_cat = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		$cat_title = isset($info_cat['title']) ? $info_cat['title'] : '';
		$brand_title = isset($brand_info['title']) ? $brand_info['title'] : '';
		$body_title = isset($body_info['title']) ? $body_info['title'] : '';
		$kit_title = isset($kit_info['title']) ? $kit_info['title'] : '';
		$color_title = isset($color_info['title']) ? $color_info['title'] : '';
		$list_access_id = isset($_POST['list_access_id']) ? $_POST['list_access_id']: '';
		$list_access_id=explode(',',$list_access_id);
		$in_the_box = isset($_POST['in_the_box']) ? $_POST['in_the_box']: '';
		$is_special = isset($_POST['is_special']) ? intval($_POST['is_special']) : 0;
		/*
		$list_access_id2 = isset($_POST['list_access_id2']) ? $_POST['list_access_id2']: '';
		$list_access_id2=explode(',',$list_access_id2);
		*/
		$title = '';
		if($brand_title!='') $title .= $brand_title;		
		if($model_title!='') $title .= ' '.$model_title;
		if($body_title!='') $title .= ' '.$body_title;
		if($kit_title!='') $title .= ' '.$kit_title;
		if($color_title!='') $title .= ' '.$color_title;
		
		$title_post = isset($_POST['title']) ? $_POST['title'] : '';
		if($title_post!=$title) $title=$title_post;		

		$alias = Common::generate_slug($title);
		$publish_date = isset($_POST['publish_date']) ? $_POST['publish_date'] : '';
		$price = isset($_POST['price']) ? $_POST['price'] : '';
		$create_date = time();
		if($publish_date!='')
		{
			$publish_date=explode('/',$publish_date);
			$publish_date=mktime(0,0,0,$publish_date[1],$publish_date[0],$publish_date[2]);
		}
		else
		{
			$publish_date = $create_date;
		}
		
		$picture = isset($_POST['picture']) ? $_POST['picture'] : '';
		$html_img=isset($_POST['html_img']) ? $_POST['html_img']:'';
		
		$camera_source = isset($_POST['camera_source']) ? $_POST['camera_source'] : '';
		$keyword = isset($_POST['keyword']) ? $_POST['keyword'] : '';
		$status = isset($_POST['status']) ? $_POST['status'] : 'active';		
		
		//Info
		$price_in = isset($_POST['price_in']) ? $_POST['price_in'] : '';
		$price_sale = isset($_POST['price_sale']) ? $_POST['price_sale'] : '';
		$price_buy = isset($_POST['price_buy']) ? $_POST['price_buy'] : '';
		$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
		
		$chinh_hang = isset($_POST['chinh_hang']) ? intval($_POST['chinh_hang']) : 0;
		$is_sale = isset($_POST['is_sale']) ? intval($_POST['is_sale']) : 0;
		//$text_chinh_hang = isset($_POST['text_chinh_hang']) ? $_POST['text_chinh_hang'] : '';
		$note_private = isset($_POST['note_private']) ? $_POST['note_private'] : '';
		$note_public = isset($_POST['note_public']) ? $_POST['note_public'] : '';
		
		$link_web = isset($_POST['link_web']) ? $_POST['link_web'] : '';
		$branch = isset($_POST['list_branch']) ? $_POST['list_branch'] : '';
		
		$time_bh = isset($_POST['time_bh']) ? $_POST['time_bh'] : '';
		
		$admin_id=Yii::app()->user->id;
		$admin_name=Yii::app()->user->name;
		
		//Anh
		preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
		if(!empty($matches))
		{
			$picture = isset($matches[1][0]) ? $matches[1][0] : '';
		}
		else
		{
			$picture = '';
		}
		
		$time_sale = isset($_POST['time_sale']) ? $_POST['time_sale'] : '';
		if($time_sale!='')
		{
			$time_sale=explode('/',$time_sale);
			$time_sale=mktime(0,0,0,$time_sale[1],$time_sale[0],$time_sale[2]);
		}
		else
		{
			$time_sale = 0;
		}
		
		$array_input = array('cat_id'=>$cat_id, 'model_id'=>$model_id, 'brand_id'=>$brand_id, 'body_id'=>$body_id, 'kit_id'=>$kit_id,'color_id'=>$color_id, 'cat_title'=>mysql_escape_string($cat_title), 'model_title'=>mysql_escape_string($model_title), 'brand_title'=>mysql_escape_string($brand_title), 'body_title'=>mysql_escape_string($body_title), 'kit_title'=>mysql_escape_string($kit_title), 'color_title'=>mysql_escape_string($color_title), 'title'=>mysql_escape_string($title), 'alias'=>mysql_escape_string($alias), 'publish_date'=>$publish_date, 'picture'=>mysql_escape_string($picture), 'camera_source'=>mysql_escape_string($camera_source), 'status'=>mysql_escape_string($status), 'admin_id'=>$admin_id, 'admin_name'=>mysql_escape_string($admin_name), 'keyword'=>mysql_escape_string($keyword), 'price'=>mysql_escape_string($price), 'price_sale'=>$price_sale, 'price_in'=>$price_in, 'price_buy'=>$price_buy,'rating'=>$rating, 'status_new'=>1, 'chinh_hang'=>$chinh_hang, 'time_sale'=>$time_sale, 'time_bh'=>mysql_escape_string($time_bh), 'is_sale'=>$is_sale, 'in_the_box'=>mysql_escape_string($in_the_box), 'is_special'=>$is_special, 'note_private'=>mysql_escape_string($note_private), 'note_public'=>mysql_escape_string($note_public), 'link_web'=>mysql_escape_string($link_web), 'branch'=>mysql_escape_string($branch));
		
		if($camera_id!=0)
		{
			$edit_date = time();
			$array_input['edit_date'] = $edit_date;
			$array_input['edit_name'] = $admin_name;
			CommonModel::updateObject($array_input, 'id', $camera_id, 'b_camera');
			
			//Delete Anh
			BListPic::deletePic($camera_id);
			//Cap nhat anh
			$sub_sql = '';
			preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
			if(!empty($matches))
			{
				$k = 0;
				$create_date = time();
				
				if(isset($matches[1]))
				foreach($matches[1] as $value)
				{
					$value = mysql_escape_string(trim(strip_tags($value)));
					$sub_sql .= "(".$camera_id.", '".$value."', '".$create_date."'),";
				}
				
			}
			if($sub_sql!='')
			{
				$sub_sql = rtrim($sub_sql, ',');
				BListPic::insertPic($sub_sql);
			}
			
			//Cap nhat gia ban cho khach hang
			CommonModel::updateObject(array('price_buy'=>$price_buy, 'price_in'=>$price_in), 'camera_id', $camera_id, 'b_camera_sale');
		}
		else
		{
			$array_input['create_date'] = $create_date;
			$camera_id = CommonModel::insertObject($array_input, 'b_camera');
			if($camera_id>0)
			{
				
				//Cap nhat anh
				$sub_sql = '';
				preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
				if(!empty($matches))
				{
					$k = 0;
					$create_date = time();
					
					if(isset($matches[1]))
					foreach($matches[1] as $value)
					{
						$value = mysql_escape_string(trim(strip_tags($value)));
						$sub_sql .= "(".$camera_id.", '".$value."', '".$create_date."'),";
					}
					
				}
				if($sub_sql!='')
				{
					$sub_sql = rtrim($sub_sql, ',');
					BListPic::insertPic($sub_sql);
				}
			}
		}
		
		//Phu kien lien quan
		/*
		Access::deleteAccessRelated($camera_id);
		$sub_sql='';
		$list_id=array();
		if(isset($list_access_id) && !empty($list_access_id))
		foreach($list_access_id as $value)
		{
			if(!in_array($value,$list_id) && $value!='')
			{
				$sub_sql.='('.$camera_id.',"'.$value.'",'.$create_date.'),';
				$list_id[]=$value;
			}
		}
		if($sub_sql!='')
		{
			$sub_sql=rtrim($sub_sql,',');
			Access::insertCameraAccess($sub_sql);
		}
		*/
		//Phu kien Free
		Access::deleteAccessFree($camera_id);
		$sub_sql='';
		$list_id=array();
		if(isset($list_access_id) && !empty($list_access_id))
		foreach($list_access_id as $value)
		{
			if(!in_array($value,$list_id) && $value!='')
			{
				$sub_sql.='('.$camera_id.',"'.$value.'"),';
				$list_id[]=$value;
			}
		}
		if($sub_sql!='')
		{
			$sub_sql=rtrim($sub_sql,',');
			Access::insertCameraAccessFree($sub_sql);
		}
		echo $camera_id;
	}
	
	public function actionAddReal()
	{
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		$seri = isset($_POST['seri']) ? $_POST['seri'] : '';
		$price_in = isset($_POST['price_in']) ? $_POST['price_in'] : '';
		/*
		$array_input = array('parent_id'=>$camera_id, 'seri'=>mysql_escape_string($seri), 'price_in'=>$price_in, 'status_new'=>2, 'status'=>'active');
		$ok = CommonModel::insertObject($array_input, 'b_camera');
		*/
		$list_seri = explode(',', $seri);
		if($list_seri)
		foreach($list_seri as $value)
		{
			$ok = BList::insertProductReall($camera_id, $value, $price_in);	
		}
		
		echo $ok;
	}
	/*
	public function actionDeleteList()
	{
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		CommonModel::deleteObject(array('id'=>$camera_id),'b_camera');
		CommonModel::deleteObject(array('camera_id'=>$camera_id),'b_camera_content');
	}
	*/
	public function actionIsActiveList()
	{
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		$detail = BList::getListById($camera_id);
		
		if($detail['status']=='active')
			$status = 'pending';
		else	
			$status = 'active';
		
		$ok = CommonModel::updateObject(array('status'=>$status), 'id', $camera_id, 'b_camera');
		echo $ok;
	}
	
	public function actionIsShowDM()
	{
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		$detail = BList::getListById($camera_id);
		
		if($detail['is_show']==1)
			$is_show = 0;
		else	
			$is_show = 1;
		
		$ok = CommonModel::updateObject(array('is_show'=>$is_show), 'id', $camera_id, 'b_camera');
		echo $ok;
	}
	
	public function actionIsFeatureDeal()
	{
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		$detail = BList::getListById($camera_id);
		
		if($detail['is_feature']==1)
			$is_feature = 0;
		else	
			$is_feature = 1;
		
		$ok = CommonModel::updateObject(array('is_feature'=>$is_feature), 'id', $camera_id, 'b_camera');
		echo $ok;
	}
	
	public function actionIsApprovedList()
	{
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		$detail = BList::getListById($camera_id);
		
		if($detail['is_approved']==1)
			$is_approved = 0;
		else	
			$is_approved = 1;
		
		$approved_name = Yii::app()->user->name;
		$approved_date = time();
		$ok = CommonModel::updateObject(array('is_approved'=>$is_approved, 'approved_name'=>$approved_name, 'approved_date'=>$approved_date), 'id', $camera_id, 'b_camera');
		echo $ok;
	}
	
	public function actionSeoList()
	{
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		$array_input['meta_keyword']=mysql_escape_string(trim($_POST['meta_keyword']));
		$array_input['meta_title']=mysql_escape_string(trim($_POST['meta_title']));
		$array_input['meta_description']=mysql_escape_string(trim($_POST['meta_description']));
		$ok = CommonModel::updateObject($array_input,'id',$camera_id,'b_camera');
		echo $ok;
	}
	
	public function actionQuickUpdateList()
	{
		$list_id=isset($_POST["list_id"]) ? $_POST["list_id"]:'';//Danh sach ID
		$quick_type=isset($_POST["quick_type"]) ? intval($_POST["quick_type"]):0;
		$result = BList::quickUpdateList($quick_type,$list_id);
		if($result)
		{
			/*Log*/
			$user_id=Yii::app()->user->id;
			$user_name=Yii::app()->user->name;
			$object_log['input']=array('list_id'=>$list_id,'quick_type'=>$quick_type);
			$module_log=1;
			$name_action='Sửa';
			$object_log['output']='Success!';
			header('Content-Type: text/html; charset=utf-8');
			$object_log=json_encode($object_log);
			$object_log=trim(mysql_escape_string($object_log));
			$content_log='<strong>'.$user_name.'</strong> Sửa tin tức . Mã tin BĐS: <strong>'.$list_id.'</strong>';

			$content_log .= ". Quicktype:".$quick_type;
			
			$content_log=trim(mysql_escape_string($content_log));
			Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
			/*End log*/
			$this->output["status"] = true;
		}
		else
		{
			$this->output["status"] = false;
		}
		echo json_encode($this->output);
	}
	
	public function actionSetHotList()
	{
		$camera_id=isset($_POST['camera_id']) ? intval($_POST['camera_id']):0;
		$detail=BList::getListById($camera_id);
		if($detail['is_hot']==0) $is_hot=1;
		else $is_hot=0;
		$array_input=array('is_hot'=>$is_hot);
		$ok=CommonModel::updateObject($array_input,'id',$camera_id,'b_camera');
        /*Log*/
        $user_id=Yii::app()->user->id;
        $user_name=Yii::app()->user->name;
        $object_log['input']=array('camera_id'=>$camera_id);    
        $module_log=1;
        $name_action='Sửa';
        $object_log['output']=$array_input;
        header('Content-Type: text/html; charset=utf-8');
        $object_log=json_encode($object_log);
        $object_log=trim(mysql_escape_string($object_log));
        $content_log='<strong>'.$user_name.'</strong> Sửa thông tin Camera. Mã: <strong>'.$camera_id.'</strong>';
        if($is_hot == 1) {
            $content_log .= '. Set Hot';
        }
        else {
            $content_log .= '. Bỏ Hot';
        }
        $content_log=trim(mysql_escape_string($content_log));
        Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
        /*End log*/
		echo $ok;
	}
	
	public function actionSetSocList()
	{
		$camera_id=isset($_POST['camera_id']) ? intval($_POST['camera_id']):0;
		$detail=BList::getListById($camera_id);
		if($detail['is_soc']==0) $is_soc=1;
		else $is_soc=0;
		$array_input=array('is_soc'=>$is_soc);
		$ok=CommonModel::updateObject($array_input,'id',$camera_id,'b_camera');
		echo $ok;
	}
	
	public function actionUpdateOrderList()
    {            
		$list_order=isset($_POST['list_order']) ? $_POST['list_order']:'';
		$list_order=rtrim($list_order,',');
		$list_order=explode(',',$list_order);
		$ok=true;
					
		if($list_order)
		{
			foreach($list_order as $row)
			{
				$value=explode('|',$row);
				$ok = BList::updateOrderList($value[0],$value[1]);             
			}
			if($ok>=0)
			{
				$ok=$ok and true;
				/*Log*/
				$user_id=Yii::app()->user->id;
				$user_name=Yii::app()->user->name;
				$object_log['input']=array('list_order'=>$list_order);    
				$module_log=2;
				$name_action='Sửa';
				$object_log['output']='Success!';
				header('Content-Type: text/html; charset=utf-8');
				$object_log=json_encode($object_log);
				$object_log=trim(mysql_escape_string($object_log));
				$content_log='<strong>'.$user_name.'</strong> Sửa thứ tự sắp xếp Camera';
				$content_log=trim(mysql_escape_string($content_log));
				Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
				/*End log*/  
			}   
			else
				$ok=$ok and false;
		}
    }	
	
	//Doanh nghiep
	public function actionAddCompany()
	{
		$company_id=isset($_POST["company_id"]) ? intval($_POST["company_id"]) : 0;
		$cat_id=isset($_POST["cat_id"]) ? intval($_POST["cat_id"]) : 0;
		$title=isset($_POST["title"]) ? $_POST["title"]:'';
		$alias=Common::generate_slug($title);
		$picture=isset($_POST["picture"]) ? $_POST["picture"]:'';
		$introtext=isset($_POST["introtext"]) ? $_POST["introtext"]:'';
		$description=isset($_POST["description"]) ? $_POST["description"] : '';
		$city_id = isset($_POST["city_id"]) ? intval($_POST["city_id"]) : 0;
		$district_id = isset($_POST["district_id"]) ? intval($_POST["district_id"]) : 0;
		$address = isset($_POST["address"]) ? $_POST["address"]:'';
		$phone = isset($_POST["phone"]) ? $_POST["phone"]:'';
		$fax = isset($_POST["fax"]) ? $_POST["fax"]:'';
		$mobile = isset($_POST["mobile"]) ? $_POST["mobile"]:'';
		$email = isset($_POST["email"]) ? $_POST["email"]:'';
		$website = isset($_POST["website"]) ? $_POST["website"]:'';
		$yahoo = isset($_POST["yahoo"]) ? $_POST["yahoo"]:'';
		$skype = isset($_POST["skype"]) ? $_POST["skype"]:'';
		$create_date=time();
		
		$edit_date=$create_date;

		$admin_id = Yii::app()->user->id;
		$admin_name = Yii::app()->user->name;

		$array_input = array('city_id'=>$city_id, 'district_id'=>$district_id,'title'=>mysql_escape_string($title),'alias'=>mysql_escape_string($alias),'cat_id'=>$cat_id, 'picture'=>mysql_escape_string($picture),'introtext'=>mysql_escape_string($introtext),'description'=>mysql_escape_string($description),'status'=>'active','admin_name'=>mysql_escape_string($admin_name), 'admin_id'=>$admin_id, 'address'=>mysql_escape_string($address), 'phone'=>mysql_escape_string($phone), 'fax'=>mysql_escape_string($fax), 'mobile'=>mysql_escape_string($mobile), 'email'=>mysql_escape_string($email), 'website'=>mysql_escape_string($website), 'yahoo'=>mysql_escape_string($yahoo), 'skype'=>mysql_escape_string($skype));
		
		if($company_id!=0)
		{
			$array_input['edit_date']=$edit_date;
            $array_input['edit_name']=$admin_name;
			CommonModel::updateObject($array_input,'id',$company_id,'b_company');
		}
		else
		{
			$array_input['create_date']=$create_date;
			$array_input['edit_date']=$edit_date;
            $array_input['admin_name']=$admin_name;
			$company_id = CommonModel::insertObject($array_input,'b_company');
		}
		echo $company_id;
	}
	
	public function actionIsActiveCompany()
	{
		$company_id=isset($_POST['company_id']) ? intval($_POST['company_id']) : 0;
		if($company_id!=0)
		{
			$detail = Company::getCompanyById($company_id);
			if($detail['status']=='active') $status = 'pending';
			else $status = 'active';
			$array_input=array('status'=>$status);
			$result=CommonModel::updateObject($array_input,'id',$company_id,'b_company');
            
		}
		echo $company_id;
	}

	public function actionIsHotCompany()
	{
		$company_id=isset($_POST['company_id']) ? intval($_POST['company_id']) : 0;
		if($company_id!=0)
		{
			$detail = Company::getCompanyById($company_id);
			if($detail['is_hot']==1) $is_hot=0;
			else $is_hot=1;
			$array_input=array('is_hot'=>$is_hot,'edit_date'=>time());
			$result=CommonModel::updateObject($array_input,'id',$company_id,'b_company');
           
		}
		echo $company_id;
	}

	public function actionDeleteCompany()
	{
		$company_id=isset($_POST['company_id']) ? intval($_POST['company_id']) : 0;
		if($company_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$company_id),'b_company');
		}
		echo $company_id;
	}
	//Hoi dap
	public function actionAddQa()
	{
		$qa_id = isset($_POST['qa_id']) ? intval($_POST['qa_id']) : 0;
		$title = isset($_POST['title']) ? trim(strip_tags($_POST['title'])) : '';
		$alias = Common::generate_slug($title);
		$cat_id = isset($_POST['cat_id']) ? intval($_POST['cat_id']) : 0;
		$city_id = isset($_POST['city_id']) ? trim(strip_tags($_POST['city_id'])) : 0;
		$district_id = isset($_POST['district_id']) ? trim(strip_tags($_POST['district_id'])) : 0;
		$description = isset($_POST['description']) ? trim(strip_tags($_POST['description'])) : '';
		$introtext = Common::getIntrotext($description, 200, '');
		$admin_id = Yii::app()->user->id;
		$admin_name = Yii::app()->user->name;
		
		$create_date = time();
		$array_input = array('title'=>mysql_escape_string($title), 'alias'=>mysql_escape_string($alias), 'cat_id'=>$cat_id,'description'=>mysql_escape_string($description),'introtext'=>mysql_escape_string($introtext),'city_id'=>$city_id,'district_id'=>$district_id);
		
		if($qa_id!=0)
		{
			$array_input['edit_date'] = $create_date;
			$ok = CommonModel::updateObject($array_input, 'id',$qa_id,'b_qa');
			$error='Cập nhật thành công';
		}
		else
		{
			$array_input['create_date'] = $create_date;
			$array_input['edit_date'] = $create_date;
			$array_input['publish_date'] = $create_date;
			$qa_id = CommonModel::insertObject($array_input,'b_qa');
			if($qa_id>0)
			{
				$error='Cập nhật thành công';
			}
		}
		echo $qa_id;
	}
	
	public function actionIsActiveQa()
	{
		$qa_id=isset($_POST['qa_id']) ? intval($_POST['qa_id']) : 0;
		if($qa_id!=0)
		{
			$detail = Qa::getQaById($qa_id);
			if($detail['status']==1) $status = 0;
			else $status = 1;
			$array_input=array('status'=>$status);
			$result=CommonModel::updateObject($array_input,'id',$qa_id,'b_qa');
            
		}
		echo $qa_id;
	}

	public function actionIsHotQa()
	{
		$qa_id=isset($_POST['qa_id']) ? intval($_POST['qa_id']) : 0;
		if($qa_id!=0)
		{
			$detail = Qa::getQaById($qa_id);
			if($detail['is_hot']==1) $is_hot = 0;
			else $is_hot = 1;
			$array_input = array('is_hot'=>$is_hot);
			$result = CommonModel::updateObject($array_input,'id',$qa_id,'b_qa');
           
		}
		echo $qa_id;
	}

	public function actionDeleteQa()
	{
		$qa_id = isset($_POST['qa_id']) ? intval($_POST['qa_id']) : 0;
		if($qa_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$qa_id),'b_qa');
		}
		echo $qa_id;
	}
	
	//Quang cao
	public function actionAddAds()
	{
		$ads_id = isset($_POST["ads_id"]) ? intval($_POST["ads_id"]) : 0;
		$cat_id = isset($_POST["cat_id"]) ? intval($_POST["cat_id"]) : 0;
		$model_id = isset($_POST["model_id"]) ? intval($_POST["model_id"]) : 0;
		$title = isset($_POST["title"]) ? $_POST["title"]:'';
		$introtext = isset($_POST["introtext"]) ? $_POST["introtext"]:'';
		$introtext = preg_replace('/\n/si', '<br>', $introtext);
		$picture = isset($_POST["picture"]) ? $_POST["picture"]:'';
		$ads_link = isset($_POST["ads_link"]) ? $_POST["ads_link"]:'';
		$ads_alignment = isset($_POST["ads_alignment"]) ? $_POST["ads_alignment"] : '';
		$create_date=time();

		$admin_id = Yii::app()->user->id;
		$admin_name = Yii::app()->user->name;

		$array_input = array('cat_id'=>$cat_id, 'title'=>mysql_escape_string($title),'introtext'=>mysql_escape_string($introtext),'picture'=>mysql_escape_string($picture),'ads_link'=>mysql_escape_string($ads_link),'ads_alignment'=>mysql_escape_string($ads_alignment),'status'=>'active','admin_name'=>mysql_escape_string($admin_name), 'admin_id'=>$admin_id, 'model_id'=>$model_id);
		
		if($ads_id!=0)
		{
			$edit_date = $create_date;
			$array_input['edit_date'] = $edit_date;
			CommonModel::updateObject($array_input,'id',$ads_id,'b_ads');
		}
		else
		{
			$array_input['create_date']=$create_date;
			$array_input['edit_date']=$create_date;
			$ads_id = CommonModel::insertObject($array_input,'b_ads');
		}
		echo $ads_id;
	}
	
	public function actionIsActiveAds()
	{
		$ads_id=isset($_POST['ads_id']) ? intval($_POST['ads_id']) : 0;
		if($ads_id!=0)
		{
			$detail = Ads::getAdsById($ads_id);
			if($detail['status']=='active') $status = 'pending';
			else $status = 'active';
			$array_input=array('status'=>$status);
			$result=CommonModel::updateObject($array_input,'id',$ads_id,'b_ads');
            
		}
		echo $ads_id;
	}

	public function actionIsHotAds()
	{
		$ads_id=isset($_POST['ads_id']) ? intval($_POST['ads_id']) : 0;
		if($ads_id!=0)
		{
			$detail = Ads::getAdsById($ads_id);
			if($detail['is_hot']==1) $is_hot=0;
			else $is_hot=1;
			$array_input=array('is_hot'=>$is_hot);
			$result=CommonModel::updateObject($array_input,'id',$ads_id,'b_ads');
           
		}
		echo $ads_id;
	}
	/*
	public function actionDeleteAds()
	{
		$ads_id=isset($_POST['ads_id']) ? intval($_POST['ads_id']) : 0;
		if($ads_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$ads_id),'b_ads');
		}
		echo $ads_id;
	}
	*/
	//Thanh vien
	
	public function actionIsActiveUser()
	{
		$user_id=isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
		if($user_id!=0)
		{
			$detail = User::getUserById($user_id);
			if($detail['status']==1) $status = 0;
			else $status = 1;
			$array_input=array('status'=>$status);
			$result=CommonModel::updateObject($array_input,'id',$user_id,'b_user');
            
		}
		echo $user_id;
	}
	/*
	public function actionDeleteUser()
	{
		$user_id=isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
		if($user_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$user_id),'b_user');
		}
		echo $user_id;
	}
	*/
	
	public function actionAddModel()
	{
		$model_id = isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
		$is_chinh_hang = isset($_POST['is_chinh_hang']) ? intval($_POST['is_chinh_hang']) : 0;
		$is_cong_ty = isset($_POST['is_cong_ty']) ? intval($_POST['is_cong_ty']) : 0;
		$text_chinh_hang = isset($_POST['text_chinh_hang']) ? $_POST['text_chinh_hang'] : '';
		$cat_id = isset($_POST['cat_id']) ? intval($_POST['cat_id']) : 0;
		$brand_id = isset($_POST['brand_id']) ? intval($_POST['brand_id']) : 0;
		$title = isset($_POST['title']) ? $_POST['title'] : '';		
		$alias = Common::generate_slug($title);
		$publish_date = isset($_POST['publish_date']) ? $_POST['publish_date'] : '';
		
		$create_date = time();
		if($publish_date!='')
		{
			$publish_date=explode('/',$publish_date);
			$publish_date=mktime(0,0,0,$publish_date[1],$publish_date[0],$publish_date[2]);
		}
		else
		{
			$publish_date = $create_date;
		}
		
		$introtext = isset($_POST['introtext']) ? $_POST['introtext'] : '';
		$introtext = preg_replace('/\n/si', '<br>', $introtext);
		$description = isset($_POST['description']) ? $_POST['description'] : '';
		$specs = isset($_POST['specs']) ? $_POST['specs'] : '';
		$pic_product = isset($_POST['pic_product']) ? $_POST['pic_product'] : '';
		$picture = isset($_POST['picture']) ? $_POST['picture'] : '';
		$html_img=isset($_POST['html_img']) ? $_POST['html_img']:'';
		$user_manual = isset($_POST['user_manual']) ? $_POST['user_manual'] : '';
		$model_video = isset($_POST['model_video']) ? $_POST['model_video'] : '';
		
		$status = isset($_POST['status']) ? $_POST['status'] : 'active';		
		
		$list_access_id = isset($_POST['list_access_id']) ? $_POST['list_access_id']: '';
		$list_access_id=explode(',',$list_access_id);
		
		$admin_id=Yii::app()->user->id;
		$admin_name=Yii::app()->user->name;
		
		$note_public = isset($_POST['note_public']) ? $_POST['note_public'] : '';
		
		//Anh
		preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
		if(!empty($matches))
		{
			$picture = isset($matches[1][0]) ? $matches[1][0] : '';
		}
		else
		{
			$picture = '';
		}
		
		$array_input = array('title'=>mysql_escape_string($title), 'alias'=>mysql_escape_string($alias), 'publish_date'=>$publish_date, 'introtext'=>mysql_escape_string($introtext), 'picture'=>mysql_escape_string($picture), 'model_video'=>mysql_escape_string($model_video), 'cat_id'=>$cat_id, 'brand_id'=>$brand_id, 'status'=>mysql_escape_string($status), 'admin_id'=>$admin_id, 'admin_name'=>mysql_escape_string($admin_name), 'description'=>mysql_escape_string($description), 'pic_product'=>mysql_escape_string($pic_product), 'specs'=>mysql_escape_string($specs), 'is_chinh_hang'=>$is_chinh_hang, 'text_chinh_hang'=>mysql_escape_string($text_chinh_hang), 'user_manual'=>mysql_escape_string($user_manual), 'is_cong_ty'=>$is_cong_ty, 'note_public'=>mysql_escape_string($note_public));
		
		if($model_id!=0)
		{
			$edit_date = time();
			$array_input['edit_date'] = $edit_date;
			$array_input['edit_name'] = $admin_name;
			CommonModel::updateObject($array_input, 'id', $model_id, 'b_model');
			//Delete Anh
			BModelPic::deletePic($model_id);
			//Cap nhat anh
			$sub_sql = '';
			preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
			if(!empty($matches))
			{
				$k = 0;
				$create_date = time();
				
				if(isset($matches[1]))
				foreach($matches[1] as $value)
				{
					$value = mysql_escape_string(trim(strip_tags($value)));
					$sub_sql .= "(".$model_id.", '".$value."', '".$create_date."'),";
				}
				
			}
			if($sub_sql!='')
			{
				$sub_sql = rtrim($sub_sql, ',');
				BModelPic::insertPic($sub_sql);
			}
			
		}
		else
		{
			$array_input['create_date'] = $create_date;
			$model_id = CommonModel::insertObject($array_input, 'b_model');
			if($model_id>0)
			{
				
				//Cap nhat anh
				$sub_sql = '';
				preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
				if(!empty($matches))
				{
					$k = 0;
					$create_date = time();
					
					if(isset($matches[1]))
					foreach($matches[1] as $value)
					{
						$value = mysql_escape_string(trim(strip_tags($value)));
						$sub_sql .= "(".$model_id.", '".$value."', '".$create_date."'),";
					}
					
				}
				if($sub_sql!='')
				{
					$sub_sql = rtrim($sub_sql, ',');
					BModelPic::insertPic($sub_sql);
				}
			}
		}
		
		Access::deleteAccessModelRelated($model_id);
		$sub_sql='';
		$list_id=array();
		if(isset($list_access_id) && !empty($list_access_id))
		foreach($list_access_id as $value)
		{
			if(!in_array($value,$list_id) && $value!='')
			{
				$sub_sql.='('.$model_id.',"'.$value.'",'.$create_date.'),';
				$list_id[]=$value;
			}
		}
		if($sub_sql!='')
		{
			$sub_sql=rtrim($sub_sql,',');
			Access::insertModelAccess($sub_sql);
		}
		
		if($model_id!=0)
		{
			if(isset($create_date) && $create_date!=0)
			{
				$path = date("Y/md/",$create_date);
			}
			else
			{
				$path = date("Y/md/");
			}
			//Save anh ve server (server anh cung server code)
			$folder = 'model';
			$dir_upload = Yii::app()->params['dir_upload'].$folder;
			$description = CommonModel::saveImgToServer($description,$model_id,$path,$dir_upload, $folder);
			$array_update = array('description'=>mysql_escape_string($description));
			CommonModel::updateObject($array_update,'id',$model_id,'b_model');
		}
		echo $model_id;
	}
	/*
	public function actionDeleteModel()
	{
		$model_id=isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
		if($model_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$model_id),'b_model');
		}
		echo $model_id;
	}
	*/
	public function actionIsActiveModel()
	{
		$model_id = isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
		$detail = BModel::getModelById($model_id);
		
		if($detail['status']=='active')
			$status = 'pending';
		else	
			$status = 'active';
		
		$ok = CommonModel::updateObject(array('status'=>$status), 'id', $model_id, 'b_model');
		echo $ok;
	}
	
	//Quan ly Body
	public function actionAddBody()
	{
		$body_id = isset($_POST["body_id"]) ? intval($_POST["body_id"]) : 0;
		$model_id = isset($_POST["model_id"]) ? intval($_POST["model_id"]) : 0;
		$title = isset($_POST["title"]) ? $_POST["title"]:'';		
		$array_input = array('model_id'=>$model_id, 'title'=>mysql_escape_string($title),'status'=>'active');
		
		if($body_id!=0)
		{			
			CommonModel::updateObject($array_input,'id',$body_id,'b_combo_body');
		}
		else
		{			
			$body_id = CommonModel::insertObject($array_input,'b_combo_body');
		}
		echo $body_id;
	}
	
	public function actionIsActiveBody()
	{
		$body_id=isset($_POST['body_id']) ? intval($_POST['body_id']) : 0;
		if($body_id!=0)
		{
			$detail = BBody::getBodyById($body_id);
			if($detail['status']=='active') $status = 'pending';
			else $status = 'active';
			$array_input=array('status'=>$status);
			$result=CommonModel::updateObject($array_input,'id',$body_id,'b_combo_body');
            
		}
		echo $body_id;
	}
	/*
	public function actionDeleteBody()
	{
		$body_id=isset($_POST['body_id']) ? intval($_POST['body_id']) : 0;
		if($body_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$body_id),'b_combo_body');
		}
		echo $body_id;
	}
	*/
	//Quan ly Kit
	public function actionAddKit()
	{
		$kit_id = isset($_POST["kit_id"]) ? intval($_POST["kit_id"]) : 0;
		$model_id = isset($_POST["model_id"]) ? intval($_POST["model_id"]) : 0;
		$title = isset($_POST["title"]) ? $_POST["title"]:'';		
		$array_input = array('model_id'=>$model_id, 'title'=>mysql_escape_string($title),'status'=>'active');
		
		if($kit_id!=0)
		{			
			CommonModel::updateObject($array_input,'id',$kit_id,'b_combo_kit');
		}
		else
		{			
			$kit_id = CommonModel::insertObject($array_input,'b_combo_kit');
		}
		echo $kit_id;
	}
	
	public function actionIsActiveKit()
	{
		$kit_id=isset($_POST['kit_id']) ? intval($_POST['kit_id']) : 0;
		if($kit_id!=0)
		{
			$detail = BKit::getKitById($kit_id);
			if($detail['status']=='active') $status = 'pending';
			else $status = 'active';
			$array_input=array('status'=>$status);
			$result=CommonModel::updateObject($array_input,'id',$kit_id,'b_combo_kit');
            
		}
		echo $kit_id;
	}
	/*
	public function actionDeleteKit()
	{
		$kit_id=isset($_POST['kit_id']) ? intval($_POST['kit_id']) : 0;
		if($kit_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$kit_id),'b_combo_kit');
		}
		echo $kit_id;
	}
	*/
	//Quan ly Brand
	public function actionAddBrand()
	{
		$brand_id = isset($_POST["brand_id"]) ? intval($_POST["brand_id"]) : 0;
		$brand_type = isset($_POST["brand_type"]) ? intval($_POST["brand_type"]) : 0;
		$title = isset($_POST["title"]) ? $_POST["title"]:'';
		$picture = isset($_POST["picture"]) ? $_POST["picture"]:'';
        $alias=isset($_POST['alias'])?$_POST['alias']:'';		
        if($alias=='') $alias=Common::generate_slug($title);
		$array_input = array( 'title'=>mysql_escape_string($title),'alias'=>mysql_escape_string($alias), 'brand_type'=>$brand_type, 'picture'=>mysql_escape_string($picture),'status'=>'active');
		
		if($brand_id!=0)
		{			
			CommonModel::updateObject($array_input,'id',$brand_id,'b_brand');
		}
		else
		{			
			$brand_id = CommonModel::insertObject($array_input,'b_brand');
		}
		echo $brand_id;
	}
	
	public function actionIsActiveBrand()
	{
		$brand_id=isset($_POST['brand_id']) ? intval($_POST['brand_id']) : 0;
		if($brand_id!=0)
		{
			$detail = BBrand::getBrandById($brand_id);
			if($detail['status']=='active') $status = 'pending';
			else $status = 'active';
			$array_input=array('status'=>$status);
			$result=CommonModel::updateObject($array_input,'id',$brand_id,'b_brand');
            
		}
		echo $brand_id;
	}
	/*
	public function actionDeleteBrand()
	{
		$brand_id=isset($_POST['brand_id']) ? intval($_POST['brand_id']) : 0;
		if($brand_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$brand_id),'b_brand');
		}
		echo $brand_id;
	}
	*/
	//Quan ly Color
	public function actionAddColor()
	{
		$color_id = isset($_POST["color_id"]) ? intval($_POST["color_id"]) : 0;
		$model_id = isset($_POST["model_id"]) ? intval($_POST["model_id"]) : 0;
		$title = isset($_POST["title"]) ? $_POST["title"]:'';		
        $code=isset($_POST['code'])?$_POST['code']:'';		
       
		$array_input = array('model_id'=>$model_id, 'title'=>mysql_escape_string($title),'code'=>mysql_escape_string($code),'status'=>'active');
		
		if($color_id!=0)
		{			
			CommonModel::updateObject($array_input,'id',$color_id,'b_combo_color');
		}
		else
		{			
			$color_id = CommonModel::insertObject($array_input,'b_combo_color');
		}
		echo $color_id;
	}
	
	public function actionIsActiveColor()
	{
		$color_id=isset($_POST['color_id']) ? intval($_POST['color_id']) : 0;
		if($color_id!=0)
		{
			$detail = BColor::getColorById($color_id);
			if($detail['status']=='active') $status = 'pending';
			else $status = 'active';
			$array_input=array('status'=>$status);
			$result=CommonModel::updateObject($array_input,'id',$color_id,'b_combo_color');
            
		}
		echo $color_id;
	}
	/*
	public function actionDeleteColor()
	{
		$color_id=isset($_POST['color_id']) ? intval($_POST['color_id']) : 0;
		if($color_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$color_id),'b_combo_color');
		}
		echo $color_id;
	}
	*/
	//Quan ly Khách hàng
	public function actionAddCustomer()
	{
		$camera_id = isset($_POST["camera_id"]) ? intval($_POST["camera_id"]) : 0;
		$access_id = isset($_POST["access_id"]) ? intval($_POST["access_id"]) : 0;
		$customer_id = isset($_POST["customer_id"]) ? intval($_POST["customer_id"]) : 0;
		$title = isset($_POST["title"]) ? $_POST["title"]:'';
		$mobile = isset($_POST["mobile"]) ? $_POST["mobile"]:'';
		$address = isset($_POST["address"]) ? $_POST["address"]:'';
		$email = isset($_POST["email"]) ? $_POST["email"]:'';
		$city_id = isset($_POST["city_id"]) ? intval($_POST["city_id"]):0;
		$city_info = BCity::getCityById($city_id);
		$city_title = isset($city_info['title']) ? $city_info['title']: '';
		$array_input = array('title'=>mysql_escape_string($title), 'mobile'=>mysql_escape_string($mobile), 'address'=>mysql_escape_string($address),'city_id'=>$city_id, 'city_title'=>mysql_escape_string($city_title), 'email'=>mysql_escape_string($email));
		
		if($customer_id!=0)
		{			
			CommonModel::updateObject($array_input,'id',$customer_id,'b_customer');
		}
		else
		{			
			$customer_id = CommonModel::insertObject($array_input,'b_customer');
			if($camera_id!=0)
			{
				CommonModel::insertObject(array('customer_id'=>$customer_id,'camera_id'=>$camera_id),'b_customer_camera');
			}
			if($access_id!=0)
			{
				CommonModel::insertObject(array('customer_id'=>$customer_id,'access_id'=>$access_id),'b_customer_access');
			}
		}
		echo $customer_id;
	}
	/*
	public function actionDeleteCustomer()
	{
		$customer_id=isset($_POST['customer_id']) ? intval($_POST['customer_id']) : 0;
		if($customer_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$customer_id),'b_customer');
		}
		echo $customer_id;
	}
	*/
	public function actionAddSale()
	{
		$camera_id = isset($_POST["camera_id"]) ? intval($_POST["camera_id"]) : 0;
		$detail = BList::getListById($camera_id);
		$price_in = isset($detail['price_in']) ? $detail['price_in']:0;
		
		$status_sale = isset($_POST["status_sale"]) ? intval($_POST["status_sale"]) : 0;
		$customer_id = isset($_POST["customer_id"]) ? intval($_POST["customer_id"]) : 0;
		$is_customer = isset($_POST["is_customer"]) ? intval($_POST["is_customer"]) : 0;
		$price_buy = isset($_POST["price_buy"]) ? $_POST["price_buy"]:'';
		
		$tien_mat = isset($_POST["tien_mat"]) ? $_POST["tien_mat"]:'';
		$chuyen_khoan = isset($_POST["chuyen_khoan"]) ? $_POST["chuyen_khoan"]:'';
		$quet_the = isset($_POST["quet_the"]) ? $_POST["quet_the"]:'';
		$is_lazada = isset($_POST["is_lazada"]) ? intval($_POST["is_lazada"]):0;
		$lazada_code = isset($_POST["lazada_code"]) ? $_POST["lazada_code"]:'';
		
		$title = isset($_POST["title"]) ? $_POST["title"]:'';
		$mobile = isset($_POST["mobile"]) ? $_POST["mobile"]:'';
		$address = isset($_POST["address"]) ? $_POST["address"]:'';
		$email = isset($_POST["email"]) ? $_POST["email"]:'';
		$city_id = isset($_POST["city_id"]) ? intval($_POST["city_id"]):0;
		$city_info = BCity::getCityById($city_id);
		$city_title = isset($city_info['title']) ? $city_info['title']: '';
		$time_buy = time();
		$day = date('d');
		$month = date('m');
		$year = date('Y');
		//Cap nhat gia ban
		CommonModel::updateObject(array('price_buy'=>$price_buy, 'status_sale'=>$status_sale, 'is_sale'=>1, 'time_buy'=>$time_buy),'id',$camera_id,'b_camera');
		//Insert log mua ban
		$array_log = array('camera_id'=>$camera_id, 'price_in'=>$price_in, 'price_buy'=>$price_buy, 'status_sale'=>$status_sale, 'time_buy'=>$time_buy, 'day'=>$day, 'month'=>$month, 'year'=>$year, 'is_lazada'=>$is_lazada,'lazada_code'=>mysql_escape_string($lazada_code));
		CommonModel::insertObject($array_log,'b_camera_sale');
		//Cap nhat thong tin khach hang
		if($is_customer==0)
		{
			$array_customer = array('customer_id'=>$customer_id, 'camera_id'=>$camera_id);
			CommonModel::insertObject(array('customer_id'=>$customer_id,'camera_id'=>$camera_id),'b_customer_camera');
		}
		else
		{
			$array_input = array('title'=>mysql_escape_string($title), 'mobile'=>mysql_escape_string($mobile), 'address'=>mysql_escape_string($address),'city_id'=>$city_id, 'city_title'=>mysql_escape_string($city_title), 'email'=>mysql_escape_string($email));
			$customer_id = CommonModel::insertObject($array_input,'b_customer');
			if($customer_id!=0)
			{
				CommonModel::insertObject(array('customer_id'=>$customer_id,'camera_id'=>$camera_id),'b_customer_camera');
			}
		}		
		//Log chi phi theo ngay
		if($status_sale==0) // Chi tinh truong hop ban le
		{
			$hinh_thuc = '';
			if($tien_mat!=0) $hinh_thuc .=' Tiền mặt:'.Common::formatNumber($tien_mat);
			if($chuyen_khoan!=0) $hinh_thuc .=' Chuyển khoản:'.Common::formatNumber($chuyen_khoan);
			if($quet_the!=0) $hinh_thuc .=' Quẹt thẻ:'.Common::formatNumber($quet_the);
			if($is_lazada==1) $hinh_thuc .=' Lazada';
			$title_money = 'Bán '.$detail['title'].' giá'.Common::formatNumber($price_buy).'. Hình thức:'.$hinh_thuc;
			$array_money_vn = array('title'=>mysql_escape_string($title_money), 'tien_mat'=>$tien_mat, 'chuyen_khoan'=>$chuyen_khoan, 'quet_the'=>$quet_the, 'is_lazada'=>$is_lazada, 'status'=>1, 'create_date'=>time(), 'day'=>$day, 'month'=>$month, 'year'=>$year, 'money'=>$price_buy);
			
			CommonModel::insertObject($array_money_vn,'b_money_vn');
		}
		//Cap nhat san pham cho hoa don
		$bill_id = isset($_POST["bill_id"]) ? intval($_POST["bill_id"]):0;
		if($bill_id!=0)
		{
			$array_input = array('bill_id'=>$bill_id, 'product_id'=>$camera_id, 'product_type'=>0, 'create_date'=>time());
			CommonModel::insertObject($array_input, 'tbl_bill_product');
		}
		
		echo 1;
		exit();
	}
	
	//Quan ly phu kien
	
	public function actionAddAccess()
	{
		$access_id = isset($_POST['access_id']) ? intval($_POST['access_id']) : 0;
		$cat_id = isset($_POST['cat_id']) ? intval($_POST['cat_id']) : 0;
		$brand_id = isset($_POST['brand_id']) ? intval($_POST['brand_id']) : 0;
		$num_p = isset($_POST['num_p']) ? intval($_POST['num_p']) : 0;
		$title = isset($_POST['title']) ? $_POST['title'] : '';
		$title_other = isset($_POST['title_other']) ? $_POST['title_other'] : '';
		$alias = Common::generate_slug($title);
		$publish_date = isset($_POST['publish_date']) ? $_POST['publish_date'] : '';
		$time_deal = isset($_POST['time_deal']) ? $_POST['time_deal'] : '';
		
		$create_date = time();
		if($publish_date!='')
		{
			$publish_date=explode('/',$publish_date);
			$publish_date=mktime(0,0,0,$publish_date[1],$publish_date[0],$publish_date[2]);
		}
		else
		{
			$publish_date = $create_date;
		}
		
		if($time_deal!='')
		{
			$time_deal=explode('/',$time_deal);
			$time_deal=mktime(0,0,0,$time_deal[1],$time_deal[0],$time_deal[2]);
		}
		else
		{
			$time_deal = $create_date;
		}
		
		$introtext = isset($_POST['introtext']) ? $_POST['introtext'] : '';
		$introtext = preg_replace('/\n/si', '<br>', $introtext);
		$description = isset($_POST['description']) ? $_POST['description'] : '';
		$specs = isset($_POST['specs']) ? $_POST['specs'] : '';
		$pic_product = isset($_POST['pic_product']) ? $_POST['pic_product'] : '';
		$picture = isset($_POST['picture']) ? $_POST['picture'] : '';
		$html_img=isset($_POST['html_img']) ? $_POST['html_img']:'';
		
		$access_video = isset($_POST['access_video']) ? $_POST['access_video'] : '';
		$keyword = isset($_POST['keyword']) ? $_POST['keyword'] : '';
		$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
		$in_the_box = isset($_POST['in_the_box']) ? $_POST['in_the_box'] : '';
		$time_bh = isset($_POST['time_bh']) ? $_POST['time_bh'] : '';
		$status = isset($_POST['status']) ? $_POST['status'] : 'active';		
		
		$price_in = isset($_POST['price_in']) ? $_POST['price_in'] : '';
		$price = isset($_POST['price']) ? $_POST['price'] : '';
		$price_buy = isset($_POST['price_buy']) ? $_POST['price_buy'] : '';
		$price_deal = isset($_POST['price_deal']) ? $_POST['price_deal'] : '';		
		$link_web = isset($_POST['link_web']) ? $_POST['link_web'] : '';
		
		
		$admin_id=Yii::app()->user->id;
		$admin_name=Yii::app()->user->name;
		
		//Anh
		preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
		if(!empty($matches))
		{
			$picture = isset($matches[1][0]) ? $matches[1][0] : '';
		}
		else
		{
			$picture = '';
		}
		
		$array_input = array('title'=>mysql_escape_string($title),'title_other'=>mysql_escape_string($title_other), 'alias'=>mysql_escape_string($alias), 'publish_date'=>$publish_date, 'introtext'=>mysql_escape_string($introtext), 'picture'=>mysql_escape_string($picture), 'access_video'=>mysql_escape_string($access_video), 'cat_id'=>$cat_id, 'status'=>mysql_escape_string($status), 'admin_id'=>$admin_id, 'admin_name'=>mysql_escape_string($admin_name), 'keyword'=>mysql_escape_string($keyword), 'description'=>mysql_escape_string($description), 'pic_product'=>mysql_escape_string($pic_product), 'specs'=>mysql_escape_string($specs),'price'=>$price,'price_in'=>$price_in,'price_buy'=>$price_buy,'price_deal'=>$price_deal, 'time_deal'=>$time_deal, 'num_p'=>$num_p, 'brand_id'=>$brand_id, 'rating'=>$rating,'in_the_box'=>mysql_escape_string($in_the_box),'time_bh'=>mysql_escape_string($time_bh),'link_web'=>mysql_escape_string($link_web));
		
		if($access_id!=0)
		{
			$detail = Access::getAccessById($access_id);
			if($detail['num_p']>$detail['num_buy'])
			{
				$array_input['status_buy'] = 1;
			}
			else
			{
				$array_input['status_buy'] = 0;
			}
			$edit_date = time();
			$array_input['edit_date'] = $edit_date;
			$array_input['edit_name'] = $admin_name;
			CommonModel::updateObject($array_input, 'id', $access_id, 'b_accessories');
			//Delete Anh
			AccessPic::deletePic($access_id);
			//Cap nhat anh
			$sub_sql = '';
			preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
			if(!empty($matches))
			{
				$k = 0;
				$create_date = time();
				
				if(isset($matches[1]))
				foreach($matches[1] as $value)
				{
					$value = mysql_escape_string(trim(strip_tags($value)));
					$sub_sql .= "(".$access_id.", '".$value."', '".$create_date."'),";
				}
			}
			if($sub_sql!='')
			{
				$sub_sql = rtrim($sub_sql, ',');
				AccessPic::insertPic($sub_sql);
			}
			
			//Cap nhat gia ban cho khach hang
			AccessSale::updateAccessSale($price_buy, $price_in, $access_id, 0);
		}
		else
		{
			$array_input['create_date'] = $create_date;
			$access_id = CommonModel::insertObject($array_input, 'b_accessories');
			if($access_id>0)
			{
				
				//Cap nhat anh
				$sub_sql = '';
				preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
				if(!empty($matches))
				{
					$k = 0;
					$create_date = time();
					
					if(isset($matches[1]))
					foreach($matches[1] as $value)
					{
						$value = mysql_escape_string(trim(strip_tags($value)));
						$sub_sql .= "(".$access_id.", '".$value."', '".$create_date."'),";
					}
					
				}
				if($sub_sql!='')
				{
					$sub_sql = rtrim($sub_sql, ',');
					AccessPic::insertPic($sub_sql);
				}
			}
		}
		
		if($access_id!=0)
		{
			if(isset($create_date) && $create_date!=0)
			{
				$path = date("Y/md/",$create_date);
			}
			else
			{
				$path = date("Y/md/");
			}
			//Save anh ve server (server anh cung server code)
			$folder = 'model';
			$dir_upload = Yii::app()->params['dir_upload'].$folder;
			$description = CommonModel::saveImgToServer($description,$access_id,$path,$dir_upload, $folder);
			$array_update = array('description'=>mysql_escape_string($description));
			CommonModel::updateObject($array_update,'id',$access_id,'b_accessories');
		}
		echo $access_id;
	}
	/*
	public function actionDeleteAccess()
	{
		$access_id=isset($_POST['access_id']) ? intval($_POST['access_id']) : 0;
		if($access_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$access_id),'b_accessories');
		}
		echo $access_id;
	}
	*/
	public function actionIsActiveAccess()
	{
		$access_id = isset($_POST['access_id']) ? intval($_POST['access_id']) : 0;
		$detail = Access::getAccessById($access_id);
		
		if($detail['status']=='active')
			$status = 'pending';
		else	
			$status = 'active';
		
		$ok = CommonModel::updateObject(array('status'=>$status), 'id', $access_id, 'b_accessories');
		echo $ok;
	}
	
	public function actionUpdateOrderAccess()
    {            
		$list_order=isset($_POST['list_order']) ? $_POST['list_order']:'';
		$list_order=rtrim($list_order,',');
		$list_order=explode(',',$list_order);
		$ok=true;
					
		if($list_order)
		{
			foreach($list_order as $row)
			{
				$value=explode('|',$row);
				$ok = Access::updateOrderAccess($value[0],$value[1]);             
			}
			if($ok>=0)
			{
				$ok=$ok and true;
			}   
			else
				$ok=$ok and false;
		}
    }
	
	public function actionAddSaleAccess()
	{
		$color_id = isset($_POST["color_id"]) ? intval($_POST["color_id"]) : 0; //Ban mau gi
		$access_id = isset($_POST["access_id"]) ? intval($_POST["access_id"]) : 0;
		
		$tien_mat = isset($_POST["tien_mat"]) ? $_POST["tien_mat"]:'';
		$chuyen_khoan = isset($_POST["chuyen_khoan"]) ? $_POST["chuyen_khoan"]:'';
		$quet_the = isset($_POST["quet_the"]) ? $_POST["quet_the"]:'';
		$is_lazada = isset($_POST["is_lazada"]) ? intval($_POST["is_lazada"]):0;
		$lazada_code = isset($_POST["lazada_code"]) ? $_POST["lazada_code"]:'';
		$detail = Access::getAccessById($access_id);
		
		$num_buy_current = $detail['num_buy']; //So luong ban hien tai
		$num_p = $detail['num_p']; //So luong nhap
		$num_buy = isset($_POST["num_buy"]) ? intval($_POST["num_buy"]) : 0;
		if($num_buy>$num_p)
		{
			echo 'Số lượng bán lớn hơn số lượng hàng nhập!';
			exit();
		}
		if($num_buy+$num_buy_current>$num_p)
		{
			echo 'Kiểm tra lại hàng tồn, hiện tại số lượng bán không còn đủ!';
			exit();
		}
		$status_buy = 1;
		if($num_buy+$num_buy_current==$num_p) //Het hang
		{
			$status_buy=0;
		}
		//
		$price_in = isset($detail['price_in']) ? $detail['price_in'] : 0; //Gia nhap
		if($color_id!=0)
		{
			$info_color = AccessColor::getColorById($color_id);
			$price_in = isset($info_color['price_in']) ? $info_color['price_in'] : 0;
			
			if($num_buy>$info_color['num_p'])
			{
				echo 'Số lượng bán lớn hơn số lượng hàng nhập!';
				exit();
			}
			
			if(($info_color['num_buy']+$num_buy)>$info_color['num_p'])
			{
				echo 'Kiểm tra lại hàng tồn, hiện tại số lượng bán không còn đủ!';
				exit();
			}
				
		}
		$customer_id = isset($_POST["customer_id"]) ? intval($_POST["customer_id"]) : 0;
		$is_customer = isset($_POST["is_customer"]) ? intval($_POST["is_customer"]) : 0;
		$price_buy = isset($_POST["price_buy"]) ? $_POST["price_buy"]:'';
		$title = isset($_POST["title"]) ? $_POST["title"]:'';
		$mobile = isset($_POST["mobile"]) ? $_POST["mobile"]:'';
		$address = isset($_POST["address"]) ? $_POST["address"]:'';
		$email = isset($_POST["email"]) ? $_POST["email"]:'';
		$city_id = isset($_POST["city_id"]) ? intval($_POST["city_id"]):0;
		$city_info = BCity::getCityById($city_id);
		$city_title = isset($city_info['title']) ? $city_info['title']: '';
		$time_buy = time();
		$day = date('d');
		$month = date('m');
		$year = date('Y');
		//Cap nhat số lượng bán
		CommonModel::updateObject(array('num_buy'=>$num_buy+$num_buy_current, 'status_buy'=>$status_buy),'id',$access_id,'b_accessories');
		if($color_id!=0)
		{
			$num_buy_current_color = isset($info_color['num_buy']) ? $info_color['num_buy']:0;
			$num_p_color = isset($info_color['num_p']) ? $info_color['num_p']:0;
			$status_buy_color = 1;
			if(($num_buy+$num_buy_current_color)==$num_p_color) //Het hang
			{
				$status_buy_color=0;
			}
			
			CommonModel::updateObject(array('num_buy'=>$num_buy+$num_buy_current_color, 'status_buy'=>$status_buy_color),'id',$color_id,'b_accessories_color');
		}
		//Cap nhat log
		$array_insert_log = array('access_id'=>$access_id, 'price_buy'=>$price_buy, 'num_buy'=>$num_buy, 'time_buy'=>$time_buy, 'color_id'=>$color_id, 'price_in'=>$price_in, 'day'=>$day, 'month'=>$month, 'year'=>$year, 'is_lazada'=>$is_lazada,'lazada_code'=>mysql_escape_string($lazada_code));
		CommonModel::insertObject($array_insert_log,'b_accessories_sale');
		
		//Cap nhat thong tin khach hang
		if($is_customer==0)//Da ton tai thong tin khach hang
		{
			$array_customer = array('customer_id'=>$customer_id, 'access_id'=>$access_id);
			CommonModel::insertObject($array_customer,'b_customer_access');
		}
		else
		{
			$array_input = array('title'=>mysql_escape_string($title), 'mobile'=>mysql_escape_string($mobile), 'address'=>mysql_escape_string($address),'city_id'=>$city_id, 'city_title'=>mysql_escape_string($city_title), 'email'=>mysql_escape_string($email));
			$customer_id = CommonModel::insertObject($array_input,'b_customer');
			if($customer_id!=0)
			{
				CommonModel::insertObject(array('customer_id'=>$customer_id,'access_id'=>$access_id),'b_customer_access');
			}
		}
		
		//Log chi phi theo ngay
		$hinh_thuc = '';
		if($tien_mat!=0) $hinh_thuc .=' Tiền mặt:'.Common::formatNumber($tien_mat);
		if($chuyen_khoan!=0) $hinh_thuc .=' Chuyển khoản:'.Common::formatNumber($chuyen_khoan);
		if($quet_the!=0) $hinh_thuc .=' Quẹt thẻ:'.Common::formatNumber($quet_the);
		if($is_lazada==1) $hinh_thuc .=' Lazada';
		$title_money = 'Bán '.$detail['title'].' giá'.Common::formatNumber($price_buy).'. Hình thức:'.$hinh_thuc;
		$array_money_vn = array('title'=>mysql_escape_string($title_money), 'tien_mat'=>$tien_mat, 'chuyen_khoan'=>$chuyen_khoan, 'quet_the'=>$quet_the, 'is_lazada'=>$is_lazada, 'status'=>1, 'create_date'=>time(), 'day'=>$day, 'month'=>$month, 'year'=>$year, 'money'=>$price_buy);
		
		CommonModel::insertObject($array_money_vn,'b_money_vn');
		
		//Cap nhat san pham cho hoa don
		$bill_id = isset($_POST["bill_id"]) ? intval($_POST["bill_id"]):0;
		if($bill_id!=0)
		{
			if($color_id!=0)
			{
				$array_input = array('bill_id'=>$bill_id, 'product_id'=>$color_id, 'product_type'=>2, 'create_date'=>time());
			}
			else
			{
				$array_input = array('bill_id'=>$bill_id, 'product_id'=>$access_id, 'product_type'=>1, 'create_date'=>time());
			}
			CommonModel::insertObject($array_input, 'tbl_bill_product');
		}
		
		echo 1;
		exit();
	}
	
	public function actionAddColorAccess()
	{
		$access_id = isset($_POST['access_id']) ? intval($_POST['access_id']) : 0;
		$color_id = isset($_POST['color_id']) ? intval($_POST['color_id']) : 0;
		$color = isset($_POST['color']) ? $_POST['color'] : '';
		$time_deal = isset($_POST['time_deal']) ? $_POST['time_deal'] : '';
		$create_date = time();
		if($time_deal!='')
		{
			$time_deal=explode('/',$time_deal);
			$time_deal=mktime(0,0,0,$time_deal[1],$time_deal[0],$time_deal[2]);
		}
		else
		{
			$time_deal = $create_date;
		}
		
		$picture = isset($_POST['picture']) ? $_POST['picture'] : '';
		$html_img=isset($_POST['html_img']) ? $_POST['html_img']:'';
		
		//Anh
		preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
		if(!empty($matches))
		{
			$picture = isset($matches[1][0]) ? $matches[1][0] : '';
		}
		else
		{
			$picture = '';
		}
		
		$num_p = isset($_POST['num_p']) ? $_POST['num_p'] : '';
		$price_in = isset($_POST['price_in']) ? $_POST['price_in'] : '';
		$price = isset($_POST['price']) ? $_POST['price'] : '';
		$price_deal = isset($_POST['price_deal']) ? $_POST['price_deal'] : '';
		$price_buy = isset($_POST['price_buy']) ? $_POST['price_buy'] : '';
		
		$array_input = array('color'=>mysql_escape_string($color),'access_id'=>$access_id,'create_date'=>$create_date, 'picture'=>mysql_escape_string($picture),'price'=>$price,'price_in'=>$price_in, 'price_buy'=>$price_buy,'price_deal'=>$price_deal, 'time_deal'=>$time_deal, 'num_p'=>$num_p);
		
		if($color_id!=0)
		{
			$detail = AccessColor::getColorById($color_id);
			if($detail['num_p']>$detail['num_buy'])
			{
				$array_input['status_buy'] = 1;
			}
			else
			{
				$array_input['status_buy'] = 0;
			}
			$edit_date = time();
			$array_input['edit_date'] = $edit_date;
			CommonModel::updateObject($array_input, 'id', $color_id, 'b_accessories_color');
			//Delete Anh
			AccessColor::deletePic($color_id);
			//Cap nhat anh
			$sub_sql = '';
			preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
			if(!empty($matches))
			{
				$k = 0;
				$create_date = time();
				
				if(isset($matches[1]))
				foreach($matches[1] as $value)
				{
					$value = mysql_escape_string(trim(strip_tags($value)));
					$sub_sql .= "(".$color_id.", '".$value."', '".$create_date."'),";
				}
			}
			if($sub_sql!='')
			{
				$sub_sql = rtrim($sub_sql, ',');
				AccessColor::insertPic($sub_sql);
			}
			
			AccessSale::updateAccessSale($price_buy, $price_in, $access_id, $color_id);
			
		}
		else
		{
			$array_input['create_date'] = $create_date;
			$color_id = CommonModel::insertObject($array_input, 'b_accessories_color');
			if($color_id>0)
			{
				//Cap nhat anh
				$sub_sql = '';
				preg_match_all('/alt=["](.*?)["]/si',$html_img, $matches);
				if(!empty($matches))
				{
					$k = 0;
					$create_date = time();
					
					if(isset($matches[1]))
					foreach($matches[1] as $value)
					{
						$value = mysql_escape_string(trim(strip_tags($value)));
						$sub_sql .= "(".$color_id.", '".$value."', '".$create_date."'),";
					}
					
				}
				if($sub_sql!='')
				{
					$sub_sql = rtrim($sub_sql, ',');
					AccessColor::insertPic($sub_sql);
				}
			}
		}
		
		
		echo $color_id;
	}
	
	public function actionDeleteColorAccess()
	{
		$color_id=isset($_POST['color_id']) ? intval($_POST['color_id']) : 0;
		if($color_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$color_id),'b_accessories_color');
		}
		echo $color_id;
	}
	
	public function actionLoadNumP()
	{
		$color_id = isset($_POST['color_id']) ? intval($_POST['color_id']) : 0;
		$num_p_sub = 0;
		$detail = AccessColor::getColorById($color_id);
		if($detail) $num_p_sub = $detail['num_p'] - $detail['num_buy'];
		echo $num_p_sub;
	}
	
	public function actionPagingAccess()
    {
    	if(isset($_POST["keyword"]))
		{
	        /* Lay danh sach chuyen muc */
			$cats = $this->cats;
			$keyword = isset($_POST["keyword"]) ? trim(strip_tags($_POST["keyword"])) : '';
			$cat_id = isset($_POST["cat_id"]) ? intval($_POST["cat_id"]) : 0;
	        $page = intval($_POST["page"]);
	        $num_per_page = intval($_POST["numperpage"]);
	        
	        /* Lấy danh sách su kien */
	        list($access, $total) = Access::getAccessPopup($keyword,$cat_id,$page,$num_per_page);
	        $num_page = ceil($total/$num_per_page);
	        
	        $this->render(
	            "paging_access"
		            , array(
	            	"cats"=>$cats
	                , "access"=>$access
	                , 'num_page'=>$num_page
	                , 'page'=>$page
	                , 'num_per_page'=>$num_per_page
	            )
	        );
    	}     	   
    }
	
	public function actionAddMoneyJapan()
	{
		$money_id = isset($_POST["money_id"]) ? intval($_POST["money_id"]) : 0;
		$type = isset($_POST["type"]) ? intval($_POST["type"]) : 0;//Loai chi tieu
		$title = isset($_POST["title"]) ? $_POST["title"]:'';
		$description = isset($_POST["description"]) ? $_POST["description"]:'';
        $money_send_japan=isset($_POST['money_send_japan'])?$_POST['money_send_japan']:0;		
       	$money_rate=isset($_POST['money_rate'])?$_POST['money_rate']:0;		
		$money_yen_received_japan=isset($_POST['money_yen_received_japan'])?$_POST['money_yen_received_japan']:0;		
		$create_date = time();
		$day = date('d');
		$month = date('m');
		$year = date('Y');
		$array_input = array('title'=>mysql_escape_string($title), 'description'=>mysql_escape_string($description),'money_send_japan'=>$money_send_japan, 'money_rate'=>$money_rate, 'money_yen_received_japan'=>$money_yen_received_japan, 'create_date'=>$create_date, 'day'=>$day, 'month'=>$month, 'year'=>$year, 'type'=>$type);
		
		if($money_id!=0)
		{			
			CommonModel::updateObject($array_input,'id',$money_id,'b_money_japan_detail');
			//BMoneyJapan::updateMoneyJapan($money_yen_received_japan);
		}
		else
		{			
			$money_id = CommonModel::insertObject($array_input,'b_money_japan_detail');
			BMoneyJapan::updateMoneyJapan($money_yen_received_japan, $type);
		}
		echo $money_id;
	}
	
	/*
	public function actionDeleteMoneyJapan()
	{
		$money_id=isset($_POST['money_id']) ? intval($_POST['money_id']) : 0;
		if($money_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$money_id),'b_money_japan_detail');
		}
		echo $money_id;
	}
	*/
	public function actionAddMoneyVn()
	{
		$money_id = isset($_POST["money_id"]) ? intval($_POST["money_id"]) : 0;
		$is_day = isset($_POST["is_day"]) ? intval($_POST["is_day"]) : 0;
		$is_month = isset($_POST["is_month"]) ? intval($_POST["is_month"]) : 0;
		$title = isset($_POST["title"]) ? $_POST["title"]:'';		
        $money=isset($_POST['money'])?$_POST['money']:0;		
       	$description=isset($_POST['description']) ? $_POST['description']:'';		
		$status=isset($_POST['status']) ? intval($_POST['status']):0;		
		$create_date = time();
		if($is_day==0) $is_month = 1;
		$array_input = array('title'=>mysql_escape_string($title),'description'=>mysql_escape_string($description), 'money'=>$money, 'create_date'=>$create_date, 'day'=>date('d'), 'month'=>date('m'), 'year'=>date('Y'), 'status'=>$status, 'is_month'=>$is_month);
		
		if($money_id!=0)
		{			
			CommonModel::updateObject($array_input,'id',$money_id,'b_money_vn');
		}
		else
		{			
			$money_id = CommonModel::insertObject($array_input,'b_money_vn');
		}
		echo $money_id;
	}
	
	/*
	public function actionDeleteMoneyVn()
	{
		$money_id=isset($_POST['money_id']) ? intval($_POST['money_id']) : 0;
		if($money_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$money_id),'b_money_vn');
		}
		echo $money_id;
	}
	*/
	//Timeline
	public function actionAddTimeline()
	{
		$timeline_id = isset($_POST['timeline_id']) ? intval($_POST['timeline_id']) : 0;
		$object_type = isset($_POST['object_type']) ? intval($_POST['object_type']) : 0;
		$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
		$title = isset($_POST['title']) ? $_POST['title'] : '';
		$title_box = isset($_POST['title_box']) ? $_POST['title_box'] : '';
		$links = isset($_POST['links']) ? $_POST['links'] : '';
		$publish_date = isset($_POST['publish_date']) ? $_POST['publish_date'] : '';
		
		$price = isset($_POST['price']) ? $_POST['price'] : 0;
		
		$create_date = time();
		
		if($publish_date!='')
		{
			$publish_date=explode('/',$publish_date);
			$publish_date=mktime(0,0,0,$publish_date[1],$publish_date[0],$publish_date[2]);
		}
		else
		{
			$publish_date = $create_date;
		}
		$edit_date = $create_date;
		
		$picture = isset($_POST['picture']) ? $_POST['picture'] : '';		
		$embed_video = isset($_POST['embed_video']) ? $_POST['embed_video'] : '';		
		$status = isset($_POST['status']) ? $_POST['status'] : 'active';		
		
		$array_input = array('title'=>mysql_escape_string($title), 'title_box'=>mysql_escape_string($title_box), 'links'=>mysql_escape_string($links), 'embed_video'=>mysql_escape_string($embed_video), 'picture'=>mysql_escape_string($picture), 'object_type'=>$object_type, 'status'=>mysql_escape_string($status), 'rating'=>$rating, 'price'=>$price);
		
		if($timeline_id!=0)
		{
			$edit_date = time();
			$array_input['edit_date'] = $edit_date;
			CommonModel::updateObject($array_input, 'id', $timeline_id, 'b_timeline');
			
			
		}
		else
		{
			$array_input['publish_date'] = $publish_date;
			$array_input['create_date'] = $create_date;
			$array_input['edit_date'] = $create_date;
			$timeline_id = CommonModel::insertObject($array_input, 'b_timeline');			
		}
		
		
		echo $timeline_id;
	}
	/*
	public function actionDeleteTimeline()
	{
		$timeline_id=isset($_POST['timeline_id']) ? intval($_POST['timeline_id']) : 0;
		if($timeline_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$timeline_id),'b_timeline');
		}
		echo $timeline_id;
	}
	*/
	public function actionIsActiveTimeline()
	{
		$timeline_id = isset($_POST['timeline_id']) ? intval($_POST['timeline_id']) : 0;
		$detail = BTimeline::getTimelineById($timeline_id);
		
		if($detail['status']=='active')
			$status = 'pending';
		else	
			$status = 'active';
		
		$ok = CommonModel::updateObject(array('status'=>$status), 'id', $timeline_id, 'b_timeline');
		echo $ok;
	}
	
	public function actionUpdateOrderTimeline()
    {            
		$list_order=isset($_POST['list_order']) ? $_POST['list_order']:'';
		$list_order=rtrim($list_order,',');
		$list_order=explode(',',$list_order);
		$ok=true;
					
		if($list_order)
		{
			foreach($list_order as $row)
			{
				$value=explode('|',$row);
				$ok = BTimeline::updateOrderTimeline($value[0],$value[1]);             
			}
			if($ok>=0)
			{
				$ok=$ok and true;
			}   
			else
				$ok=$ok and false;
		}
    }
	
	public function actionApprovedOrder()
	{
		$order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
		$status = isset($_POST['status']) ? $_POST['status'] : 'pending';
		$info_note = isset($_POST['info_note']) ? $_POST['info_note'] : '';
		$modified = time();
		$ok = CommonModel::updateObject(array('order_status'=>$status, 'info_note'=>mysql_escape_string($info_note), 'modified'=>$modified), 'id', $order_id, 'tbl_order');
		echo $ok;
	}
	
	public function actionDeleteOrder()
	{
		$order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
		if($order_id!=0)
		{
			//Xoa don hang
			CommonModel::deleteObject(array('id'=>$order_id),'tbl_order');
			//Xoa san pham don hang
			CommonModel::deleteObject(array('order_id'=>$order_id),'tbl_order_products');
		}
		echo $order_id;
	}
	
	public function actionDeleteSubscribe()
	{
		$subscribe_id = isset($_POST['subscribe_id']) ? intval($_POST['subscribe_id']) : 0;
		if($subscribe_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$subscribe_id),'b_subscribe');
		}
		echo $subscribe_id;
	}
	public function actionUpdateNumProduct()
	{
		Cat::updateSubCat();
		Cat::updateNumProduct();
	}
	
	//Quan ly Contact
	public function actionAddStaticContent()
	{
		$static_id = isset($_POST["static_id"]) ? intval($_POST["static_id"]) : 0;
		$description = isset($_POST["description"]) ? $_POST["description"]:'';		
		$array_input = array('description'=>mysql_escape_string($description));
		
		if($static_id!=0)
		{			
			CommonModel::updateObject($array_input,'id',$static_id,'b_static_content');
		}
		else
		{			
			$static_id = CommonModel::insertObject($array_input,'b_static_content');
		}
		echo $static_id;
	}
	
	public function actionFindCustomer()
	{
		$mobile = isset($_POST["mobile"]) ? $_POST["mobile"]:'';		
		$list_customer = Customer::getCustomerByMobile($mobile);
		$this->renderPartial('list_customer', array('list_customer'=>$list_customer));
	}
	
	public function actionAddBill()
	{
		$bill_id = isset($_POST['bill_id']) ? intval($_POST['bill_id']) : 0;
		$fullname = isset($_POST['fullname']) ? $_POST['fullname'] : '';
		$address = isset($_POST['address']) ? $_POST['address'] : '';
		$title = isset($_POST['title']) ? $_POST['title'] : '';
		$mobile = isset($_POST['mobile']) ? $_POST['mobile'] : '';
		$user_post = isset($_POST['user_post']) ? $_POST['user_post'] : '';
		$user_post = Yii::app()->user->name;;
		$info_note = isset($_POST['info_note']) ? $_POST['info_note'] : '';		
		$picture = isset($_POST['picture']) ? $_POST['picture'] : '';		   		
		
		$create_date = time();  
		$edit_date = $create_date;
		
		$array_input = array('title'=>mysql_escape_string($title), 'fullname'=>mysql_escape_string($fullname), 'address'=>mysql_escape_string($address), 'mobile'=>mysql_escape_string($mobile), 'picture'=>mysql_escape_string($picture), 'user_post'=>$user_post, 'info_note'=>mysql_escape_string($info_note), 'status'=>'pending');
		
		if($bill_id!=0)
		{
			$edit_date = time();
			$array_input['edit_date'] = $edit_date;
			CommonModel::updateObject($array_input, 'id', $bill_id, 'tbl_bill');
			
			
		}
		else
		{
			$array_input['create_date'] = $create_date;
			$array_input['edit_date'] = $create_date;
			$bill_id = CommonModel::insertObject($array_input, 'tbl_bill');			
		}
		echo $bill_id;
	}
	
	public function actionIsActiveBill()
	{
		$bill_id = isset($_POST['bill_id']) ? intval($_POST['bill_id']) : 0;
		$detail = Bill::getBillById($bill_id);
		
		if($detail['status']=='active')
			$status = 'pending';
		else	
			$status = 'active';
		
		$ok = CommonModel::updateObject(array('status'=>$status), 'id', $bill_id, 'tbl_bill');
		echo $ok;
	}
	
	public function actionAddProductBill()
	{
		$bill_id = isset($_POST['bill_id']) ? intval($_POST['bill_id']) : 0;
		$product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
		$product_type = isset($_POST['product_type']) ? intval($_POST['product_type']) : 0;
		$error = 1;
		if($bill_id==0)
		{
			$error .= 'Bạn chưa chọn hóa đơn, vui lòng quay lại giao diện Hóa đơn => Thêm sản phẩm<br>';
		}
		if($product_id==0)
		{
			$error .= 'Bạn chưa chọn sản phẩm';
		}
		if($error==1)
		{
			$array_input = array('bill_id'=>$bill_id, 'product_id'=>$product_id, 'product_type'=>$product_type, 'create_date'=>time());
			$ok = CommonModel::insertObject($array_input, 'tbl_bill_product');
			if($ok>0) $error = 1;
			else $error = 0;
		}
		echo $error;
	}
	
	public function actionUpdateSaleAccess()
	{
		$sale_id = isset($_POST['sale_id']) ? intval($_POST['sale_id']) : 0;
		$num_buy = isset($_POST['num_buy']) ? intval($_POST['num_buy']) : 0;
		$price_in = isset($_POST['price_in']) ? $_POST['price_in'] : 0;
		$price_buy = isset($_POST['price_buy']) ? $_POST['price_buy'] : 0;
		$array_input =array('num_buy'=>$num_buy, 'price_in'=>$price_in, 'price_buy'=>$price_buy);
		$ok = CommonModel::updateObject($array_input, 'id', $sale_id, 'b_accessories_sale');
		echo $ok;
	}
	
	public function actionUpdateSaleList()
	{
		$sale_id = isset($_POST['sale_id']) ? intval($_POST['sale_id']) : 0;
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		$price_in = isset($_POST['price_in']) ? $_POST['price_in'] : 0;
		$price_buy = isset($_POST['price_buy']) ? $_POST['price_buy'] : 0;
		$array_input =array('price_in'=>$price_in, 'price_buy'=>$price_buy);
		$ok = CommonModel::updateObject($array_input, 'id', $sale_id, 'b_camera_sale');
		//Cap nhat lai gia ban
		CommonModel::updateObject($array_input, 'id', $camera_id, 'b_camera');
		echo $ok;
	}
	public function actionUpdateNotes()
	{
		$notes = isset($_POST['notes']) ? $_POST['notes'] : '';
		//$notes = preg_replace('/\n/si', '<br>', $notes);
		$array_input =array('notes'=>mysql_escape_string($notes));
		CommonModel::updateObject($array_input, 'id', 1, 'tbl_notes');
	}
	
	//Quan ly Contact
	public function actionAddContact()
	{
		$contact_id = isset($_POST["contact_id"]) ? intval($_POST["contact_id"]) : 0;
		$email = isset($_POST["email"]) ? $_POST["email"]:'';
		$avatar = isset($_POST["avatar"]) ? $_POST["avatar"]:'';		
		$fullname = isset($_POST["fullname"]) ? $_POST["fullname"]:'';
		$trade_in_text = isset($_POST["trade_in_text"]) ? $_POST["trade_in_text"]:'';
		$trade_in_link = isset($_POST["trade_in_link"]) ? $_POST["trade_in_link"]:'';
		$array_input = array('fullname'=>mysql_escape_string($fullname),'email'=>mysql_escape_string($email), 'avatar'=>mysql_escape_string($avatar), 'trade_in_text'=>mysql_escape_string($trade_in_text), 'trade_in_link'=>mysql_escape_string($trade_in_link));
		
		if($contact_id!=0)
		{			
			CommonModel::updateObject($array_input,'id',$contact_id,'tbl_contact');
		}
		else
		{			
			$contact_id = CommonModel::insertObject($array_input,'tbl_contact');
		}
		echo $contact_id;
	}

    //Quan ly Combo
    public function actionAddCombo()
    {
        $combo_id = isset($_POST["combo_id"]) ? intval($_POST["combo_id"]) : 0;

        $title = isset($_POST["title"]) ? $_POST["title"]:'';
        $description = isset($_POST['des'])?$_POST['des']:'';
        $create_date = time();
        $array_input = array('title'=>mysql_escape_string($title),'description'=>mysql_escape_string($description),'status'=>1);

        if($combo_id!=0)
        {
            CommonModel::updateObject($array_input,'id',$combo_id,'tbl_combos');
        }
        else
        {
            $array_input['create_date'] = $create_date;
            $combo_id = CommonModel::insertObject($array_input,'tbl_combos');
        }
        echo $combo_id;
    }

    public function actionIsActiveCombo()
    {
        $combo_id=isset($_POST['combo_id']) ? intval($_POST['combo_id']) : 0;
        if($combo_id!=0)
        {
            $detail = Combos::getCombosById($combo_id);
            if($detail['status']==1) $status = 0;
            else $status = 1;
            $array_input=array('status'=>$status);
            $result = CommonModel::updateObject($array_input,'id',$combo_id,'tbl_combos');

        }
        echo $combo_id;
    }

    public function actionFindProduct()
    {
        $type = isset($_POST['type']) ? intval($_POST['type']) : 0;
        $title = isset($_POST['title']) ? $_POST['title'] : '';
        $list_product = BList::findProduct($title, $type);

        $this->renderPartial('list_product', array('list_product'=>$list_product, 'type'=>$type));
    }
    public function actionAddProductCombo(){
        $combo_id = isset($_POST['combo_id']) ? intval($_POST['combo_id']) : 0;
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        $product_type = isset($_POST['product_type']) ? intval($_POST['product_type']) : 0;
        $price_old = isset($_POST['price_old']) ? intval($_POST['price_old']) : 0;
        $price_new = isset($_POST['price_new']) ? intval($_POST['price_new']) : 0;
        $create_date = time();
        $array_input = array('combo_id'=>$combo_id, 'product_id'=>$product_id, 'product_type'=>$product_type, 'price_old'=>$price_old, 'price_new'=>$price_new, 'create_date'=>$create_date);

        $result = CommonModel::insertObject($array_input, 'tbl_combos_products');
	}
	public function actionDeleteProductCombo(){
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        CommonModel::deleteObject(array('id'=>$id),'tbl_combos_products');
    }
}


?>