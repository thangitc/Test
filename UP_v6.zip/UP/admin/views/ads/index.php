<link href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css" rel="stylesheet">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>
<script>
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/ic-date.png';?>"
	});
	$('#formSearch').keypress(function(e){
		switch(e.which)
		{
			case 13:
				$('#formSearch').submit();
			break;
		}
	});
});
function searchForm(tab)
{       
	$('#formSearch').submit();
}

/*Bo kich hoat*/
function isActiveAds(ads_id)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/isActiveAds');?>',
		type: "POST",
		data:({
			ads_id:ads_id
		}),
		success: function(resp){
			location.reload();
		}
	});
}
function isHotAds(ads_id)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/isHotAds');?>',
		type: "POST",
		data:({
			ads_id:ads_id
		}),
		success: function(resp){
			location.reload();
		}
	});
}
/*Xoa*/
function deleteAds(ads_id)
{
	if(confirm('Bạn có chắc chắn muốn xóa bản ghi và những dữ liệu liên quan?'))
		$.ajax({
		url: '<?php echo Url::createUrl('ads/deleteAds');?>',
		type: "POST",
		data:({
			ads_id:ads_id
		}),
		success: function(resp){
			if(resp!=1)
			{
				alert(resp);
			}
			location.reload();
		}
	});
}

</script>

<div class="body_pages clearfix">
    <table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
        <tr>
            <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
            <td valign="top" class="last"><div class="content_pages">
                    <?php //$this->renderPartial('application.views.eExam._box_tab');?>
                    <div class="box_form">
                        <div class="box bottom30 clearfix">
                            <form method="get" id="formSearch">
                                <ul class="form4">
                                    <li class="clearfix">
                                        <label><strong>Từ khóa :</strong> </label>
                                        <div class="filltext">
                                            <input type="text" style="width:196px;margin-right:20px" name="keyword" id="keyword" value="<?php echo $keyword;?>">
                                            &nbsp; Trong &nbsp;
                                            <select style="width:145px;margin-left:62px" id="keyword_in" name="keyword_in">
                                                <option value="1" <?php if($keyword_in==1) echo 'selected';?>>Tiêu đề</option>
                                                <option value="2" <?php if($keyword_in==2) echo 'selected';?>>ID</option>
                                            </select>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Chọn danh mục: </strong></label>
                                        <div class="filltext">
                                            <select style="width:206px" id="cat_id" name="cat_id">
                                                <option value="0">--Chọn danh mục--</option>
                                                <?php
												if($cats)
												foreach($cats as $row)
												{
													if($row['parent_id']==0)
													{
														$parent_id=$row['id'];
														$selected='';
														if($cat_id==$row['id']) $selected='selected';
														?>
														<option value="<?php echo $row['id'];?>" <?php echo $selected;?>><?php echo $row['title'];?></option>
														<?php
														foreach($cats as $row2)
														{
															if($row2['parent_id']==$parent_id)
															{
																$parent_id_2=$row2['id'];
																$selected='';
																if($cat_id==$row2['id']) $selected='selected';
															?>
															<option value="<?php echo $row2['id'];?>" <?php echo $selected;?>>--<?php echo $row2['title'];?></option>
															<?php
																foreach($cats as $row3)
																{
																	if($row3['parent_id']==$parent_id_2)
																	{
																		$selected='';
																		if($cat_id==$row3['id']) $selected='selected';
																	?>
																	<option value="<?php echo $row3['id'];?>" >----<?php echo $row3['title'];?></option>
																	<?php
																	}
																}
															}
														}
													}
												}
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Từ ngày: </strong></label>
                                        <div class="filltext">
                                            <input type="text" style="width:170px" value="<?php if(isset($from_date) && $from_date!=0) echo date('d/m/Y',$from_date);?>" id="from_date" name="from_date">
                                            &nbsp; Đến ngày &nbsp;
                                            <input type="text" style="width:170px" id="to_date" name="to_date" value="<?php if(isset($to_date) && $to_date!=0) echo date('d/m/Y',$to_date);?>">
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label>&nbsp;</label>
                                        <div class="filltext">
                                            <input type="submit" class="buton-radi" value="Tìm kiếm">
                                            <input type="button" class="buton-radi" value="Hủy" onclick="window.location.href='<?php echo Url::createUrl('ads/index');?>'">
                                        </div>
                                    </li>
                                </ul>
                                <input type="hidden" id="tab" name="tab" />
                            </form>
                        </div>
                        <div class="box clearfix">
                            <div class="clearfix fillter">
                                <div class="fl">
                                    Thao tác nhanh
                                    <select style="min-width:100px"  id="quick_type">
                                        <option value="1">Kích hoạt</option>
                                        <option value="2">Bỏ kích hoạt</option>
                                        <option value="3">Xóa</option>
                                    </select>
                                    <input type="button" class="btn-orange" value="Lưu" onclick="quickUpdateTopic($('#quick_type').val(),$('#list_id').val());">
                                </div>
                                </br >
                                </br >
                                <div class="fl"><strong>Tìm Thấy : </strong>  <strong style="color:red;"><?php echo $total;?> </strong><strong> Quảng cáo trong </strong> <strong><?php echo $page.' trang' ?></strong></div>
                                <div class="fr reseach">
                                    <input type="button" class="btn-orange fl magr10" value="Thêm mới Quảng cáo" onclick="window.location.href='<?php echo Url::createUrl('ads/add');?>'">
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0" id="list" class="col_list txt-right">
                                <tbody>
                                    <tr class="bg_grblue">
                                        <td width="2%">
                                            <strong>STT/ID</strong>
                                            <br>
                                            <input type="checkbox" id="selectAll" onclick="doCheckAll();">
                                            <input type="hidden" id="list_id" />
                                        </td>
                                        <td width="34%"><strong>Tiêu đề Quảng cáo</strong></td>
                                        <td width="15%"><strong>Ảnh</strong></td>
                                        <td width="10%"><strong>Danh mục</strong></td>
                                        <td width="12%"><strong>Vị trí</strong></td>
                                        <td width="18%"><strong>Thời gian/ Người gửi</strong></td>
                                    </tr>
                                    <?php
									$k=0;
									if($ads)
									foreach($ads as $row)
									{
										$row_cat=isset($cat_ads[$row['cat_id']]) ? $cat_ads[$row['cat_id']]:array();
										$link_detail = $row['ads_link'];
										if($row['picture']!='')
											$picture = Common::getImage($row['picture'],'ads','');	
										else $picture = '';
										?>
										<tr>
											<td>
												<?php echo (($page-1)*$num_per_page+$k);?>
												<hr />
												<?php echo $row['id'];?>
												<br />
												<input type="checkbox" value="<?php echo $row['id'];?>" class="selectOne" onclick="doCheck();">
											</td>
											<td class="txt-left">
												<span class="<?php if($row['status']=='active') echo "approv fl";else if($row['status']=='pending') echo "pending fl";else if($row['status']=='draft') echo "draft fl";  ?>"></span>
												<div class="clearfix col_30">
												<p><a href="<?php echo $link_detail;?>" target="_blank"><strong><?php echo $row['title'];?></strong></a></p>
												<div class="row-actions">
                                                	<a href="<?php echo Url::createUrl('ads/edit',array('ads_id'=>$row['id']));?>"><span>Sửa</span></a> 
                                                    | <a href="javascript:" onclick="deleteAds(<?php echo $row['id'];?>);"><span>Xóa</span></a> 
                                                    | <a href="javascript:" onclick="isActiveAds(<?php echo $row['id'];?>);"><span><?php if($row['status']=='pending') echo 'Kích hoạt'; else echo 'Bỏ kích hoạt';?></span></a>
                                                </div>
											</td>
											<td class="txt-center">
												<a class="under" href="<?php echo $link_detail;?>" target="_blank"><strong>
												<?php
												if($picture!='')
												{
													?>
                                                    <img width="100px;" height="100px;" src="<?php echo $picture;?>" />
                                                    <?php
												}
                                                ?>
                                                </strong></a>
											</td>
                                            <td>
												<?php
                                                	if(!empty($row_cat)) echo $row_cat['title'];
												?>
											</td>
											<td>
												<?php
												$arr_pos = LoadConfig::$arr_pos;
												$pos = isset($arr_pos[$row['ads_alignment']]) ? $arr_pos[$row['ads_alignment']] : '';
												echo $pos;
												?>
											</td>
											
											<td class="txt-left"><p><a class="under" href="javascript:"><strong><?php echo $row['admin_name'];?></strong></a><?php if($row['create_date']!=0) echo date('d/m/Y - H:i a',$row['create_date']);?></p> </td>
										</tr>
										<?php 
									}
									?>
                                </tbody>
                            </table>
                            <div class="clearfix fillter">
                                <div class="fr reseach">
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $this->renderPartial('application.views.static.footer');?>
                </div>
            </td>
        </tr>
    </table>
</div>