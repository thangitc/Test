<?php $this->renderPartial('js', array('detail'=>$detail));?>
<?php $this->renderPartial('js');?>
<div class="body_pages clearfix">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
<tbody>
<tr>
    <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
    <td valign="top" class="last">
        <div class="content_pages">
        <?php //$this->renderPartial('application.views.eExam._box_tab');?>
        <div class="box_form">
          
        <div class="box bottom30 clearfix">
        <div class="box bottom30 clearfix">
        <p>
        	<strong class="s14 clblue">Sửa quảng cáo</strong></p>
            <ul class="form4">
                <li class="clearfix"><label><strong>Tên quảng cáo :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="title" name="title" value="<?php echo $detail['title'];?>"> 
                    </div>
                </li>
                <li class="clearfix"><label><strong>Nội dung ngắn :</strong> </label>
                    <div class="filltext">
                    <textarea id="info" name="info"><?php echo $detail['introtext'];?></textarea>
                    </div>
                </li>
                <li class="clearfix"><label><strong>Chọn Model :</strong></label>
                    <div class="filltext">
                        <select style="width:179px;" name="model_id" id="model_id">
                            <option value="0" selected="selected"><!----Chọn Model----></option>
                            <?php
                            if($models)
                            foreach($models as $row)
                            {
                                $selected = '';
                                if($row['id']==$detail['model_id']) $selected = 'selected';
                                ?>
                                <option <?php echo $selected;?> value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    
                </li>
                <li class="clearfix"><label><strong>Tên danh mục :</strong></label>
                    <div class="filltext">
                    	<select style="width:206px" id="cat_id" name="cat_id">
                        <option value="0">--Chọn danh mục--</option>
                        <option value="-1" <?php if($detail['cat_id']==-1) echo 'selected';?>>Trang chủ</option>
                        <option value="-2" <?php if($detail['cat_id']==-2) echo 'selected';?>>Trang chi tiết</option>
                        <option value="-3" <?php if($detail['cat_id']==-3) echo 'selected';?>>Trang danh mục</option>
                        <option value="-4" <?php if($detail['cat_id']==-4) echo 'selected';?>>Trang tìm kiếm</option>
						<?php
                        if($cats)
                        foreach($cats as $row)
                        {
                            if($row['parent_id']==0)
                            {
								$select = '';
								if($row['id']==$detail['cat_id']) $select = 'selected';
								
                                $parent_id=$row['id'];
                                ?>
                                <option <?php echo $select;?> value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                <?php
                                foreach($cats as $row2)
                                {
                                    if($row2['parent_id']==$parent_id)
                                    {
                                        $parent_id_2=$row2['id'];
										$select = '';
										if($row2['id']==$detail['cat_id']) $select = 'selected';
                                        ?>
                                        <option <?php echo $select;?> value="<?php echo $row2['id'];?>" >--<?php echo $row2['title'];?></option>
                                        <?php
                                        foreach($cats as $row3)
                                        {
                                            if($row3['parent_id']==$parent_id_2)
                                            {
												$select = '';
												if($row3['id']==$detail['cat_id']) $select = 'selected';
                                                ?>
                                                <option <?php echo $select;?> value="<?php echo $row3['id'];?>" >----<?php echo $row3['title'];?></option>
                                                <?php
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        ?>
                        </select>
                    </div>
                </li>
                <li class="clearfix">
                	<label><strong>Ảnh đại diện: </strong></label>
                    <div class="filltext">
                        <div>
                            <div style="float:left;"><input type="text" id="txtFileName" readonly style="width:240px;" value="<?php echo $detail['picture'];?>" /></div>
                            <div style="float:left; margin:1px 0 0 5px;"><span id="spanButtonPlaceHolder"></span></div>
                            <div style="clear:both;"></div>
                        </div>
                        <input type="hidden" id="picture" name="picture" value="<?php echo $detail['picture'];?>" />
                        <div class="fieldset flash" id="fsUploadProgress"></div>
                        
                        <p class="magT5" id="result_file1">
                        <?php if($detail['picture']!='') { ?>
                        <img width="150px" height="90px" src="<?php echo Common::getImage($detail['picture'],'ads',''); ?>"/>
                        <?php } ?>
                        </p>
                	</div>
                </li>
               	
                
                <li class="clearfix"><label><strong>Link ads:</strong> </label>
                    <div class="filltext">
                    <input type="text" id="ads_link" name="ads_link" value="<?php echo $detail['ads_link'];?>" />
                    </div>
                </li>
                
                <li class="clearfix">
                	<label><strong>Vị trí </strong></label>
                    <div class="filltext">
                    	<select style="width:206px" id="ads_alignment" name="ads_alignment">
                            <option value="0">--Chọn vị trí--</option>
                            <?php
                            $arr_pos = LoadConfig::$arr_pos;
                            if($arr_pos)
                            foreach($arr_pos as $key=>$value)
                            {
								$select = '';
								if($key==$detail['ads_alignment']) $select = 'selected';
                                ?>
                                <option <?php echo $select;?> value="<?php echo $key;?>"><?php echo $value;?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                </li>
                
                <li class="clearfix"><label>&nbsp;</label>
                    <div class="filltext">
                    <input type="button" class="buton-radi" value="Cập nhật" onclick="addAds(<?php echo $detail['id'];?>);">
                    </div>
                </li>
                <li style="color:red;" id="result"></li>
            </ul>
        
        </div>
        </div>
        
        </div> 
            <?php $this->renderPartial('application.views.static.footer');?>
        </div>
    </td>
</tr>
</tbody>
</table>
</div>