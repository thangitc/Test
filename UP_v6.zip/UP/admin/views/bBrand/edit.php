<?php $this->renderPartial('js', array('detail'=>$detail));?>
<?php $this->renderPartial('js');?>
<div class="body_pages clearfix">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
<tbody>
<tr>
    <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
    <td valign="top" class="last">
        <div class="content_pages">
        <?php //$this->renderPartial('application.views.eExam._box_tab');?>
        <div class="box_form">
          
        <div class="box bottom30 clearfix">
        <div class="box bottom30 clearfix">
        <p>
        	<strong class="s14 clblue">Sửa Brand</strong></p>
            <ul class="form4">
                <li class="clearfix"><label><strong>Tiêu đề :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="title" name="title" value="<?php echo $detail['title'];?>"> 
                    </div>
				</li>
                <li class="clearfix bor-bottom"><label><strong>Ảnh đại diện:</strong></label>
                    <div class="filltext">            
                        <input type="text" id="filename1" name="filename1" value="<?php echo $detail['picture'];?>" readonly/>&nbsp;
                        <span id="spanButtonPlaceHolder"></span>
                    </div>
                </li>
                <li class="clearfix bor-bottom"><label>&nbsp;</label>
                    <div class="filltext" id="img_0">
                    <?php
					if($detail['picture']!='')
					{
						$src = Common::getImage($detail['picture'], 'brand', '');
						?>
						<div style="width:100px; float:left;">
							<img width="100px;" height="40px" src="<?php echo $src;?>" alt="<?php echo $detail['picture'];?>" />
							<a href="javascript:" onclick="$(this).parent('div').remove();">Xóa</a>
						</div>
						<?php
					}
					?>
                    </div>
                </li>
                
                <li class="clearfix bor-bottom">
                    <label><strong>Loại thương hiệu</strong></label>
                    <div class="filltext">
                    <select id="brand_type" name="brand_type">
                        <option value="0" <?php if($detail['brand_type']==0) echo 'selected';?>>Máy ảnh</option>
                        <option value="1" <?php if($detail['brand_type']==1) echo 'selected';?>>Phụ kiện</option>
                    </select>
                    </div>
                    
                </li>
                
                <li class="clearfix"><label>&nbsp;</label>
                    <div class="filltext">
                    <input type="button" class="buton-radi" value="Cập nhật" onclick="addBrand(<?php echo $detail['id'];?>);">
                    </div>
                </li>
                <li style="color:red;" id="result"></li>
            </ul>
        
        </div>
        </div>
        
        </div> 
            <?php $this->renderPartial('application.views.static.footer');?>
        </div>
    </td>
</tr>
</tbody>
</table>
</div>