<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab');?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div style="border-right:1px solid #ccc" class="col55">
                                    <ul class="form">
                                        <li class="clearfix"><label><strong>Tiêu đề tin :</strong></label>
                                            <div class="filltext">
                                                <input name="title" id="title" type="text" style="width:100%;">
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Chuyên Mục :</strong></label>
                                            <div class="filltext">
                                                <select style="width:52%;" name="cat_id" id="cat_id">
                                                    <option value=""> -- Chọn chuyên mục -- </option>
                                                    <?php
                                                    if($cats)
                                                    foreach($cats as $row)
                                                    {
                                                        if($row['cat_type']==2 && $row['parent_id']==0)
                                                        {
                                                            ?>
                                                            <option value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
                                                            <?php
                                                            foreach($cats as $row2)
                                                            {
                                                                if($row2['parent_id']==$row['id'])
                                                                {
                                                                    ?>
                                                                    <option value="<?php echo $row2['id'];?>">--<?php echo $row2['title'];?></option>
                                                                    <?php
                                                                    foreach($cats as $row3)
                                                                    {
                                                                        if($row3['parent_id']==$row2['id'])
                                                                        {
                                                                            ?>
                                                                            <option value="<?php echo $row3['id'];?>">--<?php echo $row3['title'];?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Tóm tắt:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="width: 518px; height: 86px;" rows="5" cols="10" name="introtext" id="introtext"></textarea>
                                            </div>                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Tin nổi bật :</strong> </label>
                                            <div class="filltext" id="result_img2">
                                                <input type="checkbox" name="is_hot" id="is_hot" value="0">
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Nội dung </strong></label>
                                            <div class="filltext">
                                                <textarea id="description" name="description"></textarea>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Từ khóa :</strong></label>
                                            <div class="filltext">
                                                <input type="text" onfocus="if (this.value == this.defaultValue) this.value = '';" onblur="if (this.value == this.defaultValue || this.value == '') this.value = this.defaultValue" value="Từ khóa" name="keyword" id="keyword"  style="width:100%;">
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Link nguồn :</strong></label>
                                            <div class="filltext">
                                                <input type="text"  style="width:100%;" id="original_link" name="original_link">
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Tiêu đề tin :</strong></label>
                                            <div class="filltext">
                                                Chưa Seo
                                            </div>
                                        </li>

                                    </ul>
                                </div>
                                <div class="col2">&nbsp;</div>
                                <div class="col40">
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addNews(0,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addNews(0,'draft');"> &nbsp; </p>
                                    <ul class="form1">
                                        <li class="clearfix bor-bottom"><label><strong>Ảnh đại diện:</strong></label>
                                            <div class="filltext">            
                                            	<input type="text" id="filename1" name="filename1" readonly/>&nbsp;
                                                <span id="spanButtonPlaceHolder" class="span_upload_0" rel="0"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_0">
                                            	
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Người đăng  :</strong></label>
                                            <div class="filltext">
                                                <input name="author_name" id="author_name" type="text" style="width:100%;">
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Chuyên đề:</strong>  </label>
                                            <input type="hidden" id="list_topic_id" name="list_topic_id">
                                            <div class="filltext">
                                                <a rel="showTopic" href="<?php echo Url::createUrl("topic/showTopic");?>" class="cboxElement"><input type="button" class="buton-radi" value="Chọn" style="margin-right:10px;"></a>
                                                <div id="list_topic_view">
                                                    
                                                </div>                                                            
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Tin liên quan:</strong>  </label>
                                            <input type="hidden" id="list_news_id" name="list_news_id">
                                            <div class="filltext">
                                                <a rel="showNews" href="<?php echo Url::createUrl("news/showNews");?>" class="cboxElement"><input type="button" value="Chọn" class="buton-radi" style="margin-right:10px;"></a>
                                                <div id="list_news_view">
                                                    
                                                </div>                                                            
                                            </div>
                                        </li>                                            
                                        <li class="clearfix">
                                            <label><strong>Link liên quan</strong></label>
                                            <div class="filltext">
                                                <div id="box_related">
                                                    <?php
                                                        $k=0;
                                                        if(!empty($related_link))
                                                        foreach($related_link as $value)
                                                        {
                                                           	$title=isset($related_title[$k]) ? $related_title[$k]:'';
                                                            ?>
                                                            <div>
                                                                <input type="text" style="width:300px;" name="related_title[]" value="<?php if($title!='') echo $title; else echo 'Tiêu đề';?>" onblur="if (this.value == 'Tiêu đề' || this.value == '') this.value = 'Tiêu đề'" onfocus="if (this.value == 'Tiêu đề') this.value = '';">
                                                                <input type="text" style="width:300px;" name="related_link[]" value="<?php if($value!='') echo $value; else echo 'Link';?>" onblur="if (this.value == 'Link' || this.value == '') this.value = 'Link'" onfocus="if (this.value == 'Link') this.value = '';">
                                                                <a class="ic_del" onclick="$(this).parent('div').remove();" href="javascript:">&nbsp;</a>
                                                            </div>
                                                            <?php
                                                                $k++;
                                                        }
                                                        else
                                                        {
                                                        ?>
                                                        <div>
                                                            <input type="text" style="width:300px;" name="related_title[]" value="Tiêu đề" onblur="if (this.value == 'Tiêu đề' || this.value == '') this.value = 'Tiêu đề'" onfocus="if (this.value == 'Tiêu đề') this.value = '';">
                                                            <input type="text" style="width:300px;" name="related_link[]" value="Link" onblur="if (this.value == 'Link' || this.value == '') this.value = 'Link'" onfocus="if (this.value == 'Link') this.value = '';">
                                                            <a class="ic_del" onclick="$(this).parent('div').remove();" href="javascript:">&nbsp;</a>
                                                        </div>
                                                        <?php
                                                        }
                                                    ?>
                                                </div>
                                                <a href="javascript:" id="add_related">Thêm</a>
                                            </div>
                                        </li>
                                    </ul>
                                    <p><strong>Thời gian đăng</strong></p>
                                    <p>
                                        <input type="text" value="<?php echo date('d');?>" style="width:40px;" name="day" onfocus="if (this.value == this.defaultValue) this.value = '';" onblur="if (this.value == this.defaultValue || this.value == '') this.value = this.defaultValue">&nbsp;
                                        <select style="width:85px" name="month">
                                            <?php
                                                for($i=1;$i<=12;$i++)
                                                {
                                                    $selected='';
                                                    if(date('m')==$i) $selected='selected';                    
                                                ?>
                                                <option <?php echo $selected;?> value="<?php echo $i;?>"><?php echo 'Tháng '.$i;?></option>
                                                <?php
                                                }
                                            ?>
                                        </select> &nbsp;
                                        <input type="text" value="<?php echo date('Y');?>" style="width:40px;" name="year" onfocus="if (this.value == this.defaultValue) this.value = '';" onblur="if (this.value == this.defaultValue || this.value == '') this.value = this.defaultValue"> @ &nbsp;<input name="hour" type="text" value="<?php echo date('H');?>" style="width:40px;" onfocus="if (this.value == this.defaultValue) this.value = '';" onblur="if (this.value == this.defaultValue || this.value == '') this.value = this.defaultValue">&nbsp;:<input name="minute" type="text" value="<?php echo date('i');?>" style="width:40px;" onfocus="if (this.value == this.defaultValue) this.value = '';" onblur="if (this.value == this.defaultValue || this.value == '') this.value = this.defaultValue">
                                    </p>                                        
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addNews(0,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addNews(0,'draft');"> &nbsp; </p>
                                </div>
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php //$this->renderPartial('popup_upload');?>
