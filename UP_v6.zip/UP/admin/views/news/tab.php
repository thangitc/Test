<?php
$action_id = Yii::app()->controller->action->id;
$id_controller = Yii::app()->controller->id;
?>
<div class="box_tab">
    <ul class="clearfix">
       	<li <?php if($action_id=='index') echo 'class="fl active"'; else echo'class="fl"';?>><span><a  href="<?php echo Url::createUrl('news/index');?>">DS Tin</span></a></li>
        <li <?php if($action_id=='add') echo 'class="fl active"'; else echo'class="fl"';?>><span><a href="<?php echo Url::createUrl('news/add');?>">Thêm mới Tin</span></a></li>
        <li <?php if($action_id=='index' && $id_controller=='newsComment') echo 'class="active"';else echo'class="fl"';?>><span><a  href="<?php echo Url::createUrl('newsComment/index');?>">Bình luận Tin</span></a></li>
    </ul>                
</div>

