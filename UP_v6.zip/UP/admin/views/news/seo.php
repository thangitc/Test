<script>
    function seoNews(news_id)
    {
        $.ajax({
            url: '<?php echo Url::createUrl('ajax/seoNews');?>',
            type: "POST",
            data:({
                news_id:news_id,
                meta_title:$('#meta_title').val(),
                meta_keyword:$('#meta_keyword').val(),
                meta_description:$('#meta_description').val()                
            }),
            success: function(resp){
                if(resp['status']=='false')    
                    $('#result_seo').html(resp['error']);
                else
                    {
                    $('#result_seo').css('color','blue');
                    $('#result_seo').html(resp['error']);
                    history.go(-1);
                }
            }
        });    
    }

</script>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">

                        <div class="box_form">
                            <?php $this->renderPartial('tab');?>
                            <div class="box bottom30">
                                <div class="title-blue">
                                    <h3><strong>Seo</strong></h3>
                                </div>                                
                                <ul class="form4">
                                    <li class="clearfix">
                                        <label><strong>Title Tag:</strong></label>
                                        <div class="filltext">
                                            <input type="text" id="meta_title" name="meta_title" style="width:45%" value="<?php echo $detail['meta_title'];?>">
                                        </div>
                                    </li>

                                    <li class="clearfix">
                                        <label><strong>Meta Description:</strong></label>
                                        <div class="filltext">
                                            <textarea style="width:45%; height:45%" rows="5" cols="5" id="meta_description"><?php echo $detail['meta_description'];?></textarea>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Meta Keywords</strong><p>(separate with commas):</p></label>
                                        <div class="filltext">
                                            <input type="text" name="meta_keyword" id="meta_keyword" style="width:45%" value="<?php echo $detail['meta_keyword'];?>">
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label>&nbsp;</label>
                                        <div class="filltext">
                                            <input type="button" id="submit" value="Cập nhật" class="buton-radi" onclick="seoNews(<?php echo $news_id;?>)">
                                        </div>
                                    </li>
                                    <li class="clearfix" id="result_seo" style="color:red;">

                                </li>                               
                            </ul>

                            </div>

                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
        </div>

