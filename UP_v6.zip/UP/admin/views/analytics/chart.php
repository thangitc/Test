<link rel="stylesheet" href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/chart/highcharts.js" type="text/javascript"></script> 
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/chart/exporting.js" type="text/javascript"></script>
<script>
    $(function(){
        $( ".datepicker" ).datepicker({
            dateFormat:"dd-mm-yy",
            changeMonth:true
        });
		$('#formSearch').keypress(function(e){
			switch(e.which)
			{
				case 13:
					$('#formSearch').submit();
				break;
			}
		});
        var chart;
        $(document).ready(function() {
            chart = new Highcharts.Chart({
                chart: {
                    renderTo: 'container_chart',
                    type: 'line',
                    marginRight: 20                
                },
                colors: [
                '#00bedf',
                '#c2c818',
                '#AA4643'
                ],
                title: {
                    text: 'Biểu đồ doanh thu'
                },            
                xAxis: {
                    labels: {
                        formatter: function() {
                            <?php /* if($search['type_view'] == 2){?>
                                return "Tháng " + (this.value - (-1));
                                <?php }else{?>
                                return "Ngày " + (this.value - (-1));
                                <?php } */?>
								
							return "Ngày " + (this.value - (-1));	
                        }
                    },
                    tickInterval: 2
                },
                yAxis: {
                    title: {
                        text: 'Doanh thu(vnđ)'
                    },
                    min: 0,                
                    formatter: function() {
                        if (this.value >= 1000000)
                            return this.value / 1000000 + 'm';
                        else if (this.value >= 1000)
                            return this.value / 1000 + 'k';
                        else if (this.value >= 0)
                            return this.value;
                    }                
                },           
                tooltip: {
                    shared:true,
                    crosshairs: true,
                    formatter: function() {
                        return '<span style="color:'+this.points[0].series.color+';font-weight:bold;">'+this.points[0].series.name + '</span>: ' + Highcharts.numberFormat(this.points[0].y, 0) + '<br>' +
                        '<span style="color:'+this.points[1].series.color+';font-weight:bold;">'+this.points[1].series.name + '</span>: ' + Highcharts.numberFormat(this.points[1].y, 0)+ '<br>' +
                        
                        '<span style="color:'+this.points[3].series.color+';font-weight:bold;">'+this.points[3].series.name + '</span>: ' + Highcharts.numberFormat(this.points[3].y, 0);
                    }
                },
                series: [ {
                    name: '<?php echo 'Sản phẩm';?>',
                    data: [<?php echo $data_report_product;?>]
                },  {
                    name: '<?php echo 'Phụ kiện';?>',
                    data: [<?php echo $data_report_access;?>]
                }]
            });
        });    
    });

</script>

<script>
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/calendar.png';?>"
	});
	
});

</script>
<div class="body_pages clearfix">
<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
    <tr>
        <td class="first" valign="top"><?php $this->renderPartial('application.views.static.sidebar') ; ?></td>
        <td valign="top" class="last"><div class="content_pages" id="container">
                <?php $this->renderPartial('_box_tab');?>
                <div class="box_form">
                    <form method="GET" action="<?php echo Url::createUrl('analytics/chart');?>" id="formSearch">
                        <div class="box bottom30">
                            <ul class="form4">
                                <li class="clearfix">
                                	<label><strong>Chọn: </strong></label>
                                    <div class="filltext">
                                        <select id="month" name="month">
                                        	<?php
											for($i=1; $i<=12; $i++)
											{
												$select='';
												if($i==$month) $select = 'selected';
												?>
                                                <option <?php echo $select;?> value="<?php echo $i;?>">Tháng <?php echo $i;?></option>
                                                <?php
											}
                                            ?>
                                        </select>
                                        
                                        <select id="year" name="year">
                                        	<?php
											for($i=2015; $i<=2030; $i++)
											{
												$select='';
												if($i==$year) $select = 'selected';
												?>
                                                <option <?php echo $select;?> value="<?php echo $i;?>">Năm <?php echo $i;?></option>
                                                <?php
											}
                                            ?>
                                        </select>
                                    </div>
                                </li>
                                
                                <li class="clearfix">
                                    <label><strong>Từ ngày: </strong></label>
                                    <div class="filltext">
                                        <input type="text" style="width:170px" value="<?php if(isset($from_date) && $from_date!=0) echo date('d/m/Y',$from_date);?>" id="from_date" name="from_date">
                                        &nbsp; Đến ngày &nbsp;
                                        <input type="text" style="width:170px" id="to_date" name="to_date" value="<?php if(isset($to_date) && $to_date!=0) echo date('d/m/Y',$to_date);?>">
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label>&nbsp;</label>
                                    <div class="filltext">
                                        <input type="submit" class="buton-radi" value="Tìm kiếm" >
                                        <input type="button" value="Hủy" class="buton-radi" onclick="window.location.href='<?php echo Url::createUrl('analytics/chart');?>'" />
                                        
                                    </div>
                                </li>
                                
                            </ul>
                        </div>
                    </form>
                    <div class="box">
                    	<div class="box-bor pad10 bottom30">
                            <p class="clblue bottom10">Doanh thu tháng <?php echo $month;?></p>
                            <p id="container_chart" class="user list_item mney_dtail"></p>
                            Doanh thu bán lẻ tháng <?php echo $month;?>: <strong style="color:red;"><?php echo Common::formatNumber($revenue_product_ban_le);?></strong> VNĐ<br />
                            Doanh thu bán buôn tháng <?php echo $month;?>: <strong style="color:red;"><?php echo Common::formatNumber($revenue_product_ban_buon);?></strong> VNĐ<br />
                            Doanh thu phụ kiện tháng <?php echo $month;?>: <strong style="color:red;"><?php echo Common::formatNumber($revenue_access);?></strong> VNĐ<br />
                            Doanh thu tháng <?php echo $month;?>: <strong style="color:red;"><?php echo Common::formatNumber($revenue_product+$revenue_access);?></strong> VNĐ<br />
                            ---------------------------------------------------------<br />
                            Lãi bán lẻ tháng <?php echo $month;?>: <strong style="color:red;"><?php echo Common::formatNumber($total_lai_ban_le);?></strong> VNĐ<br />
                            Lãi bán buôn <?php echo $month;?>: <strong style="color:red;"><?php echo Common::formatNumber($total_lai_ban_buon);?></strong> VNĐ<br />
                            Lãi phụ kiện tháng <?php echo $month;?>: <strong style="color:red;"><?php echo Common::formatNumber($total_lai_thang_access);?></strong> VNĐ<br />
                            Lãi tháng <?php echo $month;?>: <strong style="color:red;"><?php echo Common::formatNumber($total_lai_thang_product+$total_lai_thang_access);?></strong> VNĐ<br />
                        </div>
                        
                    </div>
                    
                    <div class="box">
                    	<div class="box-bor pad10 bottom30">
                            <p class="clblue bottom10">Hôm nay</p>
                            <?php
							$doanhthu_day = 0;
							$doanhthu_ban_buon = 0;
							$doanhthu_ban_le = 0;
							$doanhthu_phukien = 0;
							$lai_day = 0;
							$lai_ban_buon = 0;
							$lai_ban_le = 0;
							$lai_phukien = 0;
							//Sna pham
							if($products_day)
							foreach($products_day as $row)
							{
								if($row['status_sale']==0) $label = 'Bán lẻ';
								else $label = 'Bán buôn';
								echo $label.': '.$row['title'].'---'.'Giá: <strong style="color:red;">'.Common::formatNumber($row['price_buy']).'</strong> - '.date('H:i, d/m/Y',$row['time_buy']).'<br>';
								$doanhthu_day += $row['price_buy'];
								$lai_day += $row['price_buy']-$row['price_in']-$row['fee_vn'];
								if($row['status_sale']==0)
								{
									$lai_ban_le += $row['price_buy']-$row['price_in']-$row['fee_vn'];
									$doanhthu_ban_le += $row['price_buy'];
								}
								else
								{
									$lai_ban_buon += $row['price_buy']-$row['price_in']-$row['fee_vn'];
									$doanhthu_ban_buon += $row['price_buy'];
								}
							}
                           
						   	//Phu kien
							if($access_day)
							foreach($access_day as $row)
							{
								echo $row['title'].'---'.'Giá: <strong style="color:red;">'.Common::formatNumber($row['price_buy']).'</strong> - Số lượng: <strong style="color:red;">'.$row['num_buy'].'</strong> - '.date('H:i, d/m/Y',$row['time_buy']).'<br>';
								$doanhthu_day += $row['price_buy']*$row['num_buy'];
								$doanhthu_phukien += $row['price_buy']*$row['num_buy'];
								$lai_day += ($row['price_buy']-$row['price_in'])*$row['num_buy'];
								$lai_phukien += ($row['price_buy']-$row['price_in'])*$row['num_buy'];
							}
                            ?>
                            <br />
                            <em style="font-size:16px;">Doanh thu bán lẻ</em>: <strong style="color:red;"><?php echo Common::formatNumber($doanhthu_ban_le);?></strong> VNĐ<br />
                            <em style="font-size:16px;">Doanh thu bán buôn</em>: <strong style="color:red;"><?php echo Common::formatNumber($doanhthu_ban_buon);?></strong> VNĐ<br />
                            <em style="font-size:16px;">Doanh thu phụ kiện</em>: <strong style="color:red;"><?php echo Common::formatNumber($doanhthu_phukien);?></strong> VNĐ<br />
                            
                            <em style="font-size:16px;">Doanh thu</em>: <strong style="color:red;"><?php echo Common::formatNumber($doanhthu_day);?></strong> VNĐ<br />
                            ---------------------------------------------------------<br />
                            <em style="font-size:16px;">Lãi bán lẻ:</em> <strong style="color:red;"><?php echo Common::formatNumber($lai_ban_le);?></strong> VNĐ<br />
                            <em style="font-size:16px;">Lãi bán buôn:</em> <strong style="color:red;"><?php echo Common::formatNumber($lai_ban_buon);?></strong> VNĐ<br /> 
                            <em style="font-size:16px;">Lãi phụ kiện:</em> <strong style="color:red;"><?php echo Common::formatNumber($lai_phukien);?></strong> VNĐ<br />
                            <em style="font-size:16px;">Lãi:</em> <strong style="color:red;"><?php echo Common::formatNumber($lai_day);?></strong> VNĐ<br />
                        </div>
                        
                    </div>
                    
                    <div class="box">
                    	<div class="box-bor pad10 bottom30">
                            <p class="clblue bottom10">Hôm qua</p>                            
                            <?php
							$doanhthu_last = 0;
							$doanhthu_last_ban_le = 0;
							$doanhthu_last_ban_buon = 0;
							$doanhthu_last_phukien = 0;
							$lai_last = 0;
							$lai_last_ban_le = 0;
							$lai_last_ban_buon = 0;
							$lai_last_phukien = 0;
							//San pham
							if($products_last)
							foreach($products_last as $row)
							{
								if($row['status_sale']==0) $label = 'Bán lẻ';
								else $label = 'Bán buôn';
								echo $label.': '.$row['title'].'---'.'Giá: <strong style="color:red;">'.Common::formatNumber($row['price_buy']).'</strong> - '.date('H:i, d/m/Y',$row['time_buy']).'<br>';
								$doanhthu_last += $row['price_buy'];
								$lai_last += $row['price_buy']-$row['price_in']-$row['fee_vn'];
								
								if($row['status_sale']==0)
								{
									$doanhthu_last_ban_le += $row['price_buy'];
									$lai_last_ban_le += $row['price_buy']-$row['price_in']-$row['fee_vn'];
								}
								else
								{
									$doanhthu_last_ban_buon += $row['price_buy'];
									$lai_last_ban_buon += $row['price_buy']-$row['price_in']-$row['fee_vn'];
								}
							}
                            
							//Phu kien
							if($access_last)
							foreach($access_last as $row)
							{
								echo $row['title'].'---'.'Giá: <strong style="color:red;">'.Common::formatNumber($row['price_buy']).'</strong> - Số lượng: <strong style="color:red;">'.$row['num_buy'].'</strong> - '.date('H:i, d/m/Y',$row['time_buy']).'<br>';
								$doanhthu_last += $row['price_buy']*$row['num_buy'];
								$lai_last += ($row['price_buy']-$row['price_in'])*$row['num_buy'];
								
								$doanhthu_last_phukien += $row['price_buy']*$row['num_buy'];
								$lai_last_phukien += ($row['price_buy']-$row['price_in'])*$row['num_buy'];
							}
                            ?>
                            
                            <em style="font-size:16px;">Doanh thu bán lẻ:</em> <strong style="color:red;"><?php echo Common::formatNumber($doanhthu_last_ban_le);?></strong> VNĐ<br />
                            <em style="font-size:16px;">Doanh thu bán buôn:</em> <strong style="color:red;"><?php echo Common::formatNumber($doanhthu_last_ban_buon);?></strong> VNĐ<br />
                            <em style="font-size:16px;">Doanh thu phụ kiện:</em> <strong style="color:red;"><?php echo Common::formatNumber($doanhthu_last_phukien);?></strong> VNĐ<br />
                            <em style="font-size:16px;">Doanh thu:</em> <strong style="color:red;"><?php echo Common::formatNumber($doanhthu_last);?></strong> VNĐ<br />
                            ---------------------------------------------------------<br />
                            <em style="font-size:16px;">Lãi bán lẻ:</em> <strong style="color:red;"><?php echo Common::formatNumber($lai_last_ban_le);?></strong> VNĐ<br />
                            <em style="font-size:16px;">Lãi bán buôn:</em> <strong style="color:red;"><?php echo Common::formatNumber($lai_last_ban_buon);?></strong> VNĐ<br />
                            <em style="font-size:16px;">Lãi phụ kiện:</em> <strong style="color:red;"><?php echo Common::formatNumber($lai_last_phukien);?></strong> VNĐ<br />
                            <em style="font-size:16px;">Lãi:</em> <strong style="color:red;"><?php echo Common::formatNumber($lai_last);?></strong> VNĐ<br />
                            
                        </div>
                        
                    </div>
                </div>
                <?php $this->renderPartial('application.views.static.footer') ;  ?>
            </div>
		</td>
    </tr>
</table>
</div>
