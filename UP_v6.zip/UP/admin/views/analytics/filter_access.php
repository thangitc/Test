<script>
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/calendar.png';?>"
	});
	$('#formSearch').keypress(function(e){
		switch(e.which)
		{
			case 13:
				$('#formSearch').submit();
			break;
		}
	});
});

function searchForm(tab)
{
	$('#tab').val(tab);
    $('#formSearch').submit();
}
</script>
<div class="body_pages clearfix">
<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
    <tr>
        <td class="first" valign="top"><?php $this->renderPartial('application.views.static.sidebar') ;  ?></td>
        <td valign="top" class="last"><div class="content_pages" id="container">
                <?php $this->renderPartial('_box_tab');?>
                <div class="box_form">
                    <form method="GET" action="<?php echo Url::createUrl('analytics/exportAccess');?>" id="formSearch">
                        <div class="box bottom30">
                            <ul class="form4">
                                <li class="clearfix">
                                    <label><strong>Từ khóa:</strong></label>
                                    <div class="filltext">
                                        <input type="text" value="<?php echo $keyword;?>" style="width: 300px;" id="keyword" name="keyword">
                                        Trong
                                        <select id="keyword_in" name="keyword_in">
                                            <option value="1" <?php if($keyword_in==1) echo 'selected';?>>Tên sản phẩm</option>
                                            <option value="2" <?php if($keyword_in==2) echo 'selected';?>>Người nhập</option>
                                            <option value="3" <?php if($keyword_in==3) echo 'selected';?>>ID</option>
                                        </select>
                                    </div>                                     
                                </li>
                                <li class="clearfix">
                                    <label><strong>Số Seri:</strong></label>
                                    <div class="filltext">
                                        <input type="text" value="<?php echo $seri;?>" style="width: 300px;" id="seri" name="seri">
                                    </div>                                     
                                </li>
                                <li class="clearfix">
                                    <label><strong>Danh mục :</strong></label>
                                    <div class="filltext">
                                        <select id="cat_id" name="cat_id" style="width:200px;">
                                            <option value="0">--Chọn--</option>
                                            <?php
											if($cats)
											foreach($cats as $row)
											{
												if($row['cat_type']==3)
												{
													$select='';
													if($row['id']==$cat_id) $select='selected';
													?>
													<option <?php echo $select;?> value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
													<?php
													foreach($cats as $row2)
													{
														if($row2['parent_id']==$row['id'])
														{
															$select='';
															if($row2['id']==$cat_id) $select='selected';
															?>
															<option <?php echo $select;?> value="<?php echo $row2['id'];?>">--<?php echo $row2['title'];?></option>
															<?php
															
														}
													}
												}
											}
                                            ?>
                                        </select>
                                        
                                    </div>                                      
                                </li>
                                
                                <li class="clearfix">
                                    <label><strong>Từ ngày: </strong></label>
                                    <div class="filltext">
                                        <input type="text" style="width:170px" value="<?php if(isset($from_date) && $from_date!=0) echo date('d/m/Y',$from_date);?>" id="from_date" name="from_date">
                                        &nbsp; Đến ngày &nbsp;
                                        <input type="text" style="width:170px" id="to_date" name="to_date" value="<?php if(isset($to_date) && $to_date!=0) echo date('d/m/Y',$to_date);?>">
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label>&nbsp;</label>
                                    <div class="filltext">
                                        <input type="button" class="buton-radi" value="Export" onclick="searchForm('');">
                                        <input type="button" value="Hủy" class="buton-radi" onclick="window.location.href='<?php echo Url::createUrl('analytics/filterExportAccess');?>'" />
                                        
                                    </div>
                                </li>
                                <br />
                                <li>
                                    <div class="filltext">
                                    	<a href="javascript:" onclick="searchForm(1);"><?php if($tab==1) echo '<strong>Hôm nay</strong>'; else echo 'Hôm nay';?> </a> &nbsp;&nbsp; 
                                        <a href="javascript:" onclick="searchForm(2);"> <?php if($tab==2) echo '<strong>Hôm qua</strong>'; else echo 'Hôm qua';?></a>&nbsp;&nbsp; 
                                        <a href="javascript:" onclick="searchForm(3);"><?php if($tab==3) echo '<strong>Tháng này</strong>'; else echo 'Tháng này';?></a>&nbsp;&nbsp; 
                                        <a href="javascript:" onclick="searchForm(4);"><?php if($tab==4) echo '<strong>Tháng trước</strong>'; else echo 'Tháng trước';?></a>&nbsp;&nbsp;
                                        <a href="javascript:" onclick="searchForm(0);"><?php if($tab==0) echo '<strong>Tất cả</strong>'; else echo 'Tất cả';?></a>
                                    <input type="hidden" id="tab" name="tab" />
                                    </div>
                                </li>
                                
                            </ul>
                        </div>
                    </form>
                    
                </div>
                <?php $this->renderPartial('application.views.static.footer') ;  ?>
            </div>
		</td>
    </tr>
</table>
</div>
