<?php
	$action = Yii::app()->controller->action->id;
	$controller_id = Yii::app()->controller->id;
	$is_day = isset($_GET['is_day']) ? intval($_GET['is_day']):0;
?>
<div class="box_tab">
    <ul class="clearfix">
    	<li class="fl <?php echo $action == 'chart' && $controller_id=='analytics' ? 'active' : '';?>"><span><a title="Biểu đồ" href="<?php echo Url::createUrl('analytics/chart');?>">Biểu đồ</a></span></li>
        <li class="fl <?php echo $action == 'index' && $controller_id=='analytics' ? 'active' : '';?>"><span><a title="Số liệu" href="<?php echo Url::createUrl('analytics/index');?>">Sản phẩm </a></span></li>
        <li class="fl <?php echo $action == 'lazada' && $controller_id=='analytics' ? 'active' : '';?>"><span><a title="Số liệu" href="<?php echo Url::createUrl('analytics/lazada');?>">Lazada </a></span></li>
        <li class="fl <?php echo $action == 'access' && $controller_id=='analytics' ? 'active' : '';?>"><span><a title="Phụ kiện" href="<?php echo Url::createUrl('analytics/access');?>">Phụ kiện </a></span></li>
        <li class="fl <?php echo $controller_id == 'bMoneyJapan' ? 'active' : '';?>"><span><a title="Tiền Nhật" href="<?php echo Url::createUrl('bMoneyJapan/index');?>">Tiền hàng bên Nhật </a></span></li>
        <li class="fl <?php echo $controller_id == 'bMoneyVn' && $is_day==0 ? 'active' : '';?>"><span><a title="Quản lý tiền Việt" href="<?php echo Url::createUrl('bMoneyVn/index');?>">Tiền Sinh hoạt Tháng</a></span></li>
        <li class="fl <?php echo $controller_id == 'bMoneyVn' && $is_day==1 ? 'active' : '';?>"><span><a title="Quản lý tiền Việt" href="<?php echo Url::createUrl('bMoneyVn/day', array('is_day'=>1));?>">Tiền trong ngày </a></span></li>
        <li class="fl <?php echo $action == 'filterExportCamera' && $controller_id=='analytics' ? 'active' : '';?>"><span><a title="Xuất Excel" href="<?php echo Url::createUrl('analytics/filterExportCamera');?>">Excel (Camera) </a></span></li>
        <li class="fl <?php echo $action == 'filterExportAccess' && $controller_id=='analytics' ? 'active' : '';?>"><span><a title="Xuất Excel" href="<?php echo Url::createUrl('analytics/filterExportAccess');?>">Excel (Access) </a></span></li>
        
        <li class="fl <?php echo $action == 'export' && $controller_id=='analytics' ? 'active' : '';?>"><span><a title="Xuất Excel" href="<?php echo Url::createUrl('analytics/export');?>">Excel Customer </a></span></li>
    </ul>
</div>
