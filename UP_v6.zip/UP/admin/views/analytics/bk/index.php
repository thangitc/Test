<script>
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/calendar.png';?>"
	});
	
});

function searchForm(tab)
{
	$('#tab').val(tab);
    $('#formSearch').submit();
}
</script>
<div class="body_pages clearfix">
<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
    <tr>
        <td class="first" valign="top"><?php $this->renderPartial('application.views.static.sidebar') ;  ?></td>
        <td valign="top" class="last"><div class="content_pages" id="container">
                <?php $this->renderPartial('_box_tab');?>
                <div class="box_form">
                    <form method="GET" action="<?php echo Url::createUrl('analytics/index');?>" id="formSearch">
                        <div class="box bottom30">
                            <ul class="form4">
                                <li class="clearfix">
                                    <label><strong>Từ khóa:</strong></label>
                                    <div class="filltext">
                                        <input type="text" value="<?php echo $keyword;?>" style="width: 300px;" id="keyword" name="keyword">
                                        Trong
                                        <select id="keyword_in" name="keyword_in">
                                            <option value="1" <?php if($keyword_in==1) echo 'selected';?>>Tên sản phẩm</option>
                                            <option value="2" <?php if($keyword_in==2) echo 'selected';?>>Người nhập</option>
                                            <option value="3" <?php if($keyword_in==3) echo 'selected';?>>ID</option>
                                        </select>
                                    </div>                                     
                                </li>
                                <li class="clearfix">
                                    <label><strong>Số Seri:</strong></label>
                                    <div class="filltext">
                                        <input type="text" value="<?php echo $seri;?>" style="width: 300px;" id="seri" name="seri">
                                    </div>                                     
                                </li>
                                <li class="clearfix">
                                    <label><strong>Danh mục :</strong></label>
                                    <div class="filltext">
                                        <select id="cat_id" name="cat_id" style="width:200px;">
                                            <option value="0">--Chọn--</option>
                                            <?php
											if($cats)
											foreach($cats as $row)
											{
												if($row['cat_type']==1)
												{
													$select='';
													if($row['id']==$cat_id) $select='selected';
													?>
													<option <?php echo $select;?> value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
													<?php
													foreach($cats as $row2)
													{
														if($row2['parent_id']==$row['id'])
														{
															$select='';
															if($row2['id']==$cat_id) $select='selected';
															?>
															<option <?php echo $select;?> value="<?php echo $row2['id'];?>">--<?php echo $row2['title'];?></option>
															<?php
															/*
															foreach($cats as $row3)
															{
																if($row3['parent_id']==$row2['id'])
																{
																	$select='';
																	if($row3['id']==$cat_id) $select='selected';
																	?>
																	<option <?php echo $select;?> value="<?php echo $row3['id'];?>">--<?php echo $row3['title'];?></option>
																	<?php
																}
															}
															*/
														}
													}
												}
											}
                                            ?>
                                        </select>
                                        
                                    </div>                                      
                                </li>
                                
                                <li class="clearfix">
                                    <label><strong>Từ ngày: </strong></label>
                                    <div class="filltext">
                                        <input type="text" style="width:170px" value="<?php if(isset($from_date) && $from_date!=0) echo date('d/m/Y',$from_date);?>" id="from_date" name="from_date">
                                        &nbsp; Đến ngày &nbsp;
                                        <input type="text" style="width:170px" id="to_date" name="to_date" value="<?php if(isset($to_date) && $to_date!=0) echo date('d/m/Y',$to_date);?>">
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label>&nbsp;</label>
                                    <div class="filltext">
                                        <input type="button" class="buton-radi" value="Tìm kiếm" onclick="searchForm('');">
                                        <input type="button" value="Hủy" class="buton-radi" onclick="window.location.href='<?php echo Url::createUrl('analytics/index');?>'" />
                                        
                                    </div>
                                </li>
                                <br />
                                <li>
                                    <div class="filltext"> <a href="javascript:" onclick="searchForm(1);"><?php if($tab==1) echo '<strong>Hôm nay</strong>'; else echo 'Hôm nay';?> <strong style="color:red;">(<?php echo $total_1;?>)</strong></a> &nbsp;&nbsp; <a href="javascript:" onclick="searchForm(2);"> <?php if($tab==2) echo '<strong>Hôm qua</strong>'; else echo 'Hôm qua';?><strong style="color:red;">(<?php echo $total_2;?>)</strong></a>&nbsp;&nbsp; <a href="javascript:" onclick="searchForm(3);"><?php if($tab==3) echo '<strong>Tháng này</strong>'; else echo 'Tháng này';?><strong style="color:red;">(<?php echo $total_3;?>)</strong></a>&nbsp;&nbsp; <a href="javascript:" onclick="searchForm(4);"><?php if($tab==4) echo '<strong>Tháng trước</strong>'; else echo 'Tháng trước';?><strong style="color:red;">(<?php echo $total_4;?>)</strong></a>&nbsp;&nbsp;<a href="javascript:" onclick="searchForm(0);"><?php if($tab==0) echo '<strong>Tất cả</strong>'; else echo 'Tất cả';?><strong style="color:red;">(<?php echo $total_0;?>)</strong></a>
                                    <input type="hidden" id="tab" name="tab" />
                                    </div>
                                </li>
                                <br /><br />
                                Doanh thu: <strong style="color:red;"><?php echo Common::formatNumber($total_buy);?></strong> VND
                                <br />
                                Nhập: <strong style="color:red;"><?php echo Common::formatNumber($total_in);?></strong> VND
                                <br />
                                Lãi: <strong style="color:red;"><?php echo Common::formatNumber($total_buy-$total_in-$total_fee_vn);?></strong> VND (<?php echo $percent;?>%)
                                <br />
                                Tồn: <strong style="color:red;"><?php echo Common::formatNumber($total_in_ton_cu+$total_in_ton_moi);?></strong> VND (Hàng cũ: <strong style="color:red;"><?php echo Common::formatNumber($total_in_ton_cu);?></strong> VND -  Hàng mới: <strong style="color:red;"><?php echo Common::formatNumber($total_in_ton_moi);?></strong> VND)
                            </ul>
                        </div>
                    </form>
                    <div class="box">
                        <div class="clearfix fillter">
                            <div class="fr reseach">
                                <ul class="pages fr clearfix">
                                    <?php echo $paging;?>
                                </ul>
                                
                            </div>
                        </div>
                        <input type="hidden" id="list_id" />
                        <table width="100%" cellspacing="0" cellpadding="0" border="0" class="col_list txt-right" id="list">
                            <tbody>
                                <tr class="bg-grey">
                                    <td width="3%"><strong>ID </strong><br>
                                    <input type="checkbox" id="selectAll" onclick="doCheckAll();"></td>
                                    <td width="22%"><strong>Tiêu đề</strong></td>
                                    <td width="10%"><strong>Hình ảnh</strong></td>
                                    <td width="18%"><strong>Giá</strong></td>
                                    <td width="10%"><strong>Lãi</strong></td>
                                    <td width="12%"><strong>Thông tin khác </strong></td>
                                </tr>
                                <?php
                                
                                $k=0;
                                foreach ($list as $row)
                                {
                                    $class='';
                                    if($k%2==0)
                                    {
                                        $class='class="bg_grays"';
                                    }
                                    $link_front_end = Yii::app()->params['baseUrlFront'].'/'.$row['alias'].'-b'.$row['camera_id'].'.html';
									$total_hit=isset($hits[$row['id']]) ? intval($hits[$row['id']]):0;
									$list_topic = isset($topics[$row['id']]) ? $topics[$row['id']] : array();
									$row_comment = isset($comments[$row['id']]) ? $comments[$row['id']] : array();
									
									if($row['picture']!='') $src = Common::getImage($row['picture'], 'camera', '');
									else $src = '';
                                    ?>
                                    <tr <?php echo $class;?> rel="<?php echo $row['id'];?>">
                                        <td><?php echo ($row['id']);?><br />
                                            <input type="checkbox" value="<?php echo ($row['id']);?>" name="articles_<?php echo ($row['id']);?>" class="selectOne" onclick="doCheck();"></td>
                                        <td class="txt-left">
                                        	<a href="<?php echo $link_front_end;?>" target="_blank"><strong><?php echo stripslashes($row['title']);?></strong></a>
                                            <div class="clearfix col_30">
                                                <br />
                                                Người nhập: <strong><?php echo $row['user_post'];?></strong>
                                                <br />
                                                Shố shot: <strong><?php echo $row['num_shot'];?></strong>
                                                <br />
                                                Code: <strong><?php echo $row['code'];?></strong>
                                                <br />
                                                Số Seri: <strong><?php echo $row['seri'];?></strong>
                                                <div class="row-actions">
                                                	<a href="<?php echo Url::createUrl("bList/edit", array("camera_id"=>$row['camera_id']));?>" title="Edit this item"><span>Edit</span></a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php
											if($row['picture']!='')
											{
												?>
                                                <img src="<?php echo $src;?>" width="150px;" height="150px;" />
                                                <?php
											}
											?>
                                        </td>
                                        
                                        <td style="text-align:left">
                                            Giá nhập: <strong style="color:red;"><?php if($row['price_in']!=0) echo Common::formatNumber($row['price_in']);?></strong><br />
                                            Giá bán: <strong style="color:red;"><?php if($row['price']!=0) echo Common::formatNumber($row['price']);?></strong><br />
                                            Giá khuyến mại: <strong style="color:red;"><?php if($row['price_sale']!=0) echo Common::formatNumber($row['price_sale']);?></strong><br />
                                            Giá bán TT: <strong style="color:red;"><?php if($row['price_buy']!=0) echo Common::formatNumber($row['price_buy']);?></strong><br />
                                        </td>
                                        <td>
                                        	<?php if($row['is_sale']==1 && $row['price_in']!=0) { ?>
                                            <strong style="color:red;"><?php echo Common::formatNumber($row['price_buy']-$row['price_in']);?></strong> (<?php echo round((($row['price_buy']-$row['price_in']-$row['fee_vn'])*100)/$row['price_in']);?>%)
                                            <?php } ?>
                                        </td>
                                        <td class="txt-left">
                                        	Người nhập: <strong><?php echo $row['user_post'];?></strong><br />
                                            Ngày nhập: <strong><?php echo date('d/m/Y',$row['create_date']);?></strong><br />
                                            Ngày bán: <strong><?php if($row['time_buy']!=0) echo date('d/m/Y',$row['time_buy']);?></strong><br />
										</td>
                                    </tr>
                                    <?php
                                    $k++;
                                }
                                ?>
                            </tbody>
                        </table>
                        <div class="clearfix fillter">                                	
                            <div class="fr reseach">
                                <ul class="pages fl magT5 clearfix">
                                    <?php echo $paging;?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $this->renderPartial('application.views.static.footer') ;  ?>
            </div>
		</td>
    </tr>
</table>
</div>
