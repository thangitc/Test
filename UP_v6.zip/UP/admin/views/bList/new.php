<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab');?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div style="border-right:1px solid #ccc" class="col55">
                                    <ul class="form">
                                    	<li class="clearfix"><label><strong>Chọn Model :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="model_id" id="model_id" onchange="loadInfo($(this).val());">
                                                	<option value="0" selected="selected">--Chọn Model--</option>
                                                    
                                                    <?php
													if($models)
													foreach($models as $row)
													{
														?>
                                                        <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                                        <?php
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Chọn Body :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="body_id" id="body_id">
                                                	<option value="0" selected="selected">--Chọn Body--</option>
                                                    
                                                    <?php
													if($body)
													foreach($body as $row)
													{
														?>
                                                        <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                                        <?php
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Chọn Combo Kit :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="kit_id" id="kit_id">
                                                	<option value="0" selected="selected">--Chọn Kit--</option>
                                                    
                                                    <?php
													if($kit)
													foreach($kit as $row)
													{
														?>
                                                        <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                                        <?php
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Chọn Color :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="color_id" id="color_id">
                                                	<option value="0" selected="selected">--Chọn Color--</option>
                                                    
                                                    <?php
													if($color)
													foreach($color as $row)
													{
														?>
                                                        <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                                        <?php
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Chọn thương hiệu :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="brand_id" id="brand_id">
                                                	<option value="0" selected="selected">--Chọn Thương hiệu--</option>
                                                    
                                                    <?php
													if($brand)
													foreach($brand as $row)
													{
														if($row['brand_type']==0)
														{
															?>
                                                            <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                                            <?php	
														}
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        
                                        <li class="clearfix" id="is_chinh_hang"><label><strong>Chính hãng</strong></label>
                                            <div class="filltext">
                                            <select style="width:179px" id="chinh_hang" name="chinh_hang">
                                            	<option value="0">Nhập khẩu</option>
                                                <option value="1">Chính hãng</option>
                                                <option value="2">Công ty</option>
                                            </select>
                                            
                                            </div>
                                        </li>
                                        <!--
                                        <li class="clearfix"><label><strong>Text chính hãng :</strong></label>
                                            <div class="filltext">
                                                <input name="text_chinh_hang" id="text_chinh_hang" type="text" style="width:100%;" >
                                            </div>
                                        </li> 
                                        -->
                                        <li class="clearfix"><label><strong>Tiêu đề tin :</strong></label>
                                            <div class="filltext">
                                                <input name="title" id="title" type="text" style="width:100%;" ><a href="javascript:" onclick="loadTitle($('#model_id').val(),$('#brand_id').val(),$('#body_id').val(),$('#kit_id').val(),$('#color_id').val());">Show Title</a>
                                            </div>
                                        </li>                                        
                                        
                                        <li class="clearfix bor-bottom"><label><strong>Ảnh đại diện:</strong></label>
                                            <div class="filltext">            
                                            	<input type="text" id="filename1" name="filename1" readonly/>&nbsp;
                                                <span id="spanButtonPlaceHolder"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_0">
                                            	
                                            </div>
                                        </li>
                                       	<li class="clearfix">
                                            <label><strong>In the box </strong></label>
                                            <div class="filltext">
                                                <textarea id="in_the_box" name="in_the_box"></textarea>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Ngày đăng tin:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="publish_date" name="publish_date">
                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix">
                                            <label><strong>Video</strong></label>
                                            <div class="filltext">
                                                <input type="text" id="camera_source" name="camera_source" style="width:100%;" />
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Từ khóa</strong></label>
                                            <div class="filltext">
                                                <input type="text" id="keyword" name="keyword" style="width:100%;" />
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Ghi chú hiển thị:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="height: 152px; width: 322px;" rows="5" cols="10" name="note_public" id="note_public"></textarea>
                                            </div>                                            
                                        </li>
                                    </ul>
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addListNew(0,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addListNew(0,'draft');"> &nbsp; </p>
                                    
                                    <div id="result">
                                    </div>
                                    
                                </div>
                                
                                <div class="col2">&nbsp;</div>
                                <div class="col40">
                                    <ul class="form1">
                                    	
                                        <li class="clearfix"><label><strong>Giá hiển thị :</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price" name="price" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá nhập:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_in" name="price_in" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá khuyến mại:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_sale" name="price_sale" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Thời gian khuyến mại:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="time_sale" name="time_sale">
                                            
                                            </div>
                                        </li>
                                        <!--
                                        <li class="clearfix"><label><strong>Giá bán:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_buy" name="price_buy" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        -->
                                        <li class="clearfix"><label><strong>Xếp hạng: </strong></label>
                                            <div class="filltext">
                                                <select style="width:206px" id="rating" name="rating">
                                                    <option value="0">--Chọn loại--</option>
                                                    <?php
                                                    $arr_rating = LoadConfig::$arr_rating;
                                                    if($arr_rating)
                                                    foreach($arr_rating as $key=>$value)
                                                    {
                                                        ?>
                                                        <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Loại sản phẩm: </strong></label>
                                            <div class="filltext">
                                                <select style="width:206px" id="is_special" name="is_special">
                                                    <option value="0">--Chọn loại--</option>
                                                    <?php
                                                    $arr_special = LoadConfig::$arr_special;
                                                    if($arr_special)
                                                    foreach($arr_special as $key=>$value)
                                                    {
                                                        ?>
                                                        <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Include Free(Phụ kiện miễn phí):</strong>  </label>
                                            <input type="hidden" id="list_access_id" name="list_access_id">
                                            <div class="filltext">
                                                <a id="showAccess" href="<?php echo Url::createUrl("access/showAccess", array('tab'=>2));?>" class="cboxElement"><input type="button" class="buton-radi" value="Chọn" style="margin-right:10px;"></a>
                                                <div id="list_access_view">
                                                    
                                                </div>                                                            
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Thời gian bảo hành:</strong></label>
                                            <div class="filltext">
                                            <input type="text" name="time_bh" id="time_bh" style="width:250px">
                                            
                                            </div>
                                        </li>
                                        <li class="clearfix" id="is_chinh_hang"><label><strong>Trạng thái hàng</strong></label>
                                            <div class="filltext">
                                            <select style="width:179px" id="is_sale" name="is_sale">
                                            	<option value="0">Còn hàng</option>
                                                <option value="1">Hết hàng</option>
                                                <option value="2">Order</option>
                                            </select>
                                            
                                            </div>
                                        </li>
                                        <hr />
                                        <li class="clearfix"><label><strong>Ghi chú nội bộ:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="height: 152px; width: 322px;" rows="5" cols="10" name="note_private" id="note_private"></textarea>
                                            </div>                                            
                                        </li>
                                        <hr />
                                        <li class="clearfix"><label><strong>Link web liên quan:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="height: 152px; width: 322px;" rows="5" cols="10" name="link_web" id="link_web"></textarea>(Danh sách các link cách nhau bằng dấu phẩy)
                                            </div>                                            
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Chi nhánh:</strong> </label>
                                            <div class="filltext">
                                            <?php
											$list_chi_nhanh = LoadConfig::$list_chi_nhanh;
											if($list_chi_nhanh)
											foreach($list_chi_nhanh as $key=>$value)
											{
												$checked = '';
												if($key==0) $checked = 'checked';
												?>
                                                <input <?php echo $checked;?> type="checkbox" value="<?php echo $key;?>" class="branch" /> <?php echo $value?>
                                                <?php
											}
                                            ?>
                                            <input type="hidden" value="0" id="list_branch" />
                                            </div>                                            
                                        </li>
                                    </ul>
                                    
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addListNew(0,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addListNew(0,'draft');"> &nbsp; </p>
                                </div>
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php //$this->renderPartial('application.views.bBody.js_model');?>