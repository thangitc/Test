<?php
$action_id = Yii::app()->controller->action->id;
$id_controller = Yii::app()->controller->id;
$bill_id = isset($_GET['bill_id']) ? intval($_GET['bill_id']):0;
?>
<div class="box_tab">
    <ul class="clearfix">
       	<li <?php if($action_id=='index') echo 'class="fl active"'; else echo'class="fl"';?>><span><a  href="<?php echo Url::createUrl('bList/index', array('bill_id'=>$bill_id));?>">Danh sách CAMERA</span></a></li>
        <li <?php if($action_id=='new') echo 'class="fl active"'; else echo'class="fl"';?>><span><a href="<?php echo Url::createUrl('bList/new');?>">Thêm sản phẩm mới (ảo)</span></a></li>
        <li <?php if($action_id=='add') echo 'class="fl active"'; else echo'class="fl"';?>><span><a href="<?php echo Url::createUrl('bList/add');?>">Thêm sản phẩm cũ</span></a></li>
    </ul>                
</div>

