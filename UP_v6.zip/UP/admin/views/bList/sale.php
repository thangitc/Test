<?php $this->renderPartial('js');?>
<div class="body_pages clearfix">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
<tbody>
<tr>
    <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
    <td valign="top" class="last">
        <div class="content_pages">
        <?php //$this->renderPartial('application.views.eExam._box_tab');?>
        <div class="box_form">
		<div class="box bottom30 clearfix">
        <div class="box bottom30 clearfix">
            <p><strong class="s14 clblue"><?php if($detail) echo $detail['title'];?></strong></p>
            <?php
			if($detail['is_sale']==1)//SP da ban
			{
				?>
                <ul class="form4">
                	<li class="clearfix">
                    	<label><strong>Hình thức :</strong> </label>
                        <div class="filltext" style="color:red;">
							<?php if($detail['status_sale']==1) echo 'Bán buôn'; else echo 'Bán lẻ';?>
                        </div>
                    </li>
                	<li class="clearfix"><label><strong>Giá bán :</strong> </label>
                        <div class="filltext" >
                        <strong style="color:red;"><?php echo Common::formatNumber($detail['price_buy']);?></strong> VNĐ 
                        </div>
                    </li>
                    <li class="clearfix"><label><strong>Khách hang :</strong> </label>
                        <div class="filltext">
                        <?php
						$label = '';
						if($list_customer)
						foreach($list_customer as $row)
						{
							$label.= '<strong>Tên</strong>: '.$row['title'].', <strong>Mobile</strong>:'.$row['mobile'].', <strong>Địa chỉ</strong>: '.$row['address'].', <strong>Tỉnh</strong>: '.$row['city_title'].'<br>';
						}
						echo $label;
                        ?>
                        </div>
                    </li>
                </ul>
                <?php
			}
			else
			{
				?>
                <ul class="form4">
                    <li class="clearfix"><label><strong>Giá bán :</strong> </label>
                        <div class="filltext">
                        <input type="text" style="width:370px" id="price_buy" name="price_buy">
                        <em style="color:red;"></em> VNĐ 
                        </div>
                    </li>
                    
                    <li class="clearfix"><label><strong>Tiền mặt :</strong> </label>
                        <div class="filltext">
                        <input type="text" style="width:370px" id="tien_mat" name="tien_mat">
                        <em style="color:red;"></em> VNĐ 
                        </div>
                    </li>
                    <li class="clearfix"><label><strong>Chuyển khoản :</strong> </label>
                        <div class="filltext">
                        <input type="text" style="width:370px" id="chuyen_khoan" name="chuyen_khoan">
                        <em style="color:red;"></em> VNĐ 
                        </div>
                    </li>
                    <li class="clearfix"><label><strong>Quẹt thẻ :</strong> </label>
                        <div class="filltext">
                        <input type="text" style="width:370px" id="quet_the" name="quet_the">
                        <em style="color:red;"></em> VNĐ 
                        </div>
                    </li>
                    <li class="clearfix"><label><strong>Lazada :</strong> </label>
                        <div class="filltext">
                        <input type="checkbox" id="is_lazada" name="is_lazada" value="0" />
                        </div>
                    </li>
                    <li class="clearfix"><label><strong>Lazada Code:</strong> </label>
                        <div class="filltext">
                        <input type="text" id="lazada_code" name="lazada_code" />
                        </div>
                    </li>
                    <li class="clearfix"><label><strong>Chọn khách hàng :</strong></label>
                        <div class="filltext">
                            <select style="width:179px;" name="customer_id" id="customer_id">
                                <option value="0" selected="selected">--Chọn khách hàng--</option>
                                <?php
                                if($customer)
                                foreach($customer as $row)
                                {
									$selected = '';
									if(!empty($order_info) && $row['mobile']==$order_info['billing_mobile']) $selected = 'selected';
                                    ?>
                                    <option <?php echo $selected;?> value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                        
                    </li>
                    
                    <li class="clearfix"><label><strong>Hóa đơn :</strong></label>
                        <div class="filltext">
                            <select style="width:179px;" name="bill_id" id="bill_id">
                                <option value="0" selected="selected">--Chọn hóa đơn--</option>
                                <?php
                                if($bills)
                                foreach($bills as $row)
                                {
									$selected = '';
									if($bill_id==$row['id']) $selected = 'selected';
                                    ?>
                                    <option <?php echo $selected;?> value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                        
                    </li>
                </ul>
                <input type="checkbox" id="is_customer" name="is_customer" <?php if(!empty($order_info)) echo 'checked';?> value="<?php if(!empty($order_info)) echo 1; else echo 0;?>"  /> <strong>Thêm mới khách hàng</strong>
                <!--<p><strong class="s14 clblue">Thêm mới Khách hàng</strong></p>-->
                <ul class="form4" id="form4_customer" <?php if(!empty($order_info)) echo 'style="display:block;"'; else echo 'style="display:none;"';?> >
                	<li class="clearfix"><label><strong>Số điện thoại :</strong> </label>
                        <div class="filltext">
                        <input type="text" style="width:370px" id="mobile" name="mobile" value="<?php if(!empty($order_info)) echo $order_info['billing_mobile'];?>" placeholder="Số điện thoại"> <a href="javascript:" onclick="findCustomer($('#mobile').val());">Tìm khách hàng</a>
                        </div>
                    </li>
                    <li class="clearfix"><label><strong>&nbsp;</strong> </label>
                        <div class="filltext" id="result_customer">
                        </div>
                    </li>
                    
                    <li class="clearfix"><label><strong>Tên khách hàng :</strong> </label>
                        <div class="filltext">
                        <input type="text" style="width:370px" id="title" name="title" value="<?php if(!empty($order_info)) echo $order_info['billing_name'];?>" placeholder="Họ tên"> 
                        </div>
                    </li>
                    
                    <li class="clearfix"><label><strong>Email :</strong> </label>
                        <div class="filltext">
                        <input type="text" style="width:370px" id="email" name="email" value="<?php if(!empty($order_info)) echo $order_info['billing_email'];?>" placeholder="Email"> 
                        </div>
                    </li>
                    <li class="clearfix"><label><strong>Địa chỉ :</strong> </label>
                        <div class="filltext">
                        <input type="text" style="width:370px" id="address" name="address" value="<?php if(!empty($order_info)) echo $order_info['billing_address'];?>" placeholder="Địa chỉ"> 
                        </div>
                    </li>
                    <li class="clearfix"><label><strong>Chọn tỉnh :</strong></label>
                        <div class="filltext">
                            <select style="width:179px;" name="city_id" id="city_id">
                                <option value="0" selected="selected">--Chọn Tỉnh--</option>
                                
                                <?php
                                if($citys)
                                foreach($citys as $row)
                                {
                                    ?>
                                    <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                        
                    </li>
                    
                </ul>
                <ul class="form4">
                    <li class="clearfix"><label>&nbsp;</label>
                        <div class="filltext">
                        <input type="button" class="buton-radi" value="Bán lẻ" onclick="addSale(<?php echo $camera_id;?>, 0);">
                        <input type="button" class="buton-radi" value="Bán buôn" onclick="addSale(<?php echo $camera_id;?>,1);">
                        </div>
                    </li>
                    <li style="color:red;" id="result"></li>
                </ul>
                <?php
			}
            ?>
        	
        </div>
        </div>
        
        </div> 
            <?php $this->renderPartial('application.views.static.footer');?>
        </div>
    </td>
</tr>
</tbody>
</table>
</div>