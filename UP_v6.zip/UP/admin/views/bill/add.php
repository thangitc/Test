<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab');?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div style="border-right:1px solid #ccc; width:60%">
                                    <ul class="form">
                                    	<!--
                                        <li class="clearfix"><label><strong>Tiêu đề hóa đơn :</strong></label>
                                            <div class="filltext">
                                                <input name="title" id="title" type="text" style="width:100%;" >
                                            </div>
                                        </li>                                        
                                        -->
                                        <li class="clearfix bor-bottom"><label><strong>Ảnh hóa đơn:</strong></label>
                                            <div class="filltext">            
                                            	<input type="text" id="filename1" name="filename1" readonly/>&nbsp;
                                                <span id="spanButtonPlaceHolder"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_0">
                                            	
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Họ tên khách hàng :</strong></label>
                                            <div class="filltext">
                                                <input name="fullname" id="fullname" type="text" style="width:100%;" >
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Số điện thoại :</strong></label>
                                            <div class="filltext">
                                                <input name="mobile" id="mobile" type="text" style="width:100%;" >
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Địa chỉ :</strong></label>
                                            <div class="filltext">
                                                <input name="address" id="address" type="text" style="width:100%;" >
                                            </div>
                                        </li>
                                        <!--
                                        <li class="clearfix"><label><strong>Người lập hóa đơn:</strong></label>
                                            <div class="filltext">
                                                <input name="user_post" id="user_post" type="text" style="width:100%;" >
                                            </div>
                                        </li>
                                        -->
                                        <li class="clearfix"><label><strong>Ghi chú:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="width: 518px; height: 85px;" rows="5" cols="10" name="info_note" id="info_note"></textarea>
                                            </div>                                            
                                        </li>
                                    </ul>
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addBill(0);"> &nbsp; </p>
                                    
                                    <div id="result">
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>