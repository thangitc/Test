<!--sort-->
<link rel="stylesheet" href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.widget.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.mouse.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.sortable.js"></script>


<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tinymce_des.js"></script>

<link rel="stylesheet" href="<?php echo Yii::app()->params['upload_url'];?>/css/swfupload.css" type="text/css" />
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.queue.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/fileprogress.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers_bill.js"></script>

<script>
$(function(){
	$('#img_0').sortable();
	window.onload = function() {
		var configUploadData = {
			upload_url: upload_url_new+"upload_bill.php"
			, create_date:'<?php $create_date=isset($detail["create_date"])? $detail["create_date"]:''; echo $create_date;?>'
			, file_types: "*.jpg;*.jpeg;*.png;*.gif;*.doc;*.docx;*.xls;*.xlsx;*.pdf;*.swf"
			, file_upload_limit : 1
			, file_queue_limit : 1
			, debug : true
		};
		configUpload(configUploadData);
	};

	$("#publish_date").datepicker({
		dateFormat:"dd/mm/yy",
		minDate: new Date()
	});
	
	//format_number
	$('#price').keypress(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	$('#price').keyup(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	$('#price').keydown(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
});

function addBill(bill_id)
{
	
	//var title=$('#title').val();
	var fullname=$('#fullname').val();
	var address = $('#address').val();
	var mobile = $('#mobile').val();	
	var picture = $('#filename1').val();
	var user_post = $('#user_post').val();
	var info_note = $('#info_note').val();

	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addBill');?>',
		type: "POST",
		data:({
			bill_id:bill_id,
			//title:title,
			fullname:fullname,
			address:address,
			mobile:mobile,
			picture:picture,
			//user_post:user_post,
			info_note: info_note
		}),
		success: function(resp){
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
			}
			else
			{
				alert('Lỗi');
			}
		}
	});
}

function format_number(num)
{
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
	num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num*100+0.50000000001);
	cents = num%100;
	num = Math.floor(num/100).toString();
	if(cents<10)
	cents = "0" + cents;
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	num = num.substring(0,num.length-(4*i+3))+','+
	num.substring(num.length-(4*i+3));
	return (((sign)?'':'-') + num);
}
</script>