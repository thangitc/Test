<script>
function addKit(kit_id)
{	
	var title=$('#title').val();
	var model_id=$('#model_id').val();
	
	if($('#model_id').val()==0)
	{
		alert('Vui lòng chọn model!');
		$('#model_id').focus();
		return false;
	}
	if($('#title').val()=='')
	{
		alert('Vui lòng nhập tên dự án!');
		$('#title').focus();
		return false;
	}
	
	loadingAjax();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addKit');?>',
		type: "POST",
		data:({
			title:title,
			kit_id:kit_id,
			model_id:model_id
		}),
		success: function(resp){
			closeLoadingAjax();
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
		}
	});
}
</script>