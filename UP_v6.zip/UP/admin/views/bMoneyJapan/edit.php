<?php $this->renderPartial('js', array('detail'=>$detail));?>
<?php $this->renderPartial('js');?>
<div class="body_pages clearfix">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
<tbody>
<tr>
    <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
    <td valign="top" class="last">
        <div class="content_pages">
        <?php $this->renderPartial('application.views.analytics._box_tab');?>
        <div class="box_form">
          
        <div class="box bottom30 clearfix">
        <div class="box bottom30 clearfix">
        <p>
        	<strong class="s14 clblue">Sửa</strong></p>
            <ul class="form4">
            	<li class="clearfix"><label><strong>Tiêu đề :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:250px" id="title" name="title" value="<?php echo $detail['title'];?>"> 
                    </div>
                </li>
                <li class="clearfix"><label><strong>Tiền gửi sang Nhật :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:250px" id="money_send_japan" name="money_send_japan" value="<?php echo $detail['money_send_japan'];?>">
                    <em style="color:red;"><?php echo Common::formatNumber($detail['money_send_japan']);?></em> đ
                    </div>
                </li>
                <li class="clearfix"><label><strong>Tỷ giá :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:150px" id="money_rate" name="money_rate" value="<?php echo $detail['money_rate'];?>"> 
                    </div>
                </li>
                <li class="clearfix"><label><strong>Tiền Yên nhận được bên Nhật :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:250px" id="money_yen_received_japan" name="money_yen_received_japan" value="<?php echo $detail['money_yen_received_japan'];?>">
                    <em style="color:red;"><?php echo Common::formatNumber($detail['money_yen_received_japan']);?></em> yên
                    </div>
                </li>
                <li class="clearfix"><label>&nbsp;</label>
                    <div class="filltext">
                    <input type="button" class="buton-radi" value="Cập nhật" onclick="addMoneyJapan(<?php echo $detail['id'];?>);">
                    </div>
                </li>
                <li style="color:red;" id="result"></li>
            </ul>
        
        </div>
        </div>
        
        </div> 
            <?php $this->renderPartial('application.views.static.footer');?>
        </div>
    </td>
</tr>
</tbody>
</table>
</div>