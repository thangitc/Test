<?php $this->renderPartial('js');?>
<div class="body_pages clearfix">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
<tbody>
<tr>
    <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
    <td valign="top" class="last">
        <div class="content_pages">
        <?php //$this->renderPartial('application.views.eExam._box_tab');?>
        <div class="box_form">
          
        <div class="box bottom30 clearfix">
        <div class="box bottom30 clearfix">
        <p>
        	<strong class="s14 clblue">Thêm mới hỏi đáp</strong></p>
            <ul class="form4">
                <li class="clearfix"><label><strong>Tiêu đề câu hỏi :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="title" name="title"> 
                    </div>
                </li>
                
                <li class="clearfix"><label><strong>Phân mục hỏi đáp :</strong></label>
                    <div class="filltext">
                    	<select style="width:206px" id="cat_id" name="_id">
                        <option value="0">--Chọn phân mục--</option>
						<?php
                        if($cats)
                        foreach($cats as $row)
                        {
							if($row['parent_id']!=0 && $row['cat_type']==7)
							{
								?>
								<option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
								<?php
							}
                        }
                        ?>
                        </select>
                    </div>
                </li>
                <li class="clearfix"><label><strong>Nội dung câu hỏi:</strong></label>
                    <div class="filltext">
                    	<textarea id="description" name="description" style="width: 371px; height: 240px;"></textarea>
                    </div>
                </li>
                
               	<li class="clearfix">
                	<label><strong>Tỉnh/thành: </strong></label>
                    <div class="filltext">
                    	<select id="city_id" name="city_id" style="width:206px">
                            <option value="0">--Tỉnh thành--</option>
                            <?php
                            if($citys)
                            foreach($citys as $row)
                            {
                                if($row['parent_id']==0)
                                {
                                    ?>
                                    <option value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </div>
                </li>
                <li class="clearfix">
                	<label><strong>Quận huyện: </strong></label>
                    <div class="filltext">
                    	<select id="district_id" name="district_id" style="width:206px">
                            <option value="0">--Quận huyện--</option>
                        </select>
                    </div>
                </li>
                
                <li class="clearfix"><label>&nbsp;</label>
                    <div class="filltext">
                    <input type="button" class="buton-radi" value="Thêm mới" onclick="addQa(0);">
                    </div>
                </li>
                <li style="color:red;" id="result_qa"></li>
            </ul>
        
        </div>
        </div>
        
        </div> 
            <?php $this->renderPartial('application.views.static.footer');?>
        </div>
    </td>
</tr>
</tbody>
</table>
</div>