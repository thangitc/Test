<link href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css" rel="stylesheet">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>
<script>
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/ic-date.png';?>"
	});
});
function searchForm(tab)
{       
	$('#formSearch').submit();
}

/*Bo kich hoat*/
function isActiveQa(qa_id)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/isActiveQa');?>',
		type: "POST",
		data:({
			qa_id:qa_id
		}),
		success: function(resp){
			location.reload();
		}
	});
}
function isHotQa(qa_id)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/isHotQa');?>',
		type: "POST",
		data:({
			qa_id:qa_id
		}),
		success: function(resp){
			location.reload();
		}
	});
}
/*Xoa*/
function deleteQa(qa_id)
{
	if(confirm('Bạn có chắc chắn muốn xóa bản ghi và những dữ liệu liên quan?'))
		$.ajax({
		url: '<?php echo Url::createUrl('ajax/deleteQa');?>',
		type: "POST",
		data:({
			qa_id:qa_id
		}),
		success: function(resp){
			location.reload();
		}
	});
}

</script>

<div class="body_pages clearfix">
    <table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
        <tr>
            <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
            <td valign="top" class="last"><div class="content_pages">
                    <?php //$this->renderPartial('application.views.eExam._box_tab');?>
                    <div class="box_form">
                        <div class="box bottom30 clearfix">
                            <form method="get" id="formSearch">
                                <ul class="form4">
                                    <li class="clearfix">
                                        <label><strong>Từ khóa :</strong> </label>
                                        <div class="filltext">
                                            <input type="text" style="width:196px;margin-right:20px" name="keyword" id="keyword" value="<?php echo $keyword;?>">
                                            &nbsp; Trong &nbsp;
                                            <select style="width:145px;margin-left:62px" id="keyword_in" name="keyword_in">
                                                <option value="1" <?php if($keyword_in==1) echo 'selected';?>>Tiêu đề</option>
                                                <option value="2" <?php if($keyword_in==2) echo 'selected';?>>ID</option>
                                            </select>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Chọn danh mục: </strong></label>
                                        <div class="filltext">
                                            <select style="width:206px" id="cat_id" name="cat_id">
                                                <option value="0">--Chọn danh mục--</option>
                                                <?php
												if($cats)
												foreach($cats as $row)
												{
													if($row['parent_id']!=0 && $row['cat_type']==7)
													{
														$parent_id=$row['id'];
														$selected='';
														if($cat_id==$row['id']) $selected='selected';
														?>
														<option value="<?php echo $row['id'];?>" <?php echo $selected;?>><?php echo $row['title'];?></option>
														<?php
													}
												}
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Từ ngày: </strong></label>
                                        <div class="filltext">
                                            <input type="text" style="width:170px" value="<?php if(isset($from_date) && $from_date!=0) echo date('d/m/Y',$from_date);?>" id="from_date" name="from_date">
                                            &nbsp; Đến ngày &nbsp;
                                            <input type="text" style="width:170px" id="to_date" name="to_date" value="<?php if(isset($to_date) && $to_date!=0) echo date('d/m/Y',$to_date);?>">
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label>&nbsp;</label>
                                        <div class="filltext">
                                            <input type="submit" class="buton-radi" value="Tìm kiếm">
                                            <input type="button" class="buton-radi" value="Hủy" onclick="window.location.href='<?php echo Url::createUrl('qa/index');?>'">
                                        </div>
                                    </li>
                                </ul>
                            </form>
                        </div>
                        <div class="box clearfix">
                            <div class="clearfix fillter">
                                <div class="fl">
                                    Thao tác nhanh
                                    <select style="min-width:100px"  id="quick_type">
                                        <option value="1">Kích hoạt</option>
                                        <option value="2">Bỏ kích hoạt</option>
                                        <option value="3">Xóa</option>
                                    </select>
                                    <input type="button" class="btn-orange" value="Lưu" onclick="quickUpdateQa($('#quick_type').val(),$('#list_id').val());">
                                </div>
                                </br >
                                </br >
                                <div class="fl"><strong>Tìm Thấy : </strong>  <strong style="color:red;"><?php echo $total;?> </strong><strong> Hỏi đáp trong </strong> <strong><?php echo $page.' trang' ?></strong></div>
                                <div class="fr reseach">
                                    <input type="button" class="btn-orange fl magr10" value="Thêm mới Hỏi đáp" onclick="window.location.href='<?php echo Url::createUrl('qa/add');?>'">
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0" id="list" class="col_list txt-right">
                                <tbody>
                                    <tr class="bg_grblue">
                                        <td width="2%">
                                            <strong>STT/ID</strong>
                                            <br>
                                            <input type="checkbox" id="selectAll" onclick="doCheckAll();">
                                            <input type="hidden" id="list_id" />
                                        </td>
                                        <td width="15%"><strong>Tiêu đề câu hỏi</strong></td>
                                        <td width="34%"><strong>Nội dung câu hỏi</strong></td>
                                        <td width="10%"><strong>Danh mục</strong></td>
                                        <td width="10%"><strong>Người gửi</strong></td>
                                        <td width="12%"><strong>Lượt xem </strong></td>
                                        <td width="18%"><strong>Thời gian/ Người sửa</strong></td>
                                    </tr>
                                    <?php
									$k=0;
									if($qa)
									foreach($qa as $row)
									{
										$row_cat=isset($cat_qa[$row['cat_id']]) ? $cat_qa[$row['cat_id']]:array();
										$link_detail = Yii::app()->params['baseUrlFront'].'/'.$row['alias'].'-q'.$row['id'].'.html';
										?>
										<tr>
											<td>
												<?php echo (($page-1)*$num_per_page+$k);?>
												<hr />
												<?php echo $row['id'];?>
												<br />
												<input type="checkbox" value="<?php echo $row['id'];?>" class="selectOne" onclick="doCheck();">
											</td>
											<td class="txt-left">
												<span class="<?php if($row['status']==1) echo "approv fl";else if($row['status']==0) echo "pending fl";else if($row['status']==2) echo "draft fl";  ?>"></span>
												<div class="clearfix col_30">
												<p><a <?php if($row['is_hot']==1) echo 'style="color:red;"';?> href="<?php echo $link_detail;?>" target="_blank"><strong><?php echo $row['title'];?></strong></a></p>
												<div class="row-actions">
                                                	<a href="<?php echo Url::createUrl('qa/edit',array('qa_id'=>$row['id']));?>"><span>Sửa</span></a> 
                                                    | <a href="javascript:" onclick="deleteQa(<?php echo $row['id'];?>);"><span>Xóa</span></a> 
                                                    | <a href="javascript:" onclick="isActiveQa(<?php echo $row['id'];?>);"><span><?php if($row['status']==0) echo 'Kích hoạt'; else echo 'Bỏ kích hoạt';?></span></a>
                                                    | <a href="javascript:" onclick="isHotQa(<?php echo $row['id'];?>);"><span><?php if($row['is_hot']==0) echo 'Nổi bật'; else echo 'Bỏ nổi bật';?></span></a>
                                                </div>
											</td>
											<td class="txt-center">
												<?php echo $row['description'];?>
											</td>
                                            <td>
												<?php
                                                	if(!empty($row_cat)) echo $row_cat['title'];
												?>
											</td>
                                            <td>
												<?php echo $row['fullname'];?> - <?php echo $row['email'];?>
											</td>
											<td>
												<?php echo $row['hit'];?>
											</td>
											
											<td class="txt-left"><p><a class="under" href="javascript:"><strong><?php echo $row['admin_name'];?></strong></a><?php if($row['create_date']!=0) echo date('d/m/Y - H:i a',$row['create_date']);?></p> </td>
										</tr>
										<?php 
									}
									?>
                                </tbody>
                            </table>
                            <div class="clearfix fillter">
                                <div class="fr reseach">
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $this->renderPartial('application.views.static.footer');?>
                </div>
            </td>
        </tr>
    </table>
</div>