<link href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css" rel="stylesheet">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>

<style type="text/css" media="all">@import "<?php  echo Yii::app()->params['static_url']; ?>/js/colorbox/colorbox.css";</style>
<script type="text/javascript" src="<?php  echo Yii::app()->params['static_url']; ?>/js/colorbox/jquery.colorbox-min.js" ></script>


<script>
$(function(){
	
	 $('#city_id').change(function () {
		var val = $('#city_id').val();
		loadDistrict(val);
	});

});

function loadDistrict(city_id)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/loadDistrict');?>',
		type: "POST",
		data:({
			city_id:city_id
		}),
		success: function(resp){
			$('#district_id').html(resp);
		}
	});
}

function addQa(qa_id)
{
	var title = $('#title').val();
	var cat_id = $('#cat_id').val();
	var fullname = $('#fullname').val();	
	var email_qa = $('#email_qa').val();
	var description=$('#description').val();
	var city_id = $('#city_id').val();
	var district_id = $('#district_id').val();
	var cat_id=$('#cat_id').val();
	var city_id = $('#city_id').val();
	var district_id = $('#district_id').val();
	
	var error = '';
	
	if(title=='')
	{
		error += 'Vui lòng nhập tiêu đề bạn muốn hỏi<br>';
	}
	if(cat_id==0)
	{
		error += 'Vui lòng chọn phân mục bạn muốn hỏi<br>';
	}
	
	if(description=='')
	{
		error += 'Vui lòng nhập nội dung hỏi đáp<br>';
	}
	
	if(city_id==0)
	{
		error += 'Vui lòng chọn tỉnh thành<br>';
	}
	else
	{
		if(district_id==0)
		{
			error += 'Vui lòng chọn quận huyện<br>';
		}
	}	
		
	if(error!='')
	{
		$('#result_qa').html(error);
		return false;
	}
	else
	{
		$('#result_qa').html('');
	}
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addQa');?>',
		type: "POST",
		data:({
			title:title,
			cat_id:cat_id,
			title:title,
			description:description,
			city_id:city_id,
			district_id:district_id,
			qa_id:qa_id
		}),
		success: function(resp){
			if(resp>=0)
			{
				alert('Cập nhật thành công!');
				history.go(-1);
			}
			else
			{
				$('#result_qa').css('color', 'red');
				$('#result_qa').html(resp['error']);
			}
		}
	});
}
</script>