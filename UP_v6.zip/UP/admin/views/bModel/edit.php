<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab');?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div style="border-right:1px solid #ccc; width:60%">
                                    <ul class="form">
                                    	<li class="clearfix"><label><strong>Loại tin :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="cat_id" id="cat_id">
                                                	<option value="0" selected="selected">--Danh mục--</option>
                                                    <?php
													if($cats)
													foreach($cats as $row)
													{
														if($row['parent_id']==0 && $row['cat_type']==1)
														{
															$selected='';
															if($detail['cat_id']==$row['id']) $selected='selected';
															?>
															<option value="<?php echo $row['id'];?>" <?php echo $selected;?>><?php echo $row['title'];?></option>
															<?php
															foreach($cats as $row2)
															{
																if($row2['parent_id']==$row['id'])
																{
																	$selected='';
																	if($detail['cat_id']==$row2['id']) $selected='selected';
																	?>
																	<option value="<?php echo $row2['id'];?>" <?php echo $selected;?>>--<?php echo $row2['title'];?></option>
																	<?php
																	foreach($cats as $row3)
																	{
																		if($row3['parent_id']==$row2['id'])
																		{
																			$selected='';
																			if($detail['cat_id']==$row3['id']) $selected='selected';
																			?>
																			<option value="<?php echo $row3['id'];?>" <?php echo $selected;?> >----<?php echo $row3['title'];?></option>
																			<?php
																		}
																	}
																}
															}
														}
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Chọn thương hiệu :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="brand_id" id="brand_id">
                                                	<option value="0" selected="selected">--Chọn Thương hiệu--</option>
                                                    
                                                    <?php
													if($brand)
													foreach($brand as $row)
													{
														if($row['brand_type']==0)
														{
															$selected = '';
															if($row['id']==$detail['brand_id']) $selected = 'selected';
															?>
															<option <?php echo $selected;?> value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
															<?php	
														}														
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Tiêu đề model :</strong></label>
                                            <div class="filltext">
                                                <input name="title" id="title" type="text" style="width:100%;" value="<?php echo $detail['title'];?>">
                                            </div>
                                        </li>                                        
                                        
                                        <li class="clearfix bor-bottom"><label><strong>Ảnh đại diện:</strong></label>
                                            <div class="filltext">            
                                            	<input type="text" id="filename1" name="filename1" readonly value="<?php echo $detail['picture'];?>"/>&nbsp;
                                                <span id="spanButtonPlaceHolder"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_0">
                                            <?php
											if(!empty($model_pic))
											foreach($model_pic as $row)
											{
												$src = Common::getImage($row['picture'], 'model', '');
												?>
                                                <div style="width:150px; float:left;">
                                                    <img width="150px;" height="90px" src="<?php echo $src;?>" alt="<?php echo $row['picture'];?>" />
                                                    <a href="javascript:" onclick="$(this).parent('div').remove();">Xóa</a>
                                                </div>
												<?php
											}
											else if($detail['picture']!='')
											{
												$src = Common::getImage($detail['picture'], 'model', '');
												?>
                                                <div style="width:150px; float:left;">
													<img width="150px;" height="90px" src="<?php echo $src;?>" alt="<?php echo $detail['picture'];?>" />
                                                    <a href="javascript:" onclick="$(this).parent('div').remove();">Xóa</a>
                                                </div>
												<?php
											}
											?>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix bor-bottom"><label><strong>File hướng dẫn:</strong></label>
                                            <div class="filltext">            
                                                <input type="text" id="filename2" name="filename2" value="<?php echo $detail['user_manual'];?>" readonly/>&nbsp;
                                                <span id="spanButtonPlaceHolder_other"></span>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_2">
                                            <?php
											if($detail['user_manual']!='')
											{
												$src = Common::getImage($detail['user_manual'], 'model', '');
												$path_parts = pathinfo($src);
												$extension = $path_parts['extension'];
												$list_extension_img = array('jpg', 'jpeg', 'png', 'gif');
												if(in_array(strtolower($extension), $list_extension_img))
												{
													?>
													<div style="width:150px; float:left;">
														<img width="150px;" height="90px" src="<?php echo $src;?>" alt="<?php echo $detail['user_manual'];?>" />
														<a href="javascript:" onclick="$(this).parent('div').remove(); $('#filename2').val('');">Xóa</a>
													</div>
													<?php
												}
												else
												{
													?>
                                                    <a href="<?php echo $src;?>"><?php echo $src; ?></a>
                                                    <?php
												}
											}
											?>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Tóm tắt(Product Highlights):</strong> </label>
                                            <div class="filltext">
                                                <textarea style="width: 518px; height: 86px;" rows="5" cols="10" name="introtext" id="introtext"><?php echo $detail['introtext'];?></textarea>
                                            </div>                                            
                                        </li>
                                       	<li class="clearfix">
                                            <label><strong>Nội dung(Overview): </strong></label>
                                            <div class="filltext">
                                                <textarea id="description" name="description"><?php echo $detail['description'];?></textarea>
                                            </div>
                                        </li>
                                       	
                                        <li class="clearfix">
                                            <label><strong>Hình ảnh chụp từ sản phẩm </strong></label>
                                            <div class="filltext">
                                                <textarea id="pic_product" name="pic_product"><?php echo $detail['pic_product'];?></textarea>
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Thông số kỹ thuật </strong></label>
                                            <div class="filltext">
                                                <textarea id="specs" name="specs"><?php echo $detail['specs'];?></textarea>
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Hàng chính hãng </strong></label>
                                            <div class="filltext">
                                                <input type="checkbox" id="is_chinh_hang" value="<?php echo $detail['is_chinh_hang'];?>" <?php if($detail['is_chinh_hang']==1) echo 'checked'; ?>>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Text chính hãng :</strong></label>
                                            <div class="filltext">
                                                <input name="text_chinh_hang" id="text_chinh_hang" type="text" style="width:100%;" value="<?php echo $detail['text_chinh_hang'];?>" >
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Hàng công ty </strong></label>
                                            <div class="filltext">
                                                <input type="checkbox" id="is_cong_ty" value="<?php echo $detail['is_cong_ty'];?>" <?php if($detail['is_cong_ty']==1) echo 'checked'; ?>>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Chọn Phụ kiện :</strong></label>
                                            <div class="filltext">
                                                <a id="showAccess" href="<?php echo Url::createUrl("access/showAccess");?>" class="cboxElement"><input type="button" value="Chọn" class="buton-radi" style="margin-right:10px;"></a>
                                                <div id="list_access_view">
                                                    <?php
                                                    $list_access_id='';
                                                    if($access)
                                                    foreach($access as $row)
                                                    {
                                                        $list_access_id.=$row['id'].',';
                                                        ?>                                                    
                                                        <div class="fl" rel="<?php echo $row['id'];?>"><a href="javascript:"><?php echo $row['title'];?></a><a class="ic_del" onclick="updateListAccess(<?php echo $row['id'];?>);$(this).parent('div').remove();" href="javascript:">&nbsp;</a></div>
                                                        <?php
                                                    }
                                                    $list_access_id=rtrim($list_access_id,',');
                                                    ?>
                                                </div>                                                            
                                            </div>
                                            <input type="hidden" id="list_access_id" name="list_access_id" value="<?php echo $list_access_id; ?>">
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Ngày đăng tin:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px" value="<?php if($detail['publish_date']!=0) echo date('d/m/Y',$detail['publish_date']); ?>" id="publish_date" name="publish_date">
                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix">
                                            <label><strong>Video</strong></label>
                                            <div class="filltext">
                                                <input type="text" id="model_video" name="model_video" style="width:100%;" value="<?php echo $detail['model_video'];?>" />
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Ghi chú hiển thị:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="height: 152px; width: 322px;" rows="5" cols="10" name="note_public" id="note_public"><?php echo $detail['note_public'];?></textarea>
                                            </div>                                            
                                        </li>
                                    </ul>
                                    
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addList(<?php echo $detail['id'];?>,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addList(<?php echo $detail['id'];?>,'draft');"> &nbsp; </p>
                                    
                                    <div id="result">
                                    </div>
                                    
                                </div>
                               
                                
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php //$this->renderPartial('popup_upload');?>