<?php $this->renderPartial('js');?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?> 
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                    <div class="box_tab">
                        <?php $this->renderPartial('path_way');?>
                    </div>
                    <div class="box_form">
                        <div class="box bottom30 clearfix" id="list_cate">
                            <p class="bottom10"><strong class="s14">Cây danh mục sản phẩm</strong></p>
                            <div class="itemt" id="itemt1">
                                <div class="box-bor pad10 clearfix">
                                    <ul class="list-dot scoll2" rel="1" id="list_cate1">
                                        <?php
                                            if($cats)
											foreach($cats as $row)
											{
												if($row['level']==1)
												{
												?>
												<li rel="<?php echo $row['id'];?>" onclick="loadSubCate(<?php echo $row['id'];?>,1,3);"><a href="javascript:"><?php echo $row['title'];?>(mã: <?php echo $row['id'];?>)</a> </li>
												<?php
												}
                                            }
                                        ?>
                                    </ul>
                                </div>
                                <p align="center">[<a id="add_1" rel="0" href="javascript:" onclick="showFormAdd($(this).attr('rel'));">Thêm</a>] [<a id="edit_1" href="javascript:" onclick="showFormEdit($(this).attr('rel'));">Sửa</a>][<a href="javascript:" onclick="saveOrder(1)" >Save Order</a>] &nbsp; [<a id="delete_1" href="javascript:" onclick="deleteCate($(this).attr('rel'))">Delete</a>]
                                </p>
                            </div>                            
                            <div class="col-50">  &gt;&gt; </div>
                        </div>  
                        <div class="box bottom30">
                            <div class="title-green" id="path_select"></div>
                            <form id="form_cate">
                                <ul class="form4">
                                    <li class="clearfix"><label><strong>Tên danh mục: </strong></label>
                                        <div class="filltext"><input type="text" value="" style="width:200px" id="title" name="title"></div>
                                    </li>
                                    <li class="clearfix"><label><strong>Alias: </strong></label>
                                        <div class="filltext"><input type="text" value="" style="width:200px" id="alias" name="alias"> </div>
                                    </li>
                                    
                                    <li class="clearfix"><label><strong>Mã danh mục cha: </strong></label>
                                        <div class="filltext">
                                            <input type="text" style="width:200px" id="parent_id" name="parent_id">
                                            <span class="s11">(Nhập mã ID danh mục cha! Nếu thêm mới danh mục cấp 1 thì nhập mã 0)</span>
                                        </div>
                                    </li>
                                    <li class="clearfix"><label><strong>Giá: </strong></label>
                                        <div class="filltext"><input type="text" value="" style="width:200px" id="price" name="price"> </div>
                                    </li>
                                    <li class="clearfix bor-bottom"><label><strong>Ảnh đại diện:</strong></label>
                                        <div class="filltext">            
                                            <input type="text" id="filename1" name="filename1" readonly/>&nbsp;
                                            <span id="spanButtonPlaceHolder"></span>
                                        </div>
                                    </li>
                                    <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                        <div class="filltext" id="img_0">
                                            
                                        </div>
                                    </li>
                                    <!--
                                    <li class="clearfix bor-bottom"><label><strong>File hướng dẫn:</strong></label>
                                        <div class="filltext">            
                                            <input type="text" id="filename2" name="filename2" readonly/>&nbsp;
                                            <span id="spanButtonPlaceHolder_other"></span>
                                        </div>
                                    </li>
                                    <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                        <div class="filltext" id="img_2">
                                            
                                        </div>
                                    </li>
                                    
                                    <li class="clearfix"><label><strong>Loại: </strong></label>
                                        <div class="filltext">
                                        	<select style="width:206px" id="camera_type" name="camera_type">
                                                <option value="0">--Chọn loại--</option>
                                                <?php
                                                $arr_camera_type = LoadConfig::$arr_camera_type;
                                                if($arr_camera_type)
                                                foreach($arr_camera_type as $key=>$value)
                                                {
                                                    ?>
                                                    <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                                    <?php
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                    
                                    <li class="clearfix"><label><strong>Tiêu cự: </strong></label>
                                        <div class="filltext"><input type="text" value="" style="width:200px" id="focus" name="focus"> </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Nội dung </strong></label>
                                        <div class="filltext">
                                            <textarea id="description" name="description"></textarea>
                                        </div>
                                    </li>
                                    
                                    <li class="clearfix">
                                        <label><strong>Thông số kỹ thuật </strong></label>
                                        <div class="filltext">
                                            <textarea id="info" name="info"></textarea>
                                        </div>
                                    </li>
                                    
                                    <li class="clearfix">
                                        <label><strong>Ảnh chụp sản phẩm </strong></label>
                                        <div class="filltext">
                                            <textarea id="info_other" name="info_other"></textarea>
                                        </div>
                                    </li>
                                    -->
                                    <li class="clearfix"><label><strong>Thứ tự sắp xếp : </strong></label>
                                        <div class="filltext"><input type="text" style="width:200px" id="ordering" name="ordering"><span class="s11"> (Nhập thứ tự)</span>
                                        </div>
                                    </li>
                                    <li class="clearfix"><label><strong>Hiển thị : </strong></label>
                                        <div class="filltext"><input type="checkbox" name="status" id="status" value="1" checked="checked"><span class="s11">(Hiển thị hoặc ẩn danh mục)</span>
                                        </div>
                                    </li>

                                    <li class="clearfix"><label><strong>DM Menu ngang: </strong></label>
                                        <div class="filltext"><input type="checkbox" name="is_menu" id="is_menu" value="0" ><span class="s11">(Chọn danh mục hiển thị trên menu)</span>
                                        </div>
                                    </li>
                                     <li class="clearfix"><label><strong>DM trang chủ: </strong></label>
                                        <div class="filltext"><input type="checkbox" name="is_hot" id="is_hot" value="0" ><span class="s11">(Chọn danh mục hiển thị trang chủ)</span>
                                        </div>
                                    </li>
                                    <li class="clearfix"><label><strong>DM trang chủ (Bottom): </strong></label>
                                        <div class="filltext"><input type="checkbox" name="is_home_bottom" id="is_home_bottom" value="0" ><span class="s11">(Chọn danh mục hiển thị cuối trang chủ)</span>
                                        </div>
                                    </li>
                                    <li class="clearfix"><label><strong>DM Có Link: </strong></label>
                                        <div class="filltext"><input type="checkbox" name="is_link" id="is_link" value="0" ><span class="s11">(Danh mục có link)</span>
                                        </div>
                                    </li>
                                    <li class="clearfix"><label><strong>Chọn Link: </strong></label>
                                        <div class="filltext"><input type="text" name="links" id="links" disabled="disabled" style="width:200px"><span class="s11"> (Nhập link đối với danh mục có link)</span>
                                        </div>
                                    </li>
                                    
                                    <li>
                                    	<label><strong>Loại danh mục</strong></label>
                                        <div class="filltext">
                                        <select id="cat_type" name="cat_type">
                                        <option value="0">--Chọn loại danh mục--</option>
                                        <?php
										$arr_cat_type=LoadConfig::$arr_cat_type;
										foreach($arr_cat_type as $key=>$value)
										{
											?>
                                            <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                            <?php
										}
                                        ?>
                                        </select>
                                        </div>
                                    	
                                    </li>
                                    <!--
                                    <li>
                                    	<label><strong>Layout</strong></label>
                                        <div class="filltext">
                                        <select id="is_layout" name="is_layout">
                                        	<option value="">Layout</option>
                                            <option value="1">Layout 1</option>
                                            <option value="2">Layout 2</option>
                                        </select>
                                        </div>
                                    </li>
                                    <li>
                                    	<label><strong>Icon</strong></label>
                                        <div class="filltext">
                                        <input type="text" id="icon" name="icon" />
                                        </div>
                                    </li>
                                    -->
                                    <li class="clearfix"><label>&nbsp;</label>
                                        <div class="filltext">
                                        	<br />
                                            <input type="button" value="Lưu" class="btn-orange" id="submit">
                                            <input type="hidden" id="cid" name="cid" value="0" />
                                            <input type="hidden" id="type" name="type" value="3" />
                                        </div>
                                    </li>
                                </ul>                            
                            </form>

                        </div>


                        <?php $this->renderPartial('application.views.static.footer') ;  ?> 
                    </div>
                    </div> 
                </td>
            </tr>
        </tbody>
    </table>
        </div>
