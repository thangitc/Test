<script>
$(function(){    
    $(".search_news").keypress(function(e){
        switch(e.which)
        {
            case 13: 
                pagingNews(1);
                break;
            default:
                break; 
        }
    });     
});

function pagingNews(page)
{
    var keyword = $("#keyword_news").val();
    var news_id = $("select[name='news_id'] option:selected").val();
    var numperpage = $("select[name='numperpage'] option:selected").val();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/pagingNews');?>',
		type: "POST",
		data:({
			page:page,
			keyword:keyword,
			news_id:news_id,
			numperpage:numperpage
		}),
		success: function(resp){
			$("#NewsQa").replaceWith(resp);
		}
	});
}

function chooseNews()
{
	var html_select='';
	var list_news_id=$('#list_news_id').val();
	$('.news_select').each(function(){
		if($(this).is(":checked"))
		{
			var news_id=$(this).attr('rel');
			list_news_id+=news_id+',';
			var title=$('#qa_title_'+news_id+'').html();
			html_select+='<div class="fl" rel="'+news_id+'"><a href="javascript:">'+title+'</a><a class="ic_del" onclick="$(this).parent(\'div\').remove();" href="javascript:">&nbsp;</a></div>';
		}
	});
    $("#list_qa_view").append(html_select);
	list_news_id=rtrim(list_news_id,',');
	$('#list_news_id').val(list_news_id);
    $.fn.colorbox.close();
}
</script>
<div style="width:770px; height:430px; display: block; padding: 10px;" class="popup">
	<p align="center"><strong class="clblue s18">Chọn câu hỏi liên quan</strong></p>
	<div class="popup-cont clearfix">
		<div class="box">
			<p>
				<input type="text" id="keyword_news" class="search_news" style="width: 430px;" />
            	<input type="button" onclick="pagingNews(1);" value="Tìm" class="btn-orange">
				&nbsp;
				<select name="cat_id" style="width:258px">
					<option value="0">-- Chọn danh mục --</option>
					<?php
					if($cats)
					foreach($cats as $row)
					{
						if($row['cat_type']==2)
						{
							?>
							<option value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
							<?php
							foreach($cats as $row2)
							{
								if($row2['parent_id']==$row['id'])
								{
									?>
									<option value="<?php echo $row2['id'];?>">--<?php echo $row2['title'];?></option>
									<?php
									foreach($cats as $row3)
									{
										if($row3['parent_id']==$row2['id'])
										{
											?>
											<option value="<?php echo $row3['id'];?>">--<?php echo $row3['title'];?></option>
											<?php
										}
									}
								}
							}
						}
					}
					?>
				</select>
			</p>
		</div>
		<div class="box" id="NewsQa">
			<div class="fillter clearfix" style="border-bottom:1px solid #ccc">
				<?php if($num_page >1) { ?>
				<div class="fl">
					<ul class="paging">
						<?php echo Paging::show_paging_ajax("pagingNews", array(),$num_page, $page, 9, ''); ?>						
					</ul>
				</div>
				<?php } ?>
				<div class="fr"> Hiển thị
					<select style="width:44px" name="numperpage">
						<option value="10" <?php if($num_per_page == 10) echo ("selected");?>>10 tin</option>
						<option value="20" <?php if($num_per_page == 20) echo ("selected");?>>20 tin</option>
						<option value="30" <?php if($num_per_page == 30) echo ("selected");?>>30 tin</option>
					</select>
				</div>
				<br/>&nbsp;
			</div>
			<?php
            foreach($news as $row)
			{
				?>
                <p>
                	<input class="news_select" rel="<?php echo $row["id"];?>" type="checkbox" id="news_id_<?php echo $row["id"];?>" name="news_id_<?php echo $row["id"];?>" value="<?php echo $row["id"];?>"/>
                    <span id="qa_title_<?php echo $row["id"];?>"><?php echo $row["title"];?></span>
                </p>
                <?php
			}
			?>
		</div>
		<p align="center">
			<input type="submit" onclick="chooseNews();" value="Lưu" class="btn-orange">	
		</p>
	</div>
</div>