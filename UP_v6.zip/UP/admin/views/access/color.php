<script>
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/calendar.png';?>"
	});
	$('#formSearch').keypress(function(e){
		switch(e.which)
		{
			case 13:
				$('#formSearch').submit();
			break;
		}
	});
});

function searchForm(tab)
{
	$('#tab').val(tab);
    $('#formSearch').submit();
}

function deleteColorAccess(color_id)
{
    var answer = confirm("Bạn có chắc chắn muốn xóa?");
    if(answer){
        $.ajax({
            url:"<?php echo Url::createUrl('ajax/deleteColorAccess');?>",
            type:"POST",
            data:({
            	color_id:color_id                                                   
            }),
            success:function(response){
                location.reload();
            },
            error:function(){
                alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
            }
        });
    }
}

function addProductBill(product_id, bill_id, product_type)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addProductBill');?>',
		type: "POST",
		data:({
			product_id:product_id,
			bill_id:bill_id,
			product_type:product_type
		}),
		success: function(resp){
			if(resp==0)
			{
				alert('Thêm sản phẩm lỗi');
				return false;
			}
			else if(resp==1)
			{
				alert('Thêm sản phẩm vào hóa đơn thành công!');
				location.reload();
			}
			else
			{
				alert(resp);
				return false;
			}
			
		}
	});
}
</script>
<div class="body_pages clearfix">
<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
    <tr>
        <td class="first" valign="top"><?php $this->renderPartial('application.views.static.sidebar') ;  ?></td>
        <td valign="top" class="last"><div class="content_pages" id="container">
                <?php $this->renderPartial('tab_color', array('access_id'=>$access_id));?>
                <div class="box_form">
                    <div class="box">
                        <div class="clearfix fillter">
                            <div class="fl reseach"> 
                            </div>
                            <div class="fr reseach">
                            	<a href="<?php echo Url::createUrl("access/addColor", array('access_id'=>$access_id));?>">
                                <input type="button"class="btn-orange" value="Thêm mới màu sắc">
                                </a>&nbsp;
                                <ul class="pages fr clearfix">
                                    <?php echo $paging;?>
                                </ul>
                                
                            </div>
                        </div>
                        <input type="hidden" id="list_id" />
                        <table width="100%" cellspacing="0" cellpadding="0" border="0" class="col_list txt-right" id="list">
                            <tbody>
                                <tr class="bg-grey">
                                    <td width="3%"><strong>ID </strong><br>
                                    <input type="checkbox" id="selectAll" onclick="doCheckAll();">
                                    </td>
                                    <td width="10%"><strong>Màu</strong></td>
                                    <td width="12%"><strong>Hình ảnh</strong></td>
                                    <td width="15%"><strong>Giá</strong></td>
                                </tr>
                                <?php
                                
                                $k=0;
                                foreach ($color as $row)
                                {
                                    $class='';
                                    if($k%2==0)
                                    {
                                        $class='class="bg_grays"';
                                    }
									if($row['picture']!='') $src = Common::getImage($row['picture'], 'access', '');
									else $src = '';
									$link_front_end = Yii::app()->params['baseUrlFront'].'/'.$row['color'].'-a'.$row['access_id'].'c'.$row['id'].'.html';
                                    ?>
                                    <tr <?php echo $class;?> rel="<?php echo $row['id'];?>">
                                        <td><?php echo ($row['id']);?><br />
                                            <input type="checkbox" value="<?php echo ($row['id']);?>" name="articles_<?php echo ($row['id']);?>" class="selectOne" onclick="doCheck();"></td>
                                        <td class="txt-left">
                                        	<a href="<?php echo $link_front_end;?>" target="_blank"><strong><?php echo stripslashes($row['color']);?></strong></a>
                                            <div class="clearfix col_30">
                                                <div class="row-actions">
                                                	<a href="<?php echo Url::createUrl("access/editColor", array("color_id"=>$row['id'],"access_id"=>$access_id));?>" title="Edit this item"><span>Edit</span></a> | <a href="javascript:" onclick="deleteColorAccess(<?php echo ($row['id']);?>);">Xóa</a> |
                                                    <a href="javascript:" onclick="addProductBill(<?php echo $row['id'];?>, <?php echo $bill_id;?>, 2)" class="editinline"> 
													Thêm Phụ kiện vào hóa đơn
                                                    </a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php
											if($row['picture']!='')
											{
												?>
                                                <img src="<?php echo $src;?>" width="150px;" height="150px;" />
                                                <?php
											}
											?>
                                        </td>
                                        <td style="text-align:left;">
                                            <?php
											echo 'Số lượng nhập: <strong style="color:red;">'.Common::formatNumber($row['num_p']).'</strong><br>';
											echo 'Số lượng bán: <strong style="color:red;">'.Common::formatNumber($row['num_buy']).'</strong><br>';
											echo '-----------------<br>';
											echo 'Giá hiển thị: <strong style="color:red;">'.Common::formatNumber($row['price']).'</strong><br>';
											echo 'Giá nhập: <strong style="color:red;">'.Common::formatNumber($row['price_in']).'</strong><br>';
											echo 'Giá khuyến mại: <strong style="color:red;">'.Common::formatNumber($row['price_deal']).'</strong> - Thời gian: '.date('d/m/Y', $row['time_deal']).'<br>';
											?>
                                        </td>
                                    </tr>
                                    <?php
                                    $k++;
                                }
                                ?>
                            </tbody>
                        </table>
                        <div class="clearfix fillter">                                	
                            <div class="fr reseach">
                                <ul class="pages fl magT5 clearfix">
                                    <?php echo $paging;?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $this->renderPartial('application.views.static.footer') ;  ?>
            </div>
		</td>
    </tr>
</table>
</div>
