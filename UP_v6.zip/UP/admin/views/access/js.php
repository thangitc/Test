<!--sort-->
<link rel="stylesheet" href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.widget.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.mouse.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.sortable.js"></script>

<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tinymce_des.js"></script>

<link rel="stylesheet" href="<?php echo Yii::app()->params['upload_url'];?>/css/swfupload.css" type="text/css" />
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.queue.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/fileprogress.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers_access.js"></script>

<script>
$(function(){
	$('#img_0').sortable();
	window.onload = function() {
		var configUploadData = {
			upload_url: upload_url_new+"upload_access.php"
			, create_date:'<?php $create_date=isset($detail["create_date"])? $detail["create_date"]:''; echo $create_date;?>'
			, file_types: "*.jpg;*.jpeg;*.png;*.gif;*.doc;*.docx;*.xls;*.xlsx;*.pdf;*.swf"
			, file_upload_limit : 16
			, file_queue_limit : 16
			, debug : true
		};
		configUpload(configUploadData);
	};

	$("#publish_date").datepicker({
		dateFormat:"dd/mm/yy",
		minDate: new Date()
	});
	$("#expired_date").datepicker({
		dateFormat:"dd/mm/yy",
		minDate: new Date()
	});
	
	$("#time_deal,#time_buy,#time_deal").datepicker({
		dateFormat:"dd/mm/yy",
	});
	//format_number
	$('#price,#price_in,#price_sale,#price_buy,#price_deal').keypress(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	
	$('#status_p').change(function(){
		if($(this).val()==1) $('#num_buy').val(0);
	});
	
	$('#is_customer').click(function(){
		if($('#is_customer').is(":checked"))
		{
			$('#form4_customer').show();
			$('#is_customer').val(1);
		}
		else
		{
			$('#form4_customer').hide();
			$('#is_customer').val(0);
		}
	});
	
	//format_number
	$('#price,#price_in,#price_sale,#price_buy,#tien_mat,#chuyen_khoan,#quet_the').keypress(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	$('#price,#price_in,#price_sale,#price_buy,#tien_mat,#chuyen_khoan,#quet_the').keyup(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	$('#price,#price_in,#price_sale,#price_buy,#tien_mat,#chuyen_khoan,#quet_the').keydown(function(){
		$(this).next('em').html(format_number($(this).val()));
	});

	
});

function addAccess(access_id,status)
{
	tinyMCE.triggerSave();
		
	var title=$('#title').val();
	var num_p=$('#num_p').val();
	var title_other=$('#title_other').val();
	var brand_id=$('#brand_id').val();
	var publish_date = $('#publish_date').val();
	var time_deal = $('#time_deal').val();
	
	var introtext=$('#introtext').val();
	var description=$('#description').val();	
	var specs=$('#specs').val();	
	var pic_product=$('#pic_product').val();	
	var picture = $('#filename1').val();
	var html_img = $('#img_0').html();
	var access_video = $('#access_video').val();
	var keyword = $('#keyword').val();
	var cat_id=$('#cat_id').val();
	var price=$('#price').val();
	var price_in=$('#price_in').val();
	var price_buy=$('#price_buy').val();
	var price_deal=$('#price_deal').val();
	var rating=$('#rating').val();
	var in_the_box=$('#in_the_box').val();
	var time_bh=$('#time_bh').val();
	var link_web=$('#link_web').val();
	
	if(title=='')
	{
		alert('Vui lòng nhập tiêu đề tin');
		$('#title').focus();
		return false;
	}
	if(num_p==0)
	{
		alert('Vui lòng nhập số lượng hàng nhập');
		$('#num_p').focus();
		return false;
	}
	if(introtext=='')
	{
		alert('Vui lòng nhập nội dung tóm tắt của tin');
		$('#introtext').focus();
		return false;
	}
	/*
	if(description=='')
	{
		alert('Vui lòng nhập nội dung tin');
		tinymce.execCommand('mceFocus',false,'description');
		return false;
	}
	*/
	
	if(cat_id==0)
	{
		alert('Vui lòng chọn danh mục tin');
		$('#cat_id').focus();
		return false;
	}
	
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addAccess');?>',
		type: "POST",
		data:({
			access_id:access_id,
			title:title,
			num_p:num_p,
			title_other:title_other,
			brand_id:brand_id,
			publish_date:publish_date,
			introtext:introtext,
			description:description,
			pic_product:pic_product,
			specs:specs,
			picture:picture,
			html_img:html_img,
			access_video: access_video,
			keyword:keyword,
			cat_id:cat_id,
			price:price,
			price_in:price_in,
			price_buy:price_buy,
			price_deal:price_deal,
			time_deal:time_deal,
			status:status,
			rating:rating,
			in_the_box:in_the_box,
			time_bh:time_bh,
			link_web:link_web
		}),
		success: function(resp){
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
			}
			else
			{
				alert('Lỗi');
			}
		}
	});
}

function addSaleAccess(access_id)
{
	var price_buy = $('#price_buy').val();
	var num_buy = $('#num_buy').val();
	var customer_id = $('#customer_id').val();
	var is_customer = $('#is_customer').val();
	var title=$('#title').val();
	var mobile=$('#mobile').val();
	var email=$('#email').val();
	var address=$('#address').val();
	var city_id=$('#city_id').val();
	var color_id=$('#color_id').val();
	
	var tien_mat = $('#tien_mat').val();
	var chuyen_khoan = $('#chuyen_khoan').val();
	var quet_the = $('#quet_the').val();
	var is_lazada = $('#is_lazada').val();
	var lazada_code = $('#lazada_code').val();
	var bill_id=$('#bill_id').val();
	
	if(price_buy=='')
	{
		alert('Vui lòng nhập giá bán');
		$('#price_buy').focus();
		return false;
	}
	if(isNaN(price_buy)){
		alert('Sai định dạng. Giá bán phải là số, không chứa khoảng trắng, dấu chấm, dấu phẩy!');
		$('#price_buy').focus();
		return false;
	}
	
	if(num_buy=='')
	{
		alert('Vui lòng nhập số lượng bán');
		$('#price_buy').focus();
		return false;
	}
	if(is_customer==1)
	{
		if($('#title').val()=='')
		{
			alert('Vui lòng nhập tên khách hàng!');
			$('#title').focus();
			return false;
		}
		if($('#mobile').val()=='')
		{
			alert('Vui lòng nhập số điện thoại!');
			$('#mobile').focus();
			return false;
		}
		if($('#address').val()=='')
		{
			alert('Vui lòng nhập địa chỉ!');
			$('#mobile').focus();
			return false;
		}
	}
	
	//loadingAjax();	
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addSaleAccess');?>',
		type: "POST",
		data:({
			price_buy:price_buy,
			num_buy:num_buy,
			customer_id:customer_id,
			is_customer:is_customer,
			title:title,
			mobile:mobile,
			email:email,
			address:address,
			city_id:city_id,
			color_id:color_id,
			tien_mat:tien_mat,
			chuyen_khoan:chuyen_khoan,
			quet_the:quet_the,
			is_lazada:is_lazada,
			lazada_code:lazada_code,
			access_id:access_id,
			bill_id:bill_id
		}),
		success: function(resp){
			//closeLoadingAjax();
			if(resp==1)
			{
				alert('Cập nhật thành công!');
				history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').html(resp);
			}
			/*
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
			*/
		}
	});
}

function addColorAccess(color_id,access_id)
{		
	var color=$('#color').val();
	var num_p=$('#num_p').val();
	var time_deal = $('#time_deal').val();
	var picture = $('#filename1').val();
	var html_img = $('#img_0').html();
	var price=$('#price').val();
	var price_in=$('#price_in').val();
	var price_buy=$('#price_buy').val();
	var price_deal=$('#price_deal').val();
	
	if(color=='')
	{
		alert('Vui lòng nhập tên màu');
		$('#title').focus();
		return false;
	}
	if(picture=='')
	{
		alert('Vui lòng chọn ảnh');
		$('#filename1').focus();
		return false;
	}
	
	
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addColorAccess');?>',
		type: "POST",
		data:({
			access_id:access_id,
			color:color,
			num_p:num_p,
			time_deal:time_deal,
			picture:picture,
			html_img:html_img,			
			price:price,
			price_in:price_in,
			price_buy:price_buy,
			price_deal:price_deal,
			color_id:color_id
		}),
		success: function(resp){
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
			}
			else
			{
				alert('Lỗi');
			}
		}
	});
}

function loadNumP(color_id)
{
	if(color_id!=0)
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/loadNumP');?>',
		type: "POST",
		data:({
			color_id:color_id			
		}),
		success: function(resp){
			$('#num_p').html(resp);
		}
	});
	else
	{
		location.reload();
	}
}

function format_number(num)
{
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
	num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num*100+0.50000000001);
	cents = num%100;
	num = Math.floor(num/100).toString();
	if(cents<10)
	cents = "0" + cents;
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	num = num.substring(0,num.length-(4*i+3))+','+
	num.substring(num.length-(4*i+3));
	return (((sign)?'':'-') + num);
}

function findCustomer(mobile)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/findCustomer');?>',
		type: "POST",
		data:({
			mobile:mobile
		}),
		success: function(resp){
			$('#result_customer').html(resp);
		}
	});
}

function setOneCustomer(customer_id)
{
	$('#customer_id').val(customer_id);
	$('#is_customer').val(0);
	$('#is_customer').removeAttr('checked');
	$('#form4_customer').hide();
}
</script>