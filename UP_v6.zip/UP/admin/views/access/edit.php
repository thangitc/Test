<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab');?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div style="border-right:1px solid #ccc;" class="col55">
                                    <ul class="form">
                                    	<li class="clearfix"><label><strong>Loại tin :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="cat_id" id="cat_id">
                                                	<option value="0" selected="selected">--Danh mục--</option>
                                                    <?php
													if($cats)
													foreach($cats as $row)
													{
														if($row['parent_id']==0 && $row['cat_type']==3)
														{
															$selected='';
															if($detail['cat_id']==$row['id']) $selected='selected';
															?>
															<option value="<?php echo $row['id'];?>" <?php echo $selected;?>><?php echo $row['title'];?></option>
															<?php
															foreach($cats as $row2)
															{
																if($row2['parent_id']==$row['id'])
																{
																	$selected='';
																	if($detail['cat_id']==$row2['id']) $selected='selected';
																	?>
																	<option value="<?php echo $row2['id'];?>" <?php echo $selected;?>>--<?php echo $row2['title'];?></option>
																	<?php
																	foreach($cats as $row3)
																	{
																		if($row3['parent_id']==$row2['id'])
																		{
																			$selected='';
																			if($detail['cat_id']==$row3['id']) $selected='selected';
																			?>
																			<option value="<?php echo $row3['id'];?>" <?php echo $selected;?> >----<?php echo $row3['title'];?></option>
																			<?php
																		}
																	}
																}
															}
														}
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Thương hiệu :</strong></label>
                                            <div class="filltext">
                                            <select style="width:179px;" name="brand_id" id="brand_id">
                                            	<option value="0" selected="selected">Chọn Thương hiệu</option>
												<?php
                                                if($brands)
												foreach($brands as $row)
												{
													if($row['brand_type']==1)
													{
														$selected ='';
														if($row['id']==$detail['brand_id']) $selected = 'selected';
														?>
                                                        <option <?php echo $selected;?> value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                                        <?php
													}
												}
                                                ?>
                                            	
                                            </select>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Tên phụ kiện :</strong></label>
                                            <div class="filltext">
                                                <input name="title" id="title" type="text" style="width:100%;" value="<?php echo $detail['title'];?>">
                                            </div>
                                        </li>                                        
                                        
                                        <li class="clearfix"><label><strong>Tên khác :</strong></label>
                                            <div class="filltext">
                                                <input name="title_other" id="title_other" type="text" style="width:100%;" value="<?php echo $detail['title_other'];?>">
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label><strong>Ảnh đại diện:</strong></label>
                                            <div class="filltext">            
                                            	<input type="text" id="filename1" name="filename1" readonly value="<?php echo $detail['picture'];?>"/>&nbsp;
                                                <span id="spanButtonPlaceHolder"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_0">
                                            <?php
											if(!empty($access_pic))
											foreach($access_pic as $row)
											{
												$src = Common::getImage($row['picture'], 'access', '');
												?>
                                                <div style="width:150px; float:left;">
                                                    <img width="150px;" height="90px" src="<?php echo $src;?>" alt="<?php echo $row['picture'];?>" />
                                                    <a href="javascript:" onclick="$(this).parent('div').remove();">Xóa</a>
                                                </div>
												<?php
											}
											else if($detail['picture']!='')
											{
												$src = Common::getImage($detail['picture'], 'access', '');
												?>
                                                <div style="width:150px; float:left;">
													<img width="150px;" height="90px" src="<?php echo $src;?>" alt="<?php echo $detail['picture'];?>" />
                                                    <a href="javascript:" onclick="$(this).parent('div').remove();">Xóa</a>
                                                </div>
												<?php
											}
											?>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Xếp hạng: </strong></label>
                                            <div class="filltext">
                                                <select style="width:206px" id="rating" name="rating">
                                                    <option value="0">--Chọn loại--</option>
                                                    <?php
                                                    $arr_rating = LoadConfig::$arr_rating;
                                                    if($arr_rating)
                                                    foreach($arr_rating as $key=>$value)
                                                    {
														$select='';
														if($key==$detail['rating']) $select='selected';
                                                        ?>
                                                        <option value="<?php echo $key;?>" <?php echo $select;?>><?php echo $value;?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Tóm tắt(Product Highlights):</strong> </label>
                                            <div class="filltext">
                                                <textarea style="width: 518px; height: 86px;" rows="5" cols="10" name="introtext" id="introtext"><?php echo $detail['introtext'];?></textarea>
                                            </div>                                            
                                        </li>
                                       	<li class="clearfix">
                                            <label><strong>Nội dung(Overview): </strong></label>
                                            <div class="filltext">
                                                <textarea id="description" name="description"><?php echo $detail['description'];?></textarea>
                                            </div>
                                        </li>
                                       	
                                        <li class="clearfix">
                                            <label><strong>Hình ảnh chụp từ sản phẩm </strong></label>
                                            <div class="filltext">
                                                <textarea id="pic_product" name="pic_product"><?php echo $detail['pic_product'];?></textarea>
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Thông số kỹ thuật </strong></label>
                                            <div class="filltext">
                                                <textarea id="specs" name="specs"><?php echo $detail['specs'];?></textarea>
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>In the box </strong></label>
                                            <div class="filltext">
                                                <textarea id="in_the_box" name="in_the_box"><?php echo $detail['in_the_box'];?></textarea>
                                            </div>
                                        </li>
                                        
                                        
                                    </ul>
                                    
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addAccess(<?php echo $detail['id'];?>,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addAccess(<?php echo $detail['id'];?>,'draft');"> &nbsp; </p>
                                    
                                    <div id="result">
                                    </div>
                                    
                                </div>
                               
                               <div class="col2">&nbsp;</div>
                                <div class="col40">
                                    <ul class="form1">
                                    	<li class="clearfix"><label><strong>Số lượng nhập :</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="num_p" name="num_p" style="width:170px" value="<?php echo $detail['num_p'];?>">
                                                </div>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Số lượng đã bán :</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <strong style="color:red;"><?php echo $detail['num_buy'];?></strong>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Giá :</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price" name="price" style="width:170px" value="<?php echo $detail['price'];?>">
                                                <em style="color:red;"><?php echo Common::formatNumber($detail['price']);?></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá nhập:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_in" name="price_in" style="width:170px" value="<?php echo $detail['price_in'];?>">
                                                <em style="color:red;"><?php echo Common::formatNumber($detail['price_in']);?></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá bán:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_buy" name="price_buy" style="width:170px" value="<?php echo $detail['price_buy'];?>">
                                                <em style="color:red;"><?php echo Common::formatNumber($detail['price_buy']);?></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá khuyến mại:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_deal" name="price_deal" style="width:170px" value="<?php echo $detail['price_deal'];?>">
                                                <em style="color:red;"><?php echo Common::formatNumber($detail['price_deal']);?></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Thời gian khuyến mại:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="time_deal" name="time_deal" value="<?php if($detail['time_deal']!=0) echo date('d/m/Y',$detail['time_deal']); ?>">
                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix">
                                            <label><strong>Thời gian bảo hành </strong></label>
                                            <div class="filltext">
                                                <input style="width:170px" type="text" id="time_bh" name="time_bh" value="<?php echo $detail['time_bh'];?>" />
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Ngày đăng tin:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px" value="<?php if($detail['publish_date']!=0) echo date('d/m/Y',$detail['publish_date']); ?>" id="publish_date" name="publish_date">
                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix">
                                            <label><strong>Video</strong></label>
                                            <div class="filltext">
                                                <input type="text" id="access_video" name="access_video" style="width:100%;" value="<?php echo $detail['access_video'];?>" />
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Từ khóa</strong></label>
                                            <div class="filltext">
                                                <input type="text" id="keyword" name="keyword" style="width:100%;" value="<?php echo $detail['keyword'];?>" />
                                            </div>
                                        </li>
                                        <hr />
                                        <li class="clearfix"><label><strong>Link web liên quan:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="height: 152px; width: 322px;" rows="5" cols="10" name="link_web" id="link_web"><?php echo $detail['link_web'];?></textarea>(Danh sách các link cách nhau bằng dấu phẩy)
                                            </div>                                            
                                        </li>
                                	</ul>
                                    
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addAccess(<?php echo $detail['id'];?>,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addAccess(<?php echo $detail['id'];?>,'draft');"> &nbsp; </p>
								</div>
                                
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php //$this->renderPartial('popup_upload');?>