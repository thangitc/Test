<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab');?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div style="border-right:1px solid #ccc; width:60%">
                                    <ul class="form">
                                    	
                                        <li class="clearfix"><label><strong>Tiêu đề tin :</strong></label>
                                            <div class="filltext">
                                                <input name="title" id="title" type="text" style="width:100%;" >
                                            </div>
                                        </li>                                        
                                        <li class="clearfix"><label><strong>Tiêu đề box :</strong></label>
                                            <div class="filltext">
                                                <input name="title_box" id="title_box" type="text" style="width:100%;" >
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Links :</strong></label>
                                            <div class="filltext">
                                                <input name="links" id="links" type="text" style="width:100%;" >
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label><strong>Ảnh đại diện:</strong></label>
                                            <div class="filltext">            
                                            	<input type="text" id="filename1" name="filename1" readonly/>&nbsp;
                                                <span id="spanButtonPlaceHolder"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_0">
                                            	
                                            </div>
                                        </li>
                                        <!--
                                        <li class="clearfix"><label><strong>Tóm tắt:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="width: 518px; height: 85px;" rows="5" cols="10" name="introtext" id="introtext"></textarea>
                                            </div>                                            
                                        </li>
                                       	-->
                                        <li class="clearfix">
                                            <label><strong>Giá </strong></label>
                                            <div class="filltext">
                                                <input type="text" id="price" name="price" />
                                                <em style="color:red;"></em> VND
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Xếp hạng: </strong></label>
                                            <div class="filltext">
                                                <select style="width:206px" id="rating" name="rating">
                                                    <option value="0">--Chọn loại--</option>
                                                    <?php
                                                    $arr_rating = LoadConfig::$arr_rating;
                                                    if($arr_rating)
                                                    foreach($arr_rating as $key=>$value)
                                                    {
                                                        ?>
                                                        <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </li>
                                                                                
                                        <li class="clearfix">
                                            <label><strong>Video</strong></label>
                                            <div class="filltext">
                                                <input type="text" id="embed_video" name="embed_video" style="width:100%;" />
                                            </div>
										</li>  
                                        
                                        <li class="clearfix"><label><strong>Ngày đăng tin:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="publish_date" name="publish_date">
                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix" id="is_chinh_hang"><label><strong>Loại Timeline</strong></label>
                                            <div class="filltext">
                                            <select style="width:179px" id="object_type" name="object_type">
                                            	<option value="0">Sản phẩm</option>
                                                <option value="1">Tin tức</option>
                                                <option value="2">Video</option>
                                            </select>
                                            
                                            </div>
                                        </li>
                                                                              
                                    </ul>
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addTimeline(0,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addTimeline(0,'pending');"> &nbsp; </p>
                                    
                                    <div id="result">
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>