<?php $this->renderPartial('js', array('detail'=>$detail));?>
<div class="body_pages clearfix">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
<tbody>
<tr>
    <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
    <td valign="top" class="last">
        <div class="content_pages">
        <?php $this->renderPartial('application.views.analytics._box_tab');?>
        <div class="box_form">
          
        <div class="box bottom30 clearfix">
        <div class="box bottom30 clearfix">
        <p>
        	<strong class="s14 clblue"><?php if($is_day==1) echo 'Sửa Thu/chi trong ngày'; else echo 'Sửa sinh hoạt Tháng';?></strong></p>
            <ul class="form4">
            	<li class="clearfix"><label><strong>Tiêu đề :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:250px" id="title" name="title" value="<?php echo $detail['title'];?>"> 
                    </div>
                </li>
                <li class="clearfix"><label><strong>Tiền :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:250px" id="money" name="money" value="<?php echo $detail['money'];?>"> 
                    <em style="color:red;"><?php echo Common::formatNumber($detail['money']);?></em> VND
                    </div>
                </li>
                <li class="clearfix"><label><strong>Lý do :</strong> </label>
                    <div class="filltext">
                    <textarea id="description" name="description" style="width: 655px; height: 118px;"><?php echo $detail['description'];?></textarea>
                    </div>
                </li>
                <li class="clearfix"><label><strong>Thu/Chi :</strong> </label>
                    <div class="filltext">
                    	<select id="status" name="status">
                        	<option value="1" <?php if($detail['status']==1) echo 'selected';?>>Thu</option>
                            <option value="0" <?php if($detail['status']==0) echo 'selected';?>>Chi</option>
                        </select>
                    </div>
                </li>
                <?php if($is_day==1) {?>
                <li class="clearfix"><label><strong>Sinh hoạt trong tháng :</strong> </label>
                        <div class="filltext">
                        <input type="checkbox" id="is_month" name="is_month" value="<?php echo $is_month;?>" <?php if($is_month==2) echo 'checked';?> />
                        </div>
                </li>
                <?php } ?> 
                <li class="clearfix"><label>&nbsp;</label>
                    <div class="filltext">
                    <input type="button" class="buton-radi" value="Cập nhật" onclick="addMoneyVn(<?php echo $detail['id'];?>,<?php echo $is_day;?>);">
                    </div>
                </li>
                <li style="color:red;" id="result"></li>
            </ul>
        
        </div>
        </div>
        
        </div> 
            <?php $this->renderPartial('application.views.static.footer');?>
        </div>
    </td>
</tr>
</tbody>
</table>
</div>