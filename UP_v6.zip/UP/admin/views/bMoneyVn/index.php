<link href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css" rel="stylesheet">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>
<script>
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/ic-date.png';?>"
	});
	$('#formSearch').keypress(function(e){
		switch(e.which)
		{
			case 13:
				$('#formSearch').submit();
			break;
		}
	});
});
function searchForm(tab)
{
	$('#tab').val(tab);
    $('#formSearch').submit();
}
/*Xoa*/
function deleteMoneyVn(money_id)
{
	if(confirm('Bạn có chắc chắn muốn xóa bản ghi và những dữ liệu liên quan?'))
		$.ajax({
		url: '<?php echo Url::createUrl('bMoneyVn/deleteMoneyVn');?>',
		type: "POST",
		data:({
			money_id:money_id
		}),
		success: function(resp){
			if(resp!=1)
			{
				alert(resp);
			}
			location.reload();
		}
	});
}

</script>

<div class="body_pages clearfix">
    <table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
        <tr>
            <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
            <td valign="top" class="last"><div class="content_pages">
                    <?php $this->renderPartial('application.views.analytics._box_tab');?>
                    <div class="box_form">
                        <div class="box bottom30 clearfix">
                            <form method="get" id="formSearch">
                                <ul class="form4">
                                    <li class="clearfix">
                                        <label><strong>Từ khóa :</strong> </label>
                                        <div class="filltext">
                                            <input type="text" style="width:196px;margin-right:20px" name="keyword" id="keyword" value="<?php echo $keyword;?>">
                                            &nbsp; Trong &nbsp;
                                            <select style="width:145px;margin-left:62px" id="keyword_in" name="keyword_in">
                                                <option value="1" <?php if($keyword_in==1) echo 'selected';?>>Tiêu đề</option>
                                                <option value="2" <?php if($keyword_in==2) echo 'selected';?>>ID</option>
                                            </select>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Từ ngày: </strong></label>
                                        <div class="filltext">
                                            <input type="text" style="width:170px" value="<?php if(isset($from_date) && $from_date!=0) echo date('d/m/Y',$from_date);?>" id="from_date" name="from_date">
                                            &nbsp; Đến ngày &nbsp;
                                            <input type="text" style="width:170px" id="to_date" name="to_date" value="<?php if(isset($to_date) && $to_date!=0) echo date('d/m/Y',$to_date);?>">
                                        </div>
                                    </li>
                                    
                                    <li class="clearfix">
                                        <label>&nbsp;</label>
                                        <div class="filltext">
                                            <input type="button" class="buton-radi" value="Tìm kiếm" onclick="searchForm('');">
                                            <input type="button" value="Hủy" class="buton-radi" onclick="window.location.href='<?php echo Url::createUrl('bMoneyVn/index');?>'" />                                            
                                        </div>
                                    </li>
                                    
                                    <li>
                                    	<div class="filltext"> <a href="javascript:" onclick="searchForm(1);"><?php if($tab==1) echo '<strong>Hôm nay</strong>'; else echo 'Hôm nay';?> <strong style="color:red;">(<?php echo $total_1;?>)</strong></a> &nbsp;&nbsp; <a href="javascript:" onclick="searchForm(2);"> <?php if($tab==2) echo '<strong>Hôm qua</strong>'; else echo 'Hôm qua';?><strong style="color:red;">(<?php echo $total_2;?>)</strong></a>&nbsp;&nbsp; <a href="javascript:" onclick="searchForm(3);"><?php if($tab==3) echo '<strong>Tháng này</strong>'; else echo 'Tháng này';?><strong style="color:red;">(<?php echo $total_3;?>)</strong></a>&nbsp;&nbsp; <a href="javascript:" onclick="searchForm(4);"><?php if($tab==4) echo '<strong>Tháng trước</strong>'; else echo 'Tháng trước';?><strong style="color:red;">(<?php echo $total_4;?>)</strong></a>&nbsp;&nbsp;<a href="javascript:" onclick="searchForm(0);"><?php if($tab==0) echo '<strong>Tất cả</strong>'; else echo 'Tất cả';?><strong style="color:red;">(<?php echo $total_0;?>)</strong></a>
                                        <input type="hidden" id="tab" name="tab" />
                                        </div>
                                    </li>
                                    <li>
                                    	<div class="filltext">
                                        <br />
                                        Tổng thu: <strong style="color:red;"><?php echo Common::formatNumber($thu);?></strong> VND
                                        <br />
                                        Tổng chi: <strong style="color:red;"><?php echo Common::formatNumber($chi);?></strong> VND
                                        </div>
                                    </li>
                                </ul>
                            </form>
                        </div>
                        <div class="box clearfix">
                            <div class="clearfix fillter">
                                <div class="fl">
                                    
                                </div>                                
                               
                                <div class="fl"><strong>Tìm Thấy : </strong>  <strong style="color:red;"><?php echo $total;?> </strong><strong> kết quả trong </strong> <strong><?php echo $page.' trang' ?></strong></div>
                                <div class="fr reseach">
                                    <input type="button" class="btn-orange fl magr10" value="Thêm mới" onclick="window.location.href='<?php echo Url::createUrl('bMoneyVn/add', array('is_day'=>0));?>'">
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0" id="list" class="col_list txt-right">
                                <tbody>
                                    <tr class="bg_grblue">
                                        <td width="2%">
                                            <strong>STT/ID</strong>
                                            <br>
                                            <input type="checkbox" id="selectAll" onclick="doCheckAll();">
                                            <input type="hidden" id="list_id" />
                                        </td>
                                        <td width="12%"><strong>Tiêu đề </strong></td>
                                        <td width="15%"><strong>Số tiền</strong></td>
										<td width="20%"><strong>Lý do </strong></td>
                                        <td width="8%"><strong>Ngày </strong></td>
                                    </tr>
                                    <?php
									$k=0;
									if($money)
									foreach($money as $row)
									{
										?>
										<tr>
											<td>
												<?php echo (($page-1)*$num_per_page+$k);?>
												<hr />
												<?php echo $row['id'];?>
												<br />
												<input type="checkbox" value="<?php echo $row['id'];?>" class="selectOne" onclick="doCheck();">
											</td>
											<td class="txt-left">
												<div class="clearfix col_30">
												<p><strong><?php echo $row['title'];?></strong></p>
												<div class="row-actions">
                                                	<a href="<?php echo Url::createUrl('bMoneyVn/edit',array('money_id'=>$row['id']));?>"><span>Sửa</span></a> 
                                                    | <a href="javascript:" onclick="deleteMoneyVn(<?php echo $row['id'];?>);"><span>Xóa</span></a> 
                                                    
                                                    
                                                </div>
                                                </div>
											</td>
                                            <td><?php if($row['status']==1) echo 'Thu: '; else echo 'Chi: '; ?> <strong style="color:red;"><?php echo Common::formatNumber($row['money']);?></strong> VND</td>
                                            <td><?php echo $row['description'];?></td>
                                            <td><?php echo date('d/m/Y',$row['create_date']);?></td>
										</tr>
										<?php 
									}
									?>
                                </tbody>
                            </table>
                            <div class="clearfix fillter">
                                <div class="fr reseach">
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $this->renderPartial('application.views.static.footer');?>
                </div>
            </td>
        </tr>
    </table>
</div>