<script>
function addMoneyVn(money_id, is_day)
{	
	var title=$('#title').val();
	var money=$('#money').val();
	var description=$('#description').val();
	var status=$('#status').val();
	var is_month = 0;
	if(is_day==0)
	{
		is_month = 1;
	}
	else
	{
		is_month = $('#is_month').val();
	}
	loadingAjax();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addMoneyVn');?>',
		type: "POST",
		data:({
			title:title,
			money:money,
			description:description,
			status:status,
			is_day:is_day,
			is_month:is_month,
			money_id:money_id
		}),
		success: function(resp){
			closeLoadingAjax();
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
		}
	});
}

function format_number(num)
{
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
	num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num*100+0.50000000001);
	cents = num%100;
	num = Math.floor(num/100).toString();
	if(cents<10)
	cents = "0" + cents;
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	num = num.substring(0,num.length-(4*i+3))+','+
	num.substring(num.length-(4*i+3));
	return (((sign)?'':'-') + num);
}
$(function(){
	//format_number
	$('#money').keypress(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	$('#money').keyup(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	$('#money').keydown(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	
	$('#is_month').click(function(){
		if($('#is_month').is(":checked"))
		{
			$('#is_month').val(2);
		}
		else
		{
			$('#is_month').val(0);
		}
	});
});
</script>