                                <div class="footer">
                                    CAMERA Company
                                </div>