<?php $this->beginContent('/layouts/main');
    $pcontroller_id= Yii::app()->controller->id;
    $paction_id=Yii::app()->controller->action->id; 
?>
<?php echo $content; ?>
<?php $this->endContent(); ?>