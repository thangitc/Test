<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/style/theme.css?v=2" media="all" />
<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/style/popup.css" media="all" />
<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/style/style.css" media="all" />

<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/jquery-1.7.2.min.js" type="text/javascript"></script>
<!--
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/jquery-3.1.0.min.js" type="text/javascript"></script>
-->
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/js_v1.js" type="text/javascript"></script>
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/keypress.js" type="text/javascript"></script>

<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery-ui-1.8.9.custom.js"></script>
<link href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css" rel="stylesheet">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>

<style type="text/css" media="all">@import "<?php  echo Yii::app()->params['static_url']; ?>/js/colorbox/colorbox.css";
</style>
<script type="text/javascript" src="<?php  echo Yii::app()->params['static_url']; ?>/js/colorbox/jquery.colorbox-min.js" ></script>

<title>Admin - CAMERA</title>
</head>
<body>
<script>
/*
$(function(){
 $(document).keypress(function(e){
  switch(e.which)
  {
   case 13: 
    searchForm('');
   break;
  }
 });
});
*/
</script>
    <div class="wrapper">
        <div class="header clearfix">
            <div class="fl" style="margin-top:10px;"> <a href="<?php echo Yii::app()->params['baseUrl'];?>" ><img src="<?php echo Yii::app()->params['static_url'];?>/images/footerLogo.png" /></a>
            </div>
            <div class="log_user fr">
                <?php
                if(Yii::app()->user->id)
                {
                    echo 'Tài khoản cá nhân: <strong>'.Yii::app()->user->name.'</strong> ( <a class="exit" href="'.Url::createUrl('admin/logout').'">Thoát</a> ) ';
                }
                ?>                
            </div> 
        </div>
