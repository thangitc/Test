<?php $this->renderPartial('js_model');?>
<?php $this->renderPartial('js');?>
<div class="body_pages clearfix">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
<tbody>
<tr>
    <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
    <td valign="top" class="last">
        <div class="content_pages">
        <?php //$this->renderPartial('application.views.eExam._box_tab');?>
        <div class="box_form">
          
        <div class="box bottom30 clearfix">
        <div class="box bottom30 clearfix">
        <p>
        	<strong class="s14 clblue">Thêm mới Body</strong></p>
            <ul class="form4">
            	<li class="clearfix"><label><strong>Chọn Model :</strong></label>
                    <div class="filltext">
                        <select style="width:179px;" name="model_id" id="model_id">
                            <option value="0" selected="selected">--Chọn Model--</option>
                            
                            <?php
                            if($models)
                            foreach($models as $row)
                            {
                                ?>
                                <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    
                </li>
                <li class="clearfix"><label><strong>Tiêu đề :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="title" name="title"> 
                    </div>
                </li>
                <li class="clearfix"><label>&nbsp;</label>
                    <div class="filltext">
                    <input type="button" class="buton-radi" value="Thêm mới" onclick="addBody(0);">
                    </div>
                </li>
                <li style="color:red;" id="result"></li>
            </ul>
        
        </div>
        </div>
        
        </div> 
            <?php $this->renderPartial('application.views.static.footer');?>
        </div>
    </td>
</tr>
</tbody>
</table>
</div>