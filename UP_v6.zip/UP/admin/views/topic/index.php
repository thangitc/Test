<link href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css" rel="stylesheet">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>
<script>
    $(function(){
        $("#from_date,#to_date").datepicker({
            dateFormat:"dd/mm/yy",
            showOn: "button",
            buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/ic-date.png';?>"
        });
		
		$('#formSearch').keypress(function(e){
			switch(e.which)
			{
				case 13:
					$('#formSearch').submit();
				break;
			}
		});
    });
    function searchForm(tab)
    {
        $('#tab').val(tab);
        $('#formSearch').submit();
    }

    /*Bo kich hoat*/
    function isActiveTopicNews(topic_id)
    {
        $.ajax({
            url: '<?php echo Url::createUrl('ajax/isActiveTopicNews');?>',
            type: "POST",
            data:({
                topic_id:topic_id
            }),
            success: function(resp){
                location.reload();
            }
        });
    }
    function isHotTopicNews(topic_id)
    {
        $.ajax({
            url: '<?php echo Url::createUrl('ajax/isHotTopicNews');?>',
            type: "POST",
            data:({
                topic_id:topic_id
            }),
            success: function(resp){
                location.reload();
            }
        });
    }
    /*Xoa*/
    function deleteTopicNews(topic_id)
    {
        if(confirm('Bạn có chắc chắn muốn xóa bản ghi và những dữ liệu liên quan?'))
            $.ajax({
            url: '<?php echo Url::createUrl('ajax/deleteTopicNews');?>',
            type: "POST",
            data:({
                topic_id:topic_id
            }),
            success: function(resp){
				if(resp!=1)
				{
					alert(resp);
				}
                location.reload();
            }
        });
    }

    function quickUpdateTopic(quick_type,list_id)
    {
        if(list_id=='')
		{
            alert('Bạn chưa chọn chuyên đề để xóa. Hãy làm lại.');
            return false;
        }
        else
            {
            loadingAjax();
            $.ajax({
                url:'<?php echo Url::createUrl('ajax/quickUpdateTopicNews');?>',
                type:"POST",
                data:({
                    quick_type:quick_type,
                    list_id:list_id
                }),
                success:function(response){
                    location.reload();
                    closeLoadingAjax();
                },
                error:function(){
                    alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
                    closeLoadingAjax();
                }
            });
        }
    }
    function updateOrderTopic()
    {    
        var list_order='';
        var topic_id=0;
        var topic_order=0;

        $('#list tbody>tr').each(function(i){
            topic_id=$(this).attr('rel');
            if(topic_id)
			{               
                topic_order=$('#ordertopic_'+topic_id+'').val();
                list_order+=topic_id+'|'+topic_order+',';
            }
        });

        if(list_order!='')
            {
            loadingAjax();
            $.ajax({
                url: '<?php echo Url::createUrl('ajax/updateOrderTopic');?>',
                type: "POST",
                data:({
                    list_order:list_order
                }),
                success: function(resp){
                    closeLoadingAjax();
                    location.reload();
                }
            });
        }
    }
</script>

<div class="body_pages clearfix">
    <table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
        <tr>
            <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
            <td valign="top" class="last"><div class="content_pages">
                    <?php //$this->renderPartial('application.views.eExam._box_tab');?>
                    <div class="box_form">
                        <div class="box bottom30 clearfix">
                            <form method="get" id="formSearch">
                                <ul class="form4">
                                    <li class="clearfix">
                                        <label><strong>Từ khóa :</strong> </label>
                                        <div class="filltext">
                                            <input type="text" style="width:196px;margin-right:20px" name="keyword" id="keyword" value="<?php echo $keyword;?>">
                                            &nbsp; Trong &nbsp;
                                            <select style="width:145px;margin-left:62px" id="keyword_in" name="keyword_in">
                                                <option value="1" <?php if($keyword_in==1) echo 'selected';?>>Tiêu đề</option>
                                                <option value="2" <?php if($keyword_in==2) echo 'selected';?>>ID</option>
                                            </select>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Chọn danh mục: </strong></label>
                                        <div class="filltext">
                                            <select style="width:206px" id="cat_id" name="cat_id">
                                                <option value="0">--Chọn danh mục--</option>
                                                <?php
                                                    if($cats)
                                                        foreach($cats as $row)
                                                        {
                                                            if($row['parent_id']==0 && $row['cat_type']==3)
                                                            {
                                                                $parent_id=$row['id'];
                                                                $selected='';
                                                                if($cat_id==$row['id']) $selected='selected';
                                                            ?>
                                                            <option value="<?php echo $row['id'];?>" <?php echo $selected;?>><?php echo $row['title'];?></option>
                                                            <?php
                                                                foreach($cats as $row2)
                                                                {
                                                                    if($row2['parent_id']==$parent_id)
                                                                    {
                                                                        $parent_id_2=$row2['id'];
                                                                        $selected='';
                                                                        if($cat_id==$row2['id']) $selected='selected';
                                                                    ?>
                                                                    <option value="<?php echo $row2['id'];?>" <?php echo $selected;?>>--<?php echo $row2['title'];?></option>
                                                                    <?php
                                                                        foreach($cats as $row3)
                                                                        {
                                                                            if($row3['parent_id']==$parent_id_2)
                                                                            {
                                                                                $selected='';
                                                                                if($cat_id==$row3['id']) $selected='selected';
                                                                            ?>
                                                                            <option value="<?php echo $row3['id'];?>" >----<?php echo $row3['title'];?></option>
                                                                            <?php
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                    }
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Từ ngày: </strong></label>
                                        <div class="filltext">
                                            <input type="text" style="width:170px" value="<?php if(isset($from_date) && $from_date!=0) echo date('d/m/Y',$from_date);?>" id="from_date" name="from_date">
                                            &nbsp; Đến ngày &nbsp;
                                            <input type="text" style="width:170px" id="to_date" name="to_date" value="<?php if(isset($to_date) && $to_date!=0) echo date('d/m/Y',$to_date);?>">
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label>&nbsp;</label>
                                        <div class="filltext">
                                            <input type="submit" class="buton-radi" value="Tìm kiếm">
                                            <input type="button" class="buton-radi" value="Hủy" onclick="window.location.href='<?php echo Url::createUrl('topic/index');?>'">
                                            <input type="button" value="Sắp xếp" class="buton-radi" onclick="updateOrderTopic();">
                                        </div>
                                    </li>
                                </ul>
                                <input type="hidden" id="tab" name="tab" />
                            </form>
                        </div>
                        <div class="box clearfix">
                            <p>
                                <span class="magr20"><a href="javascript:" onclick="searchForm(-1);"><strong class="clblue">Tất cả</strong></a> <strong class="clred">(<?php echo $total_all;?>)</strong></span>
                                <span class="magr20"><a href="javascript:" onclick="searchForm(1);"><strong class="clblue">Active </strong></a> <strong class="clred">(<?php echo $total_publish;?>)</strong></span>
                                <span class="magr20"><a href="javascript:" onclick="searchForm(2);"><strong class="clblue">InActive </strong> </a><strong class="clred">(<?php echo $total_pending;?>)</strong></span>
                            </p>

                            <div class="clearfix fillter">
                                <div class="fl">
                                    Thao tác nhanh
                                    <select style="min-width:100px"  id="quick_type">
                                        <option value="1">Kích hoạt</option>
                                        <option value="2">Bỏ kích hoạt</option>
                                        <option value="3">Xóa</option>
                                    </select>
                                    <input type="button" class="btn-orange" value="Lưu" onclick="quickUpdateTopic($('#quick_type').val(),$('#list_id').val());">
                                </div>
                                </br >
                                </br >
                                <div class="fl"><strong>Tìm Thấy : </strong>  <strong style="color:red;"><?php echo $total;?> </strong><strong> Chuyên đề trong </strong> <strong><?php echo $page.' trang' ?></strong></div>
                                <div class="fr reseach">
                                    <input type="button" class="btn-orange fl magr10" value="Thêm mới Chuyên đề" onclick="window.location.href='<?php echo Url::createUrl('topic/add');?>'">
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0" id="list" class="col_list txt-right">
                                <tbody>
                                    <tr class="bg_grblue">
                                        <td width="2%">
                                            <strong>STT/ID</strong>
                                            <br>
                                            <input type="checkbox" id="selectAll" onclick="doCheckAll();">
                                            <input type="hidden" id="list_id" />
                                        </td>
                                        <td width="34%"><strong>Tiêu đề Chuyên đề</strong></td>
                                        <td width="22%"><strong>Nhãn Chuyên đề </strong></td>
                                        <td width="12%"><strong>Sắp xếp </strong></td>
                                        <td width="12%"><strong>Thống kê</strong></td>
                                        <td width="18%"><strong>Thời gian/ Người gửi</strong></td>
                                    </tr>
                                    <?php
                                        $k=0;
                                        if($topic)
										foreach($topic as $row)
										{
											$row_cat=isset($cat_topic[$row['cat_id']]) ? $cat_topic[$row['cat_id']]:array();
											$link_detai = Yii::app()->params['baseUrl'].'/'.$row['alias'].'-ex'.$row['id'].'.html';
											$total_news = isset($news_total[$row['id']]) ? $news_total[$row['id']] : 0;
											?>
											<tr id="topic_<?php echo ($row['id']);?>" rel="<?php echo $row['id'];?>">
												<td>
													<?php echo (($page-1)*$num_per_page+$k);?>
													<hr />
													<?php echo $row['id'];?>
													<br />
													<input type="checkbox" value="<?php echo $row['id'];?>" class="selectOne" onclick="doCheck();">
												</td>
												<td class="txt-left">
													<span class="<?php if($row['status']=='active') echo "approv fl";else if($row['status']=='pending') echo "pending fl";else if($row['status']=='draft') echo "draft fl";  ?>"></span>
													<div class="clearfix col_30">
													<p><a <?php if($row['is_hot']==1) echo 'style="color:red;"';?> href="<?php echo $link_detai;?>" target="_blank"><strong><?php echo $row['title'];?></strong></a></p>
													<div class="row-actions">
                                                    	<a href="<?php echo Url::createUrl('topic/edit',array('topic_id'=>$row['id']));?>"><span>Sửa</span></a>
                                                        | <a href="javascript:" onclick="deleteTopicNews(<?php echo $row['id'];?>);"><span>Xóa</span></a>
                                                        | <a href="javascript:" onclick="isActiveTopicNews(<?php echo $row['id'];?>);"><span><?php if($row['status']=='pending') echo 'Kích hoạt'; else echo 'Bỏ kích hoạt';?></span></a>
                                                        | <a href="javascript:" onclick="isHotTopicNews(<?php echo $row['id'];?>);"><span><?php if($row['is_hot']==0) echo 'Nổi bật'; else echo 'Bỏ nổi bật';?></span></a>
                                                        | <a href="<?php echo Url::createUrl('topic/news',array('topic_id'=>$row['id']));?>"><span>Danh sách tin</span></a>
                                                    </div>
												</td>
												<td class="txt-left">
													<a class="under" href="<?php echo $link_detai;?>" target="_blank"><strong><?php echo $row['title_short'];?></strong></a>
												</td>
												<td>
													<input type="text" id="ordertopic_<?php echo $row['id']; ?>" style="width:70px" value="<?php echo $row['ordering'];?>">
												</td>
												<td class="txt-left">
													<p>Số tin: <a href="<?php echo Url::createUrl('topic/news',array('topic_id'=>$row['id']));?>"><strong><?php echo $total_news; ?></strong></a></p>
												</td>
												<td class="txt-left"><p>Tác giả: <a class="under" href="javascript:" rel="nofollow"><strong><?php echo $row['admin_name'];?></strong></a><?php echo date('d/m/Y - H:i a',$row['create_date']);?></p> </td>
											</tr>
											<?php 
										}
									?>
                                </tbody>
                            </table>
                            <div class="clearfix fillter">
                                <div class="fr reseach">
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $this->renderPartial('application.views.static.footer');?>
                </div>
            </td>
        </tr>
    </table>
</div>