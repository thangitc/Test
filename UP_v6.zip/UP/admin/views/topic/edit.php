<?php $this->renderPartial('js');?>
<div class="body_pages clearfix">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
<tbody>
<tr>
    <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
    <td valign="top" class="last">
        <div class="content_pages">
        <?php //$this->renderPartial('application.views.eExam._box_tab');?>
        <div class="box_form">
          
        <div class="box bottom30 clearfix">
        <div class="box bottom30 clearfix">
        <p>
        	<strong class="s14">Sửa chuyên đề: <em class="clblue"><?php echo $detail['title'];?></em></strong></p>
            <ul class="form4">
                <li class="clearfix"><label><strong>Tên chuyên đề :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="title" name="title" value="<?php echo $detail['title'];?>"> 
                    </div>
                </li>
                <li class="clearfix"><label><strong>Nhãn :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="title_short" name="title_short" value="<?php echo $detail['title_short'];?>"> 
                    </div>
                </li>
                <li class="clearfix"><label><strong>Tên danh mục :</strong></label>
                    <div class="filltext">
                    	<select style="width:206px" id="cat_id" name="cat_id">
                        <option value="0">--Chọn danh mục--</option>
						<?php
                        if($cats)
                        foreach($cats as $row)
                        {
                            if($row['parent_id']==0 && $row['cat_type']==3)
                            {
                                $parent_id=$row['id'];
								$selected='';
								if($detail['cat_id']==$row['id']) $selected='selected';
                                ?>
                                <option value="<?php echo $row['id'];?>" <?php echo $selected;?>><?php echo $row['title'];?></option>
                                <?php
                                foreach($cats as $row2)
                                {
                                    if($row2['parent_id']==$parent_id)
                                    {
                                        $parent_id_2=$row2['id'];
										$selected='';
										if($detail['cat_id']==$row2['id']) $selected='selected';
                                        ?>
                                        <option value="<?php echo $row2['id'];?>" <?php echo $selected;?>>--<?php echo $row2['title'];?></option>
                                        <?php
                                        foreach($cats as $row3)
                                        {
                                            if($row3['parent_id']==$parent_id_2)
                                            {
												$selected='';
												if($detail['cat_id']==$row3['id']) $selected='selected';
                                                ?>
                                                <option value="<?php echo $row3['id'];?>" >----<?php echo $row3['title'];?></option>
                                                <?php
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        ?>
                        </select>
                    </div>
                </li>
               	<li class="clearfix">
                	<label><strong>Chuyên đề Có Link: </strong></label>
                    <div class="filltext">
                    	<input type="checkbox" name="is_link" id="is_link" value="<?php echo $detail['is_link'];?>" <?php if($detail['is_link']==1) echo 'checked';?> >
                    </div>
                </li>
                <li class="clearfix"><label><strong>Nhập Link: </strong></label>
                    <div class="filltext">
                    	<input type="text" name="links" id="links" <?php if($detail['is_link']==0) echo 'disabled';?> style="width:370px" value="<?php echo $detail['links'];?>">
                    </div>
                </li>
                <li class="clearfix"><label><strong>Ghi chú: </strong></label>
                    <div class="filltext">
                    	<textarea id="introtext" name="introtext" style="width: 375px; height: 127px;"><?php echo $detail['introtext'];?></textarea>
                    </div>
                </li>
                <li class="clearfix">
                	<label><strong>Ảnh đại diện: </strong></label>
                    <div class="filltext">                                
                        <label>1. Upload ảnh từ máy tính</label><br/>
                        <div>
                            <div style="float:left;"><input type="text" id="txtFileName" readonly style="width:240px;" value="<?php echo $detail['picture'];?>" /></div>
                            <div style="float:left; margin:1px 0 0 5px;"><span id="spanButtonPlaceHolder"></span></div>
                            <div style="clear:both;"></div>
                        </div>
                        <label>2. Hoặc Url:</label><br/> 
                        <input type="text" size="37px" name="urlFile" id="urlFile">
                        <input type="button" class="buton-radi" id="urlFileButton" value="Upload File"/>
                        <input type="hidden" id="picture" name="picture" value="<?php echo $detail['picture'];?>" />
                        <div class="fieldset flash" id="fsUploadProgress"></div>
                        
                        <p class="magT5" id="result_file1">
                        <?php
                        if($detail['picture']!='')
                        {
                            $picture=Common::getImage($detail['picture'],'topic','');
                            ?>
                            <img width="150px;" height="150px" src="<?php echo $picture;?>" />
                            <a class="ic_del" href="javascript:" onclick="$('#picture').val('');$('#result_file1').html('');">&nbsp;</a>
                            <?php
                        }
                        ?>
                        </p>
                	</div>
                </li>
               	<li class="clearfix">
                	<label><strong>Từ khóa: </strong></label>
                    <div class="filltext">
                    	<input type="textbox" name="keyword" id="keyword" style="width:370px" value="<?php echo $detail['keyword'];?>">
                    </div>
                </li>
                <li class="clearfix"><label>&nbsp;</label>
                    <div class="filltext">
                    <input type="button" class="buton-radi" value="Cập nhật" onclick="addTopic(<?php echo $detail['id'];?>);">
                    </div>
                </li>
                <li style="color:red;" id="result"></li>
            </ul>
        
        </div>
        </div>
        
        </div> 
            <?php $this->renderPartial('application.views.static.footer');?>
        </div>
    </td>
</tr>
</tbody>
</table>
</div>