<link href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css" rel="stylesheet">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>

<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tinymce_des.js"></script>

<link rel="stylesheet" href="<?php echo Yii::app()->params['upload_url'];?>/css/swfupload.css" type="text/css" />
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.queue.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/fileprogress.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers_topic.js"></script>

<style type="text/css" media="all">@import "<?php  echo Yii::app()->params['static_url']; ?>/js/colorbox/colorbox.css";</style>
<script type="text/javascript" src="<?php  echo Yii::app()->params['static_url']; ?>/js/colorbox/jquery.colorbox-min.js" ></script>


<script>
window.onload = function() {
	var configUploadData = {
		upload_url: upload_url_new+"upload_topic.php"
		, create_date:'<?php $create_date=isset($detail["create_date"])? $detail["create_date"]:''; echo $create_date;?>'
		, file_types: "*.jpg;*.jpeg;*.png;*.gif;*.doc;*.docx;*.xls;*.xlsx;*.pdf;*.swf"
		, file_upload_limit : 1
		, file_queue_limit : 1
		, debug : true
	};
	configUpload(configUploadData);
};
$(function(){
	$('#is_link').click(function(){
		if($(this).val()==1)
		{
			$(this).removeAttr('checked');
			$(this).val(0);
			$('#links').removeAttr('disabled').attr('disabled','disabled');
			$('#links').val('');
		}
		else
		{
			$(this).attr('checked','checked');            
			$(this).val(1);
			$('#links').removeAttr('disabled');
		}
	});
	
});
function addTopic(topic_id)
{	
	var cat_id=$('#cat_id').val();
	var title=$('#title').val();
	var title_short=$('#title_short').val();
	var is_link=$('#is_link').val();
	var links=$('#links').val();
	var picture=$('#picture').val();
	var introtext=$('#introtext').val();
	var keyword=$('#keyword').val();
	
	if(cat_id==0)
	{
		alert('Vui lòng chọn danh mục!');
		return false;
	}
	if($('#title').val()=='')
	{
		alert('Vui lòng nhập tên chuyên đề!');
		$('#title').focus();
		return false;
	}
	
	else if($('#is_link').val()!=0 && $('#links').val()=='')
	{
		alert('Vui lòng nhập link cho chuyên đề!');
		$('#links').focus();
		return false;
	}
	
	loadingAjax();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addTopicNews');?>',
		type: "POST",
		data:({
			cat_id:cat_id,
			title:title,
			title_short:title_short,
			picture:picture,
			introtext:introtext,
			is_link:is_link,
			links:links,
			keyword:keyword,
			topic_id:topic_id
		}),
		success: function(resp){
			closeLoadingAjax();
			if(resp>=0)	
			{
				//alert('Cập nhật thành công!');
				//history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
		}
	});
}
</script>