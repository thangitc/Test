<?php $url = new Url();?>    
   <div class="body_pages clearfix">
            <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
                <tbody>
                    <tr>
                        <td class="first" valign="top">
                              <?php $this->renderPartial('application.views.static.sidebar') ;  ?>
                        </td>
                        <td valign="top" class="last">
                            <div class="content_pages">
                            
                                <div class="box_form">
                                 <div class="box magt20 bottom30">
            <ul class="form">
          <li class="clearfix">
            <label><strong>Họ tên  </strong><span class="clred">*</span></label>
            <div class="filltext">
                        <input type="text"  id="full_name" name="full_name"  value="<?php echo $infor['full_name'];?>" style="width:220px">
                    </div>
          </li>
          <li class="clearfix">
            <label><strong>Tên đăng nhập  </strong><span class="clred">*</span></label>
            <div class="filltext">
                        <input type="text" id="username" name="username" value="<?php echo $infor['username'];?>" style="width:220px">
                    </div> 
          </li>
          <li class="clearfix">
            <label><strong>Email </strong><span class="clred">*</span></label>
            <div class="filltext">
                        <input type="text" id="email" name="email" value="<?php echo $infor['email'];?>" style="width:220px">
                    </div>
          </li>
          <li class="clearfix">
                        <label><strong>Vị trí </strong><span class="clred">*</span></label>
                        <div class="filltext">
                        <select style="width: 100px;" id="type_admin" name="type_admin">
                            <option value="1" <?php if($infor['type_admin']==1) echo 'selected';?>>Admin</option>
                            <option value="2" <?php if($infor['type_admin']==2) echo 'selected';?>>Biên tập viên</option>
                            <option value="3" <?php if($infor['type_admin']==3) echo 'selected';?>>Cộng tác viên</option>                       
                        </select>
                    </div>
                        
                    </li>
          <li class="clearfix">
                        <label><strong>Thông tin khác </strong> </label>
                        <div class="filltext">
                              <div class="filltext">
                        <textarea style="width:70%; height:120px" id="info_admin" name="info_admin"><?php echo $infor['info'];?></textarea>
                    </div>
                        </div>
                    </li>                    
          <li class="clearfix">
            <label>&nbsp;</label>
            <div class="filltext">
          <input  type="submit" class="buton-radi" onclick="saveAdmin()" value=" Sửa ">
            </div>
          </li>
          <li id="result_login" style="color:red;">
                </li>
        </ul>
        </div>
            
                                
        </div> 
                                 <?php $this->renderPartial('application.views.static.footer') ;  ?>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
<script>
function check_editemail(mail) {
    emailRegExp = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.([a-z]){2,4})$/;
    if (emailRegExp.test(mail)) {
        return 1;
    }
    else {
        return 0;
    }
}
function saveAdmin()
{
    var full_name = $("#full_name").val();
    var email = $("#email").val();
    var type_admin=$('#type_admin').val();
    var info_admin=$('#info_admin').val();
    if(full_name ==""){
        $('#result_login').html('Vui lòng nhập họ tên');
        return false;
    }
    
    if(check_editemail(email) !=1){
        $('#result_login').html('Không đúng định dạng email');
        return false;  
    }
    
    var strUrl = "<?=$url->createUrl("admin/updateProfile") ?>"; 
    $.ajax({
        type: "POST",
        url: strUrl,
        data: {email:email,full_name:full_name,type_admin:type_admin,info_admin:info_admin,user_id:'<?php echo $infor['id'];?>'},
        success: function(msg){
            $('#result_login').html(msg);
        }
    });
}
</script>