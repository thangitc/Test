<link href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css" rel="stylesheet">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>
<script>
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/ic-date.png';?>"
	});
	$('#formSearch').keypress(function(e){
		switch(e.which)
		{
			case 13:
				$('#formSearch').submit();
			break;
		}
	});
});
function searchForm(tab)
{
	$('#tab').val(tab);
    $('#formSearch').submit();
}
/*Xoa*/
function deleteOrder(order_id)
{
	if(confirm('Bạn có chắc chắn muốn xóa bản ghi và những dữ liệu liên quan?'))
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/deleteOrder');?>',
		type: "POST",
		data:({
			order_id:order_id
		}),
		success: function(resp){
			location.reload();
		}
	});
}

function approvedOrder(order_id, status, info_note)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/approvedOrder');?>',
		type: "POST",
		data:({
			order_id:order_id,
			status:status,
			info_note:info_note
		}),
		success: function(resp){
			//location.reload();
		}
	});
}
</script>

<div class="body_pages clearfix">
    <table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
        <tr>
            <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
            <td valign="top" class="last"><div class="content_pages">
                    <?php //$this->renderPartial('application.views.analytics._box_tab');?>
                    <div class="box_form">
                        <div class="box bottom30 clearfix">
                            <form method="get" id="formSearch" action="<?php echo Url::createUrl('cart/index');?>">
                                <ul class="form4">
                                    <li class="clearfix">
                                        <label><strong>Từ khóa :</strong> </label>
                                        <div class="filltext">
                                            <input type="text" style="width:196px;margin-right:20px" name="keyword" id="keyword" value="<?php echo $keyword;?>">
                                            &nbsp; Trong &nbsp;
                                            <select style="width:145px;margin-left:62px" id="keyword_in" name="keyword_in">
                                                <option value="1" <?php if($keyword_in==1) echo 'selected';?>>ID</option>
                                            </select>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                    	<label><strong>Trạng thái: </strong></label>
                                        <div class="filltext">
                                            <select id="order_status" name="order_status">
                                            <option value="">Chọn</option>
                                            <?php
                                            $arr_order_status = LoadConfig::$arr_order_status;
                                            foreach($arr_order_status as $key=>$value)
                                            {
                                                $selected = '';
                                                if($key==$order_status) $selected = 'selected';
                                                ?>
                                                <option value="<?php echo $key;?>" <?php echo $selected;?>><?php echo $value;?></option>
                                                <?php
                                            }
                                            ?>
                                            </select>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Từ ngày: </strong></label>
                                        <div class="filltext">
                                            <input type="text" style="width:170px" value="<?php if(isset($from_date) && $from_date!=0) echo date('d/m/Y',$from_date);?>" id="from_date" name="from_date">
                                            &nbsp; Đến ngày &nbsp;
                                            <input type="text" style="width:170px" id="to_date" name="to_date" value="<?php if(isset($to_date) && $to_date!=0) echo date('d/m/Y',$to_date);?>">
                                        </div>
                                    </li>
                                    
                                    <li class="clearfix">
                                        <label>&nbsp;</label>
                                        <div class="filltext">
                                            <input type="button" class="buton-radi" value="Tìm kiếm" onclick="searchForm('');">
                                            <input type="button" value="Hủy" class="buton-radi" onclick="window.location.href='<?php echo Url::createUrl('cart/index');?>'" />                                            
                                        </div>
                                    </li>
                                    
                                    <li>
                                    	<div class="filltext"> <a href="javascript:" onclick="searchForm(1);"><?php if($tab==1) echo '<strong>Hôm nay</strong>'; else echo 'Hôm nay';?> <strong style="color:red;">(<?php echo $total_1;?>)</strong></a> &nbsp;&nbsp; <a href="javascript:" onclick="searchForm(2);"> <?php if($tab==2) echo '<strong>Hôm qua</strong>'; else echo 'Hôm qua';?><strong style="color:red;">(<?php echo $total_2;?>)</strong></a>&nbsp;&nbsp; <a href="javascript:" onclick="searchForm(3);"><?php if($tab==3) echo '<strong>Tháng này</strong>'; else echo 'Tháng này';?><strong style="color:red;">(<?php echo $total_3;?>)</strong></a>&nbsp;&nbsp; <a href="javascript:" onclick="searchForm(4);"><?php if($tab==4) echo '<strong>Tháng trước</strong>'; else echo 'Tháng trước';?><strong style="color:red;">(<?php echo $total_4;?>)</strong></a>&nbsp;&nbsp;<a href="javascript:" onclick="searchForm(0);"><?php if($tab==0) echo '<strong>Tất cả</strong>'; else echo 'Tất cả';?><strong style="color:red;">(<?php echo $total_0;?>)</strong></a>
                                        <input type="hidden" id="tab" name="tab" />
                                        </div>
                                    </li>
                                   
                                </ul>
                            </form>
                        </div>
                        <div class="box clearfix">
                            <div class="clearfix fillter">
                                <div class="fl">
                                    
                                </div>                                
                               
                                <div class="fl"><strong>Tìm Thấy : </strong>  <strong style="color:red;"><?php echo $total;?> </strong><strong> kết quả trong </strong> <strong><?php echo $page.' trang' ?></strong></div>
                                <div class="fr reseach">
                                    
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0" id="list" class="col_list txt-right">
                                <tbody>
                                    <tr class="bg_grblue">
                                        <td width="5%">
                                            <strong>Mã đơn hàng</strong>
                                            <br>
                                            <input type="checkbox" id="selectAll" onclick="doCheckAll();">
                                            <input type="hidden" id="list_id" />
                                        </td>
                                        <td width="25%"><strong>Sản phẩm</strong></td>
                                        <td width="20%"><strong>Thông tin đặt hàng</strong></td>
                                        <td width="20%"><strong>Nội dung</strong></td>
										<td width="10%"><strong>Trạng thái </strong></td>
                                        <td width="8%"><strong>Ngày </strong></td>
                                    </tr>
                                    <?php
									$arr_order_status = LoadConfig::$arr_order_status;
									$k=0;
									if($orders)
									foreach($orders as $row)
									{
										$list_products_one = isset($list_products[$row['id']]) ? $list_products[$row['id']] : array();
										?>
										<tr>
											<td>
												<?php echo (($page-1)*$num_per_page+$k);?>
												<hr />
												<?php echo $row['id'];?>
												<br />
												<input type="checkbox" value="<?php echo $row['id'];?>" class="selectOne" onclick="doCheck();">
											</td>
											
                                            <td class="txt-left">
												<?php
												if($list_products_one)
												foreach($list_products_one as $row2)
												{
													$alias = Common::generate_slug($row2['title']);
													if($row2['product_type']==0) //san pham
													{
														$link_p = Yii::app()->params['baseUrlFront'].'/'.$alias.'-b'.$row2['product_id'].'.html';
														$link_sale = Url::createUrl('bList/sale', array('camera_id'=>$row2['product_id'], 'order_id'=>$row['id']));
													}
													else if($row2['product_type']==1) //phu kien
													{
														$link_p = Yii::app()->params['baseUrlFront'].'/'.$alias.'-a'.$row2['product_id'].'.html';
														$link_sale = Url::createUrl('access/sale', array('access_id'=>$row2['product_id'], 'order_id'=>$row['id']));
													}
													else //phu kien, mau sac
													{
														$access_id = AccessColor::getAccessIdById($row2['product_id']);
														$link_p = Yii::app()->params['baseUrlFront'].'/'.$alias.'-a'.$access_id.'c'.$row2['product_id'].'.html';
														$link_sale = Url::createUrl('access/sale', array('access_id'=>$access_id,'color_id'=>$row2['product_id'], 'order_id'=>$row['id']));
													}
													?>
                                                    - <a href="<?php echo $link_p;?>" target="_blank"><?php echo $row2['title'];?></a> - SL: <?php echo $row2['quantity'];?> - Giá bán: <?php echo Common::formatNumber($row2['price']);?> VND (Giá hiển thị: <?php echo Common::formatNumber($row2['price_show']);?>, <?php if($row2['price_deal']!=0) echo 'Giá KM: '.Common::formatNumber($row2['price_deal']);?>) &nbsp;<a target="_blank" href="<?php echo $link_sale;?>">Bán</a><br />
                                                    <?php
												}
                                                ?>
                                                <br />
                                                <hr />
                                                Tổng giá trị đơn hàng: <strong style="color:red;"><?php echo Common::formatNumber($row['total_price']);?></strong> VND
                                                <div class="row-actions">
                                                	<a href="javascript:" onclick="deleteOrder(<?php echo $row['id'];?>);"><span>Xóa</span></a> 
                                                </div>
                                                <hr />
                                                <?php
												$color = '';
												if($row['order_status']=='canceled')  $color = 'style="color:red; font-size:16px;"';
												if($row['order_status']=='completed')  $color = 'style="color:blue; font-size:16px;"';
												if($row['order_status']=='pending')  $color = 'style="color:purple; font-size:16px;"';
												if($row['order_status']=='processing')  $color = 'style="color:#6F0; font-size:16px;"';
                                                ?>
                                                <strong <?php echo $color;?> ><?php echo $arr_order_status[$row['order_status']];?></strong>
                                            </td>
                                            <td class="txt-left">
											Họ và tên: <?php echo $row['billing_name'];?><br />
                                            Mobile: <?php echo $row['billing_mobile'];?><br />
                                            Email: <a href="mailto:<?php echo $row['billing_email'];?>"><?php echo $row['billing_email'];?></a><br />
                                            Địa chỉ: <?php echo $row['billing_address'];?><br />
                                            </td>
                                            <td><?php echo $row['billing_note'];?></td>
                                            <td>											
                                            	<select onchange="approvedOrder(<?php echo $row['id'];?>,$(this).val(), $('#info_note<?php echo $row['id'];?>').val());">
                                                	<option value="">--Duyệt đơn hàng--</option>
                                                    <?php
                                                    foreach($arr_order_status as $key=>$value)
													{
														$selected = '';
														if($key==$row['order_status']) $selected = 'selected';
														?>
                                                        <option <?php echo $selected;?> value="<?php echo $key;?>"><?php echo $value;?></option>
                                                        <?php
													}
													?>
                                                </select>
                                                <textarea style="width: 188px; height: 157px;" id="info_note<?php echo $row['id'];?>"><?php echo $row['info_note']?></textarea>
                                            </td>
                                            <td>
												Ngày tạo: <?php echo date('H:i, d/m/Y',$row['created']);?><br /><br />
                                                <?php if($row['modified']!=0) echo '<hr>Ngày xử lý:'.date('H:i, d/m/Y',$row['modified']);?>
                                            </td>
										</tr>
										<?php
										$k++;
									}
									?>
                                </tbody>
                            </table>
                            <div class="clearfix fillter">
                                <div class="fr reseach">
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $this->renderPartial('application.views.static.footer');?>
                </div>
            </td>
        </tr>
    </table>
</div>