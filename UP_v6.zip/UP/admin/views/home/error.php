<div style="margin-bottom: 10px;">
    <h2>Error <?php echo $error["code"]; ?></h2>
    <div class="error">
    <?php echo CHtml::encode($error["message"]); ?>
    </div>
</div>
