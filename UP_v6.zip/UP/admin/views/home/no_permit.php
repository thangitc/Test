<div class="body_pages clearfix">
<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
    <tr>
        <td class="first" valign="top"><?php $this->renderPartial('application.views.static.sidebar');?></td>
        <td valign="top" class="last">
        	<div class="content_pages" id="container">
            	<div style="height:500px; margin:50px;">
                	<center><strong style="color:red; font-size:20px;">No Permission</strong></center>
                </div>
                <?php $this->renderPartial('application.views.static.footer') ;  ?>
            </div>
		</td>
    </tr>
</table>
</div>