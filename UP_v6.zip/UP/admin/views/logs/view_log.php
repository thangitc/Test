<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css" media="all">@import "<?php  echo Yii::app()->params['static_url']; ?>/style/theme.css";</style>
<title>Danh sách log</title>
</head>
<body>
<div>
    <div class="popup-cont clearfix">
        <div class="box" id="box_event">
        	<?php
			if($log_detail)
			{
				$object=$log_detail['object'];
				$object=json_decode($object);
				if(is_object($object) || is_array($object))
				foreach($object as $key=>$value)
				{
					echo '<strong style="color:red;">'.$key.'</strong>:<br>';
					if(is_object($value) || is_array($value))
					{
						foreach($value as $key1=>$value1)
						{
							if(is_object($value1) || is_array($value1)) {
								foreach ($value1 as $key2=>$value2) {
									echo '<strong>'.$key2.'</strong>:'.stripslashes($value2).'<br>';	
								}
							} else {
								echo '<strong>'.$key1.'</strong>:'.stripslashes($value1).'<br>';
							}
						}
					}
					else
					echo htmlspecialchars ($value);
				}
			}
            ?>
        </div>
    </div>
</div>
</body>
</html>
