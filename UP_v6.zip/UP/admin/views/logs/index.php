<style type="text/css" media="all">@import "<?php  echo Yii::app()->params['static_url']; ?>/js/colorbox/colorbox.css";</style>
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/colorbox/jquery.colorbox-min.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>
<script>
    $(function(){
        $("#from_date, #to_date").datepicker({
            dateFormat:"dd/mm/yy",
            showOn: "button",
            buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/ic-date.png';?>",
        });

        $('.paging').find('a').each(function(){
            $(this).attr('href','javascript:');
        });

        $('.paging').find('a').click(function(){
            $('#page').val($(this).children('span').html());
            $('#form_post').submit();
            return false;
        });
        $(".viewlog").colorbox({innerWidth:550, innerHeight:450});

    });
</script> 
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tr>
            <td class="first" valign="top">
                <?php $this->renderPartial('application.views.static.sidebar') ;  ?> 
            </td>
            <td valign="top" class="last">
                <div class="content_pages">
                <div class="box_tab">
                    <ul class="clearfix">
                        <li class="fl active"><span><a href="">QL Log</span></a></li>
                    </ul>
                </div>
                <div class="box_form">

                <div class="box bottom30 clearfix">
                    <form id="form_post" action="<?php echo Url::createUrl('logs/index');?>" method="get">
                        <ul class="form4 bottom30">
                        <li class="clearfix">
                            <label><strong>Từ khóa:</strong></label>
                            <div class="filltext">
                                <input type="text" id="keyword" name="keyword" size="30" value="<?php echo $keyword;?>">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Trong:</strong>
                                <select style="width:100px" name="keyword_field">
                                  <option value="logId" <?php if(isset($keyword_field) && $keyword_field === "logId") echo "selected"; ?>>ID</option>
                                  <option value="content" <?php if(isset($keyword_field) && $keyword_field === "content") echo "selected"; ?>>Nội dung</option>
                                  <option value="userName" <?php if(isset($keyword_field) && $keyword_field === "userName") echo "selected"; ?>>User name</option>
                            </select>
                            </div>
                        </li>
                        <li class="clearfix">
                            <label><strong>Chọn sự kiện:</strong></label>
                            <div class="filltext">
                                <select id="name_action" name="name_action" style="width:214px">
                                <option value="">---Chọn---</option>
                                <option value="Thêm" <?php if($name_action=='Thêm') echo 'selected';?> >Thêm</option>
                                <option value="Sửa" <?php if($name_action=='Sửa') echo 'selected';?> >Sửa</option>
                                <option value="Xóa" <?php if($name_action=='Xóa') echo 'selected';?>>Xóa</option>
                                <option value="Seo" <?php if($name_action=='Seo') echo 'selected';?>>Seo</option>
                            </select>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Loại:</strong>
                                
                                <select id="module" name="module" style="width:100px">
                                 <option value="">---Chọn---</option>
                            <?php 
                                $modules=Common::array_module();
                                if($modules)
                                foreach($modules as $key=>$value)
                                {
                                    if($key==$module)
                                        $selected='selected';
                                    else
                                        $selected='';
                                    echo '<option '.$selected.' value='.$key.'> '.$value.' </option>';
                                }
                            ?>
                            </select>
                            </div>
                        </li>
                        <li class="clearfix">
                            <label><strong>Xem từ:</strong></label>
                            <div class="filltext">
                                <input type="text" style="width:150px" name="from_date" id="from_date" value="<?php if($from_date!=0) echo date('d/m/Y',$from_date); ?>" >
                        &nbsp; Đến &nbsp;
                        <input type="text" style="width:150px" name="to_date" id="to_date" value="<?php if($to_date!=0) echo date('d/m/Y',$to_date); ?>">
                            </div>
                        </li>
                        <li class="clearfix">
                            <label>&nbsp;</label>
                            <div class="filltext">
                                <input type="hidden" id="page" name="page" value="1" />
                                <input type="submit" class="buton-radi" value=" Xem ">
                            </div>
                        </li>
                    </ul>
                                        </form>
                </div>
                <div class="box">
                <div class="clearfix fillter">
                    <div class="fl">Tổng số: <strong class="clred"><?php echo $total_record;?></strong> bài viết trong <?php echo ceil ($total_record/$num_per_page);?> trang </div>
                    <div class="fr reseach">
                        <ul class="pages fl magT5 clearfix">
                            <?php echo $paging;?>
                        </ul>
                    </div>
                </div>
                <table width="100%" cellspacing="0" cellpadding="0" border="0" class="col_list txt-right">
                <tbody>
                <tr class="bg-grey">
                    <td width="3%"><strong>STT</strong></td>
                    <td width="45%"><strong>Tên sự kiện</strong></td>
                    <td width="14%"><strong>Tên tài khoản</strong></td>
                    <td width="12%"><strong>Thời gian </strong></td>
                </tr>
                <?php
                    $k=1;
                    if($logs)
                        foreach($logs as $row)
                        {
                        ?>
                        <tr>
                        <td>
                            <?php echo ($k+($page-1)*$num_per_page);?>
                            <hr />
                        <?php echo $row['id'];?> </td>
                    </td>
                    <td class="text-left"><?php echo stripslashes($row['content']);?></td>

                    <td><a class="viewlog" href="<?php echo Url::createUrl('logs/viewLog',array('id'=>$row['id']));?>"> <?php echo $row['username'];?> </a></td>
                    <td><?php echo date('H:ia  d/m/Y',$row['time_action']);?></td>
                </tr>
                <?php
                    $k++;
            }
        ?>

        </tbody>
    </table>
    <div class="clearfix fillter">
        <div class="fl"><span class="clred">Log nội dung sau 3 tháng xóa 1 lần</span></div>
        <div class="fr reseach">
            <ul class="pages fl magT5 clearfix">
                <?php echo $paging;?>
            </ul>
        </div>
    </div>
        </div>
    </div> 
    <?php $this->renderPartial('application.views.static.footer');?>
</div>
</td>
</tr>
</table>
</div>
