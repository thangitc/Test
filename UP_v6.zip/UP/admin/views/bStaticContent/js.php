<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tinymce_des.js"></script>
<script>
function addStaticContent(static_id)
{
	tinyMCE.triggerSave();
	var description=$('#description').val();
	loadingAjax();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addStaticContent');?>',
		type: "POST",
		data:({
			description:description,
			static_id:static_id
		}),
		success: function(resp){
			closeLoadingAjax();
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				location.reload();
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
		}
	});
}
</script>