<?php
class CombosController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		
		$url_rewrite=Common::genUrlRewrite();
		
		list($combos ,$paging,$total, $list_products, $list_camera, $list_access)=Combos::getCombos($keyword,$keyword_in ,$page,$num_per_page,$url_rewrite);
		
		$this->render('index',
				array('combos'=>$combos,'paging'=>$paging,'total'=>$total,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,
                      'list_products'=>$list_products, 'list_camera'=>$list_camera, 'list_access'=>$list_access
		));	
	}
	public function actionAdd()
	{
		$this->render('add');
	}
	public function actionEdit()
	{
		$combo_id=isset($_GET['combo_id']) ? intval($_GET['combo_id']) :0;
		$detail = Combos::getCombosById($combo_id);

		$this->render('edit',array('detail'=>$detail));
	}
	
	public function actionDeleteCombo()
	{
		$combo_id=isset($_POST['combo_id']) ? intval($_POST['combo_id']) : 0;
		if($combo_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$combo_id),'tbl_combos');
		}
		echo 1;
	}
    public function actionAddProduct()
    {
        $combo_id=isset($_GET['combo_id']) ? intval($_GET['combo_id']) :0;
        $detail = Combos::getCombosById($combo_id);
        $this->render('add_product', array('detail'=>$detail));
    }
}
?>