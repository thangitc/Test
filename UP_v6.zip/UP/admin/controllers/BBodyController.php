<?php
class BBodyController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		$model_id=isset($_GET['model_id']) ? intval($_GET['model_id']):0;
		
		$url_rewrite=Common::genUrlRewrite();
		
		list($body ,$paging,$total, $models )=BBody::getBody($model_id, $keyword,$keyword_in ,$page,$num_per_page,$url_rewrite);
		
		//Danh muc
		$cats=$this->cats;
		//Models
		$list_models = BModel::getAllModel();
		$this->render('index',
				array('body'=>$body,'paging'=>$paging,'total'=>$total,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,'model_id'=>$model_id,
					  'models'=>$models,'list_models'=>$list_models
		));	
	}
	public function actionAdd()
	{		
		$models = BModel::getAllModel();
		$this->render('add', array('models'=>$models));
	}
	public function actionEdit()
	{
		$body_id=isset($_GET['body_id']) ? intval($_GET['body_id']) :0;
		$detail = BBody::getBodyById($body_id);
		$models = BModel::getAllModel();
		$this->render('edit',array('detail'=>$detail, 'models'=>$models));
	}
	
	public function actionDeleteBody()
	{
		$body_id=isset($_POST['body_id']) ? intval($_POST['body_id']) : 0;
		if($body_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$body_id),'b_combo_body');
		}
		echo 1;
	}
}
?>