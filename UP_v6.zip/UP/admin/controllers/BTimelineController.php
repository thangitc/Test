<?php
class BTimelineController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 0;
		
		$url_rewrite=Common::genUrlRewrite();
		
		list($total_all, $total_active, $total_pending) = BTimeline::countTabTimeline();
		
		list($list,$paging,$total)=BTimeline::getTimeline($keyword,$keyword_in, $tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite);
		$this->render("index",
				array('list'=>$list,'paging'=>$paging,'total'=>$total, 
					  'total_all'=>$total_all,'total_active'=>$total_active, 'total_pending'=>$total_pending, 
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,
					  'page'=>$page,'num_per_page'=>$num_per_page
		));
	}
	public function actionAdd()
	{
		$timeline_id=isset($_GET['timeline_id']) ? intval($_GET['timeline_id']):0;
		$detail=BTimeline::getTimelineById($timeline_id);
        $this->render("add",
				array('detail'=>$detail,'timeline_id'=>$timeline_id
		));
	}
	public function actionEdit()
	{
		$timeline_id=isset($_GET['timeline_id']) ? intval($_GET['timeline_id']):0;
		$detail = BTimeline::getTimelineById($timeline_id);
		
        $this->render("edit",
				array('detail'=>$detail, 'timeline_id'=>$timeline_id
		));
	}
	
	public function actionDeleteTimeline()
	{
		$timeline_id=isset($_POST['timeline_id']) ? intval($_POST['timeline_id']) : 0;
		if($timeline_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$timeline_id),'b_timeline');
		}
		echo 1;
	}
}
?>