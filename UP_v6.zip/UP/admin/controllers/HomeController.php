<?php
class HomeController extends Controller
{
	public function actionIndex()
	{
		$total_order = Cart::countOrder();
		$notes = Notes::getNotes();
		$this->render('index', array('total_order'=>$total_order, 'notes'=>$notes));
	}
}
?>