<?php
class BMoneyVnController extends Controller
{
	//Tien sinh hoat trong thang
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 1;
		
		$url_rewrite=Common::genUrlRewrite();
		
		$cond_add = '(is_month=1 || is_month=2)';
		list($total_0, $total_1, $total_2, $total_3, $total_4) = BMoneyVn::getTotalMoneyVn($cond_add);
		
		list($money ,$paging,$total, $thu, $chi)=BMoneyVn::getMoneyVn($keyword,$keyword_in, $from_date, $to_date,$tab,$page,$num_per_page,$url_rewrite);
		
		$this->render('index',
				array('money'=>$money,'paging'=>$paging,'total'=>$total,
					  'total_0'=>$total_0,'total_1'=>$total_1, 'total_2'=>$total_2, 'total_3'=>$total_3,'total_4'=>$total_4,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'from_date'=>$from_date, 'to_date'=>$to_date,
					  'tab'=>$tab,
					  'thu'=>$thu, 'chi'=>$chi
		));	
	}
	//Tien thu chi buon ban trong ngay
	public function actionDay()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 1;
		$type = isset($_GET['type']) ? intval($_GET['type']) : 0;
		$url_rewrite=Common::genUrlRewrite();
		
		$cond_add = '(is_month=0 || is_month=2)';
		list($total_0, $total_1, $total_2, $total_3, $total_4) = BMoneyVn::getTotalMoneyVn($cond_add);
		
		list($money ,$paging,$total, $thu, $chi, $tien_mat, $chuyen_khoan, $quet_the, $total_is_lazada)=BMoneyVn::getMoneyVnDay($keyword,$keyword_in, $from_date, $to_date,$tab,$type,$page,$num_per_page,$url_rewrite);
		
		$this->render('day',
				array('money'=>$money,'paging'=>$paging,'total'=>$total,
					  'total_0'=>$total_0,'total_1'=>$total_1, 'total_2'=>$total_2, 'total_3'=>$total_3,'total_4'=>$total_4,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'from_date'=>$from_date, 'to_date'=>$to_date,
					  'tab'=>$tab, 'type'=>$type,
					  'thu'=>$thu, 'chi'=>$chi,
					  'tien_mat'=>$tien_mat, 'chuyen_khoan'=>$chuyen_khoan, 'quet_the'=>$quet_the, 'total_is_lazada'=>$total_is_lazada
		));	
	}
	public function actionAdd()
	{
		$is_day = isset($_GET['is_day']) ? intval($_GET['is_day']):0;
		$this->render('add', array('is_day'=>$is_day));
	}
	public function actionEdit()
	{
		$is_day = isset($_GET['is_day']) ? intval($_GET['is_day']):0;
		$money_id=isset($_GET['money_id']) ? intval($_GET['money_id']) :0;
		$detail = BMoneyVn::getMoneyVnById($money_id);
		$this->render('edit',array('detail'=>$detail, 'is_day'=>$is_day));
	}
	
	public function actionDeleteMoneyVn()
	{
		$money_id=isset($_POST['money_id']) ? intval($_POST['money_id']) : 0;
		if($money_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$money_id),'b_money_vn');
		}
		echo 1;
	}
}
?>