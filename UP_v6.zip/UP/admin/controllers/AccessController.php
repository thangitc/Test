<?php
//Phu kien
class AccessController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		$cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 0;
		//Hoa don
		$bill_id = isset($_GET['bill_id']) ? intval($_GET['bill_id']):0;
		
		$url_rewrite=Common::genUrlRewrite();
		$cats = $this->cats;
		list($total_all, $total_active, $total_pending, $total_draft) = Access::countTabAccess();
		
		list($access,$paging,$total)=Access::getAccess($cat_id,$keyword,$keyword_in, $tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite);
		$this->render("index",
				array('access'=>$access,'paging'=>$paging,'total'=>$total,
					  'total_all'=>$total_all,'total_active'=>$total_active, 'total_pending'=>$total_pending, 'total_draft'=>$total_draft,
					  'cat_id'=>$cat_id, 'cats'=>$cats,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'bill_id'=>$bill_id
		));
	}
	public function actionAdd()
	{
		$access_id=isset($_GET['access_id']) ? intval($_GET['access_id']):0;
		$detail=Access::getAccessById($access_id);		
		$cats = $this->cats;
		$brands = BBrand::getAllBrand();
        $this->render("add",
				array('detail'=>$detail,'access_id'=>$access_id,'cats'=>$cats, 'brands'=>$brands
		));
	}
	public function actionEdit()
	{
		$access_id=isset($_GET['access_id']) ? intval($_GET['access_id']):0;
		$detail = Access::getAccessById($access_id);
		$cats = $this->cats;	
		$brands = BBrand::getAllBrand();
		//Picture
		$access_pic = AccessPic::getPicById($access_id);
        $this->render("edit",
				array('detail'=>$detail, 'access_id'=>$access_id,
					  'access_pic'=>$access_pic, 'cats'=>$cats, 'brands'=>$brands
		));
	}
	public function actionSeo()
	{
		$access_id=isset($_GET['access_id']) ? intval($_GET['access_id']):0;
		$detail=Access::getAccessById($access_id);
		$this->render("seo",
				array('detail'=>$detail,'access_id'=>$access_id
		));
	}
	
	public function actionSale()
	{
		$access_id=isset($_GET['access_id']) ? intval($_GET['access_id']):0;
		$order_id=isset($_GET['order_id']) ? intval($_GET['order_id']):0;
		$detail=Access::getAccessById($access_id);
		$citys = BCity::getCity();
		$customer = Customer::getAllCustomer();
		$list_customer = Customer::getListCustomerAccess($access_id);
		$list_sale = AccessSale::getAccessSale($access_id);
		$list_color = AccessColor::getAllColorByAccess($access_id); //Danh sach mau phu kien
		
		//Order
		$order_info = Cart::getOrderById($order_id);
		//Hoa don
		$bill_id = isset($_GET['bill_id']) ? intval($_GET['bill_id']):0;
		$bills = Bill::getAllBill();
		
        $this->render("sale",
				array('detail'=>$detail,'access_id'=>$access_id,
					  'citys'=>$citys, 'customer'=>$customer,
					  'list_customer'=>$list_customer, 'list_sale'=>$list_sale, 'list_color'=>$list_color,
					  'order_info'=>$order_info,
					  'bills'=>$bills, 'bill_id'=>$bill_id
		));
	}
	
	public function actionColor()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$access_id=isset($_GET['access_id']) ? intval($_GET['access_id']):0;
		$url_rewrite=Common::genUrlRewrite();
		//Hoa don
		$bill_id = isset($_GET['bill_id']) ? intval($_GET['bill_id']):0;
		list($color,$paging,$total)=AccessColor::getColorByAccess($access_id, $page,$num_per_page,$url_rewrite);
		
		$this->render("color",
				array('color'=>$color,'paging'=>$paging,'total'=>$total,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'access_id'=>$access_id, 'bill_id'=>$bill_id
		));
	}
	public function actionAddColor()
	{
		$access_id=isset($_GET['access_id']) ? intval($_GET['access_id']):0;
		$color_id=isset($_GET['color_id']) ? intval($_GET['color_id']):0;
		$detail = Access::getAccessById($access_id);
		//Picture
		$color_pic = AccessColor::getPicByColorId($color_id);
        $this->render("add_color",
				array('detail'=>$detail, 'access_id'=>$access_id, 'color_id'=>$color_id,
					  'color_pic'=>$color_pic
		));
	}
	
	public function actionEditColor()
	{
		$access_id=isset($_GET['access_id']) ? intval($_GET['access_id']):0;
		$color_id=isset($_GET['color_id']) ? intval($_GET['color_id']):0;
		$detail = AccessColor::getColorById($color_id);
		//Picture
		$color_pic = AccessColor::getPicByColorId($color_id);
        $this->render("edit_color",
				array('detail'=>$detail, 'access_id'=>$access_id, 'color_id'=>$color_id,
					  'color_pic'=>$color_pic
		));
	}
	
	public function actionShowAccess()
	{
        $page=isset($_GET['page']) ? intval($_GET['page']):1;
        $cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;
		$tab=isset($_GET['tab']) ? intval($_GET['tab']):0;
		$num_per_page=10;
		$keyword='';
		$cat = $this->cats;
		$boolean = isset($_GET['boolean']) ? intval($_GET['boolean']):0;
		list($access,$total) = Access::getAccessPopup($keyword,$cat_id,$page,$num_per_page);
		$num_page=ceil($total/$num_per_page);
		
		$this->renderPartial("show_access",
				array('access'=>$access,'cat'=>$cat,'num_page'=>$num_page,'boolean'=>$boolean,
					  'num_per_page'=>$num_per_page,'page'=>$page,'total'=>$total,'cat_id'=>$cat_id,
					  'tab'=>$tab
		));
	}
	
	public function actionDeleteAccess()
	{
		$access_id=isset($_POST['access_id']) ? intval($_POST['access_id']) : 0;
		if($access_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$access_id),'b_accessories');
		}
		echo 1;
	}
	
	public function actionEditSale()
	{
		$sale_id=isset($_GET['sale_id']) ? intval($_GET['sale_id']):0;
		$detail = AccessSale::getAccessSaleById($sale_id);
		$access_info = Access::getAccessById($detail['access_id']);
        $this->render("edit_sale",
				array('detail'=>$detail, 'access_id'=>$detail['access_id'],
					  'access_info'=>$access_info
		));
	}
}
?>