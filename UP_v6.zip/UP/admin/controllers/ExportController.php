<?php
class ExportController extends Controller
{
	public function init()
	{
		if(!isset(Yii::app()->user->id))
		{
			$this->redirect(Url::createUrl('user/login'));
			exit();
		}
	}
	
	public function actionAll()
	{
		ini_set("memory_limit","512M");
		$rows = BList::getTon();
		$cats = Cat::getCats();
		$arr_rating = LoadConfig::$arr_rating;		
		//Export
		Yii::import('application.vendors.PHPExcel',true);
		$objPHPExcel = new PHPExcel(); 
		// Set the active Excel worksheet to sheet 0
		$objPHPExcel->setActiveSheetIndex(0); 
		// Initialise the Excel row number
		$objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Báo cáo hàng tồn'); 
		$rowCount = 3; 
		// Iterate through each result from the SQL query in turn
		// We fetch each database result row into $row in turn
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, 'STT'); 
		$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, 'Tên sản phẩm');
		$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, 'Danh mục');
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, 'Seri');
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, 'Giá nhập');
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount, 'Giá');
		$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount, 'Số shot');
		$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount, 'Xếp hạng');

		
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->getFont()->setBold(true);
		
		
		//Center
		$style_center = array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			)
		);
		
		$style_right = array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
			)
		);
		$style_left = array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT,
			)
		);
		
		$objPHPExcel->getActiveSheet()->getStyle('E3:G3')->applyFromArray($style_right);
		$objPHPExcel->getActiveSheet()->getStyle('H3')->applyFromArray($style_center);
		/*
		$objPHPExcel->getActiveSheet()->getStyle("A3:H3")->applyFromArray($style_center);
		//$objPHPExcel->getActiveSheet()->getStyle("D9:E9")->applyFromArray($style_center);
		//MegeCenter
		$objPHPExcel->getActiveSheet()->mergeCells('D8:E8');
		*/
	
		$k=1;
		$cat_id = 0;
		$cat_name = '';
		foreach($rows as $row)
		{
			$rating = isset($arr_rating[$row['rating']]) ? $arr_rating[$row['rating']] : '';
			if($row['cat_id']!=$cat_id)
			{
				$rowCount++;
				$cat_id = $row['cat_id'];
				$info_cat = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
				//var_dump($info_cat);exit();
				$cat_name = !empty($info_cat['title']) ? $info_cat['title'] : '';
				$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, $cat_name);
				$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount)->getFont()->setBold(true);
				
				$k=1;
			}
			$rowCount++;
			
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, $k); 
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, $row['title']);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, $cat_name);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, $row['seri']);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, $row['price_in']);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount, $row['price']);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount, $row['num_shot']);
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount, $rating);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount)->applyFromArray($style_center);
			$objPHPExcel->getActiveSheet()->getStyle('D'.$rowCount)->applyFromArray($style_left);
			$objPHPExcel->getActiveSheet()->getStyle('H'.$rowCount)->applyFromArray($style_center);
			$k++;
		}

		//Format Currency
		$objPHPExcel->getActiveSheet()
		->getStyle('A3:H'.$rowCount.'')
		->getNumberFormat()
		->setFormatCode(
			'#,##0_-'
		);

		//Border
		$styleArray = array(
		  'borders' => array(
			  'allborders' => array(
				  'style' => PHPExcel_Style_Border::BORDER_THIN,
				  'color' => array(
						'argb' => '000000',
				  ),
			  )
		  )
	  	);
		$objPHPExcel->getActiveSheet()->getStyle('A3:H'.$rowCount.'')->applyFromArray($styleArray);
		
		//Set Width
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth('8');
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth('35');
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth('35');
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth('18');
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth('18');
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth('18');
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth('12');		
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth('12');

		// Instantiate a Writer to create an OfficeOpenXML Excel .xlsx file
		/*
		header('Content-Type: application/vnd.ms-excel'); 
		header('Content-Disposition: attachment;filename="Limesurvey_Results.xls"');
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel); 
		// Write the Excel file to filename some_excel_file.xlsx in the current directory
		$objWriter->save('some_excel_file.xlsx'); 
		*/
		ob_end_clean();
		header('Content-Type: application/vnd.ms-excel'); 
		header('Content-Disposition: attachment;filename="Bao_cao_hang_ton_'.date('d_m_Y_H_i').'.xls"'); 
		header('Cache-Control: max-age=0'); 
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5'); 
		$objWriter->save('php://output');
		//$objWriter->save('/usr/local/myWorkbooks/workbook1.xlsx');  
		exit();
	}
	
	public function actionError()
    {
        if($error=Yii::app()->errorHandler->error)
		{
			$this->renderPartial('error',array("error"=>$error));
		}
        else
		{
            throw new CHttpException(404, 'Trang không tồn tại.');
		}
    }
}
?>