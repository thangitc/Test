<?php
class BBrandController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		
		
		$url_rewrite=Common::genUrlRewrite();
		
		list($brand ,$paging,$total )=BBrand::getBrand($keyword,$keyword_in ,$page,$num_per_page,$url_rewrite);
		
		//Danh muc
		$cats=$this->cats;
		
		$this->render('index',
				array('brand'=>$brand,'paging'=>$paging,'total'=>$total,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in
		));	
	}
	public function actionAdd()
	{		
		
		$this->render('add');
	}
	public function actionEdit()
	{
		$brand_id=isset($_GET['brand_id']) ? intval($_GET['brand_id']) :0;
		$detail = BBrand::getBrandById($brand_id);
		$this->render('edit',array('detail'=>$detail));
	}
	public function actionDeleteBrand()
	{
		$brand_id=isset($_POST['brand_id']) ? intval($_POST['brand_id']) : 0;
		if($brand_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$brand_id),'b_brand');
		}
		echo 1;
	}
}
?>