<?php
class AnalyticsController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		$cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;
		
		$seri = isset($_GET['seri']) ? $_GET['seri'] : '';
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 1;
		
		$url_rewrite=Common::genUrlRewrite();
		$cats = $this->cats;
		list($total_0, $total_1, $total_2, $total_3, $total_4) = Analytics::getTotal();
		
		list($list,$paging,$total, $total_buy, $total_in, $percent, $total_in_ton_cu, $total_in_ton_moi, $total_fee_vn)=Analytics::getListAnalytics($cat_id, $seri,$keyword,$keyword_in,$tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite);
		$this->render("index",
				array('list'=>$list,'paging'=>$paging,'total'=>$total,
					  'total_0'=>$total_0,'total_1'=>$total_1, 'total_2'=>$total_2, 'total_3'=>$total_3,'total_4'=>$total_4,
					  'cat_id'=>$cat_id, 'cats'=>$cats, 'seri'=>$seri,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'tab'=>$tab,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'total_buy'=>$total_buy, 'total_in'=>$total_in, 'percent'=>$percent, 'total_in_ton_cu'=>$total_in_ton_cu, 'total_in_ton_moi'=>$total_in_ton_moi, 'total_fee_vn'=>$total_fee_vn
		));
	}
	
	
	public function actionLazada()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		$cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;
		
		$seri = isset($_GET['seri']) ? $_GET['seri'] : '';
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 1;
		
		$url_rewrite=Common::genUrlRewrite();
		$cats = $this->cats;
		list($total_0, $total_1, $total_2, $total_3, $total_4) = Analytics::getTotalLazada();
		
		list($list,$paging,$total, $total_buy, $total_in, $percent, $total_in_ton_cu, $total_in_ton_moi, $total_fee_vn)=Analytics::getLazadaAnalytics($cat_id, $seri,$keyword,$keyword_in,$tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite);
		$this->render("lazada",
				array('list'=>$list,'paging'=>$paging,'total'=>$total,
					  'total_0'=>$total_0,'total_1'=>$total_1, 'total_2'=>$total_2, 'total_3'=>$total_3,'total_4'=>$total_4,
					  'cat_id'=>$cat_id, 'cats'=>$cats, 'seri'=>$seri,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'tab'=>$tab,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'total_buy'=>$total_buy, 'total_in'=>$total_in, 'percent'=>$percent, 'total_in_ton_cu'=>$total_in_ton_cu, 'total_in_ton_moi'=>$total_in_ton_moi, 'total_fee_vn'=>$total_fee_vn
		));
	}
	
	public function actionAccess()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		$cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 1;
		
		$url_rewrite=Common::genUrlRewrite();
		$cats = $this->cats;
		list($total_0, $total_1, $total_2, $total_3, $total_4) = Analytics::getTotalAccess();
		
		list($access, $colors,$paging,$total, $total_buy, $total_in, $percent, $total_in_ton)=Analytics::getAnalyticsAccess($cat_id,$keyword,$keyword_in,$tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite);
		$this->render("access",
				array('access'=>$access, 'colors'=>$colors,'paging'=>$paging,'total'=>$total,
					  'total_0'=>$total_0,'total_1'=>$total_1, 'total_2'=>$total_2, 'total_3'=>$total_3,'total_4'=>$total_4,
					  'cat_id'=>$cat_id, 'cats'=>$cats, 
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'tab'=>$tab,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'total_buy'=>$total_buy, 'total_in'=>$total_in, 'percent'=>$percent, 'total_in_ton'=>$total_in_ton
		));
	}
	
	public function actionChart()
	{
		$month=isset($_GET['month']) ? intval($_GET['month']):intval(date('m'));
		$year = isset($_GET['year']) ? intval($_GET['year']):intval(date('Y'));
		list($data_report_product, $data_report_access, $total_lai_thang_product, $total_lai_thang_access, $revenue_product, $revenue_access, $products_day, $access_day, $products_last, $access_last, $revenue_product_ban_le, $revenue_product_ban_buon, $total_lai_ban_le, $total_lai_ban_buon) = Analytics::getChartAll($month, $year);
		
		$this->render("chart",
				array('month'=>$month, 'year'=>$year,
					  'data_report_product'=>$data_report_product, 'data_report_access'=>$data_report_access,
					  'revenue_product'=>$revenue_product, 'revenue_access'=>$revenue_access,
					  'total_lai_thang_access'=>$total_lai_thang_access, 'total_lai_thang_product'=>$total_lai_thang_product,
					  'products_day'=>$products_day, 'access_day'=>$access_day, 'products_last'=>$products_last, 'access_last'=>$access_last,
					  'revenue_product_ban_le'=>$revenue_product_ban_le, 'revenue_product_ban_buon'=>$revenue_product_ban_buon, 'total_lai_ban_le'=>$total_lai_ban_le, 'total_lai_ban_buon'=>$total_lai_ban_buon
		));
	}
	
	public function actionFilterExportCamera()
	{
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		$cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;		
		$seri = isset($_GET['seri']) ? $_GET['seri'] : '';
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 1;
		$cats = $this->cats;
		
		$this->render("filter_camera",
				array('cat_id'=>$cat_id, 'cats'=>$cats, 'seri'=>$seri,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'tab'=>$tab,
					  'from_date'=>$from_date,'to_date'=>$to_date
		));
		
	}
	public function actionExportCamera()
	{
		ini_set("memory_limit","512M");
		
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		$cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;		
		$seri = isset($_GET['seri']) ? $_GET['seri'] : '';
		
		$from_date = isset($_GET['from_date']) && $_GET['from_date']!='' ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) && $_GET['to_date']!='' ?  $_GET['to_date']:0;
		
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 1;
		list($list, $list_customer) = Analytics::getListExportCamera($cat_id, $seri,$keyword,$keyword_in,$tab, $from_date, $to_date);

		//Export
		Yii::import('application.vendors.PHPExcel',true);
		$objPHPExcel = new PHPExcel(); 
		// Set the active Excel worksheet to sheet 0
		$objPHPExcel->setActiveSheetIndex(0); 
		// Initialise the Excel row number
		$objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Báo cáo bán hàng máy ảnh'); 
		$rowCount = 3; 
		// Iterate through each result from the SQL query in turn
		// We fetch each database result row into $row in turn
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, 'STT'); 
		$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, 'Số Seri');
		$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, 'Tiêu đề');
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, 'Khách hàng');
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, 'Giá Bán');
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount, 'Thời gian bán');
		
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:F3')->getFont()->setBold(true);
		
	
		$k=1;
		foreach($list as $row)
		{
			$rowCount++;
			$cus_info = '';
			$row_cus = isset($list_customer[$row['camera_id']]) ? $list_customer[$row['camera_id']] : array();
			if(!empty($row_cus))
			{
				$cus_info = $row_cus['title'].' - '.$row_cus['mobile'].' - '.$row_cus['address'].' - '.$row_cus['city_title'];
			}
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, $k); 
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, $row['seri']);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, $row['title']);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, $cus_info);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, $row['price_buy']);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount, date('d/m/Y', $row['time_buy']));
			$k++;
		}
		

		//Format Currency
		$objPHPExcel->getActiveSheet()
		->getStyle('E4:E'.$rowCount.'')
		->getNumberFormat()
		->setFormatCode(
			'#,##0_-'
		);
		//Border
		$styleArray = array(
		  'borders' => array(
			  'allborders' => array(
				  'style' => PHPExcel_Style_Border::BORDER_THIN,
				  'color' => array(
						'argb' => '000000',
				  ),
			  )
		  )
	  	);
		$objPHPExcel->getActiveSheet()->getStyle('A3:F'.$rowCount.'')->applyFromArray($styleArray);

		//Set Width

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth('10');
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth('20');
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth('60');
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth('40');
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth('20');
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth('20');

		// Instantiate a Writer to create an OfficeOpenXML Excel .xlsx file
		/*
		header('Content-Type: application/vnd.ms-excel'); 
		header('Content-Disposition: attachment;filename="Limesurvey_Results.xls"');
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel); 
		// Write the Excel file to filename some_excel_file.xlsx in the current directory
		$objWriter->save('some_excel_file.xlsx'); 
		*/
		ob_end_clean();
		header('Content-Encoding: UTF-8');
		header('Content-Type: application/vnd.ms-excel'); 
		header('Content-Disposition: attachment;filename="Bao_cao_ban_camera_'.date('d_m_Y').'.xls"'); 
		header('Cache-Control: max-age=0'); 
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5'); 
		
		$objWriter->save('php://output');

		exit();
	}
	
	public function actionFilterExportAccess()
	{
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		$cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;		
		$seri = isset($_GET['seri']) ? $_GET['seri'] : '';
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 1;
		$cats = $this->cats;
		
		$this->render("filter_access",
				array('cat_id'=>$cat_id, 'cats'=>$cats, 'seri'=>$seri,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'tab'=>$tab,
					  'from_date'=>$from_date,'to_date'=>$to_date
		));
		
	}
	public function actionExportAccess()
	{
		ini_set("memory_limit","512M");
		
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		$cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;		
		$seri = isset($_GET['seri']) ? $_GET['seri'] : '';
		
		$from_date = isset($_GET['from_date']) && $_GET['from_date']!='' ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) && $_GET['to_date']!='' ?  $_GET['to_date']:0;
		
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 1;
		list($list, $list_color, $list_customer) = Analytics::getListExportAccess($cat_id,$keyword,$keyword_in,$tab, $from_date, $to_date);

		//Export
		Yii::import('application.vendors.PHPExcel',true);
		$objPHPExcel = new PHPExcel(); 
		// Set the active Excel worksheet to sheet 0
		$objPHPExcel->setActiveSheetIndex(0); 
		// Initialise the Excel row number
		$objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Báo cáo bán hàng phụ kiện'); 
		$rowCount = 3; 
		// Iterate through each result from the SQL query in turn
		// We fetch each database result row into $row in turn
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, 'STT'); 
		$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, 'Tiêu đề');
		$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, 'Khách hàng');
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, 'Giá Bán');
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, 'Thời gian bán');
		
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:E3')->getFont()->setBold(true);
		
		$k=1;
		foreach($list as $row)
		{
			$rowCount++;
			//Ten phu kien
			$color_info = isset($list_color[$row['color_id']]) ? $list_color[$row['color_id']] : array();
			$color_title = !empty($color_info['color']) ? $color_info['color'] : '';
			$cus_info = '';
			$row_cus = isset($list_customer[$row['access_id']]) ? $list_customer[$row['access_id']] : array();
			if(!empty($row_cus))
			{
				$cus_info = $row_cus['title'].' - '.$row_cus['mobile'].' - '.$row_cus['address'].' - '.$row_cus['city_title'];
			}
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, $k); 
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, $row['title'].' '.$color_title);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, $cus_info);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, $row['price_buy']);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, date('d/m/Y', $row['time_buy']));
			$k++;
		}
		

		//Format Currency
		$objPHPExcel->getActiveSheet()
		->getStyle('D4:D'.$rowCount.'')
		->getNumberFormat()
		->setFormatCode(
			'#,##0_-'
		);
		//Border
		$styleArray = array(
		  'borders' => array(
			  'allborders' => array(
				  'style' => PHPExcel_Style_Border::BORDER_THIN,
				  'color' => array(
						'argb' => '000000',
				  ),
			  )
		  )
	  	);
		$objPHPExcel->getActiveSheet()->getStyle('A3:E'.$rowCount.'')->applyFromArray($styleArray);

		//Set Width

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth('10');
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth('40');
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth('60');
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth('20');
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth('20');

		// Instantiate a Writer to create an OfficeOpenXML Excel .xlsx file
		/*
		header('Content-Type: application/vnd.ms-excel'); 
		header('Content-Disposition: attachment;filename="Limesurvey_Results.xls"');
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel); 
		// Write the Excel file to filename some_excel_file.xlsx in the current directory
		$objWriter->save('some_excel_file.xlsx'); 
		*/
		ob_end_clean();
		header('Content-Encoding: UTF-8');
		header('Content-Type: application/vnd.ms-excel'); 
		header('Content-Disposition: attachment;filename="Bao_cao_ban_phu_kien_'.date('d_m_Y').'.xls"'); 
		header('Cache-Control: max-age=0'); 
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5'); 
		
		$objWriter->save('php://output');

		exit();
	}
	
	public function actionExport()
	{
		ini_set("memory_limit","512M");
		
		
		list($list_customer, $list_cus_camera, $list_cus_access) = Analytics::getListExport();
		//var_dump($list_cus_access);
		//exit();

		//Export
		Yii::import('application.vendors.PHPExcel',true);
		$objPHPExcel = new PHPExcel(); 
		// Set the active Excel worksheet to sheet 0
		$objPHPExcel->setActiveSheetIndex(0); 
		// Initialise the Excel row number
		$objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Báo cáo bán hàng'); 
		$rowCount = 3; 
		// Iterate through each result from the SQL query in turn
		// We fetch each database result row into $row in turn
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, 'Khách hàng'); 
		$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, 'STT');
		$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, 'Tên sản phẩm');
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, 'Giá Bán');
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, 'Thời gian bán');
		
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:E3')->getFont()->setBold(true);
		
		
		foreach($list_customer as $row)
		{			
			$rowCount++;
			$start= $rowCount;
			$list_camera = isset($list_cus_camera[$row['id']]) ? $list_cus_camera[$row['id']] :array();
			$list_access = isset($list_cus_access[$row['id']]) ? $list_cus_access[$row['id']] :array();			
			$cus_info = $row['title'].' - '.$row['address'].' - '.$row['city_title'].' - '.$row['mobile'];
			
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, $cus_info);
			
			$k=1;
			if(!empty($list_camera))
			foreach($list_camera as $row_camera)
			{
				$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, $k);
				$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, $row_camera['title']);
				$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, $row_camera['price_buy']);
				$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, date('d/m/Y', $row_camera['time_buy']));
				$k++;	
				$rowCount ++ ;
			}
			
			if(!empty($list_access))
			foreach($list_access as $row_access)
			{
				$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, $k);
				$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, $row_access['title']);
				$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, $row_access['price_buy']);
				$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, date('d/m/Y', $row_access['time_buy']));
				$k++;	
				$rowCount ++ ;
			}
			$end = $rowCount;
			$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A'.$start.':A'.$end);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$start.':A'.$end)->getAlignment()->setWrapText(true); 
			
			$style = array(
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					'wrap' => true
				)
			);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$start.':A'.$end)->applyFromArray($style);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$start.':A'.$end)->getAlignment()->setVertical(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
		}



		//Format Currency
		$objPHPExcel->getActiveSheet()
		->getStyle('D4:D'.$rowCount.'')
		->getNumberFormat()
		->setFormatCode(
			'#,##0_-'
		);
		//Border
		$styleArray = array(
		  'borders' => array(
			  'allborders' => array(
				  'style' => PHPExcel_Style_Border::BORDER_THIN,
				  'color' => array(
						'argb' => '000000',
				  ),
			  )
		  )
	  	);
		$objPHPExcel->getActiveSheet()->getStyle('A3:E'.$rowCount.'')->applyFromArray($styleArray);

		//Set Width

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth('55');
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth('10');
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth('60');
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth('20');
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth('20');

		// Instantiate a Writer to create an OfficeOpenXML Excel .xlsx file
		/*
		header('Content-Type: application/vnd.ms-excel'); 
		header('Content-Disposition: attachment;filename="Limesurvey_Results.xls"');
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel); 
		// Write the Excel file to filename some_excel_file.xlsx in the current directory
		$objWriter->save('some_excel_file.xlsx'); 
		*/
		ob_end_clean();
		header('Content-Encoding: UTF-8');
		header('Content-Type: application/vnd.ms-excel'); 
		header('Content-Disposition: attachment;filename="Bao_cao_ban_phu_kien_'.date('d_m_Y').'.xls"'); 
		header('Cache-Control: max-age=0'); 
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5'); 
		
		$objWriter->save('php://output');

		exit();
	}
}
?>