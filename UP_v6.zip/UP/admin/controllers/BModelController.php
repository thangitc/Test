<?php
class BModelController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		$cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 0;
		
		$url_rewrite=Common::genUrlRewrite();
		$cats = $this->cats;
		list($total_all, $total_active, $total_pending, $total_draft) = BModel::countTabModel();
		
		list($list,$paging,$total, $access_related)=BModel::getModel($cat_id,$keyword,$keyword_in, $tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite);
		$this->render("index",
				array('list'=>$list,'paging'=>$paging,'total'=>$total, 'access_related'=>$access_related,
					  'total_all'=>$total_all,'total_active'=>$total_active, 'total_pending'=>$total_pending, 'total_draft'=>$total_draft,
					  'cat_id'=>$cat_id, 'cats'=>$cats,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,
					  'page'=>$page,'num_per_page'=>$num_per_page
		));
	}
	public function actionAdd()
	{
		$model_id=isset($_GET['model_id']) ? intval($_GET['model_id']):0;
		$detail=BModel::getModelById($model_id);		
		$cats = $this->cats;
		$brand = BBrand::getAllBrand();
        $this->render("add",
				array('detail'=>$detail,'model_id'=>$model_id,'cats'=>$cats, 'brand'=>$brand
		));
	}
	public function actionEdit()
	{
		$model_id=isset($_GET['model_id']) ? intval($_GET['model_id']):0;
		$detail = BModel::getModelById($model_id);
		$cats = $this->cats;	
		$brand = BBrand::getAllBrand();
		//Picture
		$model_pic = BModelPic::getPicById($model_id);
		$access = Access::getAccessByModelId($model_id);
        $this->render("edit",
				array('detail'=>$detail, 'model_id'=>$model_id,
					  'model_pic'=>$model_pic, 'cats'=>$cats, 'access'=>$access, 'brand'=>$brand
		));
	}
	public function actionSeo()
	{
		$model_id=isset($_GET['model_id']) ? intval($_GET['model_id']):0;
		$detail=BModel::getModelById($model_id);
		$this->render("seo",
				array('detail'=>$detail,'model_id'=>$model_id
		));
	}
	public function actionShowNews()
	{
		$page = isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page = 10;
		$keyword = '';
		$cat_id = 0;
		$cats = $this->cats;
		list($news,$total)=BModel::getNewsPopup($keyword,$cat_id,$page,$num_per_page);
		$num_page=ceil($total/$num_per_page);
		$this->renderPartial("show_news",
				array('news'=>$news,'cats'=>$cats,'num_page'=>$num_page,
					  'num_per_page'=>$num_per_page,'page'=>$page,'total'=>$total
		));
	}
	
	public function actionDeleteModel()
	{
		$model_id=isset($_POST['model_id']) ? intval($_POST['model_id']) : 0;
		if($model_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$model_id),'b_model');
		}
		echo 1;
	}
}
?>