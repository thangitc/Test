<?php
class CatController extends Controller
{
    public function actionIndex()
    {
        $cats=$this->cats;
        $this->render("index",array('cats'=>$cats));
    }
    public function actionSeo()
    {
        $cats=$this->cats;
        $this->render("seo",array('cats'=>$cats));
    }
    
    public function actionOrderMenu()
    {
        $cats=Cat::getCatMenu();
        $this->render("order_menu",array('cats'=>$cats));
    }
    
    public function actionOrderCatHome()
    {
        $cats=Cat::getCatHome();
        $this->render("order_cat_home",array('cats'=>$cats));
    }
	 public function actionOrderCatHomeBottom()
    {
        $cats=Cat::getCatHomeBottom();
        $this->render("order_cat_home_bottom",array('cats'=>$cats));
    }
    /*Hanv*/
    public function actionShowCat()
    {
        $cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;
        $list_cat = $this->cats;
        $this->renderPartial("show_cat",array('categories'=>$list_cat,'cat_id'=>$cat_id));
    }
    /*End*/
	/*Cap nhat subCat*/
	public function actionUpdateSubCat()
	{
		Cat::updateSubCat();
	}
	
	public function actionDeleteCate()
	{
		if(isset($_POST['cid']))
		{
			$cid=$_POST['cid'];
			$info=Cat::getCateInfor($cid);
			$array_input=array('id'=>$cid);
			$ok1=CommonModel::deleteObject($array_input,'b_cat');

			if($ok1>=0) {
				/*Log*/
				$user_id=Yii::app()->user->id;
				$user_name=Yii::app()->user->name;
				$object_log['input']=array('id'=>$cid);    
				$module_log=3;
				$name_action='Sửa';
				$object_log['output']='Success!';
				header('Content-Type: text/html; charset=utf-8');
				$object_log=json_encode($object_log);
				$object_log=trim(mysql_escape_string($object_log));
				$content_log='<strong>'.$user_name.'</strong> Xóa danh mục . Mã danh mục <strong>'.$cid.'</strong>';
				$content_log=trim(mysql_escape_string($content_log));
				Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
				/*End log*/

				$error='Xóa dữ liệu thành công!';
			}
			else
				$error='Xóa dữ liệu lỗi!';
			$array=array('status'=>1,'error'=>$error,'parent_id'=>$info['parent_id'],'level'=>$info['level']);    
		}
		else
		{
			$error='Bạn chưa chọn danh mục để xóa!';
			$array=array('status'=>0,'error'=>$error);
		}

		$output=json_encode($array);
		header("Content-Type: application/json; charset=utf-8");
		echo $output;
	}
}
?>
