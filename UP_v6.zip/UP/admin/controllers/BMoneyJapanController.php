<?php
class BMoneyJapanController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$url_rewrite=Common::genUrlRewrite();
		
		list($money ,$paging,$total)=BMoneyJapan::getMoneyJapan($keyword,$keyword_in, $from_date, $to_date,$page,$num_per_page,$url_rewrite);
		list($total_money_month_vnd_thu, $total_money_month_japan_thu, $total_money_month_japan_chi) = BMoneyJapan::getTotalMoneyThuChi(date('m'), date('Y'));
		$total_money_japan = BMoneyJapan::getTotalMoneyJapan();
		$this->render('index',
				array('money'=>$money,'paging'=>$paging,'total'=>$total,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'from_date'=>$from_date, 'to_date'=>$to_date,
					  'total_money_japan'=>$total_money_japan,
					  'total_money_month_vnd_thu'=>$total_money_month_vnd_thu, 'total_money_month_japan_thu'=>$total_money_month_japan_thu, 'total_money_month_japan_chi'=>$total_money_month_japan_chi
		));	
	}
	public function actionAdd()
	{		
		$this->render('add');
	}
	public function actionEdit()
	{
		$money_id=isset($_GET['money_id']) ? intval($_GET['money_id']) :0;
		$detail = BMoneyJapan::getMoneyJapanById($money_id);
		$this->render('edit',array('detail'=>$detail));
	}
	
	public function actionDeleteMoneyJapan()
	{
		$money_id=isset($_POST['money_id']) ? intval($_POST['money_id']) : 0;
		if($money_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$money_id),'b_money_japan_detail');
		}
		echo 1;
	}
}
?>