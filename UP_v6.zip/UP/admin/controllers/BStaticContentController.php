<?php
class BStaticContentController extends Controller
{
	public function actionEdit()
	{
		$static_id=isset($_GET['static_id']) ? intval($_GET['static_id']) :1;
		$detail = BStaticContent::getStaticContentById($static_id);
		$this->render('edit',array('detail'=>$detail));
	}
}
?>