<?php
class BKitController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		$model_id=isset($_GET['model_id']) ? intval($_GET['model_id']):0;
		$url_rewrite=Common::genUrlRewrite();
		
		list($kit ,$paging,$total, $models)=BKit::getKit($model_id, $keyword,$keyword_in ,$page,$num_per_page,$url_rewrite);		
		
		//Models
		$list_models = BModel::getAllModel();
		
		$this->render('index',
				array('kit'=>$kit,'paging'=>$paging,'total'=>$total,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'model_id'=>$model_id,
					  'models'=>$models, 'list_models'=>$list_models
		));	
	}
	public function actionAdd()
	{		
		$models = BModel::getAllModel();
		$this->render('add', array('models'=>$models));
	}
	public function actionEdit()
	{
		$kit_id=isset($_GET['kit_id']) ? intval($_GET['kit_id']) :0;
		$detail = BKit::getKitById($kit_id);
		$models = BModel::getAllModel();
		$this->render('edit',array('detail'=>$detail,'models'=>$models));
	}
	
	public function actionDeleteKit()
	{
		$kit_id=isset($_POST['kit_id']) ? intval($_POST['kit_id']) : 0;
		if($kit_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$kit_id),'b_combo_kit');
		}
		echo 1;
	}
}
?>