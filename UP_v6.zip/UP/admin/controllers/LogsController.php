<?php
class LogsController extends Controller
{
	public function actionIndex()
	{
		$pathway='';
		//$url_rewrite = Url::createUrl('logs/index').'/';
        $url_rewrite=Common::genUrlRewrite();
		//Xác định tham số
		$page = isset($_GET ['page']) ? intval($_GET['page']) : 1;
		$num_per_page=10;
		$keyword = isset($_GET ['keyword']) ? $_GET['keyword'] : '';
		$keyword_field = isset($_GET['keyword_field']) ? $_GET['keyword_field'] : '';
		$module = isset($_GET['module']) ?  $_GET['module'] : '';;
		$name_action= isset($_GET['name_action']) ?  $_GET['name_action'] : '';
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(0,0,0,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		//End
		//Goi ham
		list($logs,$total_record,$paging)=Logs::getLogs($keyword,$keyword_field,$module,$name_action,$from_date,$to_date,$page,$num_per_page,$url_rewrite);
		//Render
		$this->render("index",array('keyword'=>$keyword,'keyword_field'=>$keyword_field,'module'=>$module,'name_action'=>$name_action,'from_date'=>$from_date,'to_date'=>$to_date,'total_record'=>$total_record,'page'=>$page,'num_per_page'=>$num_per_page ,'logs'=>$logs,'paging'=>$paging));
	}
	public function actionViewLog()
	{
		$id=$_GET['id'];
		$log_detail=TsLogs::viewLog($id);
		$this->renderPartial("view_log",array('log_detail'=>$log_detail));
	}
}
?>
