<?php
class BContactController extends Controller
{
	public function actionEdit()
	{
		$contact_id=isset($_GET['contact_id']) ? intval($_GET['contact_id']) :1;
		$detail = BContact::getContactById($contact_id);
		$this->render('edit',array('detail'=>$detail));
	}
}
?>