<?php
class CrawlingController extends Controller
{
	public function init()
	{
		if(!isset(Yii::app()->user->id))
		{
			$this->redirect(Url::createUrl('user/login'));
			exit();
		}
	}
	
	public function actionAll()
	{
		ini_set("memory_limit","512M");
		$rows = BList::getTon();
		$cats = Cat::getCats();
		$arr_rating = LoadConfig::$arr_rating;		
		//Export
		Yii::import('application.vendors.PHPExcel',true);
		$objPHPExcel = new PHPExcel(); 
		// Set the active Excel worksheet to sheet 0
		$objPHPExcel->setActiveSheetIndex(0); 
		// Initialise the Excel row number
		$objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Báo cáo hàng tồn'); 
		$rowCount = 3; 
		// Iterate through each result from the SQL query in turn
		// We fetch each database result row into $row in turn
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, 'STT'); 
		$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, 'Tên sản phẩm');
		$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, 'Danh mục');
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, 'Seri');
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, 'Giá nhập');
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount, 'Giá');
		$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount, 'Số shot');
		$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount, 'Xếp hạng');

		
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->getFont()->setBold(true);
		
		
		//Center
		$style_center = array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			)
		);
		
		$style_right = array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
			)
		);
		$style_left = array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT,
			)
		);
		
		$objPHPExcel->getActiveSheet()->getStyle('E3:G3')->applyFromArray($style_right);
		$objPHPExcel->getActiveSheet()->getStyle('H3')->applyFromArray($style_center);
		/*
		$objPHPExcel->getActiveSheet()->getStyle("A3:H3")->applyFromArray($style_center);
		//$objPHPExcel->getActiveSheet()->getStyle("D9:E9")->applyFromArray($style_center);
		//MegeCenter
		$objPHPExcel->getActiveSheet()->mergeCells('D8:E8');
		*/
	
		$k=1;
		$cat_id = 0;
		$cat_name = '';
		foreach($rows as $row)
		{
			$rating = isset($arr_rating[$row['rating']]) ? $arr_rating[$row['rating']] : '';
			if($row['cat_id']!=$cat_id)
			{
				$rowCount++;
				$cat_id = $row['cat_id'];
				$info_cat = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
				//var_dump($info_cat);exit();
				$cat_name = !empty($info_cat['title']) ? $info_cat['title'] : '';
				$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, $cat_name);
				$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount)->getFont()->setBold(true);
				
				$k=1;
			}
			$rowCount++;
			
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, $k); 
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, $row['title']);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, $cat_name);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, $row['seri']);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, $row['price_in']);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount, $row['price']);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount, $row['num_shot']);
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount, $rating);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount)->applyFromArray($style_center);
			$objPHPExcel->getActiveSheet()->getStyle('D'.$rowCount)->applyFromArray($style_left);
			$objPHPExcel->getActiveSheet()->getStyle('H'.$rowCount)->applyFromArray($style_center);
			$k++;
		}

		//Format Currency
		$objPHPExcel->getActiveSheet()
		->getStyle('A3:H'.$rowCount.'')
		->getNumberFormat()
		->setFormatCode(
			'#,##0_-'
		);

		//Border
		$styleArray = array(
		  'borders' => array(
			  'allborders' => array(
				  'style' => PHPExcel_Style_Border::BORDER_THIN,
				  'color' => array(
						'argb' => '000000',
				  ),
			  )
		  )
	  	);
		$objPHPExcel->getActiveSheet()->getStyle('A3:H'.$rowCount.'')->applyFromArray($styleArray);
		
		//Set Width
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth('8');
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth('35');
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth('35');
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth('18');
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth('18');
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth('18');
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth('12');		
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth('12');

		// Instantiate a Writer to create an OfficeOpenXML Excel .xlsx file
		/*
		header('Content-Type: application/vnd.ms-excel'); 
		header('Content-Disposition: attachment;filename="Limesurvey_Results.xls"');
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel); 
		// Write the Excel file to filename some_excel_file.xlsx in the current directory
		$objWriter->save('some_excel_file.xlsx'); 
		*/
		ob_end_clean();
		header('Content-Type: application/vnd.ms-excel'); 
		header('Content-Disposition: attachment;filename="Bao_cao_hang_ton_'.date('d_m_Y_H_i').'.xls"'); 
		header('Cache-Control: max-age=0'); 
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5'); 
		$objWriter->save('php://output');
		//$objWriter->save('/usr/local/myWorkbooks/workbook1.xlsx');  
		exit();
	}
	
	public function actionError()
    {
        if($error=Yii::app()->errorHandler->error)
		{
			$this->renderPartial('error',array("error"=>$error));
		}
        else
		{
            throw new CHttpException(404, 'Trang không tồn tại.');
		}
    }
	
	public function actionImportData()
	{
		ini_set("memory_limit","512M");
		$connect = Yii::app()->db;
		/*
		$fileinfo=pathinfo($file);
		$path_tmp=Yii::getPathOfAlias('application.runtime.tmp');
		file_put_contents($path_tmp.'/'.$fileinfo['basename'], file_get_contents($file));			
		*/
		Yii::import('application.vendors.PHPExcel',true);
		$objPHPExcel = new PHPExcel();
		$objReader = PHPExcel_IOFactory::createReader('Excel2007');
		$path_excel='D:\wamp\www\GoogleSearch\crawler2.xlsx';
		$objPHPExcel = $objReader->load($path_excel);
		$objPHPExcel->setActiveSheetIndex(0);
		//$number_row = $objPHPExcel->getActiveSheet()->getHighestRow();
		$number_row = 65284;
		//echo $number_row;
		
		$sub_sql='';
		if($number_row>0)
		for($i=65001;$i<=$number_row;$i++)
		{
			if($i!=1)
			{
				echo $i.'<br>';
				//$request_id=trim($objPHPExcel->getActiveSheet()->getCell("A".$i)->getValue());
				$destination=trim($objPHPExcel->getActiveSheet()->getCell("B".$i)->getValue());
				$tags=trim($objPHPExcel->getActiveSheet()->getCell("C".$i)->getValue());
				//$request_url=trim($objPHPExcel->getActiveSheet()->getCell("D".$i)->getValue());
				if($tags=='')
					$q = $destination;
				else
					$q = $tags.'+'.$destination;
				$request_url = 'http://www.google.fr/search?q='.$q;
				$sub_sql.='("'.mysql_escape_string($destination).'","'.mysql_escape_string($tags).'","'.mysql_real_escape_string($request_url).'"),';
				if ($i>=70000) break;
			}
		}
		$msg='';
		if($sub_sql!='')
		{
			$sub_sql=rtrim($sub_sql,',');
			$sql="INSERT IGNORE INTO tbl_request(`destination`, `tags`, `request_url`) VALUES ".$sub_sql."";
			$command=$connect->createCommand($sql);
			$ok= $command->execute();
			if($ok>=0)
			{
				$msg='Import thành công!';
			}
			else
			{
				$msg='Import lỗi!';
			}
		}
		else
		{
			$msg='File Excel không có bản ghi nào';
		}
        echo $msg;
	}
	
	public function actionExportData()
	{
		ini_set("memory_limit","1024M");
		$connect=Yii::app()->db;
		//$sql="SELECT * FROM tbl_result_mix ORDER BY id ASC LIMIT 50000";
		$sql="SELECT * FROM tbl_result_mix WHERE id>600000 LIMIT 50000";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		
		//Export
		Yii::import('application.vendors.PHPExcel',true);
		$objPHPExcel = new PHPExcel(); 
		/*
		if($type=="application/vnd.ms-excel")
			$objReader = PHPExcel_IOFactory::createReader('Excel5');                    
		else 
			$objReader = PHPExcel_IOFactory::createReader('Excel2007');
		*/
		// Set the active Excel worksheet to sheet 0
		$objPHPExcel->setActiveSheetIndex(0); 
		// Initialise the Excel row number
		//$objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Báo cáo hàng tồn'); 
		$rowCount = 1; 
		// Iterate through each result from the SQL query in turn
		// We fetch each database result row into $row in turn
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, 'Request ID'); 
		$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, 'Request to scrape');
		$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, 'Url');
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, 'Destination');
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, 'Tag');
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount, 'Ranking result');
		$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount, 'Title');
		$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount, 'Website');
		$objPHPExcel->getActiveSheet()->SetCellValue('I'.$rowCount, 'Meta Description');
		$objPHPExcel->getActiveSheet()->SetCellValue('J'.$rowCount, 'Photo Url');
		$objPHPExcel->getActiveSheet()->SetCellValue('K'.$rowCount, 'Photo website');
		$objPHPExcel->getActiveSheet()->SetCellValue('L'.$rowCount, 'Meta keywords');
		$objPHPExcel->getActiveSheet()->SetCellValue('M'.$rowCount, 'Logo url');
		$objPHPExcel->getActiveSheet()->SetCellValue('N'.$rowCount, 'Language');
		
		$objPHPExcel->getActiveSheet()->getStyle('A1:N1')->getFont()->setBold(true);
		
		
		//Center
		$style_center = array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			)
		);
		
		$style_right = array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
			)
		);
		$style_left = array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT,
			)
		);
		
		$objPHPExcel->getActiveSheet()->getStyle('A1:N1')->applyFromArray($style_left);
		//$objPHPExcel->getActiveSheet()->getStyle('H3')->applyFromArray($style_center);
		/*
		$objPHPExcel->getActiveSheet()->getStyle("A3:H3")->applyFromArray($style_center);
		//$objPHPExcel->getActiveSheet()->getStyle("D9:E9")->applyFromArray($style_center);
		//MegeCenter
		$objPHPExcel->getActiveSheet()->mergeCells('D8:E8');
		*/
		echo '<meta content="text/html; charset=UTF-8" http-equiv="Content-Type" />';
		foreach($rows as $row)
		{
			$rowCount++;
			$title = $row['title'];
			//ENT_QUOTES
			$title = htmlspecialchars_decode($row['title'],ENT_QUOTES);
			$title = html_entity_decode($title,ENT_QUOTES,'UTF-8');
			//$title = html_entity_decode($title);
			$website = urldecode($row['website']);
			$meta_description = htmlspecialchars_decode($row['meta_description']);
			$meta_description = html_entity_decode($meta_description,ENT_QUOTES,'UTF-8');
			$meta_keywords = htmlspecialchars_decode($row['meta_keywords']);
			$meta_keywords = html_entity_decode($meta_keywords,ENT_QUOTES,'UTF-8');
			$request_url = str_replace('http://www.google.fr/search?q=','http://www.google.fr/#q=',$row['request_url']);
			
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, $row['request_id']); 
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, $row['request_scrape']);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, $request_url);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, $row['destination']);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, $row['tag']);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount, $row['number_result']);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount, $title);
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount, $website);
			
			$objPHPExcel->getActiveSheet()->SetCellValue('I'.$rowCount, $meta_description);
			$objPHPExcel->getActiveSheet()->SetCellValue('J'.$rowCount, $row['photo_url']);
			$objPHPExcel->getActiveSheet()->SetCellValue('K'.$rowCount, $row['photo_website']);
			$objPHPExcel->getActiveSheet()->SetCellValue('L'.$rowCount, $meta_keywords);
			$objPHPExcel->getActiveSheet()->SetCellValue('M'.$rowCount, $row['logo_url']);
			$objPHPExcel->getActiveSheet()->SetCellValue('N'.$rowCount, $row['language']);
			
			$objPHPExcel->getActiveSheet()->getStyle('F'.$rowCount)->applyFromArray($style_right);
			
			//if($rowCount>=10) break;
		}
		/*
		//Format Currency
		$objPHPExcel->getActiveSheet()
		->getStyle('A3:H'.$rowCount.'')
		->getNumberFormat()
		->setFormatCode(
			'#,##0_-'
		);
		*/
		//Border
		/*
		$styleArray = array(
		  'borders' => array(
			  'allborders' => array(
				  'style' => PHPExcel_Style_Border::BORDER_THIN,
				  'color' => array(
						'argb' => '000000',
				  ),
			  )
		  )
	  	);
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:H'.$rowCount.'')->applyFromArray($styleArray);
		*/
		//Set Width
		/*
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth('8');
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth('10');
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth('15');
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth('12');
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth('12');
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth('6');
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth('20');		
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth('20');
		$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth('20');
		$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth('20');
		$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth('20');
		$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth('20');
		$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth('20');
		$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth('5');
		*/
		// Instantiate a Writer to create an OfficeOpenXML Excel .xlsx file
		/*
		header('Content-Type: application/vnd.ms-excel'); 
		header('Content-Disposition: attachment;filename="Limesurvey_Results.xls"');
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel); 
		// Write the Excel file to filename some_excel_file.xlsx in the current directory
		$objWriter->save('some_excel_file.xlsx'); 
		*/
		ob_end_clean();
		header("Content-Encoding: UTF-8");
		header('Content-Type: application/vnd.ms-excel');
		header("Content-Type:   text/html; charset=utf-8");
		header('Content-Disposition: attachment;filename="rank.xlsx"'); 
		header('Cache-Control: max-age=0'); 
		//Excel2007 //Excel5
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
		$objWriter->setPreCalculateFormulas(false);
		$objWriter->save('php://output');
		//$objWriter->save('/usr/local/myWorkbooks/workbook1.xlsx');  
		exit();
	}
	
	
	public function actionAppendData()
	{
		ini_set("memory_limit","2048M");
		$connect=Yii::app()->db;
		$sql="SELECT * FROM tbl_result_mix WHERE id>200000 LIMIT 50000";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
						
		//Export
		Yii::import('application.vendors.PHPExcel',true);
		$objPHPExcel = new PHPExcel(); 
		
		$objPHPExcel = PHPExcel_IOFactory::load("D:\Delivery_of_results.xlsx");
		$objPHPExcel->setActiveSheetIndex(0);
		$rowCount = $objPHPExcel->getActiveSheet()->getHighestRow();
		
		
		$style_right = array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
			)
		);
		
		foreach($rows as $row)
		{
			$rowCount++;
			$title = $row['title'];
			//ENT_QUOTES
			$title = htmlspecialchars_decode($row['title'],ENT_QUOTES);
			$title = html_entity_decode($title,ENT_QUOTES,'UTF-8');
			//$title = html_entity_decode($title);
			$website = urldecode($row['website']);
			$meta_description = htmlspecialchars_decode($row['meta_description']);
			$meta_description = html_entity_decode($meta_description,ENT_QUOTES,'UTF-8');
			$meta_keywords = htmlspecialchars_decode($row['meta_keywords']);
			$meta_keywords = html_entity_decode($meta_keywords,ENT_QUOTES,'UTF-8');
			$request_url = str_replace('http://www.google.fr/search?q=','http://www.google.fr/#q=',$row['request_url']);
			
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount, $row['request_id']); 
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount, $row['request_scrape']);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, $request_url);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, $row['destination']);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount, $row['tag']);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount, $row['number_result']);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount, $title);
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount, $website);
			
			$objPHPExcel->getActiveSheet()->SetCellValue('I'.$rowCount, $meta_description);
			$objPHPExcel->getActiveSheet()->SetCellValue('J'.$rowCount, $row['photo_url']);
			$objPHPExcel->getActiveSheet()->SetCellValue('K'.$rowCount, $row['photo_website']);
			$objPHPExcel->getActiveSheet()->SetCellValue('L'.$rowCount, $meta_keywords);
			$objPHPExcel->getActiveSheet()->SetCellValue('M'.$rowCount, $row['logo_url']);
			$objPHPExcel->getActiveSheet()->SetCellValue('N'.$rowCount, $row['language']);
			
			$objPHPExcel->getActiveSheet()->getStyle('F'.$rowCount)->applyFromArray($style_right);
			
			//if($rowCount>=10) break;
		}
		
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
		$objWriter->setPreCalculateFormulas(false);
		$objWriter->save('D:\Delivery_of_results.xlsx');
	}
	
}
?>