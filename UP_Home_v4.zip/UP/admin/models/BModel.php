<?php
class BModel extends CActiveRecord
{
	public function getModel($cat_id,$keyword,$keyword_in,$tab,  $from_date, $to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';		
		
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND (t1.title LIKE "%'.$keyword.'%" || t1.user_post LIKE "%'.$keyword.'%")';
			if($keyword_in==2) $cond.=' AND t1.user_post LIKE "%'.$keyword.'%"';
			if($keyword_in==3) $cond.=' AND t1.id ="'.$keyword.'"';
		}
		if($cat_id!=0)
		{
			$cats = $this->cats;
			$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] :  array();
			if(!empty($cat_info['sub_id'])) $cond.=' AND t1.cat_id IN ('.$cat_info['sub_id'].')'; 
			else $cond.=' AND t1.cat_id='.$cat_id;
		}
		
		if($tab==1) $cond.=' AND t1.status="active"';
		if($tab==2) $cond.=' AND t1.status="pending"';
		if($tab==3) $cond.=' AND t1.status="draft"';
		
		$cond_order = "ORDER BY t1.ordering DESC,t1.create_date DESC";
		
		$sql = "SELECT count(*) as total FROM b_model t1 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.*,t2.title as cat_title,t2.alias as cat_alias FROM b_model t1 LEFT JOIN b_cat t2 ON t1.cat_id=t2.id WHERE ".$cond." ".$cond_order." LIMIT ".$begin.",".$num_per_page." ";
		$command = $connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$access_related = array();
		$list_id = array();
		if($rows)
		foreach($rows as $row)
		{
			$list_id[] = $row['id'];
		}
		if(!empty($list_id))
		{
			$list_id = implode(',', $list_id);
			$sql = "SELECT t1.id, t1.title, t1.alias, t2.model_id FROM b_accessories t1, b_model_accessories t2 WHERE t1.id = t2.access_id AND t2.model_id IN (".$list_id.")";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$access_related[$row['model_id']][] = $row;
			}
		}
		
		$a=array($rows,$paging,$total, $access_related);
		return $a;
	}
	
	
	public function getModelById($model_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_model WHERE id=".$model_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function getModelRelated($model_id)
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_model_related WHERE news_id=".$model_id."";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function getListPopup($keyword,$cat_id,$page,$num_per_page)
	{
		$cacheService = new CacheService("News","getListPopup",$keyword.$cat_id.$page);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db;
			$cond='1 ';
			if($keyword!='')
			{
				$cond.= ' AND title like "%'.$keyword.'%"';
			}
			if($cat_id!=0) $cond.= ' AND cat_id = "'.$cat_id.'"';
			$sql = "SELECT count(*) as total FROM b_model WHERE ".$cond."";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			$total=$row['total'];
			$sql = "SELECT * FROM b_model WHERE ".$cond."  ORDER BY create_date DESC LIMIT ".($page-1)*$num_per_page.",".$num_per_page."";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			$a=array($rows,$total);
			Yii::app()->cache->set($key,$a,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	public function getListByListId($list_news_id)
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_model WHERE id IN (".$list_news_id.")";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	public function getHitListId($list_news_id)
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_hit_news WHERE news_id IN (".$list_news_id.")";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	public function countTabModel()
	{
		$connect=Yii::app()->db;
		//Tong so ban ghi
		$sql = "SELECT count(id) as total FROM b_model";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total = isset($row['total']) ? intval($row['total']):0;
		//Public
		$sql = "SELECT count(id) as total FROM b_model WHERE status='active'";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_active = isset($row['total']) ? intval($row['total']):0;
		//Pending
		$sql = "SELECT count(id) as total FROM b_model WHERE status='pending'";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total_pending=isset($row['total']) ? intval($row['total']):0;
		//Draf
		$sql = "SELECT count(id) as total FROM b_model WHERE status='draft'";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total_draft=isset($row['total']) ? intval($row['total']):0;
			
		$a=array($total, $total_active, $total_pending, $total_draft);
		return $a;
	}
	
	public function quickUpdateList($quick_type,$list_id)
	{
		$connect = Yii::app()->db;
		if($quick_type==1)//Kich hoat tin
		{
    		$sql = "UPDATE b_model SET status='active' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==2)//Bo kich hoat
		{
			$sql = "UPDATE b_model SET status='pending' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==3)//Xoa tin bai
		{
			$sql = "DELETE FROM b_model WHERE id IN (".$list_id.")";
		}
		else if ($quick_type==4)
		{
			$sql = "UPDATE b_model SET is_approved = 1 WHERE id IN (".$list_id.")";
		}
		else if ($quick_type==5)
		{
			$sql = "UPDATE b_model SET is_approved = 0 WHERE id IN (".$list_id.")";
		}
				
		$command = $connect->createCommand($sql);
        $result = $command->execute();
		
		if($quick_type==3)
		{
			$sql = "DELETE FROM b_model_content WHERE camera_id IN (".$list_id.")";
			$command = $connect->createCommand($sql);
        	$result = $command->execute();
		}
        return $result;	
    }
	
	public function getListCrawling($keyword,$keyword_in,$type,$cat_id,$city_id,$district_id,$ward_id,$street_id,$project_id,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND (t1.title LIKE "%'.$keyword.'%" || t1.dien_thoai_lien_he LIKE "%'.$keyword.'%" || t1.mobile_lien_he LIKE "%'.$keyword.'%")';
			if($keyword_in==2) $cond.=' AND t1.username LIKE "%'.$keyword.'%"';
			if($keyword_in==3) $cond.=' AND t1.id ="'.$keyword.'"';
		}
		
		if($type!=0) $cond.=' AND t1.type='.$type;
		if($cat_id!=0) $cond.=' AND t1.cat_id='.$cat_id;
		
		if($city_id!=0) $cond.=' AND t1.city_id="'.$city_id.'"';
		if($district_id!=0) $cond.=' AND t1.district_id="'.$district_id.'"';
		if($ward_id!=0) $cond.=' AND t1.ward_id="'.$ward_id.'"';
		if($street_id!=0) $cond.=' AND t1.street_id="'.$street_id.'"';
		if($project_id!=0) $cond.=' AND t1.project_id="'.$project_id.'"';
		
		$sql = "SELECT count(*) as total FROM b_model t1 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.*,t2.title as cat_title,t2.alias as cat_alias FROM b_model t1 LEFT JOIN b_cat t2 ON t1.cat_id=t2.id WHERE ".$cond." LIMIT ".$begin.",".$num_per_page." ";
		$command = $connect->createCommand($sql);
		$rows= $command->queryAll();
		
	   
		$a=array($rows,$paging,$total);
		return $a;
	}
	
	public function checkTitleAlias($alias)
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_model WHERE alias = '".$alias."'";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
	
	public function getListAnalytics($cat_id, $seri,$keyword,$keyword_in,$tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 AND status_p=0';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND (t1.title LIKE "%'.$keyword.'%" || t1.user_post LIKE "%'.$keyword.'%")';
			if($keyword_in==2) $cond.=' AND t1.user_post LIKE "%'.$keyword.'%"';
			if($keyword_in==3) $cond.=' AND t1.id ="'.$keyword.'"';
		}
		if($cat_id!=0) $cond.=' AND t1.cat_id='.$cat_id;
		if($seri!='') $cond.=' AND t1.seri LIKE "%'.$seri.'%"';
		if($from_date!=0) $cond.=' AND t1.time_buy >= '.$from_date;
		if($to_date!=0) $cond.=' AND t1.time_buy <= '.$to_date;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		
		if($tab==1)//Hom nay
		{
			$cond.=' AND time_buy>='.$today.' AND time_buy<'.($today+86400);
		}
		if($tab==2)//Hom qua
		{
			$cond.=' AND time_buy>='.($today-86400).' AND time_buy<'.$today;
		}
		if($tab==3)//Thang nay
		{
			$from = mktime(0,0,0,date('m'),1,date('Y'));
			$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
			$cond.=' AND time_buy>='.$from.' AND time_buy<='.$to;
		}
		if($tab==4)//Thang truoc
		{
			$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
			$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
			$cond.=' AND time_buy>='.$from.' AND time_buy<='.$to;
		}
		
		$cond_order = "ORDER BY t1.create_date DESC";
		
		$sql = "SELECT count(*) as total FROM b_model t1 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.*,t2.title as cat_title,t2.alias as cat_alias FROM b_model t1 LEFT JOIN b_cat t2 ON t1.cat_id=t2.id WHERE ".$cond." ".$cond_order." LIMIT ".$begin.",".$num_per_page." ";
		$command = $connect->createCommand($sql);
		$rows= $command->queryAll();
		//Tinh tong tien
		$sql = "SELECT sum(price_buy) as total_buy,sum(price_in) as total_in  FROM b_model t1 LEFT JOIN b_cat t2 ON t1.cat_id=t2.id WHERE ".$cond."";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_buy = $row['total_buy']; //Tong tien ban
		$total_in = $row['total_in']; //Tong tien ban
		if($total_in!=0)
			$percent = ($total_buy-$total_in)*100/$total_in;
		else	
			$percent = 0;
		//Ton
		$sql = "SELECT sum(price_in) as total_in_ton FROM b_model WHERE status_p=1";
	   	$command = $connect->createCommand($sql);
		$row= $command->queryRow();
		$total_in_ton = $row['total_in_ton']; //Tong tien ton
		$a=array($rows,$paging,$total, $total_buy, $total_in, $percent, $total_in_ton);
		return $a;
	}
	
	public function getTotal()
	{
		$connect=Yii::app()->db;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		//Hom nay
		$sql = 'SELECT count(id) as total FROM b_model WHERE status_p=0 AND time_buy>='.$today.' AND time_buy<'.($today+86400);
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_1 = isset($row['total']) ? intval($row['total']):0;
		
		//Hom qua
		$sql = 'SELECT count(id) as total FROM b_model WHERE status_p=0 AND time_buy>='.($today-86400).' AND time_buy<'.$today;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_2 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang nay
		$from = mktime(0,0,0,date('m'),1,date('Y'));
		$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
		$sql = 'SELECT count(id) as total FROM b_model WHERE status_p=0 AND time_buy>='.$from.' AND time_buy<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_3 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang truoc
		$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
		$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
		$sql = 'SELECT count(id) as total FROM b_model WHERE status_p=0 AND time_buy>='.$from.' AND time_buy<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_4 = isset($row['total']) ? intval($row['total']):0;
		//Total
		$sql = 'SELECT count(id) as total FROM b_model WHERE status_p=0';
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_0 = isset($row['total']) ? intval($row['total']):0;
		
		return array($total_0, $total_1, $total_2, $total_3, $total_4);
	}
	
	public function getChart($month)
	{
		$connect=Yii::app()->db;
		$cond='1 AND status_p=0 AND MONTH(FROM_UNIXTIME(time_buy))='.$month.' AND YEAR(FROM_UNIXTIME(time_buy))='.date('Y');
		//Tinh tong tien
		$sql = "SELECT sum(price_buy) as total_buy,sum(price_in) as total_in, DAY(FROM_UNIXTIME(time_buy)) as day_buy FROM b_model WHERE ".$cond." GROUP BY DAY(FROM_UNIXTIME(time_buy))";
	   	$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		
		$data_report_buy = array();
		$data_report_lai = array();
		for($i=1; $i<=31; $i++)
		{
			$data_report_buy[$i] = 0;
			$data_report_lai[$i] = 0;
		}
		
		foreach($rows as $row)
		{
			$data_report_buy[$row['day_buy']] = $row['total_buy'];
			$data_report_lai[$row['day_buy']] = $row['total_buy'] - $row['total_in'];
		}
		$data_report_buy = implode(',', $data_report_buy);
		$data_report_lai = implode(',', $data_report_lai);
		$a = array($data_report_buy, $data_report_lai);
		return $a;
	}
	
	public function insertProductBy($camera_id, $price_in_one)
	{
		$connect=Yii::app()->db;
		$sql = "INSERT INTO b_model(`num_p`, `cat_id`, `title`, `alias`, `introtext`, `picture`, `is_hot`, `keyword`, `hit`, `meta_title`, `meta_keyword`, `meta_description`, `status`, `create_date`, `edit_date`, `publish_date`, `expired_date`, `edit_name`, `user_post`, `admin_id`, `admin_name`, `price`, `price_in`, `price_sale`, `price_buy`, `time_sale`, `num_shot`, `note_shot`, `code`, `rating`, `time_buy`, `info_customer`, `seri`, `is_seri`, `is_new`, `time_bh`, `phu_kien`, `title_other`, `sale_add`, `xuat_xu`, `status_p`, `chinh_hang`, `user_id`, `username`, `camera_source`, `original_link`, `original_link_picture`, `is_approved`, `approved_name`, `approved_date`) SELECT 1, `cat_id`, `title`, `alias`, `introtext`, `picture`, `is_hot`, `keyword`, `hit`, `meta_title`, `meta_keyword`, `meta_description`, `status`, `create_date`, `edit_date`, `publish_date`, `expired_date`, `edit_name`, `user_post`, `admin_id`, `admin_name`, `price`, ".$price_in_one.", `price_sale`, `price_buy`, `time_sale`, `num_shot`, `note_shot`, `code`, `rating`, `time_buy`, `info_customer`, `seri`, `is_seri`, `is_new`, `time_bh`, `phu_kien`, `title_other`, `sale_add`, `xuat_xu`, 0, `chinh_hang`, `user_id`, `username`, `camera_source`, `original_link`, `original_link_picture`, `is_approved`, `approved_name`, `approved_date` FROM b_model WHERE id=".$camera_id;
		
		$command = $connect->createCommand($sql);
		$a=$command->execute();
		return $a;
	}
	
	public function updateOrderList($id,$order)
	{
		$connect=Yii::app()->db;
		$sql="UPDATE b_model SET ordering=".$order." WHERE id=".$id;
		$command = $connect->createCommand($sql);
		$ok = $command->execute();
		return $ok;
	}
	
	public function getTon()
	{
		$connect=Yii::app()->db;
		$cond='1 AND status_p=1';		
		
		$sql = "SELECT `id`, `num_p`, `cat_id`, `title`, `price`, `price_in`, `price_sale`, `price_buy`, `num_shot`, `rating`, `seri`, `is_seri` FROM b_model WHERE ".$cond." ORDER BY cat_id ASC";
		$command = $connect->createCommand($sql);
		$rows= $command->queryAll();
	   
		return $rows;
	}
	
	public function getAllModel()
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_model";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
}
?>