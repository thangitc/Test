<?php
class Bill extends CActiveRecord
{
	public function getBill($keyword,$keyword_in,$tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';		
		
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND (t1.fullname LIKE "%'.$keyword.'%" || t1.address LIKE "%'.$keyword.'%" || t1.mobile LIKE "%'.$keyword.'%")';
			if($keyword_in==2) $cond.=' AND t1.mobile ="'.$keyword.'"';
		}
		
		if($from_date!=0) $cond.=' AND t1.create_date>='.$from_date;
		if($to_date!=0) $cond.=' AND t1.create_date<='.$to_date;
		
		if($tab==1) $cond.=' AND t1.status="active"';
		if($tab==2) $cond.=' AND t1.status="pending"';
		
		$sql = "SELECT count(*) as total FROM tbl_bill t1 WHERE ".$cond." ";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.* FROM tbl_bill t1 WHERE ".$cond." ORDER BY t1.create_date DESC LIMIT ".$begin.",".$num_per_page." ";
		$command = $connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$a=array($rows,$paging,$total);
		return $a;
	}
	
	
	public function getBillById($timeline_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM tbl_bill WHERE id=".$timeline_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function getAllBill()
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM tbl_bill";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	public function countTabBill()
	{
		$connect=Yii::app()->db;
		//Tong so ban ghi
		$sql = "SELECT count(id) as total FROM tbl_bill";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total = isset($row['total']) ? intval($row['total']):0;
		//Public
		$sql = "SELECT count(id) as total FROM tbl_bill WHERE status='active'";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_active = isset($row['total']) ? intval($row['total']):0;
		//Pending
		$sql = "SELECT count(id) as total FROM tbl_bill WHERE status='pending'";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total_pending=isset($row['total']) ? intval($row['total']):0;
		
		$a=array($total, $total_active, $total_pending);
		return $a;
	}
	
	public function quickUpdateBill($quick_type,$list_id)
	{
		$connect = Yii::app()->db;
		if($quick_type==1)//Kich hoat tin
		{
    		$sql = "UPDATE tbl_bill SET status='active' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==2)//Bo kich hoat
		{
			$sql = "UPDATE tbl_bill SET status='pending' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==3)//Xoa tin bai
		{
			$sql = "DELETE FROM tbl_bill WHERE id IN (".$list_id.")";
		}
		
		$command = $connect->createCommand($sql);
        $result = $command->execute();				
        return $result;	
    }
	
	public function updateOrderBill($id,$order)
	{
		$connect=Yii::app()->db;
		$sql="UPDATE tbl_bill SET ordering=".$order." WHERE id=".$id;
		$command = $connect->createCommand($sql);
		$ok = $command->execute();
		return $ok;
	}
}
?>