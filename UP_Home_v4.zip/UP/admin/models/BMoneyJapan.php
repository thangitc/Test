<?php
class BMoneyJapan extends CActiveRecord
{
	public function getMoneyJapan($keyword,$keyword_in, $from_date, $to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND id = "'.$keyword.'"';
		}
		
		if($from_date!=0) $cond.=' AND create_date >= '.$from_date;
		if($to_date!=0) $cond.=' AND create_date <= '.$to_date;
		
		$sql = "SELECT count(*) as total FROM b_money_japan_detail WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
        $exam_total=array();
		$sql = "SELECT * FROM b_money_japan_detail WHERE ".$cond." ORDER BY id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		
		$a = array($rows,$paging,$total);
		return $a;
	}
	
	public function getMoneyJapanById($money_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_money_japan_detail WHERE id=".$money_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function updateMoneyJapan($money, $type)
	{
		$connect=Yii::app()->db;
		if($type==1)
		{
			$sql = "UPDATE b_money_japan SET money=money+".$money." WHERE id=1";
		}
		else
		{
			$sql = "UPDATE b_money_japan SET money=money-".$money." WHERE id=1";
		}
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function getTotalMoneyJapan()
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_money_japan WHERE id=1";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total = $row['money'];
		return $total;
	}
	
	public function getTotalMoneyThuChi($month, $year)
	{
		$connect=Yii::app()->db;
		//Thu
		$sql = "SELECT sum(money_send_japan) as total_money_month_vnd_thu, sum(money_yen_received_japan) as total_money_month_japan_thu FROM b_money_japan_detail WHERE month=".$month." AND year=".$year." AND type=1";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_money_month_vnd_thu = $row['total_money_month_vnd_thu'];
		$total_money_month_japan_thu = $row['total_money_month_japan_thu'];
		//Chi
		$sql = "SELECT sum(money_yen_received_japan) as total_money_month_japan_chi FROM b_money_japan_detail WHERE month=".$month." AND year=".$year." AND type=0";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_money_month_japan_chi = $row['total_money_month_japan_chi'];
		$a = array($total_money_month_vnd_thu, $total_money_month_japan_thu, $total_money_month_japan_chi);
		return $a;
	}
}
?>