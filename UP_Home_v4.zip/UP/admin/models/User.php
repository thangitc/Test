<?php
class User extends CActiveRecord
{
	public function getUser($keyword,$keyword_in ,$from_date,$to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND id = "'.$keyword.'"';
		}
		if($from_date!=0) $cond.=' AND create_date >= '.$from_date;
		if($to_date!=0) $cond.=' AND create_date <= '.$to_date;
		
		$sql = "SELECT count(*) as total FROM b_user WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
        $exam_total=array();
		$sql = "SELECT * FROM b_user WHERE ".$cond." ORDER BY id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$a = array($rows,$paging,$total);
		return $a;
	}
	public function getUserById($user_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_user WHERE id=".$user_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
}
?>