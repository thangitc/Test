<?php
class AdminAuthassignment extends CActiveRecord
{
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    public function tableName()
    {
        return 'b_authassignment';
    }
	
	public function getAllPermit()
    {
  		$sql = "SELECT * FROM b_authassignment";       
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);
        $rows = $command->queryAll();   
		$array=array();
		if($rows)
		foreach($rows as $row)
		{
			$array[$row['user_id'].'_'.$row['permit_id'].'_'.$row['module_id']]=$row;
		}
		return $array;
    }
	public function insertAssignPermit($sub_sql)
	{
		$sql = "REPLACE INTO b_authassignment(`user_id`, `permit_id`, `module_id`, `username`, `permit`, `module`, `create_date`) VALUES ".$sub_sql."";
		$connect = Yii::app()->db;
		$command = $connect->createCommand($sql);       
		$result = $command->execute();
		return $result;
	}
	public function deleteAssignPermit($list_id)
	{
		$sql = "DELETE FROM b_authassignment WHERE id in (".$list_id.")";
		$connect = Yii::app()->db;
		$command = $connect->createCommand($sql);       
		$result = $command->execute();
		return $result;
	}
	public function getPermitByModuleUser($module_id,$user_id)
	{
		$sql = "SELECT * FROM b_authassignment WHERE module_id=".$module_id." AND user_id=".$user_id."";       
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);
        $rows = $command->queryAll();   
		$array=array();
		if($rows)
		foreach($rows as $row)
		{
			$array[$row['user_id'].'_'.$row['permit_id'].'_'.$row['module_id']]=$row;
		}
		return $array;
	}
    public function getPermitByUser($user_id)
    {
        $sql = "SELECT distinct(module_id) as module FROM b_authassignment WHERE user_id=".$user_id."";       
        $connect = Yii::app()->db;
        $command = $connect->createCommand($sql);
        $rows = $command->queryAll(); 
        $array=array();
        if($rows)
        foreach($rows as $row)
        {
            $array[$row['module']]=$row;
        }         
        return $array;
    }
}
?>