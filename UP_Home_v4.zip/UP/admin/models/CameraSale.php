<?php
class CameraSale extends CActiveRecord
{
	public function getCameraSaleById($sale_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_camera_sale WHERE id=".$sale_id;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}
?>