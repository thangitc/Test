<?php
class Combos extends CActiveRecord
{
	public function getCombos($keyword,$keyword_in,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND id = "'.$keyword.'"';
		}
		
		$sql = "SELECT count(*) as total FROM tbl_combos WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);

		$sql = "SELECT * FROM tbl_combos WHERE ".$cond." ORDER BY id DESC LIMIT ".$begin.",".$num_per_page." ";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		
		//Danh sach models
		$list_combo_id = '0';
        $list_camera_id = '0';
        $list_access_id = '0';
        $list_model_id = '0';

		if($rows)
		foreach($rows as $row)
		{
            $list_combo_id.=','.$row['id'];
		}

        $sql = "SELECT * FROM tbl_combos_products WHERE combo_id IN (".$list_combo_id.")";
        $command = $connect->createCommand($sql);
        $rows_products = $command->queryAll();
        $list_products = array();
        $list_camera = array();
        $list_access = array();
        $list_model = array();

        if($rows_products){
            foreach($rows_products as $row)
            {
                $list_products[$row['combo_id']][] = $row;
                if($row['product_type']==0){
                    $list_camera_id.=','.$row['product_id'];
                }else if($row['product_type']==1){
                    $list_access_id.=','.$row['product_id'];
                }else{
                    $list_model_id .= ','.$row['product_id'];
                }
            }
        }

        //Camera
        $sql = "SELECT * FROM b_camera WHERE id IN (".$list_camera_id.")";
        $command = $connect->createCommand($sql);
        $row_cameras = $command->queryAll();
        if($row_cameras){
            foreach($row_cameras as $row){
                $list_camera[$row['id']] = $row;
            }
        }
        //Access
        $sql = "SELECT * FROM b_accessories WHERE id IN (".$list_access_id.")";
        $command = $connect->createCommand($sql);
        $row_access = $command->queryAll();
        if($row_access){
            foreach($row_access as $row){
                $list_access[$row['id']] = $row;
            }
        }

        //Model
        $sql = "SELECT * FROM b_model WHERE id IN (".$list_model_id.")";
        $command = $connect->createCommand($sql);
        $row_model = $command->queryAll();
        if($row_model){
            foreach($row_model as $row){
                $list_model[$row['id']] = $row;
            }
        }

		$a = array($rows,$paging,$total, $list_products, $list_camera, $list_access, $list_model);
		return $a;
	}
	
	public function getCombosById($combos_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM tbl_combos WHERE id=".$combos_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function checkComboProduct($product_id, $product_type, $list_model){
        $connect = Yii::app()->db;
        $sql = "SELECT * FROM tbl_combos_products WHERE product_id=".$product_id." AND product_type=".$product_type;
        $command = $connect->createCommand($sql);
        $row = $command->queryRow();
        $is_combo = 0; //Khong thuoc combo
        if(!empty($row)){
            $is_combo = 1; //Thuoc Combo
            $sql = "SELECT * FROM tbl_combos_products WHERE combo_id=".$row['combo_id']." AND product_type=2";
            $command = $connect->createCommand($sql);
            $row2 = $command->queryRow();
            $model_id = isset($row2['product_id']) ? intval($row2['product_id']) : 0;
            if(!in_array($model_id, $list_model)){ //Kiem tra xem co san pham chinh trong gio hang khong
                $is_combo = 0; //Tra ve gia thuong
            }
        }
        return array($is_combo, $row);
    }
}
?>