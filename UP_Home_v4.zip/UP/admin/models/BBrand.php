<?php
class BBrand extends CActiveRecord
{
	public function getBrand($keyword,$keyword_in,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND id = "'.$keyword.'"';
		}
		
		$sql = "SELECT count(*) as total FROM b_brand WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
        $exam_total=array();
		$sql = "SELECT * FROM b_brand WHERE ".$cond." ORDER BY id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		$a = array($rows,$paging,$total);
		return $a;
	}
	
	public function getBrandById($brand_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_brand WHERE id=".$brand_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function getAllBrand()
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_brand";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
}
?>