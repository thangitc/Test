<?php
class BListContent extends CActiveRecord
{
	public function getContentById($camera_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_camera_content WHERE camera_id=".$camera_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
}
?>