<?php
class Access extends CActiveRecord
{
	public function getAccess($cat_id,$keyword,$keyword_in,$tab,  $from_date, $to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';		
		
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND (t1.title LIKE "%'.$keyword.'%" || t1.user_post LIKE "%'.$keyword.'%")';
			if($keyword_in==2) $cond.=' AND t1.user_post LIKE "%'.$keyword.'%"';
			if($keyword_in==3) $cond.=' AND t1.id ="'.$keyword.'"';
		}
		if($cat_id!=0)
		{
			$cats = $this->cats;
			$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] :  array();
			if(!empty($cat_info['sub_id'])) $cond.=' AND t1.cat_id IN ('.$cat_info['sub_id'].')'; 
			else $cond.=' AND t1.cat_id='.$cat_id;
		}
		
		if($tab==1) $cond.=' AND t1.status="active"';
		if($tab==2) $cond.=' AND t1.status="pending"';
		if($tab==3) $cond.=' AND t1.status="draft"';
		
		$cond_order = "ORDER BY t1.ordering DESC,t1.create_date DESC";
		
		$sql = "SELECT count(*) as total FROM b_accessories t1 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.*,t2.title as cat_title,t2.alias as cat_alias FROM b_accessories t1 LEFT JOIN b_cat t2 ON t1.cat_id=t2.id WHERE ".$cond." ".$cond_order." LIMIT ".$begin.",".$num_per_page." ";
		$command = $connect->createCommand($sql);
		$rows= $command->queryAll();
		
	   
		$a=array($rows,$paging,$total);
		return $a;
	}
	
	
	public function getAccessById($access_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_accessories WHERE id=".$access_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function getAccessRelated($access_id)
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_accessories_related WHERE news_id=".$access_id."";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function countTabAccess()
	{
		$connect=Yii::app()->db;
		//Tong so ban ghi
		$sql = "SELECT count(id) as total FROM b_accessories";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total = isset($row['total']) ? intval($row['total']):0;
		//Public
		$sql = "SELECT count(id) as total FROM b_accessories WHERE status='active'";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_active = isset($row['total']) ? intval($row['total']):0;
		//Pending
		$sql = "SELECT count(id) as total FROM b_accessories WHERE status='pending'";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total_pending=isset($row['total']) ? intval($row['total']):0;
		//Draf
		$sql = "SELECT count(id) as total FROM b_accessories WHERE status='draft'";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total_draft=isset($row['total']) ? intval($row['total']):0;
			
		$a=array($total, $total_active, $total_pending, $total_draft);
		return $a;
	}
	
	public function quickUpdateList($quick_type,$list_id)
	{
		$connect = Yii::app()->db;
		if($quick_type==1)//Kich hoat tin
		{
    		$sql = "UPDATE b_accessories SET status='active' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==2)//Bo kich hoat
		{
			$sql = "UPDATE b_accessories SET status='pending' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==3)//Xoa tin bai
		{
			$sql = "DELETE FROM b_accessories WHERE id IN (".$list_id.")";
		}
		else if ($quick_type==4)
		{
			$sql = "UPDATE b_accessories SET is_approved = 1 WHERE id IN (".$list_id.")";
		}
		else if ($quick_type==5)
		{
			$sql = "UPDATE b_accessories SET is_approved = 0 WHERE id IN (".$list_id.")";
		}
				
		$command = $connect->createCommand($sql);
        $result = $command->execute();
		
		if($quick_type==3)
		{
			$sql = "DELETE FROM b_accessories_content WHERE camera_id IN (".$list_id.")";
			$command = $connect->createCommand($sql);
        	$result = $command->execute();
		}
        return $result;	
    }
	
	public function getTotal()
	{
		$connect=Yii::app()->db;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		//Hom nay
		$sql = 'SELECT count(id) as total FROM b_accessories WHERE status_p=0 AND time_buy>='.$today.' AND time_buy<'.($today+86400);
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_1 = isset($row['total']) ? intval($row['total']):0;
		
		//Hom qua
		$sql = 'SELECT count(id) as total FROM b_accessories WHERE status_p=0 AND time_buy>='.($today-86400).' AND time_buy<'.$today;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_2 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang nay
		$from = mktime(0,0,0,date('m'),1,date('Y'));
		$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
		$sql = 'SELECT count(id) as total FROM b_accessories WHERE status_p=0 AND time_buy>='.$from.' AND time_buy<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_3 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang truoc
		$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
		$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
		$sql = 'SELECT count(id) as total FROM b_accessories WHERE status_p=0 AND time_buy>='.$from.' AND time_buy<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_4 = isset($row['total']) ? intval($row['total']):0;
		//Total
		$sql = 'SELECT count(id) as total FROM b_accessories WHERE status_p=0';
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_0 = isset($row['total']) ? intval($row['total']):0;
		
		return array($total_0, $total_1, $total_2, $total_3, $total_4);
	}
	
	public function getChart($month)
	{
		$connect=Yii::app()->db;
		$cond='1 AND status_p=0 AND MONTH(FROM_UNIXTIME(time_buy))='.$month.' AND YEAR(FROM_UNIXTIME(time_buy))='.date('Y');
		//Tinh tong tien
		$sql = "SELECT sum(price_buy) as total_buy,sum(price_in) as total_in, DAY(FROM_UNIXTIME(time_buy)) as day_buy FROM b_accessories WHERE ".$cond." GROUP BY DAY(FROM_UNIXTIME(time_buy))";
	   	$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		
		$data_report_buy = array();
		$data_report_lai = array();
		for($i=1; $i<=31; $i++)
		{
			$data_report_buy[$i] = 0;
			$data_report_lai[$i] = 0;
		}
		
		foreach($rows as $row)
		{
			$data_report_buy[$row['day_buy']] = $row['total_buy'];
			$data_report_lai[$row['day_buy']] = $row['total_buy'] - $row['total_in'];
		}
		$data_report_buy = implode(',', $data_report_buy);
		$data_report_lai = implode(',', $data_report_lai);
		$a = array($data_report_buy, $data_report_lai);
		return $a;
	}
	
	public function getAccessPopup($keyword,$cat_id,$page,$num_per_page)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			$cond.= ' AND title LIKE "%'.$keyword.'%"';
		}
		if($cat_id!=0) $cond.= ' AND cat_id = "'.$cat_id.'"';
		$sql = "SELECT count(*) as total FROM b_accessories WHERE ".$cond."";
		$command = $connect->createCommand($sql);
		$row = $command->queryRow();
		$total = $row['total'];
		$sql = "SELECT * FROM b_accessories WHERE ".$cond." ORDER BY create_date DESC LIMIT ".($page-1)*$num_per_page.",".$num_per_page."";
		$command = $connect->createCommand($sql);
		$rows = $command->queryAll();
		$a = array($rows,$total);
		return $a;
	}
	//Camera
	public function getAccessByCameraId($camera_id)
	{
		$connect = Yii::app()->db;
		$sql="SELECT t1.id, t1.title, t1.alias FROM b_accessories t1 WHERE t1.id IN (SELECT access_id FROM b_camera_accessories WHERE camera_id=".$camera_id.")";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		return $rows;
	}
	
	public function deleteAccessRelated($camera_id)
	{
		$connect=Yii::app()->db;
		$sql="DELETE FROM b_camera_accessories WHERE camera_id ='".$camera_id."'";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function insertCameraAccess($sub_sql)
	{
		$connect=Yii::app()->db;
		$sql="INSERT IGNORE INTO b_camera_accessories(`camera_id`, `access_id`, `create_date`) VALUES ".$sub_sql."";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	//Model
	
	public function getAccessByModelId($model_id)
	{
		$connect = Yii::app()->db;
		$sql="SELECT t1.id, t1.title, t1.alias FROM b_accessories t1 WHERE t1.id IN (SELECT access_id FROM b_model_accessories WHERE model_id=".$model_id.")";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		return $rows;
	}
	
	public function deleteAccessModelRelated($model_id)
	{
		$connect=Yii::app()->db;
		$sql="DELETE FROM b_model_accessories WHERE model_id ='".$model_id."'";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function insertModelAccess($sub_sql)
	{
		$connect=Yii::app()->db;
		$sql="INSERT IGNORE INTO b_model_accessories(`model_id`, `access_id`, `create_date`) VALUES ".$sub_sql."";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	//Assce Free
	public function getAccessFreeByCameraId($camera_id)
	{
		$connect = Yii::app()->db;
		$sql="SELECT t1.id, t1.title, t1.alias FROM b_accessories t1 WHERE t1.id IN (SELECT access_id FROM b_camera_access_free WHERE camera_id=".$camera_id.")";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		return $rows;
	}
	
	public function deleteAccessFree($camera_id)
	{
		$connect=Yii::app()->db;
		$sql="DELETE FROM b_camera_access_free WHERE camera_id ='".$camera_id."'";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function insertCameraAccessFree($sub_sql)
	{
		$connect=Yii::app()->db;
		$sql="INSERT IGNORE INTO b_camera_access_free(`camera_id`, `access_id`) VALUES ".$sub_sql."";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function updateOrderAccess($id,$order)
	{
		$connect=Yii::app()->db;
		$sql="UPDATE b_accessories SET ordering=".$order." WHERE id=".$id;
		$command = $connect->createCommand($sql);
		$ok = $command->execute();
		return $ok;
	}
	
}
?>