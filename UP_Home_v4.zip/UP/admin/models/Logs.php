<?php
class Logs extends CActiveRecord
{
	public function getLogs($keyword,$keyword_field,$module,$name_action,$from_date,$to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect =yii::app()->db;
		$url = Yii::app ()->urlManager;
		//Cache
		$cacheService = new CacheService("Logs","getLogs",$keyword.$keyword_field.$module.$name_action.$from_date.$to_date.$page.$num_per_page.$url_rewrite);
		
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
        
		$cache = false;
        if ($cache == false) 
		{
			/*Xác định điều kiện*/
			$cond_sql=" 1 ";
			$cond_order='';
			
			if(!empty($keyword_field) && !empty($keyword)) {
				if($keyword_field === 'logId'){
					$cond_sql.=' AND t1.id = '. intval($keyword);
				}
				else if($keyword_field === 'userName'){
					$cond_sql.=' AND t1.username like "%'.mysql_escape_string($keyword).'%"';
				}
				else if($keyword_field === 'content'){
					$cond_sql.=' AND t1.content like "%'.mysql_escape_string($keyword).'%"';
				}
			}
				
			if($module!='')
				$cond_sql.=' AND t1.module ="'.$module.'"';	
			
			if($name_action!='')	
				$cond_sql.=' AND t1.name_action="'.$name_action.'"';
			if($from_date!='')	
				$cond_sql.=' AND t1.time_action>='.$from_date.'';
			if($to_date!='')	
				$cond_sql.=' AND t1.time_action<='.$to_date.'';
			
			//End kiem tra dieu kien	
			
			$sql="SELECT count(id) as total FROM b_system_log t1 WHERE ".$cond_sql."";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			$total=$row['total'];
			//Phân trang
			$num_per_page = $num_per_page;
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$sql = "SELECT * FROM b_system_log t1 WHERE ".$cond_sql." ORDER BY time_action DESC LIMIT ".$begin.",".$num_per_page."";
				
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			$iSEGSIZE = 9;
			
			$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			$a=array($rows,$total,$paging);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_300);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	public function insertLogs($user_id,$user_name,$name_action,$object,$content,$time_action,$module)
	{
		$connect =yii::app()->db;
		$sql="INSERT INTO b_system_log(`user_id`, `username`, `name_action`, `object`, `content`, `time_action`, `module`) VALUES (".$user_id.",'".$user_name."','".$name_action."','".$object."','".$content."','".$time_action."','".$module."')";
		$command=$connect->createCommand($sql);
		$result =$command->execute();
		return $result;
	}
	public function viewLog($id)
	{
		$connect =yii::app()->db;
		$sql="SELECT * FROM b_system_log WHERE id=".$id."";
		$command=$connect->createCommand($sql);
		$row =$command->queryRow();
		return $row;
	}
}
?>