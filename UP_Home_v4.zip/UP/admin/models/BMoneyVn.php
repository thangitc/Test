<?php
class BMoneyVn extends CActiveRecord
{
	public function getMoneyVn($keyword,$keyword_in, $from_date, $to_date, $tab,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 AND (is_month=1 || is_month=2)';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND id = "'.$keyword.'"';
		}
		
		if($from_date!=0) $cond.=' AND create_date >= '.$from_date;
		if($to_date!=0) $cond.=' AND create_date <= '.$to_date;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		if($tab==1)//Hom nay
		{
			$cond.=' AND create_date>='.$today.' AND create_date<'.($today+86400);		
		}
		if($tab==2)//Hom qua
		{
			$cond.=' AND create_date>='.($today-86400).' AND create_date<'.$today;
		}
		if($tab==3)//Thang nay
		{
			$from = mktime(0,0,0,date('m'),1,date('Y'));
			$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
			$cond.=' AND create_date>='.$from.' AND create_date<='.$to;
		}
		if($tab==4)//Thang truoc
		{
			$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
			$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
			$cond.=' AND create_date>='.$from.' AND create_date<='.$to;
		}
		
		$sql = "SELECT count(*) as total FROM b_money_vn WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
        $exam_total=array();
		$sql = "SELECT * FROM b_money_vn WHERE ".$cond." ORDER BY id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		//Tong thu, chi
		$sql = "SELECT sum(money) as total_thu_chi, status FROM b_money_vn WHERE ".$cond." GROUP BY status ";
		$command=$connect->createCommand($sql);
		$thu_chi= $command->queryAll();
		$thu = 0;
		$chi = 0;
		if($thu_chi)
		foreach($thu_chi as $row)
		{
			if($row['status']==1) $thu =  $row['total_thu_chi'];
			if($row['status']==0) $chi =  $row['total_thu_chi'];
		}
		$a = array($rows,$paging,$total, $thu, $chi);
		return $a;
	}
	
	public function getMoneyVnDay($keyword,$keyword_in, $from_date, $to_date, $tab, $type,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 AND (is_month=0 || is_month=2)';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND id = "'.$keyword.'"';
		}
		
		if($from_date!=0) $cond.=' AND create_date >= '.$from_date;
		if($to_date!=0) $cond.=' AND create_date <= '.$to_date;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		if($tab==1)//Hom nay
		{
			$cond.=' AND create_date>='.$today.' AND create_date<'.($today+86400);		
		}
		if($tab==2)//Hom qua
		{
			$cond.=' AND create_date>='.($today-86400).' AND create_date<'.$today;
		}
		if($tab==3)//Thang nay
		{
			$from = mktime(0,0,0,date('m'),1,date('Y'));
			$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
			$cond.=' AND create_date>='.$from.' AND create_date<='.$to;
		}
		if($tab==4)//Thang truoc
		{
			$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
			$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
			$cond.=' AND create_date>='.$from.' AND create_date<='.$to;
		}
		
		if($type==1)//Thu
		{
			$cond.=' AND status=1';
		}
		
		if($type==2)//Chi
		{
			$cond.=' AND status=0';
		}
		
		if($type==3)//Tien mat
		{
			$cond.=' AND tien_mat!=0';
		}
		if($type==4)//Chuyen khoan
		{
			$cond.=' AND chuyen_khoan!=0';
		}
		if($type==5)//Quet the
		{
			$cond.=' AND quet_the!=0';
		}
		if($type==6)//Lazada
		{
			$cond.=' AND is_lazada=1';
		}
		
		$sql = "SELECT count(*) as total FROM b_money_vn WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
        $exam_total=array();
		$sql = "SELECT * FROM b_money_vn WHERE ".$cond." ORDER BY id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		//Tong thu, chi
		$sql = "SELECT sum(money) as total_thu_chi, status FROM b_money_vn WHERE ".$cond." GROUP BY status ";
		$command=$connect->createCommand($sql);
		$thu_chi= $command->queryAll();
		$thu = 0;
		$chi = 0;
		if($thu_chi)
		foreach($thu_chi as $row)
		{
			if($row['status']==1) $thu =  $row['total_thu_chi'];
			if($row['status']==0) $chi =  $row['total_thu_chi'];
		}
		//Tien mat, chuyen khoan, quet the
		$tien_mat = 0;
		$chuyen_khoan = 0;
		$quet_the = 0;
		$total_is_lazada = 0;
		$sql = "SELECT sum(tien_mat) as total_tien_mat,sum(chuyen_khoan) as total_chuyen_khoan, sum(quet_the) as total_quet_the FROM b_money_vn WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		if($row)
		{
			$tien_mat = $row['total_tien_mat'];
			$chuyen_khoan = $row['total_chuyen_khoan'];
			$quet_the = $row['total_quet_the'];
		}
		$sql = "SELECT COUNT(DISTINCT(id)) as total_is_lazada FROM b_money_vn WHERE ".$cond." AND is_lazada=1";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		if($row) $total_is_lazada = $row['total_is_lazada'];
		$a = array($rows,$paging,$total, $thu, $chi, $tien_mat, $chuyen_khoan, $quet_the, $total_is_lazada);
		return $a;
	}
	
	public function getTotalMoneyVn($cond_add)
	{
		$connect=Yii::app()->db;
		
		$today = mktime(0,0,0,date('m'),date('d'),date('Y'));
		//Hom nay
		$sql = 'SELECT count(id) as total FROM b_money_vn WHERE '.$cond_add.' AND create_date>='.$today.' AND create_date<'.($today+86400);
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_1 = isset($row['total']) ? intval($row['total']):0;
		
		//Hom qua
		$sql = 'SELECT count(id) as total FROM b_money_vn WHERE '.$cond_add.' AND create_date>='.($today-86400).' AND create_date<'.$today;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_2 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang nay
		$from = mktime(0,0,0,date('m'),1,date('Y'));
		$to = mktime(23,59,59,date('m'),date('d'),date('Y'));
		$sql = 'SELECT count(id) as total FROM b_money_vn WHERE '.$cond_add.' AND create_date>='.$from.' AND create_date<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_3 = isset($row['total']) ? intval($row['total']):0;
		
		//Thang truoc
		$from = mktime(0,0,0,(date('m')-1),1,date('Y'));
		$to = mktime(23,59,59,(date('m')-1),31,date('Y'));
		$sql = 'SELECT count(id) as total FROM b_money_vn WHERE '.$cond_add.' AND create_date>='.$from.' AND create_date<'.$to;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_4 = isset($row['total']) ? intval($row['total']):0;
		//Total
		$sql = 'SELECT count(id) as total FROM b_money_vn WHERE '.$cond_add.'';
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_0 = isset($row['total']) ? intval($row['total']):0;
		
		return array($total_0, $total_1, $total_2, $total_3, $total_4);
	}
	
	public function getMoneyVnById($money_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_money_vn WHERE id=".$money_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
}
?>