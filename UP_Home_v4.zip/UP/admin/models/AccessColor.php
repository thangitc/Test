<?php
class AccessColor extends CActiveRecord
{
	public function getColorByAccess($access_id,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT count(*) as total FROM b_accessories_color WHERE access_id=".$access_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Phan trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT * FROM b_accessories_color WHERE access_id=".$access_id." ORDER BY id DESC LIMIT ".$begin.",".$num_per_page." ";

		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		
		$a = array($rows,$paging,$total);
		
		return $a;
	}
	public function deleteColor($color_id)
	{
		$connect=Yii::app()->db;
		$sql = "DELETE FROM b_accessories_color WHERE color_id=".$color_id;
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function getColorById($color_id)
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_accessories_color WHERE id=".$color_id."";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
	
	public function getAccessIdById($color_id)
	{
		$connect =Yii::app()->db;
		$sql = "SELECT access_id FROM b_accessories_color WHERE id=".$color_id."";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row['access_id'];
	}
	public function insertPic($sub_sql)
	{
		$connect=Yii::app()->db;
		$sql = "INSERT IGNORE INTO b_accessories_color_pic(color_id, picture, create_date) VALUES ".$sub_sql."";
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	public function deletePic($color_id)
	{
		$connect=Yii::app()->db;
		$sql = "DELETE FROM b_accessories_color_pic WHERE color_id=".$color_id;
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function getPicByColorId($color_id)
	{
		$connect =Yii::app()->db;
		$sql = "SELECT color_id, picture FROM b_accessories_color_pic WHERE color_id=".$color_id." ORDER BY id ASC";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function getAllColorByAccess($access_id)
	{
		$connect=Yii::app()->db;		
		$sql = "SELECT * FROM b_accessories_color WHERE access_id=".$access_id."";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		return $rows;
	}
}
?>