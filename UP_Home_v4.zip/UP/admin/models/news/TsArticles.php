<?php
class TsArticles extends CActiveRecord
{
  	public function getArticles($numberRecordPerPage = '', $currentPage = 1, $search)
	{
  		$limit = '';
		if (isset($numberRecordPerPage) && $numberRecordPerPage != '') {
			$startRecord = ($currentPage - 1) * $numberRecordPerPage;
			$limit = " LIMIT " . $startRecord . ", " . $numberRecordPerPage;
		}
		
  		$condition = '';
  		$condition .= !empty($search["toDate"]) ? " AND create_date >= " . strtotime($search["toDate"]) . " " : "";
        $condition .= !empty($search["fromDate"]) ? " AND create_date <= " .strtotime($search["fromDate"]) ." " : "";
        
        if(!empty($search["keyword_field"]) && trim($search["keyword"]) != '') {
        	if($search["keyword_field"] === "articlesId") {
				$condition .= " AND id=" . intval($search["keyword"]);
			}
        	else if($search["keyword_field"] === "title") {
				$condition .= " AND " . $search["keyword_field"] ." LIKE '%" . mysql_escape_string($search["keyword"]) ."%'";
			}
			else if($search["keyword_field"] === "userId") {
				$condition .= " AND user_id=" . intval($search["keyword"]);
			}			
		}
		if (!empty($search["categoriesId"]))
		{
			$cat_info=TsCategoriesNews::getCateInfor($search["categoriesId"]);
			if(isset($cat_info['parent_id']) && $cat_info['parent_id']==0)
			{
		   		$condition .= " AND cat_id1= '" . mysql_escape_string($search["categoriesId"])."'";
			}
			else
			{
				$condition .= " AND cat_id= '" . mysql_escape_string($search["categoriesId"])."'";
			}
		}
		if (!empty($search["status"])) {
        	$condition .= " AND status='".$search["status"]."'";
        }
		if (isset($search["is_hot"]) && $search["is_hot"]!='')
		{
        	$condition .= " AND is_hot='".$search["is_hot"]."'";
        }
        $order = "";
        if ($search["orderby"] == 'articlesId') {
        	$order .= " ORDER BY id DESC";
        	if (!empty($search["order"])) {
	        	$order .= " DESC ";	
	        }	
        } 
        else if ($search["orderby"] == 'hit') {
        	/* Luot xem */
        	/*
        	$sql = "SELECT article_id FROM tbl_hit_article ORDER BY hit";
        	if (!empty($search["order"])) {
	        	$sql .= " DESC ";
	        }
	        $condition .= " AND id IN (" . $sql . ")";*/
	        
	        $sql = "SELECT article_id FROM tbl_hit_article ORDER BY hit";
	        if (!empty($search["order"])) {
	        	$sql .= " DESC " . $limit;
	        } else {
	        	$sql .= $limit;
	        }
			$command = Yii::app()->db_news->createCommand($sql);
    		$rowHitArticles = $command->queryAll();
    		$list_articles_id = 0;
	        foreach ($rowHitArticles as $row) {
	        	$list_articles_id .= !empty($row["article_id"]) ? ",".$row["article_id"] : "";	
	        }
			$list_articles_id = Common::remove_duplicate($list_articles_id);
			$list_articles_id = ltrim($list_articles_id, "0,");
	        
			$condition .= " AND id IN (" . $list_articles_id . ") ORDER BY CASE id ";
	        $countHit = count($rowHitArticles);
	        for ($i=0; $i < $countHit; $i++) {
	        	if(!empty($rowHitArticles[$i]['article_id'])) {
	        		$condition .= " WHEN " . $rowHitArticles[$i]['article_id'] . " THEN " . $i;
	        	}
	        	if($i == $countHit-1) {
	        		$condition .= " END ";
	        	}
	        }
	        $limit = "";
	        
        }
        else {
        	$order .= " ORDER BY publish_date DESC, id DESC ";	
        }
        if ($search["seo"] != '') {
        	if ($search["seo"] == 0) {
				$condition .= " AND (meta_title ='' OR meta_title IS NULL)";        				
        	}
        	else {
        		$condition .= " AND meta_title != '' ";
        	}			
		}
		if($search['is_hot']==1) $order = 'ORDER BY ordering DESC, publish_date DESC';
		$sql = "SELECT * FROM tbl_articles WHERE 1 " . $condition . $order . $limit;
	    $command = Yii::app()->db_news->createCommand($sql);
	    $rows = $command->queryAll();
	    $eventArticle=array();
        if (!empty($rows)) {
	        $list_articles_id = 0;
	        $list_cat_articles_id = 0;
	        foreach($rows as $row){
	            $list_articles_id .= !empty($row["id"]) ? ",".$row["id"] : "";
	            $list_cat_articles_id .= !empty($row["cat_id"]) ? ",".$row["cat_id"] : "";
	        }
            $list_articles_id = Common::remove_duplicate($list_articles_id);
            $list_cat_articles_id = Common::remove_duplicate($list_cat_articles_id);
	        
	        /* Lay chuyen muc */
	        $sql = "SELECT id, title,price,is_charging FROM tbl_categories WHERE id IN (" . $list_cat_articles_id . ")";
			$command = Yii::app()->db_news->createCommand($sql);
	        $rowCategories = $command->queryAll();
	        $replaceCategories = array();
	        foreach($rowCategories as $row){
	            //$replaceCategories[$row["id"]] = $row["title"];
				$replaceCategories[$row["id"]] = $row;
	        }
	        
	        /* Lay danh sach id cua su kien */
	        $sql = "SELECT * FROM tbl_event_articles WHERE article_id IN (" . $list_articles_id . ")";
			$command = Yii::app()->db_news->createCommand($sql);
	        $rowEventArticles = $command->queryAll();
	        $list_event_id = 0;                     
	        foreach($rowEventArticles as $row){
	        	$list_event_id .= !empty($row["event_id"]) ? ",".$row["event_id"] : "";
	        }
            $list_event_id = Common::remove_duplicate($list_event_id);
			/* Lay ten su kien */
	        $rowEvent = TsEvent::getEventByListId($list_event_id);
			if($rowEventArticles)
			foreach($rowEventArticles as $row){
	        	$eventArticle[$row['article_id']][]=isset($rowEvent[$row['event_id']]) ? $rowEvent[$row['event_id']]:array();
	        }
	        /* Lay so luot view */
	        $sql = "SELECT id, article_id, hit FROM tbl_hit_article WHERE article_id IN (" . $list_articles_id . ")";
	        $command = Yii::app()->db_news->createCommand($sql);
	        $rowHitArticle = $command->queryAll();                     
	        $replaceHitArticle = array();
	        foreach($rowHitArticle as $row){
	            $replaceHitArticle[$row["article_id"]] = $row["hit"];
	        }
	        
	        /* Lay so luot comment */
	        $sql = "SELECT count(id) as total, article_id,status FROM tbl_comments WHERE article_id IN (".$list_articles_id.") GROUP BY article_id,status";
	        $command = Yii::app()->db_news->createCommand($sql);
	        $rowComment = $command->queryAll();                     
	        $replaceComment = array();
	        foreach($rowComment as $row)
			{
	            $replaceComment[$row["article_id"]][] = $row;
	        }
	        
	         /* Lay danh sach id cua khoa hoc va tuyen sinh lien quan */
	        $sql = "SELECT * FROM tbl_articles_categories WHERE article_id IN (" . $list_articles_id . ")";
			$command = Yii::app()->db_news->createCommand($sql);
	        $rowCatArticles = $command->queryAll();
	        $list_cat_id = 0;                     
	        foreach($rowCatArticles as $row){
	        	$list_cat_id .= !empty($row["cat_id"]) ? ",".$row["cat_id"] : "";
	        }
            $list_cat_id = Common::remove_duplicate($list_cat_id);
			/* Lay ten khoa hoc va tuyen sinh lien quan */
			$sql = "SELECT id, title FROM tbl_categories WHERE id IN (" . $list_cat_id . ")";
			$command = Yii::app()->db_news->createCommand($sql);
	        $rowCat = $command->queryAll();                     
	        $replaceCat = array();
	        foreach($rowCat as $row){
	            $replaceCat[$row["id"]] = $row["title"];
	        }
	        
            $i = 0;
	        $replaceCatArticles = array();
	        while(isset($rowCatArticles[$i])){
	        	$rowCatArticles[$i]['catName'] = isset($replaceCat[$rowCatArticles[$i]['cat_id']]) ? $replaceCat[$rowCatArticles[$i]['cat_id']]:'' ;
	        	$replaceCatArticles[$rowCatArticles[$i]["article_id"]][] = $rowCatArticles[$i];
	        	$i++; 		
	        }
	        
	        $i = 0;
	        while(isset($rows[$i]))
			{
	            $rows[$i]["countComment"] = isset($replaceComment[$rows[$i]["id"]]) ? $replaceComment[$rows[$i]["id"]] : 0;
	            $rows[$i]["categoriesName"] = isset($replaceCategories[$rows[$i]["cat_id"]]['title']) ? $replaceCategories[$rows[$i]["cat_id"]]['title'] : "";
				$rows[$i]["cat_price"] = isset($replaceCategories[$rows[$i]["cat_id"]]['price']) ? $replaceCategories[$rows[$i]["cat_id"]]['price'] : 0;
				$rows[$i]["cat_is_charging"] = isset($replaceCategories[$rows[$i]["cat_id"]]['is_charging']) ? $replaceCategories[$rows[$i]["cat_id"]]['is_charging'] : 0;
	            $rows[$i]["hit"] = isset($replaceHitArticle[$rows[$i]["id"]]) ? $replaceHitArticle[$rows[$i]["id"]] : 0;
	            $i++;
	        }
        }
        return array($rows,$eventArticle);
    }
    
    public function getTotalArticles($search){
    	$condition = '';
  		$condition .= !empty($search["toDate"]) ? " AND create_date >= " . strtotime($search["toDate"]) . " " : "";
        $condition .= !empty($search["fromDate"]) ? " AND create_date <= " .strtotime($search["fromDate"]) ." " : "";
        
        if(!empty($search["keyword_field"]) && trim($search["keyword"]) != '') {
        	if($search["keyword_field"] === "articlesId") {
				$condition .= " AND id=" . intval($search["keyword"]);
			}
        	else if($search["keyword_field"] === "title") {
				$condition .= " AND " . $search["keyword_field"] ." LIKE '%" . mysql_escape_string($search["keyword"]) ."%'";
			}
			else if($search["keyword_field"] === "userId") {
				$condition .= " AND user_id=" . intval($search["keyword"]);
			}			
		}
		if (!empty($search["categoriesId"])) {			
		   	$condition .= " AND cat_id=" . mysql_escape_string($search["categoriesId"]);								
		}
		if (!empty($search["status"])) {
        	$condition .= " AND status='".$search["status"]."'";
        }
		if (isset($search["is_hot"]) && $search["is_hot"]!='')
		{
        	$condition .= " AND is_hot='".$search["is_hot"]."'";
        }
        if (isset($search["seo"]) && $search["seo"] != '') {
        	if ($search["seo"] == 0) {
				$condition .= " AND (meta_title ='' OR meta_title IS NULL)";        				
        	}
        	else {
        		$condition .= " AND meta_title <> '' ";
        	}			
		}
		
		$sql = "SELECT count(id) FROM tbl_articles WHERE 1 " . $condition;
	    $command = Yii::app()->db_news->createCommand($sql);
	    $rows = $command->queryRow();
	                   		        
        return $rows['count(id)'];
    }
    
    public function getArticlesById($articlesId)
	{
		$cacheService = new CacheServiceNews("TsArticles","getArticlesById",$articlesId);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			$connect = Yii::app()->db_news;
			$sql = "SELECT id, alias, cat_id, title, introtext, content, tags, meta_keyword, picture, file_name, create_date, publish_date, is_hot,original_link,status,is_charging,price FROM tbl_articles WHERE id=".$articlesId;
			$command=$connect->createCommand($sql);
			$row = $command->queryRow();
			Yii::app()->cache->set($key,$row,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row=$cache;
		}
		return $row;
    }
    
    public function getSeoArticlesById($articlesId)
    {
    	$sql = "SELECT id, title, alias, meta_keyword, meta_title, meta_description, meta_noindex, meta_nofollow FROM tbl_articles WHERE id=" . $articlesId;
	    $command = Yii::app()->db_news->createCommand($sql);
	    $rows = $command->queryRow();
	    
	    return $rows;
    }
    
    public function UpdateSeo($option){
    	$sql = "UPDATE tbl_articles SET
	    				title=:title
	    				, alias=:alias
			            , meta_keyword=:meta_keyword
			            , meta_title=:meta_title
			            , meta_description=:meta_description
			            , meta_noindex=:meta_noindex
			            , meta_nofollow=:meta_nofollow
			       	WHERE id=:id            
	        ";
	        
        $command = Yii::app()->db_news->createCommand($sql);
    	$command->bindValues($option);
    	$result = $command->execute();
		
		if($result >= 0) {
			$table = array('tbl_articles_short', 'tbl_articles_short_latest');
	    	foreach ($table as $row) {
		    	$sql = "UPDATE " . $row . " SET
		    				title=:title
		    				, alias=:alias
				            , meta_keyword=:meta_keyword
				            , meta_title=:meta_title
				            , meta_description=:meta_description
				            , meta_noindex=:meta_noindex
				            , meta_nofollow=:meta_nofollow
				       	WHERE id=:id            
		        ";
		        
		        $command = Yii::app()->db_news->createCommand($sql);
	        	$command->bindValues($option);
	        	$command->execute();
	    	}
		}   
        return $result;
    }
    
    public function SaveArticles($option) {
    	$sql = "UPDATE tbl_articles SET 
			            is_hot=:is_hot
			            , status=:status
			            , edit_date=:edit_date
			            , edit_name=:edit_name
			       	WHERE id=:id            
	        ";
	        
        $command = Yii::app()->db_news->createCommand($sql);
    	$command->bindValues($option);
    	$result = $command->execute();
		
		if($result >= 0) {
			$table = array('tbl_articles_short', 'tbl_articles_short_latest');
	    	foreach ($table as $row) {
		    	$sql = "UPDATE " . $row . " SET 
				            is_hot=:is_hot
				            , status=:status
				            , edit_date=:edit_date
				            , edit_name=:edit_name
				       	WHERE id=:id            
		        ";
		        
		        $command = Yii::app()->db_news->createCommand($sql);
	        	$command->bindValues($option);
	        	$command->execute();
	    	}
		}   
		
        return $result;
    }
    
    public function DeleteArticles($id) {
    	$sql = "DELETE FROM tbl_articles WHERE id=" . $id;
		$command = Yii::app()->db_news->createCommand($sql);
    	$result = $command->execute();
		
		if($result > 0) {
			$table = array('tbl_articles_short', 'tbl_articles_short_latest');	        	
	    	foreach ($table as $row) {
	    		$sql = "DELETE FROM " . $row. " WHERE id=" . $id;
	    		$command = Yii::app()->db_news->createCommand($sql);
	        	$command->execute();
	    	}
		
        	$sql = "DELETE FROM tbl_hit_article WHERE article_id=" . $id;
			$command = Yii::app()->db_news->createCommand($sql);
	    	$command->execute();
    		
    		$sql = "DELETE FROM tbl_comments_reply WHERE comment_id IN (SELECT id FROM tbl_comments WHERE article_id=" . $id . ")";
    		$command = Yii::app()->db_news->createCommand($sql);
	    	$command->execute();
    		
        	$sql = "DELETE FROM tbl_comments WHERE article_id=" . $id . "";
			$command = Yii::app()->db_news->createCommand($sql);
	    	$command->execute();
	    	
	    	$sql = "DELETE FROM tbl_articles_categories WHERE article_id=".$id;
        	$command = Yii::app()->db_news->createCommand($sql);
	    	$command->execute();
	    	
	    	$sql = "DELETE FROM tbl_event_articles WHERE article_id=" . $id;
			$command = Yii::app()->db_news->createCommand($sql);
	        $command->execute();
            
            $sql = "DELETE FROM tbl_articles_related WHERE article_id=" . $id;
            $command = Yii::app()->db_news->createCommand($sql);
            $command->execute();
	        
        }
        return $result;    		
    }
    
    public function InsertArticles($option) {
    	$sql = "INSERT INTO tbl_articles SET 
	            cat_id=:cat_id
	            , cat_id1=:cat_id1
	            , cat_id2=:cat_id2        
	            , title=:title                  
	            , alias=:alias        
	            , introtext=:introtext                    
	            , content=:content
	            , tags=:tags
	            , picture=:picture
	            , file_name=:file_name                            
	            , admin_id=:admin_id
	            , admin_name=:admin_name        
	            , create_date=:create_date
				, edit_date=:edit_date
	            , publish_date=:publish_date
	            , status=:status        
	            , is_hot=:is_hot
				, original_link=:original_link
				, is_charging=:is_charging
				, price=:price
	        ";
        $command = Yii::app()->db_news->createCommand($sql);
        $command->bindValues($option);
        $result = $command->execute();
        $lastId = Yii::app()->db_news->getLastInsertID();
	        
		if($result > 0) {
			$table = array('tbl_articles_short', 'tbl_articles_short_latest');
	    	foreach ($table as $row) {
		    	$sql = "REPLACE INTO " . $row . "( 
		    					id, cat_id, cat_id1, cat_id2, title, alias, introtext, tags, picture, file_name, admin_id, admin_name, create_date, publish_date, status, is_hot)
		    			SELECT 
		    					id, cat_id, cat_id1, cat_id2, title, alias, introtext, tags, picture, file_name, admin_id, admin_name, create_date, publish_date, status, is_hot
		    			FROM tbl_articles WHERE id=:id
		        ";
		        $command = Yii::app()->db_news->createCommand($sql);
		        $command->bindValue(":id", $lastId, PDO::PARAM_STR);
		        $command->execute();
	    	}
		}
        
        return $lastId;
    }
    
	public function insertNews($array_input)
	{
		$article_id = CommonModel::insertObjectNews($array_input,'tbl_articles');
		if($article_id)
		{
			$connect = Yii::app()->db_news;
			$sql = "REPLACE INTO tbl_articles_short( 
							id, cat_id, cat_id1, cat_id2, title, alias, introtext, tags, picture, file_name, admin_id, admin_name, create_date, publish_date, status, is_hot)
					SELECT 
							id, cat_id, cat_id1, cat_id2, title, alias, introtext, tags, picture, file_name, admin_id, admin_name, create_date, publish_date, status, is_hot
					FROM tbl_articles WHERE id=".$article_id."";
			
			$command = $connect->createCommand($sql);
			$command->execute();
			$sql = "REPLACE INTO tbl_articles_short_latest( 
							id, cat_id, cat_id1, cat_id2, title, alias, introtext, tags, picture, file_name, admin_id, admin_name, create_date, publish_date, status, is_hot)
					SELECT 
							id, cat_id, cat_id1, cat_id2, title, alias, introtext, tags, picture, file_name, admin_id, admin_name, create_date, publish_date, status, is_hot
					FROM tbl_articles WHERE id=".$article_id."";
			$command = $connect->createCommand($sql);
			$command->execute();					
		}
		return $article_id;
	}
    public function InsertArticlesHit($option) {
    	$sql = "INSERT INTO tbl_hit_article SET 
            article_id=:article_id        
            , hit=:hit                  
            , update_date=:update_date                                                    
        ";
        
        $command = Yii::app()->db_news->createCommand($sql);
        $command->bindValues($option);
        $result = $command->execute();
        $lastId = Yii::app()->db_news->getLastInsertID();
        return $lastId;
    }
    
    public function InsertEventArticles($option) {
    	$sql = "INSERT IGNORE INTO tbl_event_articles SET 
            article_id=:article_id        
            , event_id=:event_id                  
            , ordering=:ordering                  
            , create_date=:create_date                                                    
        ";
        
        $command = Yii::app()->db_news->createCommand($sql);
        $command->bindValues($option);
        $result = $command->execute();
        $lastId = Yii::app()->db_news->getLastInsertID();
        return $lastId;
    }
    
    public function InsertArticlesCategories($option) {
    	$sql = "INSERT INTO tbl_articles_categories SET 
            article_id=:article_id        
            , cat_id=:cat_id                  
            , type=:type                                                    
        ";
        
        $command = Yii::app()->db_news->createCommand($sql);
        $command->bindValues($option);
        $result = $command->execute();
        $lastId = Yii::app()->db_news->getLastInsertID();
        return $lastId;
    }
    
    public function UpdateArticles($option) {
        /*không update alias(hanv)*/
        unset($option['alias']);
    	$sql = "UPDATE tbl_articles SET 
			            cat_id=:cat_id
			            , cat_id1=:cat_id1
			            , cat_id2=:cat_id2        
			            , title=:title                          
			            , introtext=:introtext                    
			            , content=:content
			            , tags=:tags
			            , picture=:picture
			            , file_name=:file_name                            
			            , edit_date=:edit_date
			            , publish_date=:publish_date
			            , status=:status
			            , is_hot=:is_hot
			            , edit_name=:edit_name
						, original_link=:original_link
						, is_charging=:is_charging
						, price=:price
					WHERE id=:id            		                                
	        ";
        $command = Yii::app()->db_news->createCommand($sql);
        $command->bindValues($option);
        $result = $command->execute();
		if($result >= 0) {
			$table = array('tbl_articles_short', 'tbl_articles_short_latest');
	    	foreach ($table as $row) {
		    	$sql = "REPLACE INTO " . $row . "( 
		    					id, cat_id, cat_id1, cat_id2, title, alias, introtext, tags, picture, file_name, create_date, publish_date, status, is_hot, edit_name)
		    			SELECT 
		    					id, cat_id, cat_id1, cat_id2, title, alias, introtext, tags, picture, file_name, create_date, publish_date, status, is_hot, edit_name
		    			FROM tbl_articles WHERE id=:id
		        ";
		        $command = Yii::app()->db_news->createCommand($sql);
		        $command->bindValue(":id", $option['id'], PDO::PARAM_STR);
		        $command->execute();
	    	}
		}	 
		
        return $result;
    }
    
    public function DeleteEventByArticlesId($id) {
    	$sql = "DELETE FROM tbl_event_articles WHERE article_id=" . $id;
    	
		$command = Yii::app()->db_news->createCommand($sql);
        $result = $command->execute();
        return $result;
    }
    
    public function DeleteEventArticles($option) {
		$sql = "DELETE FROM tbl_event_articles WHERE article_id=:article_id AND event_id=:event_id";
    	
		$command = Yii::app()->db_news->createCommand($sql);
		$command->bindValues($option);
        $result = $command->execute();
        return $result;
    }
    
    public function DeleteAllEventArticles($option) {
    	$sql = "DELETE FROM tbl_event_articles WHERE article_id IN (" . $option['list_articles_id'] . ") AND event_id=" . $option['event_id'];
    	
		$command = Yii::app()->db_news->createCommand($sql);
        $result = $command->execute();
        return $result;
    }
    
    public function DeleteCatByArticlesId($id, $type = "") {
    	$condition = !empty($type) ? " AND type=" . $type : "";
    	$sql = "DELETE FROM tbl_articles_categories WHERE article_id=" . $id . $condition;
		$command = Yii::app()->db_news->createCommand($sql);
        $result = $command->execute();
        return $result;
    }
    
    public function getArticlesByAlias($title){
    	$alias = Common::generate_slug($title);
    	$sql = "SELECT * FROM tbl_articles WHERE title='".$title . "' OR alias='".$alias . "'";
    	$command = Yii::app()->db_news->createCommand($sql);
        $row = $command->queryRow();
        return $row;	
    }
	public function quickUpdate($quick_type,$list_id)
	{
		$connect = Yii::app()->db_news;
		if($quick_type==1)//Kich hoat tin
		{
    		$sql1 = "UPDATE tbl_articles SET status='active' WHERE id IN (".$list_id.")";
			$sql2 = "UPDATE tbl_articles_short SET status='active' WHERE id IN (".$list_id.")";
			$sql3 = "UPDATE tbl_articles_short SET status='active' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==2)//Bo kich hoat
		{
			$sql1 = "UPDATE tbl_articles SET status='pending' WHERE id IN (".$list_id.")";
			$sql2 = "UPDATE tbl_articles_short SET status='pending' WHERE id IN (".$list_id.")";
			$sql3 = "UPDATE tbl_articles_short SET status='pending' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==3)//Xoa tin bai
		{
			$sql1 = "DELETE FROM tbl_articles WHERE id IN (".$list_id.")";
			$sql2 = "DELETE FROM tbl_articles_short WHERE id IN (".$list_id.")";
			$sql3 = "DELETE FROM tbl_articles_short_latest WHERE id IN (".$list_id.")";
		}
		else if ($quick_type==5)
		{
			$sql1 = "UPDATE tbl_articles SET is_hot=1 WHERE id IN (".$list_id.")";
			$sql2 = "UPDATE tbl_articles_short SET is_hot=1 WHERE id IN (".$list_id.")";
			$sql3 = "UPDATE tbl_articles_short SET is_hot=1 WHERE id IN (".$list_id.")";
		}
		
		$command = $connect->createCommand($sql1);
        $result1 = $command->execute();
		$command = $connect->createCommand($sql2);
        $result2 = $command->execute();
		$command = $connect->createCommand($sql3);
        $result3 = $command->execute();
		if($result1>=0 && $result2>=0 && $result3>=0)
			$result=true;
		else
			$result=false;
        return $result;	
    }
	public function moveCat($list_id,$cat_id,$cat_id1,$cat_id2)
	{
		$connect = Yii::app()->db_news;
		$sql1 = "UPDATE tbl_articles SET cat_id=".$cat_id.",cat_id1=".$cat_id1.",cat_id2=".$cat_id2." WHERE id IN (".$list_id.")";
		$sql2 = "UPDATE tbl_articles_short SET cat_id=".$cat_id.",cat_id1=".$cat_id1.",cat_id2=".$cat_id2." WHERE id IN (".$list_id.")";
		$sql3 = "UPDATE tbl_articles_short_latest SET cat_id=".$cat_id.",cat_id1=".$cat_id1.",cat_id2=".$cat_id2." WHERE id IN (".$list_id.")";
		$command = $connect->createCommand($sql1);
        $result1 = $command->execute();
		$command = $connect->createCommand($sql2);
        $result2 = $command->execute();
		$command = $connect->createCommand($sql3);
        $result3 = $command->execute();
		if($result1>=0 && $result2>=0 && $result3>=0)
			$result=true;
		else
			$result=false;
        return $result;	
	}
	public function getTotalArticlesByListUserId($list_user_id)
	{
		$cacheService = new CacheServiceNews("TsArticles","getTotalArticlesByListUserId",$list_user_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$sql = "SELECT count(id) as total, user_id FROM tbl_articles_short WHERE user_id IN (".$list_user_id.") AND user_id<>0";
			$command = Yii::app()->db_news->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key,$rows,ConstantsUtil::TIME_CACHE_900);
		}
		else
		{
			$rows=$cache;
		}
		return $rows;
	}
	public function getArticlesPopup($keyword,$cat_id,$page,$num_per_page)
	{
		$cacheService = new CacheServiceNews("TsArticles","getArticlesPopup",$keyword.$cat_id.$page);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db_news;
			$cond='1 ';
			if($keyword!='')
			{
				$cond.= ' AND title like "%'.$keyword.'%"';
			}
			
			if($cat_id!=0)
			{
				$cat_info=TsCategoriesNews::getCateInfor($cat_id);
				if(isset($cat_info['parent_id']) && $cat_info['parent_id']==0)
				{
					$cond .= " AND cat_id1= '".$cat_id."'";
				}
				else
				{
					$cond .= " AND cat_id= '".$cat_id."'";
				}
			}
			$sql = "SELECT count(*) as total FROM tbl_articles_short WHERE ".$cond."";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			$total=$row['total'];
			$sql = "SELECT * FROM tbl_articles_short WHERE ".$cond."  ORDER BY publish_date DESC LIMIT ".($page-1)*$num_per_page.",".$num_per_page."";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			$a=array($rows,$total);
			Yii::app()->cache->set($key,$a,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	public function insertArticleRelated($sub_sql)
	{
		$connect=Yii::app()->db_news;
		$sql="INSERT IGNORE INTO tbl_articles_related(`article_id`, `related_id`,`related_title`, `related_link`, `create_date`) VALUES ".$sub_sql."";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	public function getArticlesRelated($articles_id)
	{
		$connect=Yii::app()->db_news;
		$sql="SELECT * FROM tbl_articles_related WHERE article_id=".$articles_id."";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	public function getArticlesByListId($list_id)
	{
		$connect=Yii::app()->db_news;
		$sql="SELECT * FROM tbl_articles_short WHERE id IN (".$list_id.")";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	public function deleteArticleRelated($article_id)
	{
		$connect=Yii::app()->db_news;
		$sql="DELETE FROM tbl_articles_related WHERE article_id ='".$article_id."'";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	public function updateOrderArticles($id,$order)
	{
		$connect=Yii::app()->db_news;
		$sql="UPDATE tbl_articles SET ordering=".$order." WHERE id=".$id;
		$command = $connect->createCommand($sql);
		$ok = $command->execute();
		$sql="UPDATE tbl_articles_short SET ordering=".$order." WHERE id=".$id;
		$command = $connect->createCommand($sql);
		$ok = $command->execute();
		$sql="UPDATE tbl_articles_short_latest SET ordering=".$order." WHERE id=".$id;
		$command = $connect->createCommand($sql);
		$ok = $command->execute();
		return $ok;
	}
}  
?>