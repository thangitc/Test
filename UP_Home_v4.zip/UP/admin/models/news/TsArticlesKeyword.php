<?php
class TsArticlesKeyword extends CActiveRecord
{    
    public function tableName()
    {
        return 'tbl_keyword_footer';
    }
	
	public function getKeywordFooter($is_fix,$page,$num_per_page,$url_rewrite)
	{
		$connect =Yii::app()->db_news;
		$url = Yii::app ()->urlManager;
		//Cache
		$cacheService = new CacheServiceNews("TsArticlesKeyword","getKeywordFooter",$page.$num_per_page);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache = false;
        if ($cache == false) 
		{
			//End kiem tra dieu kien	
			
			$sql="SELECT count(id) as total FROM tbl_keyword_footer t1 WHERE is_fix=".$is_fix."";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			$total=$row['total'];
			//Phân trang
			$num_per_page = $num_per_page;
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$sql = "SELECT * FROM tbl_keyword_footer t1 WHERE t1.is_fix=".$is_fix." ORDER BY ordering ASC LIMIT ".$begin.",".$num_per_page."";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			$iSEGSIZE = 9;
			$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			$a=array($rows,$total,$paging);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_300);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	public function getKeywordDetail($id)
	{
		$connect =Yii::app()->db_news;
		$sql="SELECT * FROM  tbl_keyword_footer WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$row=$command->queryRow();
		return $row;
	}
	public function insertKeyword($keyword,$url,$is_fix,$is_blank,$created_date,$status)
	{
		$connect =Yii::app()->db_news;
		$sql="INSERT INTO tbl_keyword_footer SET keyword='".$keyword."',url='".$url."',is_fix='".$is_fix."',is_blank='".$is_blank."',created_date='".$created_date."',status='".$status."'";
		$command=$connect->createCommand($sql);
		$command->execute();
		$record_id=Yii::app()->db_news->getLastInsertID();  
		return $record_id;
	}
	public function updateKeyword($id,$keyword,$url,$is_fix,$is_blank)
	{
		$connect =Yii::app()->db_news;
		$sql="UPDATE tbl_keyword_footer SET keyword='".$keyword."',url='".$url."',is_fix='".$is_fix."',is_blank='".$is_blank."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a=$command->execute();
		return $a;
	}
	public function deleteKeyword($id)
	{
		$connect =Yii::app()->db_news;
		$sql="DELETE FROM tbl_keyword_footer WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a=$command->execute();
		return $a;
	}
	public function deleteMultiKeyword($list_id)
	{
		if($list_id!='')
		{
			$connect =Yii::app()->db_news;
			$sql="DELETE FROM tbl_keyword_footer WHERE id IN (".$list_id.")";
			$command=$connect->createCommand($sql);
			$a=$command->execute();
			return $a;
		}
		else return -1;
	}
	public function updateOrderKeyword($id,$ordering)
	{
		$connect =Yii::app()->db_news;
		$sql="UPDATE tbl_keyword_footer SET ordering='".$ordering."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a=$command->execute();
		return $a;
	}
	public function updateStatusKeyword($id,$status)
	{
		$connect =Yii::app()->db_news;
		$sql="UPDATE tbl_keyword_footer SET status='".$status."' WHERE id=".$id;
		$command=$connect->createCommand($sql);
		$a=$command->execute();
		return $a;
	}
}
?>