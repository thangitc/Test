<?php
class TsCommentEvent extends CActiveRecord
{
	public function getComments($keyword,$keyword_in,$from_date,$to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db_news;
		$cond='1 AND t1.event_id=t2.id ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND t2.title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND t1.id = "'.$keyword.'"';
		}
		
		if($from_date!=0) $cond.=' AND t1.create_date>="'.$from_date.'"';
		if($to_date!=0) $cond.=' AND t1.create_date<="'.$to_date.'"';
		
		$sql = "SELECT count(*) as total FROM tbl_comments_event t1,tbl_event t2 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.*,t2.title,t2.alias FROM tbl_comments_event t1, tbl_event t2 WHERE ".$cond." ORDER BY t1.create_date DESC LIMIT ".$begin.",".$num_per_page." ";
		$command=$connect->createCommand($sql);
		$rows= $command->queryAll();
		$a=array($rows,$paging,$total);
		
		return $a;
	}
	
	public function deleteComment($comment_id)
	{
		$connect=Yii::app()->db_news;
		$sql = "DELETE FROM tbl_comments_event WHERE id=".$comment_id;
		$command=$connect->createCommand($sql);
		$result= $command->execute();
		return $result;
	}
	public function getCommentById($comment_id)
	{
		$connect=Yii::app()->db_news;
		$sql = "SELECT * FROM tbl_comments_event WHERE id=".$comment_id;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}  
?>
