<?php
class News extends CActiveRecord
{
	public function getNews($cat_id,$keyword,$keyword_in,$status, $is_hot,$orderby, $order, $seo, $from_date, $to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND t1.title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND t1.username LIKE "%'.$keyword.'%"';
		}
		if($cat_id!=0) $cond.=' AND t1.cat_id='.$cat_id;
		if($status!='') $cond.=' AND t1.status="'.$status.'"';
		if($is_hot!=0) $cond.=' AND t1.is_hot='.$is_hot.'';
		if($seo!='')
		{
			if($seo==0) $cond.=' AND t1.meta_title=""';
			if($seo==1) $cond.=' AND t1.meta_title != ""';
		}
		
		if($orderby!='')
		{
			$order_DESC_ASC='';
			if($order==1) $order_DESC_ASC = 'DESC';
			else $order_DESC_ASC = 'ASC';
			if($orderby=='id')
			{
				$cond_order = ' ORDER BY t1.id '.$order_DESC_ASC;	
			}
			else if($orderby=='hit')
			{
				$cond_order = ' ORDER BY t1.hit '.$order_DESC_ASC;	
			}
			else
			{
				$cond_order = ' ORDER BY t1.create_date '.$order_DESC_ASC;	
			}
		}
		else
		{
			$cond_order = "ORDER BY t1.create_date DESC";
		}
		$sql = "SELECT count(*) as total FROM b_news t1 WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.*,t2.title as cat_title,t2.alias as cat_alias FROM b_news t1 LEFT JOIN b_cat t2 ON t1.cat_id=t2.id WHERE ".$cond." ".$cond_order." LIMIT ".$begin.",".$num_per_page." ";
		$command = $connect->createCommand($sql);
		$rows= $command->queryAll();
		$list_id = array();
		foreach($rows as $row)
		{
			$list_id[] = $row['id'];
		}
		$hits=array();			
		$topics = array(); //Su kien
		$comments = array();// Binh luan
		if(!empty($list_id))
		{
			$list_id=implode(',',$list_id);
			$topics = Topic::getTopicByListNewsId($list_id);
			$hit=News::getHitListId($list_id);
			if($hit)
			foreach($hit as $row)
			{
				$hits[$row['news_id']]=$row['hit'];
			}
			//Comment
			$sql = "SELECT count(id) as total, news_id, status FROM b_comment WHERE news_id IN (".$list_id.") GROUP BY news_id,status";
			$command = Yii::app()->db->createCommand($sql);
			$array = $command->queryAll();                     
			foreach($array as $row)
			{
				$comments[$row["news_id"]][] = $row;
			}
		}
		
		
	   
		$a = array($rows,$paging,$total,$hits, $topics, $comments);
		return $a;
	}
	
	public function getNewsTopic($topic_id,$keyword,$keyword_in,$status, $is_hot,$orderby, $order, $seo, $from_date, $to_date,$page,$num_per_page,$url_rewrite)
	{
		$connect=Yii::app()->db;
		$cond='1 ';
		if($keyword!='')
		{
			if($keyword_in==1) $cond.=' AND t1.title LIKE "%'.$keyword.'%"';
			if($keyword_in==2) $cond.=' AND t1.username LIKE "%'.$keyword.'%"';
		}
		if($topic_id!=0) $cond.=' AND t2.topic_id='.$topic_id;
		if($status!='') $cond.=' AND t1.status="'.$status.'"';
		if($is_hot!=0) $cond.=' AND t1.is_hot='.$is_hot.'';
		if($seo!='')
		{
			if($seo==0) $cond.=' AND t1.meta_title=""';
			if($seo==1) $cond.=' AND t1.meta_title != ""';
		}
		
		if($orderby!='')
		{
			$order_DESC_ASC='';
			if($order==1) $order_DESC_ASC = 'DESC';
			else $order_DESC_ASC = 'ASC';
			if($orderby=='id')
			{
				$cond_order = ' ORDER BY t1.id '.$order_DESC_ASC;	
			}
			if($orderby=='hit')
			{
				$cond_order = ' ORDER BY t1.hit '.$order_DESC_ASC;	
			}
		}
		else
		{
			$cond_order = "ORDER BY t1.create_date DESC";
		}
		//Danh sach tin bai cua chuyen de
		$sql = "SELECT count(t1.id) as total FROM b_news t1 INNER JOIN b_topic_news t2 ON t1.id=t2.news_id WHERE ".$cond."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total=$row['total'];
		//Ph�n trang
		$num_page = ceil($total / $num_per_page);
		$begin = ($page - 1) * $num_per_page;
		$iSEGSIZE = 9;
		$paging=Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
		
		$sql = "SELECT t1.* FROM b_news t1 INNER JOIN b_topic_news t2 ON t1.id=t2.news_id WHERE ".$cond." ".$cond_order." LIMIT ".$begin.",".$num_per_page." ";
		$command = $connect->createCommand($sql);
		$rows= $command->queryAll();
		$list_id = array();
		$list_id = array();
		foreach($rows as $row)
		{
			$list_id[] = $row['id'];
		}
		
		$hits=array();
		$topics = array();
		$comments = array();// Binh luan
		if(!empty($list_id))
		{
			$list_id=implode(',',$list_id);
			$topics = Topic::getTopicByListNewsId($list_id);
			$hit=News::getHitListId($list_id);
			if($hit)
			foreach($hit as $row)
			{
				$hits[$row['news_id']]=$row['hit'];
			}
			//Comment
			$sql = "SELECT count(id) as total, news_id, status FROM b_comment WHERE news_id IN (".$list_id.") GROUP BY news_id,status";
			$command = Yii::app()->db->createCommand($sql);
			$array = $command->queryAll();                     
			foreach($array as $row)
			{
				$comments[$row["news_id"]][] = $row;
			}
		}
	   
		$a=array($rows,$paging,$total,$hits, $topics, $comments);
		return $a;
	}
	
	public function getNewsById($news_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_news WHERE id=".$news_id;
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	public function insertNewsRelated($sub_sql)
	{
		$connect=Yii::app()->db;
		$sql="INSERT IGNORE INTO b_news_related(`news_id`, `related_id`,`related_title`, `related_link`, `create_date`) VALUES ".$sub_sql."";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	public function getNewsRelated($news_id)
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_news_related WHERE news_id=".$news_id."";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	public function deleteNewsRelated($news_id)
	{
		$connect=Yii::app()->db;
		$sql="DELETE FROM b_news_related WHERE news_id ='".$news_id."'";
		$command=$connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	public function getNewsPopup($keyword,$cat_id,$page,$num_per_page)
	{
		$cacheService = new CacheService("News","getNewsPopup",$keyword.$cat_id.$page);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache==false)
		{
			$connect=Yii::app()->db;
			$cond='1 ';
			if($keyword!='')
			{
				$cond.= ' AND title like "%'.$keyword.'%"';
			}
			if($cat_id!=0) $cond.= ' AND cat_id = "'.$cat_id.'"';
			$sql = "SELECT count(*) as total FROM b_news WHERE ".$cond."";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			$total=$row['total'];
			$sql = "SELECT * FROM b_news WHERE ".$cond."  ORDER BY create_date DESC LIMIT ".($page-1)*$num_per_page.",".$num_per_page."";
			$command=$connect->createCommand($sql);
			$rows= $command->queryAll();
			$a=array($rows,$total);
			Yii::app()->cache->set($key,$a,ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a=$cache;
		}
		return $a;
	}
	public function getNewsByListId($list_news_id)
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_news WHERE id IN (".$list_news_id.")";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	public function getHitListId($list_news_id)
	{
		$connect=Yii::app()->db;
		$sql="SELECT * FROM b_hit_news WHERE news_id IN (".$list_news_id.")";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	public function countTabNews()
	{
		$connect=Yii::app()->db;
		//Tong so ban ghi
		$sql = "SELECT count(id) as total FROM b_news";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total = isset($row['total']) ? intval($row['total']):0;
		//Public
		$sql = "SELECT count(id) as total FROM b_news WHERE status='active'";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		$total_active = isset($row['total']) ? intval($row['total']):0;
		//Pending
		$sql = "SELECT count(id) as total FROM b_news WHERE status='pending'";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total_pending=isset($row['total']) ? intval($row['total']):0;
		//Draf
		$sql = "SELECT count(id) as total FROM b_news WHERE status='draft'";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total_draft=isset($row['total']) ? intval($row['total']):0;
		
		//Hot
		$sql = "SELECT count(id) as total FROM b_news WHERE is_hot=1";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		$total_hot=isset($row['total']) ? intval($row['total']):0;
		
		$a=array($total, $total_active, $total_pending, $total_draft, $total_hot);
		return $a;
	}
	
	public function updateOrderNews($id,$order)
	{
		$connect=Yii::app()->db;
		$sql="UPDATE b_news SET ordering=".$order." WHERE id=".$id;
		$command = $connect->createCommand($sql);
		$ok = $command->execute();
		return $ok;
	}
	
	public function quickUpdateNews($quick_type,$list_id)
	{
		$connect = Yii::app()->db;
		if($quick_type==1)//Kich hoat tin
		{
    		$sql = "UPDATE b_news SET status='active' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==2)//Bo kich hoat
		{
			$sql = "UPDATE b_news SET status='pending' WHERE id IN (".$list_id.")";
		}
		else if($quick_type==3)//Xoa tin bai
		{
			$sql = "DELETE FROM b_news WHERE id IN (".$list_id.")";
		}
		else if ($quick_type==5)
		{
			$sql = "UPDATE b_news SET is_hot=1 WHERE id IN (".$list_id.")";
		}
		
		$command = $connect->createCommand($sql);
        $result = $command->execute();
        return $result;	
    }
	
	public function moveCatNews($list_id,$cat_id)
	{
		$connect = Yii::app()->db;
		$sql = "UPDATE b_news SET cat_id=".$cat_id." WHERE id IN (".$list_id.")";
		$command = $connect->createCommand($sql);
        $result = $command->execute();
        return $result;	
	}
}
?>