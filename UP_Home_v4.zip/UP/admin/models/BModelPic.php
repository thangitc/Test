<?php
class BModelPic extends CActiveRecord
{
	public function insertPic($sub_sql)
	{
		$connect=Yii::app()->db;
		$sql = "INSERT IGNORE INTO b_model_picture(model_id, picture, create_date) VALUES ".$sub_sql."";
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	public function deletePic($model_id)
	{
		$connect=Yii::app()->db;
		$sql = "DELETE FROM b_model_picture WHERE model_id=".$model_id;
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function getPicById($model_id)
	{
		//Cache
		$cacheService = new CacheService("BModelPic","getPicById", $model_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT model_id, picture FROM b_model_picture WHERE model_id=".$model_id." ORDER BY id ASC";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
}
?>