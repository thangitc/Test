<?php
class BListPic extends CActiveRecord
{
	public function insertPic($sub_sql)
	{
		$connect=Yii::app()->db;
		$sql = "INSERT IGNORE INTO b_camera_picture(camera_id, picture, create_date) VALUES ".$sub_sql."";
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	public function deletePic($camera_id)
	{
		$connect=Yii::app()->db;
		$sql = "DELETE FROM b_camera_picture WHERE camera_id=".$camera_id;
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function getPicById($camera_id)
	{
		//Cache
		$cacheService = new CacheService("BListPic","getPicById", $camera_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT camera_id, picture FROM b_camera_picture WHERE camera_id=".$camera_id." ORDER BY id ASC";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
}
?>