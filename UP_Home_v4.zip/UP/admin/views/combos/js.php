<script>
function addCombo(combo_id)
{	
	var title = $('#title').val();
	var description = $('#des').val();

	if($('#title').val()=='')
	{
		alert('Vui lòng nhập tên Combo!');
		$('#title').focus();
		return false;
	}

	
	loadingAjax();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addCombo');?>',
		type: "POST",
		data:({
			title:title,
            description:description,
			combo_id:combo_id
		}),
		success: function(resp){
			closeLoadingAjax();
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
		}
	});
}
function findProduct(type){
    var title = $('#title').val();
    $.ajax({
        url: '<?php echo Url::createUrl('ajax/findProduct');?>',
        type: "POST",
        data:({
            title:title,
            type:type
        }),
        success: function(resp){
            $('#result_search').html(resp);
        }
    });
}

function selectProduct(product_id, price_old, type){
    $('#product_id').val(product_id);
    $('#price_old').val(price_old);
    $('#product_type').val(type);
    $('#result_search').html('');
}

function addProductCombo(combo_id){
    var product_type = $('#product_type').val();
    var product_id = $('#product_id').val();
    var price_old = $('#price_old').val();
    var price_new = $('#price_new').val();
    if(product_id==0){
        alert('Bạn chưa chọn sản phẩm cho Combo');
        return false;
    }
    if(price_new==0){
        alert('Bạn chưa nhập giá mới cho sản phẩm');
        return false;
    }
    $.ajax({
        url: '<?php echo Url::createUrl('ajax/addProductCombo');?>',
        type: "POST",
        data:({
            combo_id:combo_id,
            product_id:product_id,
            product_type:product_type,
            price_old:price_old,
            price_new: price_new

        }),
        success: function(resp){
            alert('Thêm mới thành công');
            window.location.href = '<?php echo Url::createUrl('combos/addProduct');?>/combo_id/'+combo_id;
            $('#result').html(resp);
        }
    });
}

function format_number(num)
{
    num = num.toString().replace(/\$|\,/g,'');
    if(isNaN(num))
        num = "0";
    sign = (num == (num = Math.abs(num)));
    num = Math.floor(num*100+0.50000000001);
    cents = num%100;
    num = Math.floor(num/100).toString();
    if(cents<10)
        cents = "0" + cents;
    for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
        num = num.substring(0,num.length-(4*i+3))+','+
            num.substring(num.length-(4*i+3));
    return (((sign)?'':'-') + num);
}

</script>