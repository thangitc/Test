<link href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css" rel="stylesheet">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>

<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tinymce_des.js"></script>

<link rel="stylesheet" href="<?php echo Yii::app()->params['upload_url'];?>/css/swfupload.css" type="text/css" />
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.queue.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/fileprogress.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers_ads.js"></script>

<script>
window.onload = function() {
	var configUploadData = {
		upload_url: upload_url_new+"upload_ads.php"
		, create_date:'<?php $create_date=isset($detail["create_date"])? $detail["create_date"]:''; echo $create_date;?>'
		, file_types: "*.jpg;*.jpeg;*.png;*.gif;*.doc;*.docx;*.xls;*.xlsx;*.pdf;*.swf"
		, file_upload_limit : 1
		, file_queue_limit : 1
		, debug : true
	};
	configUpload(configUploadData);
};


function addAds(ads_id)
{	
	tinyMCE.triggerSave();
	var cat_id=$('#cat_id').val();
	var model_id=$('#model_id').val();
	var title=$('#title').val();
	var ads_link=$('#ads_link').val();
	var ads_alignment=$('#ads_alignment').val();
	var picture=$('#picture').val();	
	var introtext=$('#info').val();	
	
	
	if($('#title').val()=='')
	{
		alert('Vui lòng nhập tên dự án!');
		$('#title').focus();
		return false;
	}
	if($('#picture').val()=='')
	{
		alert('Vui chọn chọn ảnh quảng cáo!');
		$('#picture').focus();
		return false;
	}
	if($('#ads_link').val()=='')
	{
		alert('Vui lòng nhập link!');
		$('#ads_link').focus();
		return false;
	}
	if($('#ads_alignment').val()=='')
	{
		alert('Vui lòng chọn vị trí!');
		$('#ads_alignment').focus();
		return false;
	}
	
	loadingAjax();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addAds');?>',
		type: "POST",
		data:({
			cat_id:cat_id,
			model_id:model_id,
			title:title,
			introtext:introtext,
			picture:picture,
			ads_link:ads_link,
			ads_alignment:ads_alignment,
			ads_id:ads_id
		}),
		success: function(resp){
			closeLoadingAjax();
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
		}
	});
}
</script>