<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tinymce_des.js"></script>

<link rel="stylesheet" href="<?php echo Yii::app()->params['upload_url'];?>/css/swfupload.css" type="text/css" />
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.queue.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/fileprogress.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers_news.js"></script>

<script>
$(function(){
	$("a[rel='showTopic']").colorbox({slideshow:true,innerWidth:800, innerHeight:460});
    $("a[rel='showNews']").colorbox({slideshow:true,innerWidth:800, innerHeight:460});
		
	$('#add_related').click(function(){
		$('#box_related').append('<div><input type="text" style="width:300px;" name="related_title"><br><input type="text" style="width:300px;" name="related_link"><a class="ic_del" onclick="$(this).parent(\'div\').remove();" href="javascript:">&nbsp;</a></div>');
	});
	$("#showNews").colorbox({slideshow:true,innerWidth:800, innerHeight:460});
});
function addNews(news_id,status)
{
	tinyMCE.triggerSave();
	var cat_id=$('#cat_id').val();
	var title=$('#title').val();
	var introtext=$('#introtext').val();
	var description=$('#description').val();
	var original_link=$('#original_link').val();
	var keyword=$('#keyword').val();
	var author_name=$('#author_name').val();
	var related_title='';
	var related_link='';
	var list_news_id=$('#list_news_id').val();
	var list_topic_id=$('#list_topic_id').val();
	var day=$('#day').val();
	var month=$('#month').val();
	var year=$('#year').val();
	var hour=$('#hour').val();
	var minute=$('#minute').val();	
	//Tieu de link
	$('input[name="related_title"]').each(function(){
		if($(this).val()!='Tiêu đề')
		{
			related_title+=$(this).val()+',';
		}
	});
	related_title=rtrim(related_title,',');
	//Link
	$('input[name="related_link"]').each(function(){
		if($(this).val()!='Link')
		{
			related_link+=$(this).val()+',';
		}
	});
	related_link=rtrim(related_link,',');
	
	if(cat_id==0)
	{
		alert('Vui lòng chọn chọn danh mục tin');
		return false;
	}
	if(title=='')
	{
		alert('Vui lòng nhập tiêu đề tin');
		return false;
	}
	
	if(introtext=='')
	{
		alert('Vui lòng nhập nội dung tóm tắt của tin');
		return false;
	}
	if(description=='')
	{
		alert('Vui lòng nhập nội dung tin');
		return false;
	}
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addNews');?>',
		type: "POST",
		data:({
			news_id:news_id,
			cat_id:cat_id,
			title:title,
			picture:$('#filename1').val(),
			is_hot:$('#is_hot').val(),
			keyword:$('#keyword').val(),
			original_link:$('#original_link').val(),
			author_name:author_name,
			list_news_id:list_news_id,
			related_title:related_title,
			related_link:related_link,
			introtext:introtext,
			description:description,
			list_topic_id:list_topic_id,
			list_news_id:list_news_id,			
			day:day,
			month:month,
			year:year,
			hour:hour,
			minute:minute,
			status:status
		}),
		success: function(resp){
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
			}
			else
			{
				alert('Lỗi');
			}
		}
	});
}
function updateListNews(news_id)
{
	var list_news_id='';
	$('#list_news_view>div').each(function(){
		if($(this).attr('rel')!=news_id)
		{
			list_news_id += $(this).attr('rel')+',';
		}
	});
	list_news_id=rtrim(list_news_id,',');
	$('#list_news_id').val(list_news_id);
}
function updateListTopic(topic_id)
{
	var list_topic_id='';
	$('#list_topic_view>div').each(function(){
		if($(this).attr('rel')!=topic_id)
		{
			list_topic_id += $(this).attr('rel')+',';
		}
	});
	list_topic_id=rtrim(list_topic_id,',');
	$('#list_topic_id').val(list_topic_id);
}
</script>