<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
    <tr>
        <td class="first" valign="top">
            <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
        </td>
        <td valign="top" class="last">
            <div class="content_pages">
                <?php $this->renderPartial('tab');?>
                <div class="box_form">
                    <div class="box bottom30 clearfix">
                        <div style="border-right:1px solid #ccc" class="col55">
                            <ul class="form">
                                <li class="clearfix"><label><strong>Tiêu đề :</strong></label>
                                    <div class="filltext">
                                        <input name="title" id="title" type="text" style="width:100%;" value="<?php if(isset($detail['title'])) echo $detail['title'];?>">
                                    </div>
                                </li>
                                <li class="clearfix"><label><strong>Chuyên mục :</strong>   </label>
                                    <div class="filltext">
                                        <select style="width:52%;" name="cat_id" id="cat_id">
                                            <option value=""> -- Chọn chuyên mục -- </option>
                                            <?php
                                            if($cats)
                                            foreach($cats as $row)
                                            {
                                                if($row['cat_type']==2 && $row['parent_id']==0)
                                                {
                                                    $select = '';
                                                    if($row['id']==$detail['cat_id']) $select = 'selected';
                                                    ?>
                                                    <option <?php echo $select;?> value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
                                                    <?php
                                                    foreach($cats as $row2)
                                                    {
                                                        if($row2['parent_id']==$row['id'])
                                                        {
															$select = '';
                                                            if($row2['id']==$detail['cat_id']) $select = 'selected';
                                                            ?>
                                                            <option <?php echo $select;?> value="<?php echo $row2['id'];?>">--<?php echo $row2['title'];?></option>
                                                            <?php
                                                            foreach($cats as $row3)
                                                            {
                                                                if($row3['parent_id']==$row2['id'])
                                                                {
																	$select = '';
                                                                    if($row3['id']==$detail['cat_id']) $select = 'selected';
                                                                    ?>
                                                                    <option <?php echo $select;?> value="<?php echo $row3['id'];?>">--<?php echo $row3['title'];?></option>
                                                                    <?php
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </li>
                                <li class="clearfix"><label><strong>Tóm tắt:</strong> </label>
                                    <div class="filltext">
                                        <textarea name="introtext" id="introtext" cols="10" rows="5" style="width:80%; height:80px"><?php echo $detail['introtext'];?></textarea>
                                    </div>
                                </li>
                                <li class="clearfix"><label><strong>Tin nổi bật :</strong> </label>
                                    <div class="filltext" id="result_img2">
                                        <input type="checkbox" name="is_hot" id="is_hot" value="<?php echo $detail['is_hot'];?>" <?php if(isset($detail['is_hot']) && $detail['is_hot'] == 1) echo "checked";?>>
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label><strong>Nội dung </strong></label>
                                    <div class="filltext">
                                        <textarea id="description" name="description"><?php if(isset($detail["description"])) echo $detail["description"];?></textarea>
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label><strong>Từ khóa  </strong></label>
                                    <div class="filltext">
                                        <input type="text" name="keyword" id="keyword"  style="width:100%;">
                                    </div>
                                </li>
                                <li>
                                    <label><strong>Nguồn :</strong></label>
                                    <div class="filltext">
                                        <input type="text" style="width:100%;" id="original_link" name="original_link" value="<?php echo $detail["original_link"];?>">
                                    </div>
                                </li>

                                <li class="clearfix">
                                    <label><strong>Trạng thái SEO  </strong></label>
                                    <div class="filltext">
                                        <?php
                                        if(!empty($detail["meta_keyword"]))
										{
											echo "Đã Seo";
										} else {
											echo "Chưa Seo";
										} 
                                        ?>
                                    </div>
                                </li>

                            </ul>
                        </div>
                        <div class="col2">&nbsp;</div>
                        <div class="col40">
                            <p><input type="button" value="Cập nhật" class="btn-orange" onclick="addNews(<?php echo $detail['id'];?>,'<?php echo $detail['status'];?>');"></p>
                            <ul class="form1">
                                <li class="clearfix bor-bottom">
                                    <div class="clearfix">
                                        <label style="margin-top:25px"><strong>Ảnh đại diện</strong></label>
                                        <input type="text" id="filename1" name="filename1" value="<?php echo $detail['picture'];?>" readonly/>&nbsp;
                                        <span id="spanButtonPlaceHolder" class="span_upload_0" rel="0"></span>
                                    </div>
                                </li>
                                <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                    <div class="filltext" id="img_0">
                                    	<img width="150px" height="90px" src="<?php echo Common::getImage($detail['picture'],'news',''); ?>"/>
                                    </div>
                                </li>
                                <li class="clearfix"><label><strong>Người đăng  :</strong></label>
                                    <div class="filltext">
                                        <input name="author_name" id="author_name" type="text" style="width:100%;" value="<?php echo $detail['author_name'];?>">
                                    </div>
                                </li>
                                <li class="clearfix"><label><strong>Chuyên đề :</strong></label>
                                    <div class="filltext">
                                        <a rel="showTopic" href="<?php echo Url::createUrl("topic/showTopic");?>" class="cboxElement"><input type="button" value="Chọn" class="buton-radi" style="margin-right:10px;"></a>
                                        <div id="list_topic_view">
                                            <?php
											$list_topic_id='';
											if($topic)
											foreach($topic as $row)
											{
												$list_topic_id.=$row['id'].',';
												?>                                                    
												<div class="fl" rel="<?php echo $row['id'];?>"><a href="javascript:"><?php echo $row['title'];?></a><a class="ic_del" onclick="updateListTopic(<?php echo $row['id'];?>);$(this).parent('div').remove();" href="javascript:">&nbsp;</a></div>
												<?php
											}
											$list_topic_id=rtrim($list_topic_id,',');
                                            ?>
                                        </div>                                                            
                                    </div>
                                    <input type="hidden" id="list_topic_id" name="list_topic_id" value="<?php echo $list_topic_id; ?>">
                                </li>

                                <li class="clearfix">
                                    <label><strong>Tin liên quan:</strong>  </label>

                                    <div class="filltext">
                                        <a rel="showNews" href="<?php echo Url::createUrl("news/showNews");?>" class="cboxElement"><input type="button" value="Chọn" class="buton-radi" style="margin-right:10px;"></a>
                                        <div id="list_news_view">
                                        	<?php
											if($news_related)
											foreach($news_related as $row)
											{
												?>
												<div class="fl" rel="<?php echo $row['id'];?>"><a href="javascript:"><?php echo $row['title'];?></a><a class="ic_del" onclick="updateListNews(<?php echo $row['id'];?>);$(this).parent('div').remove();" href="javascript:">&nbsp;</a></div>
												<?php
											}
											?>
                                        </div>                                                            
                                    </div>
                                    <input type="hidden" id="list_news_id" name="list_news_id" value="<?php echo $list_news_id; ?>">
                                </li>

                                <li class="clearfix">
                                    <label><strong>Link liên quan</strong></label>
                                    <div class="filltext">
                                        <div id="box_related">
                                            <?php
                                                if(!empty($related))
												foreach($related as $row)
												{
													if($row['related_link']!='')
													{
													?>
													<div>
														<input type="text" style="width:300px;" name="related_title" value="<?php if($row['related_title']!='') echo $row['related_title']; else echo 'Tiêu đề';?>">
														<input type="text" style="width:300px;" name="related_link" value="<?php if($row['related_link']!='') echo $row['related_link']; else echo 'Link';?>">
														<a class="ic_del" onclick="$(this).parent('div').remove();" href="javascript:">&nbsp;</a>
													</div>
													<?php
													}
                                                }
                                                else
                                                {
                                                ?>
                                                <div>
                                                    <input type="text" style="width:300px;" name="related_title" value="Tiêu đề" onblur="if (this.value == 'Tiêu đề' || this.value == '') this.value = 'Tiêu đề'" onfocus="if (this.value == 'Tiêu đề') this.value = '';">
                                                    <input type="text" style="width:300px;" name="related_link" value="Link" onblur="if (this.value == 'Link' || this.value == '') this.value = 'Link'" onfocus="if (this.value == 'Link') this.value = '';">
                                                    <a class="ic_del" onclick="$(this).parent('div').remove();" href="javascript:">&nbsp;</a>
                                                </div>
                                                <?php
                                                }
                                            ?>
                                        </div>
                                        <a href="javascript:" id="add_related">Thêm</a>
                                    </div>
                                </li>
                            </ul>
                            <p><strong>Thời gian đăng</strong></p>
                            <p>
                                <input type="text" value="<?php echo date('d',$detail['publish_date']);?>" style="width:40px;" name="day" onfocus="if (this.value == this.defaultValue) this.value = '';" onblur="if (this.value == this.defaultValue || this.value == '') this.value = this.defaultValue">&nbsp;
                                <select style="width:85px" name="month">
                                    <?php
                                        for($i=1;$i<=12;$i++)
                                        {
                                            $selected='';
                                            if(date('m',$detail['publish_date'])==$i) $selected='selected';                    
                                        ?>
                                        <option <?php echo $selected;?> value="<?php echo $i;?>"><?php echo 'Tháng '.$i;?></option>
                                        <?php
                                        }
                                    ?>
                                </select> &nbsp;
                                <input type="text" value="<?php echo date('Y',$detail['publish_date']);?>" style="width:40px;" name="year" onfocus="if (this.value == this.defaultValue) this.value = '';" onblur="if (this.value == this.defaultValue || this.value == '') this.value = this.defaultValue"> @ &nbsp;<input name="hour" type="text" value="<?php echo date('H',$detail['publish_date']);?>" style="width:40px;" onfocus="if (this.value == this.defaultValue) this.value = '';" onblur="if (this.value == this.defaultValue || this.value == '') this.value = this.defaultValue">&nbsp;:<input name="minute" type="text" value="<?php echo date('i',$detail['publish_date']);?>" style="width:40px;" onfocus="if (this.value == this.defaultValue) this.value = '';" onblur="if (this.value == this.defaultValue || this.value == '') this.value = this.defaultValue">
                            </p>                                        
                            <p><input type="button" value="Cập nhật" class="btn-orange" onclick="addNews(<?php echo $detail['id'];?>,'<?php echo $detail['status'];?>');">
                        </div>
                        <div style="color:red;" id="result"></div>
                    </div>
                </div> 
                <?php $this->renderPartial('application.views.static.footer') ;  ?>
            </div>
        </td>
    </tr>
</table>
</div>