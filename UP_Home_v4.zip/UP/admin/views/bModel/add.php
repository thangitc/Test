<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab');?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div style="border-right:1px solid #ccc; width:60%">
                                    <ul class="form">
                                    	<li class="clearfix"><label><strong>Loại tin :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="cat_id" id="cat_id">
                                                	<option value="0" selected="selected">--Danh mục--</option>
                                                    
                                                    <?php
													if($cats)
													foreach($cats as $row)
													{
														if($row['parent_id']==0 && $row['cat_type']==1)
														{
															$parent_id=$row['id'];
															?>
															<option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
															<?php
															foreach($cats as $row2)
															{
																if($row2['parent_id']==$parent_id)
																{
																	$parent_id_2=$row2['id'];
																	?>
																	<option value="<?php echo $row2['id'];?>" >--<?php echo $row2['title'];?></option>
																	<?php
																	foreach($cats as $row3)
																	{
																		if($row3['parent_id']==$parent_id_2)
																		{
																			?>
																			<option value="<?php echo $row3['id'];?>" >----<?php echo $row3['title'];?></option>
																			<?php
																		}
																	}
																}
															}
														}
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Chọn thương hiệu :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="brand_id" id="brand_id">
                                                	<option value="0" selected="selected">--Chọn thương hiệu--</option>
                                                    
                                                    <?php
													if($brand)
													foreach($brand as $row)
													{
														if($row['brand_type']==0)
														{
															?>
                                                            <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                                            <?php	
														}
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Tiêu đề model :</strong></label>
                                            <div class="filltext">
                                                <input name="title" id="title" type="text" style="width:100%;" >
                                            </div>
                                        </li>                                        
                                        
                                        
                                        <li class="clearfix bor-bottom"><label><strong>Ảnh đại diện:</strong></label>
                                            <div class="filltext">            
                                            	<input type="text" id="filename1" name="filename1" readonly/>&nbsp;
                                                <span id="spanButtonPlaceHolder"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_0">
                                            	
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix bor-bottom"><label><strong>File hướng dẫn:</strong></label>
                                            <div class="filltext">            
                                                <input type="text" id="filename2" name="filename2" readonly/>&nbsp;
                                                <span id="spanButtonPlaceHolder_other"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_2">
                                                
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Tóm tắt(Product Highlights):</strong> </label>
                                            <div class="filltext">
                                                <textarea style="width: 518px; height: 85px;" rows="5" cols="10" name="introtext" id="introtext"></textarea>
                                            </div>                                            
                                        </li>
                                       	<li class="clearfix">
                                            <label><strong>Nội dung(Overview):</strong></label>
                                            <div class="filltext">
                                                <textarea id="description" name="description"></textarea>
                                            </div>
                                        </li>
                                       	
                                        <li class="clearfix">
                                            <label><strong>Hình ảnh chụp từ sản phẩm </strong></label>
                                            <div class="filltext">
                                                <textarea id="pic_product" name="pic_product"></textarea>
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Thông số kỹ thuật </strong></label>
                                            <div class="filltext">
                                                <textarea id="specs" name="specs"></textarea>
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Hàng chính hãng </strong></label>
                                            <div class="filltext">
                                                <input type="checkbox" value="0" id="is_chinh_hang" />
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Hàng công ty </strong></label>
                                            <div class="filltext">
                                                <input type="checkbox" value="0" id="is_cong_ty" />
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Text chính hãng :</strong></label>
                                            <div class="filltext">
                                                <input name="text_chinh_hang" id="text_chinh_hang" type="text" style="width:100%;" >
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Chọn phụ kiện:</strong>  </label>
                                            <input type="hidden" id="list_access_id" name="list_access_id">
                                            <div class="filltext">
                                                <a id="showAccess" href="<?php echo Url::createUrl("access/showAccess");?>" class="cboxElement"><input type="button" class="buton-radi" value="Chọn" style="margin-right:10px;"></a>
                                                <div id="list_access_view">
                                                    
                                                </div>                                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Ngày đăng tin:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="publish_date" name="publish_date">
                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix">
                                            <label><strong>Video</strong></label>
                                            <div class="filltext">
                                                <input type="text" id="model_video" name="model_video" style="width:100%;" />
                                            </div>
										</li>
                                        <li class="clearfix"><label><strong>Ghi chú hiển thị:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="height: 152px; width: 322px;" rows="5" cols="10" name="note_public" id="note_public"></textarea>
                                            </div>                                            
                                        </li>                                        
                                    </ul>
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addList(0,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addList(0,'draft');"> &nbsp; </p>
                                    
                                    <div id="result">
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>