<!--sort-->
<link rel="stylesheet" href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.widget.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.mouse.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.sortable.js"></script>


<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tinymce_des.js"></script>

<link rel="stylesheet" href="<?php echo Yii::app()->params['upload_url'];?>/css/swfupload.css" type="text/css" />
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.queue.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/fileprogress.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers_model.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers_model_file.js"></script>

<script>
$(function(){
	$("#showAccess").colorbox({slideshow:true,innerWidth:800, innerHeight:460});
	$('#img_0').sortable();
	window.onload = function() {
		var configUploadData = {
			upload_url: upload_url_new+"upload_model.php"
			, create_date:'<?php $create_date=isset($detail["create_date"])? $detail["create_date"]:''; echo $create_date;?>'
			, file_types: "*.jpg;*.jpeg;*.png;*.gif;*.doc;*.docx;*.xls;*.xlsx;*.pdf;*.swf"
			, file_upload_limit : 16
			, file_queue_limit : 16
			, debug : true
		};
		configUpload(configUploadData);
		
		var configUploadDataOther = {
			upload_url: upload_url_new+"upload_model.php"
			, create_date:'<?php $create_date=isset($detail["create_date"])? $detail["create_date"]:''; echo $create_date;?>'
			, file_types: "*.jpg;*.jpeg;*.png;*.gif;*.doc;*.docx;*.xls;*.xlsx;*.pdf;*.swf;*.txt"
			, file_upload_limit : 5
			, file_queue_limit : 5
			, debug : false
		};
		configUploadOther(configUploadDataOther);
	};
		
	$("#publish_date").datepicker({
		dateFormat:"dd/mm/yy",
		minDate: new Date()
	});
	$("#expired_date").datepicker({
		dateFormat:"dd/mm/yy",
		minDate: new Date()
	});
	
	$("#time_sale,#time_buy").datepicker({
		dateFormat:"dd/mm/yy",
	});
	//format_number
	$('#price,#price_in,#price_sale,#price_buy').keypress(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	$('#price,#price_in,#price_sale,#price_buy').keyup(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	$('#price,#price_in,#price_sale,#price_buy').keydown(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	
	$('#status_p').change(function(){
		if($(this).val()==1) $('#num_buy').val(0);
	});
	$('#is_chinh_hang,#is_cong_ty').click(function(){
		if($(this).is(":checked"))
		{
			$(this).val(1);
		}
		else
		{
			$(this).val(0);
		}
	});
});

function addList(model_id,status)
{
	tinyMCE.triggerSave();
		
	var title=$('#title').val();
	var publish_date = $('#publish_date').val();
	
	var introtext=$('#introtext').val();
	var description=$('#description').val();	
	var specs=$('#specs').val();	
	var pic_product=$('#pic_product').val();	
	var picture = $('#filename1').val();
	var html_img = $('#img_0').html();
	var user_manual = $('#filename2').val();
	var model_video = $('#model_video').val();

	var cat_id=$('#cat_id').val();
	var brand_id=$('#brand_id').val();
	var is_chinh_hang = $('#is_chinh_hang').val();
	var is_cong_ty = $('#is_cong_ty').val();
	var text_chinh_hang = $('#text_chinh_hang').val();
	var list_access_id = $('#list_access_id').val();
	var note_public = $('#note_public').val();
	
	if(title=='')
	{
		alert('Vui lòng nhập tiêu đề tin');
		$('#title').focus();
		return false;
	}
	
	if(introtext=='')
	{
		alert('Vui lòng nhập nội dung tóm tắt của tin');
		$('#introtext').focus();
		return false;
	}
	/*
	if(description=='')
	{
		alert('Vui lòng nhập nội dung tin');
		tinymce.execCommand('mceFocus',false,'description');
		return false;
	}
	*/
	
	if(cat_id==0)
	{
		alert('Vui lòng chọn danh mục tin');
		$('#cat_id').focus();
		return false;
	}
	
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addModel');?>',
		type: "POST",
		data:({
			model_id:model_id,
			title:title,
			publish_date:publish_date,
			introtext:introtext,
			description:description,
			pic_product:pic_product,
			specs:specs,
			picture:picture,
			html_img:html_img,
			model_video: model_video,
			cat_id:cat_id,
			brand_id:brand_id,
			status:status,
			is_chinh_hang:is_chinh_hang,
			is_cong_ty:is_cong_ty,
			text_chinh_hang:text_chinh_hang,
			list_access_id:list_access_id,
			user_manual:user_manual,
			note_public:note_public
		}),
		success: function(resp){
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
			}
			else
			{
				alert('Lỗi');
			}
		}
	});
}

function format_number(num)
{
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
	num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num*100+0.50000000001);
	cents = num%100;
	num = Math.floor(num/100).toString();
	if(cents<10)
	cents = "0" + cents;
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	num = num.substring(0,num.length-(4*i+3))+','+
	num.substring(num.length-(4*i+3));
	return (((sign)?'':'-') + num);
}

function updateListAccess(access_id)
{
	var list_access_id='';
	$('#list_access_view>div').each(function(){
		if($(this).attr('rel')!=access_id)
		{
			list_access_id += $(this).attr('rel')+',';
		}
	});
	list_access_id=rtrim(list_access_id,',');
	$('#list_access_id').val(list_access_id);
}
</script>