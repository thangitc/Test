<script>
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/calendar.png';?>"
	});
	$('#formSearch').keypress(function(e){
		switch(e.which)
		{
			case 13:
				$('#formSearch').submit();
			break;
		}
	});
});

function searchForm(tab)
{
	$('#tab').val(tab);
    $('#formSearch').submit();
}

function deleteBill(bill_id)
{
    var answer = confirm("Bạn có chắc chắn muốn xóa?");
    if(answer){
        $.ajax({
            url:"<?php echo Url::createUrl('bill/deleteBill');?>",
            type:"POST",
            data:({
            	bill_id:bill_id                                                   
            }),
            success:function(response){
				if(response!=1)
				{
					alert(response);
				}
                location.reload();
            },
            error:function(){
                alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
            }
        });
    }
}
function isActiveBill(bill_id)
{
    $.ajax({
		url:"<?php echo Url::createUrl('ajax/isActiveBill');?>",
		type:"POST",
		data:({
			bill_id:bill_id                                                   
		}),
		success:function(response){
			location.reload();
		},
		error:function(){
			alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
		}
	});
}

function quickUpdateBill(quick_type,list_id)
{
	if(list_id=='')
	{
		alert('Bạn chưa chọn tin. Hãy làm lại.');
		return false;
	}
	else
	{
		loadingAjax();
		$.ajax({
			url:"<?php echo Url::createUrl('ajax/quickUpdateBill');?>",
			type:"POST",
			data:({
				quick_type:quick_type,
				list_id:list_id
			}),
			success:function(response){
				var result = eval( "(" + response + ")" );
				if(result.status !== "noPermis"){
					/*alert("Cập nhật thành công.");*/
				} else {
					alert("Bạn không đủ quyền thực hiện hành động này.");    
				}
				location.reload();
				closeLoadingAjax();
			},
			error:function(){
				alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
				closeLoadingAjax();
			}
		});
	}
}
function quickUpdateBill()
{    
	var list_order='';
	var bill_id=0;
	var timeline_order=0;

	$('#list tbody>tr').each(function(i){
		bill_id=$(this).attr('rel');
		if(bill_id)
		{               
			timeline_order=$('#orderlist_'+bill_id+'').val();
			list_order+=bill_id+'|'+timeline_order+',';
		}
	});

	if(list_order!='')
		{
		loadingAjax();
		$.ajax({
			url: '<?php echo Url::createUrl('ajax/quickUpdateBill');?>',
			type: "POST",
			data:({
				list_order:list_order
			}),
			success: function(resp){
				closeLoadingAjax();
				location.reload();
			}
		});
	}
}
</script>
<div class="body_pages clearfix">
<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
    <tr>
        <td class="first" valign="top"><?php $this->renderPartial('application.views.static.sidebar') ;  ?></td>
        <td valign="top" class="last"><div class="content_pages" id="container">
                <?php $this->renderPartial('tab');?>
                <div class="box_form">
                    <form method="GET" action="<?php echo Url::createUrl('bill/index');?>" id="formSearch">
                        <div class="box bottom30">
                            <ul class="form4">
                                <li class="clearfix">
                                    <label><strong>Từ khóa:</strong></label>
                                    <div class="filltext">
                                        <input type="text" value="<?php echo $keyword;?>" style="width: 300px;" id="keyword" name="keyword">
                                        Trong
                                        <select id="keyword_in" name="keyword_in">
                                            <option value="1" <?php if($keyword_in==1) echo 'selected';?>>Tên khách hàng</option>
                                            <option value="2" <?php if($keyword_in==2) echo 'selected';?>>Số điện thoại</option>
                                        </select>
                                    </div>                                     
                                </li>
                                                         
                                <li class="clearfix">
                                    <label><strong>Từ ngày: </strong></label>
                                    <div class="filltext">
                                        <input type="text" style="width:170px" value="<?php if(isset($from_date) && $from_date!=0) echo date('d/m/Y',$from_date);?>" id="from_date" name="from_date">
                                        &nbsp; Đến ngày &nbsp;
                                        <input type="text" style="width:170px" id="to_date" name="to_date" value="<?php if(isset($to_date) && $to_date!=0) echo date('d/m/Y',$to_date);?>">
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label>&nbsp;</label>
                                    <div class="filltext">
                                        <input type="button" class="buton-radi" value="Tìm kiếm" onclick="searchForm('');">
                                        <input type="button" value="Hủy" class="buton-radi" onclick="window.location.href='<?php echo Url::createUrl('bill/index');?>'" />
                                    </div>
                                </li>
                                <br />
                                <li>
                                    <div class="filltext"> <a href="javascript:" onclick="searchForm(0);">Tất cả <strong style="color:red;">(<?php echo $total_all;?>)</strong></a> &nbsp;&nbsp; <a href="javascript:" onclick="searchForm(1);">Hoàn thành<strong style="color:red;">(<?php echo $total_active;?>)</strong></a>&nbsp;&nbsp; <a href="javascript:" onclick="searchForm(2);">Đang xử lý<strong style="color:red;">(<?php echo $total_pending;?>)</strong></a>
                                    <input type="hidden" id="tab" name="tab" />
                                    </div>
                                </li>
                                <br />
                            </ul>
                        </div>
                    </form>
                    <div class="box">
                        <div class="clearfix fillter">
                            <div class="fl reseach">
                                
                            </div>
                            <div class="fr reseach">
                            	<a href="<?php echo Url::createUrl("bill/add");?>">
                                <input type="button"class="btn-orange" value="Thêm mới">
                                </a>&nbsp;
                                <ul class="pages fr clearfix">
                                    <?php echo $paging;?>
                                </ul>
                                
                            </div>
                        </div>
                        <input type="hidden" id="list_id" />
                        <table width="100%" cellspacing="0" cellpadding="0" border="0" class="col_list txt-right" id="list">
                            <tbody>
                                <tr class="bg-grey">
                                    <td width="3%"><strong>ID </strong><br>
                                    <input type="checkbox" id="selectAll" onclick="doCheckAll();">
                                    </td>
                                    <td width="16%"><strong>Tiêu đề hóa đơn</strong></td>
                                    <td width="12%"><strong>Hình ảnh</strong></td>
                                    <td width="8%"><strong>Người lập</strong></td>
                                    <td width="12%"><strong>Thời gian tạo</strong></td>
                                </tr>
                                <?php
                                
                                $k=0;
                                foreach ($bill as $row)
                                {
                                    $class='';
                                    if($k%2==0)
                                    {
                                        $class='class="bg_grays"';
                                    }
									if($row['picture']!='') $src = Common::getImage($row['picture'], 'bill', '');
									else $src = '';
									$link_bill = Yii::app()->params['baseUrlFront'].'/hoa-don-bill'.$row['id'].'.html';
                                    ?>
                                    <tr <?php echo $class;?> rel="<?php echo $row['id'];?>">
                                        <td><?php echo ($row['id']);?><br />
                                            <input type="checkbox" value="<?php echo ($row['id']);?>" name="articles_<?php echo ($row['id']);?>" class="selectOne" onclick="doCheck();"></td>
                                        <td class="txt-left">
                                        	<a href="<?php echo Url::createUrl('bill/view');?>" target="_blank"><strong><?php echo stripslashes($row['title']);?></strong></a>
                                            <br />Họ tên: <strong><?php echo $row['fullname'];?></strong>
                                            <br />Địa chỉ: <strong><?php echo $row['address'];?></strong>
                                            <br />Mobile: <strong><?php echo $row['mobile'];?></strong>
                                            <div class="clearfix col_30">                                                
                                                <div class="row-actions">
                                                	<a href="<?php echo Url::createUrl("bill/edit", array("bill_id"=>$row['id']));?>" title="Edit this item"><span>Edit</span></a> | <a href="javascript:" onclick="deleteBill(<?php echo ($row['id']);?>);">Xóa</a> | <a href="<?php echo Url::createUrl('bList/index', array('bill_id'=>$row['id']));?>">Thêm SP</a> | <a href="<?php echo Url::createUrl('access/index', array('bill_id'=>$row['id']));?>">Thêm Phụ kiện</a>
                                                    |
                                                    <a href="javascript:" onclick="isActiveBill(<?php echo ($row['id']);?>);">
                                                    <?php
													if ($row['status'] == "active")
														echo '<span>Set Đang xử lý<span>';
													else
														echo '<span>Set Hoàn thành<span>';
                                                    ?>
                                                    </a>
                                                    |
                                                    <a target="_blank" href="<?php echo $link_bill;?>" title="Xem hóa đơn"><span>Xuất hóa đơn</span></a>
                                                </div>
                                            </div>
                                            
                                            <?php
											$color = '';
											
											if($row['status']=='active')  $color = 'style="color:blue; font-size:16px;"';
											if($row['status']=='pending')  $color = 'style="color:purple; font-size:16px;"';
											?>
                                            <strong <?php echo $color;?> ><?php if($row['status']=='active') echo 'Hoàn thành'; else echo 'Đang xử lý';?></strong>
                                        </td>
                                        <td>
                                            <?php
											if($row['picture']!='')
											{
												?>
                                                <img src="<?php echo $src;?>" width="150px;" height="150px;" />
                                                <?php
											}
											?>
                                        </td>
                                        <td>
                                             <strong style="color:blue"><?php echo $row['user_post'];?></strong>
                                        </td>
                                        <td class="txt-left">
                                        	<p>Sửa: <?php echo date('d/m/Y - H:i a',$row['edit_date']);?></p>
                                            <p>Tạo: <?php echo date('d/m/Y - H:i a',$row['create_date']);?></p>
										</td>
                                    </tr>
                                    <?php
                                    $k++;
                                }
                                ?>
                            </tbody>
                        </table>
                        <div class="clearfix fillter">                                	
                            <div class="fr reseach">
                                <ul class="pages fl magT5 clearfix">
                                    <?php echo $paging;?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $this->renderPartial('application.views.static.footer') ;  ?>
            </div>
		</td>
    </tr>
</table>
</div>
