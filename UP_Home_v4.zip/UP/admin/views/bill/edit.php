<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab');?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div style="border-right:1px solid #ccc; width:60%">
                                    <ul class="form">
                                    	<!--
                                        <li class="clearfix"><label><strong>Tiêu đề hóa đơn :</strong></label>
                                            <div class="filltext">
                                                <input name="title" id="title" type="text" style="width:100%;" value="<?php echo $detail['title'];?>" >
                                            </div>
                                        </li>                                        
                                        -->
                                        <li class="clearfix bor-bottom"><label><strong>Ảnh hóa đơn:</strong></label>
                                            <div class="filltext">            
                                            	<input type="text" id="filename1" name="filename1" value="<?php echo $detail['picture'];?>" readonly/>&nbsp;
                                                <span id="spanButtonPlaceHolder"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_0">
                                            <?php
											if($detail['picture']!='')
											{
												$src = Common::getImage($detail['picture'], 'bill', '');
												?>
                                                <div style="width:150px; float:left;">
													<img width="150px;" height="90px" src="<?php echo $src;?>" alt="<?php echo $detail['picture'];?>" />
                                                    <a href="javascript:" onclick="$(this).parent('div').remove();">Xóa</a>
                                                </div>
												<?php
											}
											?>	
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Họ tên khách hàng :</strong></label>
                                            <div class="filltext">
                                                <input name="fullname" id="fullname" type="text" style="width:100%;" value="<?php echo $detail['fullname'];?>">
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Số điện thoại :</strong></label>
                                            <div class="filltext">
                                                <input name="mobile" id="mobile" type="text" style="width:100%;" value="<?php echo $detail['mobile'];?>">
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Địa chỉ :</strong></label>
                                            <div class="filltext">
                                                <input name="address" id="address" type="text" style="width:100%;" value="<?php echo $detail['address'];?>">
                                            </div>
                                        </li>
                                        <!--
                                        <li class="clearfix"><label><strong>Người lập hóa đơn:</strong></label>
                                            <div class="filltext">
                                                <input name="user_post" id="user_post" type="text" style="width:100%;" value="<?php echo $detail['user_post'];?>">
                                            </div>
                                        </li>
                                        -->
                                        <li class="clearfix"><label><strong>Ghi chú:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="width: 518px; height: 85px;" rows="5" cols="10" name="info_note" id="info_note"><?php echo $detail['info_note'];?></textarea>
                                            </div>                                            
                                        </li>
                                    </ul>
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addBill(<?php echo $detail['id'];?>);"></p>
                                    
                                    <div id="result">
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>