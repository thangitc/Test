<!--sort-->
<link rel="stylesheet" href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.widget.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.mouse.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.sortable.js"></script>


<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tinymce_des.js"></script>

<link rel="stylesheet" href="<?php echo Yii::app()->params['upload_url'];?>/css/swfupload.css" type="text/css" />
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.queue.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/fileprogress.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers_camera.js"></script>

<script>
$(function(){
	$("#showAccess").colorbox({slideshow:true,innerWidth:800, innerHeight:460});
	//$("#showAccess2").colorbox({slideshow:true,innerWidth:800, innerHeight:460});
	
	$('#img_0').sortable();
	window.onload = function() {
		var configUploadData = {
			upload_url: upload_url_new+"upload_camera.php"
			, create_date:'<?php $create_date=isset($detail["create_date"])? $detail["create_date"]:''; echo $create_date;?>'
			, file_types: "*.jpg;*.jpeg;*.png;*.gif;*.doc;*.docx;*.xls;*.xlsx;*.pdf;*.swf"
			, file_upload_limit : 16
			, file_queue_limit : 16
			, debug : false
		};
		configUpload(configUploadData);
	};

	$("#publish_date").datepicker({
		dateFormat:"dd/mm/yy",
		minDate: new Date()
	});
	$("#expired_date").datepicker({
		dateFormat:"dd/mm/yy",
		minDate: new Date()
	});
	
	$("#time_sale,#time_buy").datepicker({
		dateFormat:"dd/mm/yy",
	});
	//format_number
	$('#price,#price_in,#price_sale,#price_buy,#tien_mat,#chuyen_khoan,#quet_the,#fee_vn,#price_dk').keypress(function(){
		$(this).next('em').html(format_number($(this).val()));
		var price_in_after = parseFloat($('#price_in').val());
		var fee_vn = parseFloat($('#fee_vn').val());	
		price_in_after = (price_in_after+fee_vn)*110/100;
		$('#price_ct').html(format_number(price_in_after));
	});
	$('#price,#price_in,#price_sale,#price_buy,#tien_mat,#chuyen_khoan,#quet_the,#fee_vn,#price_dk').keyup(function(){
		$(this).next('em').html(format_number($(this).val()));
		var price_in_after = parseFloat($('#price_in').val());
		var fee_vn = parseFloat($('#fee_vn').val());	
		price_in_after = (price_in_after+fee_vn)*110/100;
		$('#price_ct').html(format_number(price_in_after));
	});
	$('#price,#price_in,#price_sale,#price_buy,#tien_mat,#chuyen_khoan,#quet_the,#fee_vn,#price_dk').keydown(function(){
		$(this).next('em').html(format_number($(this).val()));
		var price_in_after = parseFloat($('#price_in').val());
		var fee_vn = parseFloat($('#fee_vn').val());	
		price_in_after = (price_in_after+fee_vn)*110/100;
		$('#price_ct').html(format_number(price_in_after));
	});
	
	$('#price_in_japan, #fee_japan,#rate_japan').keypress(function(){
		$(this).next('em').html(format_number($(this).val()));
		var price_in_japan = $('#price_in_japan').val();
		var rate_japan = $('#rate_japan').val();
		$('#price_in').val(price_in_japan*rate_japan);
		$('#price_in').next('em').html(format_number(price_in_japan*rate_japan));
		
	});
	$('#price_in_japan, #fee_japan,#rate_japan').keyup(function(){
		$(this).next('em').html(format_number($(this).val()));
		var price_in_japan = $('#price_in_japan').val();
		var rate_japan = $('#rate_japan').val();
		$('#price_in').val(price_in_japan*rate_japan);
		$('#price_in').next('em').html(format_number(price_in_japan*rate_japan));
	});
	$('#price_in_japan, #fee_japan,#rate_japan').keydown(function(){
		$(this).next('em').html(format_number($(this).val()));
		var price_in_japan = $('#price_in_japan').val();
		var rate_japan = $('#rate_japan').val();
		$('#price_in').val(price_in_japan*rate_japan);
		$('#price_in').next('em').html(format_number(price_in_japan*rate_japan));
	});
	
	$('#status_p').change(function(){
		if($(this).val()==1) $('#num_buy').val(0);
	});
	
	
	$('#is_customer').click(function(){
		if($('#is_customer').is(":checked"))
		{
			$('#form4_customer').show();
			$('#is_customer').val(1);
		}
		else
		{
			$('#form4_customer').hide();
			$('#is_customer').val(0);
		}
	});
	
	$('#is_lazada').click(function(){
		if($('#is_lazada').is(":checked"))
		{
			$('#is_lazada').val(1);
		}
		else
		{
			$('#is_lazada').val(0);
		}
	});
	$('.branch').click(function(){
		var list_branch = $('#list_branch').val();
		var value = $(this).val();
		if($(this).is(":checked"))
		{			
			if(list_branch!='')
			{
				list_branch += ','+value+',';
			}
			else
			{
				list_branch=value+',';
			}
		}
		else
		{
			list_branch = list_branch.replace(value+',','');
			list_branch = list_branch.replace(value,'');
			list_branch = list_branch.replace(','+value,'');
		}
		list_branch = rtrim(list_branch,',');
		$('#list_branch').val(list_branch);
	});
});

function addList(camera_id,status)
{
	tinyMCE.triggerSave();
		
	var title=$('#title').val();
	var introtext=$('#introtext').val();
	//var title_other=$('#title_other').val();
	var publish_date = $('#publish_date').val();
	var picture = $('#filename1').val();
	var html_img = $('#img_0').html();
	var camera_source = $('#camera_source').val();
	var keyword = $('#keyword').val();
	var price = $('#price').val();
	var model_id=$('#model_id').val();
	var list_access_id = $('#list_access_id').val();
	//Info
	var num_p=$('#num_p').val();
	var num_buy = $('#num_buy').val();
	var price_sale=$('#price_sale').val();
	var time_sale=$('#time_sale').val();
	var price_buy=$('#price_buy').val();
	//var info_customer=$('#info').val();	
	//var phu_kien=$('#phu_kien').val();
	//var sale_add=$('#sale_add').val();
	var price_in_japan=$('#price_in_japan').val();
	//var fee_japan=$('#fee_japan').val();
	var rate_japan=$('#rate_japan').val();
	var price_in=$('#price_in').val();
	var fee_vn=$('#fee_vn').val();
	var price_dk=$('#price_dk').val();
	
	var xuat_xu=$('#xuat_xu').val();
	var num_shot=$('#num_shot').val();
	var code=$('#code').val();
	var seri=$('#seri').val();
	var rating=$('#rating').val();
	var time_buy=$('#time_buy').val();
	var time_bh=$('#time_bh').val();
	//var status_p=$('#status_p').val();
	var chinh_hang=$('#chinh_hang').val();
	//var text_chinh_hang=$('#text_chinh_hang').val();
	var note_shot=$('#note_shot').val();
	var info_note=$('#info_note').val();
	var note_private=$('#note_private').val();
	var note_public=$('#note_public').val();
	var brand_id = $('#brand_id').val();
	var is_special = $('#is_special').val();
	var dot_hang = $('#dot_hang').val();
	var list_branch = $('#list_branch').val();
	if(model_id==0)
	{
		alert('Vui lòng chọn model');
		$('#cat_id').focus();
		return false;
	}
	
	var is_seri = 0;
	if($('#is_seri').is(":checked"))
	{
		is_seri=1;
	}		
	
	if(title=='')
	{
		alert('Vui lòng nhập tiêu đề tin');
		$('#title').focus();
		return false;
	}			
	
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addList');?>',
		type: "POST",
		data:({
			camera_id:camera_id,
			title:title,
			brand_id:brand_id,
			//title_other:title_other,
			introtext:introtext,
			publish_date:publish_date,
			picture:picture,
			html_img:html_img,
			camera_source: camera_source,
			keyword:keyword,
			model_id:model_id,
			price:price,
			status:status,
			price_sale:price_sale,
			time_sale:time_sale,
			price_in_japan:price_in_japan,
			//fee_japan:fee_japan,
			rate_japan:rate_japan,
			price_in:price_in,
			fee_vn:fee_vn,
			price_dk:price_dk,
			price_buy:price_buy,
			//info_customer:info_customer,			
			//phu_kien:phu_kien,
			//sale_add:sale_add,
			xuat_xu:xuat_xu,
			num_shot:num_shot,
			code:code,
			seri:seri,
			is_seri:is_seri,
			rating:rating,
			time_buy:time_buy,
			time_bh:time_bh,
			//status_p:status_p,
			chinh_hang:chinh_hang,
			//text_chinh_hang:text_chinh_hang,
			note_shot:note_shot,
			info_note:info_note,
			note_private:note_private,
			note_public:note_public,
			list_access_id:list_access_id,
			is_special:is_special,
			dot_hang:dot_hang,
			list_branch:list_branch
		}),
		success: function(resp){
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
			}
			else
			{
				alert('Lỗi');
			}
		}
	});
}


function addListNew(camera_id,status)
{
	tinyMCE.triggerSave();
	var model_id = $('#model_id').val();
	var brand_id = $('#brand_id').val();
	var body_id = $('#body_id').val();
	var kit_id = $('#kit_id').val();
	var color_id = $('#color_id').val();
	var title = $('#title').val();
	var publish_date = $('#publish_date').val();
	var picture = $('#filename1').val();
	var html_img = $('#img_0').html();
	var camera_source = $('#camera_source').val();
	var keyword = $('#keyword').val();
	var price = $('#price').val();
	var cat_id=$('#cat_id').val();
	var list_access_id = $('#list_access_id').val();
	//var list_access_id2 = $('#list_access_id2').val();
	//Info
	var price_in=$('#price_in').val();
	var price_sale=$('#price_sale').val();
	var time_sale=$('#time_sale').val();
	var time_bh = $('#time_bh').val();
	var price_buy=$('#price_buy').val();
	//var seri=$('#seri').val();	
	//var status_p=$('#status_p').val();
	var rating=$('#rating').val();
	var chinh_hang=$('#chinh_hang').val();
	var is_sale=$('#is_sale').val();
	var in_the_box=$('#in_the_box').val();
	var is_special = $('#is_special').val();
	//var text_chinh_hang = $('#text_chinh_hang').val();
	var note_private=$('#note_private').val();
	var note_public=$('#note_public').val();
	var link_web=$('#link_web').val();
	var list_branch = $('#list_branch').val();
	if($('#model_id').val()==0)
	{
		alert('Vui lòng chọn model cho sản phẩm');
		$('#model_id').focus();
		return false;
	}
	
	if($('#brand_id').val()==0)
	{
		alert('Vui lòng chọn thương hiệu cho sản phẩm');
		$('#model_id').focus();
		return false;
	}
	
	if(title=='')
	{
		alert('Vui lòng nhập tiêu đề tin');
		$('#title').focus();
		return false;
	}
	
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addListNew');?>',
		type: "POST",
		data:({
			camera_id:camera_id,
			title:title,
			model_id:model_id,
			brand_id:brand_id,
			body_id:body_id,
			kit_id:kit_id,
			color_id:color_id,
			picture:picture,
			html_img:html_img,
			camera_source: camera_source,
			keyword:keyword,
			price:price,
			status:status,			
			price_in:price_in,
			price_sale:price_sale,
			time_sale:time_sale,
			time_bh:time_bh,
			price_buy:price_buy,
			rating:rating,
			chinh_hang:chinh_hang,
			is_sale:is_sale,
			//text_chinh_hang:text_chinh_hang,
			list_access_id:list_access_id,
			in_the_box:in_the_box,
			is_special:is_special,
			note_private:note_private,
			note_public:note_public,
			link_web:link_web,
			list_branch:list_branch
		}),
		success: function(resp){
			if(resp>=0)	
			{
				if(camera_id==0)
				{
					//window.location.href='<?php echo Url::createUrl('bList/editNew');?>/camera_id/'+resp;
					alert('Cập nhật thành công!');
					return false;
				}
				alert('Cập nhật thành công!');
				//window.location.href='<?php echo Url::createUrl('bList/index');?>';
				history.go(-1);
			}
			else
			{
				alert('Lỗi');
			}
		}
	});
}
function loadTitle(model_id, brand_id, body_id, kit_id, color_id)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/loadTitle');?>',
		type: "POST",
		data:({
			model_id:model_id,
			brand_id:brand_id,
			body_id:body_id,
			kit_id:kit_id,
			color_id:color_id			
		}),
		success: function(resp){
			if(resp!='')	
			{
				$('#title').val(resp);
			}
			else
			{
				$('#title').val('');
			}
		}
	});
}

function loadInfo(model_id)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/loadInfo');?>',
		type: "POST",
		data:({
			model_id:model_id
		}),
		success: function(resp){
			$('#body_id').html(resp['html_body']);
			$('#kit_id').html(resp['html_kit']);
			$('#color_id').html(resp['html_color']);
			/*
			if(resp['is_chinh_hang']==1)
			{
				$('#is_chinh_hang').show();
			}
			else
			{
				$('#is_chinh_hang').hide();
			}
			*/
		}
	});
}

function addReal(camera_id)
{
	var price_in = $('#price_in').val();
	var seri = $('#seri').val();
	if(seri=='')
	{
		alert('Vui lòng nhập seri sản phẩm thật');
		$('#seri').focus();
		return false;
	}
	if(price_in=='')
	{
		alert('Vui lòng nhập giá nhập sản phẩm thật');
		$('#price_in').focus();
		return false;
	}
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addReal');?>',
		type: "POST",
		data:({
			seri:seri,
			price_in:price_in,
			camera_id:camera_id
		}),
		success: function(resp){
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
			}
			else
			{
				alert('Lỗi');
			}
		}
	});
}

function addSale(camera_id, status_sale)
{
	var price_buy = $('#price_buy').val();	
	var tien_mat = $('#tien_mat').val();
	var chuyen_khoan = $('#chuyen_khoan').val();
	var quet_the = $('#quet_the').val();
	var is_lazada = $('#is_lazada').val();
	var lazada_code = $('#lazada_code').val();
	var customer_id = $('#customer_id').val();
	var is_customer = $('#is_customer').val();
	var title=$('#title').val();
	var mobile=$('#mobile').val();
	var email=$('#email').val();
	var address=$('#address').val();
	var city_id=$('#city_id').val();
	var bill_id=$('#bill_id').val();
	
	if(price_buy=='')
	{
		alert('Vui lòng nhập giá bán');
		$('#price_buy').focus();
		return false;
	}
	if(isNaN(price_buy)){
		alert('Sai định dạng. Giá bán phải là số, không chứa khoảng trắng, dấu chấm, dấu phẩy!');
		$('#price_buy').focus();
		return false;
	}

	if(is_customer==1)
	{
		if($('#title').val()=='')
		{
			alert('Vui lòng nhập tên khách hàng!');
			$('#title').focus();
			return false;
		}
		if($('#mobile').val()=='')
		{
			alert('Vui lòng nhập số điện thoại!');
			$('#mobile').focus();
			return false;
		}
		if($('#address').val()=='')
		{
			alert('Vui lòng nhập địa chỉ!');
			$('#mobile').focus();
			return false;
		}
	}
	
	loadingAjax();	
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addSale');?>',
		type: "POST",
		data:({
			price_buy:price_buy,
			tien_mat:tien_mat,
			chuyen_khoan:chuyen_khoan,
			quet_the:quet_the,
			is_lazada:is_lazada,
			lazada_code:lazada_code,
			status_sale:status_sale,
			customer_id:customer_id,
			is_customer:is_customer,
			title:title,
			mobile:mobile,
			email:email,
			address:address,
			city_id:city_id,
			camera_id:camera_id,
			bill_id:bill_id
		}),
		success: function(resp){
			closeLoadingAjax();
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
		}
	});
}
function format_number(num)
{
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
	num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num*100+0.50000000001);
	cents = num%100;
	num = Math.floor(num/100).toString();
	if(cents<10)
	cents = "0" + cents;
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	num = num.substring(0,num.length-(4*i+3))+','+
	num.substring(num.length-(4*i+3));
	return (((sign)?'':'-') + num);
}

function updateListAccess(access_id)
{
	var list_access_id='';
	$('#list_access_view>div').each(function(){
		if($(this).attr('rel')!=access_id)
		{
			list_access_id += $(this).attr('rel')+',';
		}
	});
	list_access_id=rtrim(list_access_id,',');
	$('#list_access_id').val(list_access_id);
}

function findCustomer(mobile)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/findCustomer');?>',
		type: "POST",
		data:({
			mobile:mobile
		}),
		success: function(resp){
			$('#result_customer').html(resp);
		}
	});
}
function setOneCustomer(customer_id)
{
	$('#customer_id').val(customer_id);
	$('#is_customer').val(0);
	$('#is_customer').removeAttr('checked');
	$('#form4_customer').hide();
}
</script>