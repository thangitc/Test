<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab');?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div style="border-right:1px solid #ccc" class="col55">
                                    <ul class="form">
                                    	<li class="clearfix"><label><strong>Chọn Model :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="model_id" id="model_id" onchange="loadInfo($(this).val());">
                                                	<option value="0" selected="selected">--Chọn Model--</option>
                                                    
                                                    <?php
													if($models)
													foreach($models as $row)
													{
														?>
                                                        <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                                        <?php
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        <li class="clearfix" id="is_chinh_hang"><label><strong>Chính hãng</strong></label>
                                            <div class="filltext">
                                            <select style="width:179px" id="chinh_hang" name="chinh_hang">
                                            	<option value="0">Nhập khẩu</option>
                                                <option value="1">Chính hãng</option>
                                                <option value="2">Công ty</option>
                                            </select>
                                            
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Chọn thương hiệu :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="brand_id" id="brand_id">
                                                	<option value="0" selected="selected">--Chọn Thương hiệu--</option>
                                                    
                                                    <?php
													if($brand)
													foreach($brand as $row)
													{
														if($row['brand_type']==0)
														{
															?>
                                                            <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                                            <?php	
														}
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        <!--
                                        <li class="clearfix"><label><strong>Text chính hãng :</strong></label>
                                            <div class="filltext">
                                                <input name="text_chinh_hang" id="text_chinh_hang" type="text" style="width:100%;" >
                                            </div>
                                        </li>
                                        -->
                                        <li class="clearfix"><label><strong>Tên sản phẩm :</strong></label>
                                            <div class="filltext">
                                                <input name="title" id="title" type="text" style="width:100%;" >
                                                <a href="javascript:" onclick="loadTitle($('#model_id').val(),0,0,0,0);">Show Title</a>
                                            </div>
                                        </li>                                        
                                        <!--
                                        <li class="clearfix"><label><strong>Tiêu khác :</strong></label>
                                            <div class="filltext">
                                                <input name="title_other" id="title_other" type="text" style="width:100%;">
                                            </div>
                                        </li>
                                        -->
                                        <li class="clearfix bor-bottom"><label><strong>Ảnh đại diện:</strong></label>
                                            <div class="filltext">            
                                            	<input type="text" id="filename1" name="filename1" readonly/>&nbsp;
                                                <span id="spanButtonPlaceHolder"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_0">
                                            	
                                            </div>
                                        </li>
										<li class="clearfix"><label><strong>Tóm tắt(Product Highlights):</strong> </label>
                                            <div class="filltext">
                                                <textarea style="width: 518px; height: 85px;" rows="5" cols="10" name="introtext" id="introtext"></textarea>
                                            </div>                                            
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Include Free(Phụ kiện miễn phí):</strong>  </label>
                                            <input type="hidden" id="list_access_id" name="list_access_id">
                                            <div class="filltext">
                                                <a id="showAccess" href="<?php echo Url::createUrl("access/showAccess", array('tab'=>2));?>" class="cboxElement"><input type="button" class="buton-radi" value="Chọn" style="margin-right:10px;"></a>
                                                <div id="list_access_view">
                                                    
                                                </div>                                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Xuất xứ:</strong> </label>
                                            <div class="filltext">
                                                <input type="text" style="width:170px"  id="xuat_xu" name="xuat_xu">
                                            </div>                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Shot:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="num_shot" name="num_shot">
                                            
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Note Shot:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="note_shot" name="note_shot">
                                            
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Code:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="code" name="code">
                                            
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Seri:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="seri" name="seri">
                                            
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Show Seri:</strong></label>
                                            <div class="filltext">
                                            <input type="checkbox" id="is_seri" name="is_seri" />
                                            
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Xếp hạng: </strong></label>
                                            <div class="filltext">
                                                <select style="width:206px" id="rating" name="rating">
                                                    <option value="0">--Chọn loại--</option>
                                                    <?php
                                                    $arr_rating = LoadConfig::$arr_rating;
                                                    if($arr_rating)
                                                    foreach($arr_rating as $key=>$value)
                                                    {
                                                        ?>
                                                        <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Loại sản phẩm: </strong></label>
                                            <div class="filltext">
                                                <select style="width:206px" id="is_special" name="is_special">
                                                    <option value="0">--Chọn loại--</option>
                                                    <?php
                                                    $arr_special = LoadConfig::$arr_special;
                                                    if($arr_special)
                                                    foreach($arr_special as $key=>$value)
                                                    {
                                                        ?>
                                                        <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Thời gian bán:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="time_buy" name="time_buy">
                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Thời gian bảo hành:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="time_bh" name="time_bh">
                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Ngày đăng tin:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="publish_date" name="publish_date">
                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix">
                                            <label><strong>Video</strong></label>
                                            <div class="filltext">
                                                <input type="text" id="camera_source" name="camera_source" style="width:100%;" />
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Từ khóa</strong></label>
                                            <div class="filltext">
                                                <input type="text" id="keyword" name="keyword" style="width:100%;" />
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Ghi chú hiển thị:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="height: 152px; width: 322px;" rows="5" cols="10" name="note_public" id="note_public"></textarea>
                                            </div>                                            
                                        </li>
                                    </ul>
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addList(0,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addList(0,'draft');"> &nbsp; </p>
                                    
                                    <div id="result">
                                    </div>
                                    
                                </div>
                                
                                <div class="col2">&nbsp;</div>
                                <div class="col40">
                                    <ul class="form1">
                                        <li class="clearfix"><label><strong>Giá hiển thị:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price" name="price" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá khuyến mại:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_sale" name="price_sale" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Thời gian khuyến mại:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="time_sale" name="time_sale">
                                            
                                            </div>
                                        </li>
                                        <hr />
                                        <li class="clearfix"><label><strong>Giá nhập (J):</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_in_japan" name="price_in_japan" style="width:170px">
                                                <em style="color:red;"></em> JPY
                                                </div>
                                            </div>
                                        </li>
                                        <!--
                                        <li class="clearfix"><label><strong>Phí vận chuyển nội địa (J):</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="fee_japan" name="fee_japan" style="width:170px">
                                                <em style="color:red;"></em> JPY
                                                </div>
                                            </div>
                                        </li>
                                        -->
                                        <li class="clearfix"><label><strong>Tỷ giá:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="rate_japan" name="rate_japan" style="width:170px">
                                                <em style="color:red;"></em>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Giá nhập (V):</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_in" name="price_in" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Phí vận chuyển:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="fee_vn" name="fee_vn" style="width:170px">
                                                <em style="color:red;"></em> VND
                                                </div>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Giá bán chỉ tiêu (10%):</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                	<em style="color:red;" id="price_ct"></em> VND
                                                </div>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Giá bán dự kiến:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_dk" name="price_dk" style="width:170px">
                                                <em style="color:red;"></em> VND
                                                </div>
                                            </div>
                                        </li>
                                        <!--
                                        <li class="clearfix"><label><strong>Giá bán:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_buy" name="price_buy" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        -->
                                        <hr />
                                        <li class="clearfix"><label><strong>Ghi chú:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="height: 152px; width: 322px;" rows="5" cols="10" name="info_note" id="info_note"></textarea>
                                            </div>                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Ghi chú nội bộ:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="height: 152px; width: 322px;" rows="5" cols="10" name="note_private" id="note_private"></textarea>
                                            </div>                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Đợt hàng:</strong> </label>
                                            <div class="filltext">
                                                <input type="text" name="dot_hang" id="dot_hang" style="width:170px" />
                                            </div>                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Chi nhánh:</strong> </label>
                                            <div class="filltext">
                                            <?php
											$list_chi_nhanh = LoadConfig::$list_chi_nhanh;
											if($list_chi_nhanh)
											foreach($list_chi_nhanh as $key=>$value)
											{
												$checked = '';
												if($key==0) $checked = 'checked';
												?>
                                                <input <?php echo $checked;?> type="checkbox" value="<?php echo $key;?>" class="branch" /> <?php echo $value?>
                                                <?php
											}
                                            ?>
                                            <input type="hidden" value="0" id="list_branch" />
                                            </div>                                            
                                        </li>
                                    </ul>
                                    
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addList(0,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addList(0,'draft');"> &nbsp; </p>
                                </div>
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php //$this->renderPartial('application.views.bBody.js_model');?>