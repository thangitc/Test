<script>
function updateSaleList(sale_id,camera_id)
{
	var price_buy = $('#price_buy').val();
	var price_in = $('#price_in').val();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/updateSaleList');?>',
		type: "POST",
		data:({
			camera_id:camera_id,  
			sale_id:sale_id,
			price_buy:price_buy,
			price_in:price_in
		}),
		success: function(resp){
			closeLoadingAjax();
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
		}
	});
}
$(function(){
	//format_number
	$('#price,#price_in,#price_sale,#price_buy,#tien_mat,#chuyen_khoan,#quet_the,#fee_vn,#price_dk').keypress(function(){
		$(this).next('em').html(format_number($(this).val()));
		var price_in_after = parseFloat($('#price_in').val());
		var fee_vn = parseFloat($('#fee_vn').val());	
		price_in_after = (price_in_after+fee_vn)*110/100;
		$('#price_ct').html(format_number(price_in_after));
	});
	$('#price,#price_in,#price_sale,#price_buy,#tien_mat,#chuyen_khoan,#quet_the,#fee_vn,#price_dk').keyup(function(){
		$(this).next('em').html(format_number($(this).val()));
		var price_in_after = parseFloat($('#price_in').val());
		var fee_vn = parseFloat($('#fee_vn').val());	
		price_in_after = (price_in_after+fee_vn)*110/100;
		$('#price_ct').html(format_number(price_in_after));
	});
	$('#price,#price_in,#price_sale,#price_buy,#tien_mat,#chuyen_khoan,#quet_the,#fee_vn,#price_dk').keydown(function(){
		$(this).next('em').html(format_number($(this).val()));
		var price_in_after = parseFloat($('#price_in').val());
		var fee_vn = parseFloat($('#fee_vn').val());	
		price_in_after = (price_in_after+fee_vn)*110/100;
		$('#price_ct').html(format_number(price_in_after));
	});
});

function format_number(num)
{
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
	num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num*100+0.50000000001);
	cents = num%100;
	num = Math.floor(num/100).toString();
	if(cents<10)
	cents = "0" + cents;
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	num = num.substring(0,num.length-(4*i+3))+','+
	num.substring(num.length-(4*i+3));
	return (((sign)?'':'-') + num);
}
</script>
<div class="body_pages clearfix">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
<tbody>
<tr>
    <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
    <td valign="top" class="last">
        <div class="content_pages">
        <?php $this->renderPartial('tab', array('camera_id'=>$camera_info['id']));?>
        <div class="box_form">
		<div class="box bottom30 clearfix">
        <div class="box bottom30 clearfix">
            <p><strong class="s14 clblue"><?php if($camera_info) echo $camera_info['title'];?></strong></p>
            <ul class="form4">
                
                <li class="clearfix"><label><strong>Giá bán :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="price_buy" name="price_buy" value="<?php echo $detail['price_buy'];?>">
                    <em style="color:red;"><?php echo Common::formatNumber($detail['price_buy']);?></em> VNĐ 
                    </div>
                </li>
                <li class="clearfix"><label><strong>Giá nhập :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="price_in" name="price_in" value="<?php echo $detail['price_in'];?>">
                    <em style="color:red;"><?php echo Common::formatNumber($detail['price_in']);?></em> VNĐ 
                    </div>
                </li>
                <li class="clearfix"><label>&nbsp;</label>
                    <div class="filltext">
                    <input type="button" class="buton-radi" value="Cập nhật" onclick="updateSaleList(<?php echo $detail['id'];?>, <?php echo $detail['camera_id'];?>);">
                    </div>
                </li>
                <li style="color:red;" id="result"></li>
            </ul>
        </div>
        </div>
        
        </div> 
            <?php $this->renderPartial('application.views.static.footer');?>
        </div>
    </td>
</tr>
</tbody>
</table>
</div>