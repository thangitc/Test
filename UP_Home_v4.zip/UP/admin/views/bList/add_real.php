<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab');?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                            	
                                <div style="border-right:1px solid #ccc" class="col55">
                                    <ul class="form">
                                    	<li>
                                            <strong style="font-size:20px;">Thêm sản phẩm thật(Add Serie)</strong>
                                            <br />
                                        </li>
                                        <li class="clearfix"><label><strong>Tên sản phẩm :</strong></label>
                                            <div class="filltext">
                                                <?php echo $detail['title'];?>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Số Seri:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:550px"  id="seri" name="seri">
                                            (Danh sách seri cách nhau dấu phẩy)
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá nhập:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_in" name="price_in" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                    </ul>
                                    <p><input type="button" value="Thêm" class="btn-orange" onclick="addReal(<?php echo $detail['id'];?>);"> </p>
                                    
                                    <div id="result">
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>