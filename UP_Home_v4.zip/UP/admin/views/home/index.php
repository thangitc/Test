<?php
	/*
    if(isset($_SERVER["HTTP_HOST"]) && $_SERVER["HTTP_HOST"]=="localhost"){
		Yii::app()->user->id = 1;
		Yii::app()->user->name ='admin';
	}
	*/
    $user_id=Yii::app()->user->id;
    $permit=AdminAuthassignment::getPermitByUser($user_id);
?>

<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tr>
            <td class="first" valign="top"><?php $this->renderPartial('application.views.static.sidebar') ;  ?></td>
            <td valign="top" class="last"><div class="content_pages">
                    <?php if($user_id!=1){ ?>
                    <div class="admin clearfix">
                        <?php if(isset($permit[1]) || isset($permit[2]) || isset($permit[3]) || isset($permit[4]) || isset($permit[5]) || isset($permit[6]) || isset($permit[7]) || isset($permit[8]) || isset($permit[9]) || isset($permit[10]) || isset($permit[15]) || isset($permit[16]) || isset($permit[19]) || isset($permit[25])){ ?>
                       
                        <div class="col30">
                            <h1><strong>Quản lý CAMERA</strong></h1>
                            <ol>
                            	<?php if(isset($permit[1])) { ?>
                            	<li><a href="<?php echo Url::createUrl('cat/index');?>">Danh mục</a></li>
                                <?php } ?>
                                <?php if(isset($permit[2])) { ?>
                                <li><a href="<?php echo Url::createUrl('bList/index');?>">Danh sách CAMERA</a></li>
                                <?php } ?>
                                <?php if(isset($permit[3])) { ?>
                                <li><a href="<?php echo Url::createUrl('bModel/index');?>">QL Model</a></li>
                                <?php } ?>
                                <?php if(isset($permit[8])) { ?>
                                <li><a href="<?php echo Url::createUrl('access/index');?>">QL Phụ kiện</a></li>
                                <?php } ?>
                                <?php if(isset($permit[25])) { ?>
                                <li><a href="<?php echo Url::createUrl('combos/index');?>">COMBOS</a></li>
                                <?php } ?>
                                <?php if(isset($permit[5])) { ?>
                                <li><a href="<?php echo Url::createUrl('bBrand/index');?>">QL Brand</a></li>
                                <?php } ?>
                                <?php if(isset($permit[4])) { ?>
                                <li><a href="<?php echo Url::createUrl('bBody/index');?>">QL Body</a></li>
                                <?php } ?>
                                <?php if(isset($permit[7])) { ?>
                                <li><a href="<?php echo Url::createUrl('bKit/index');?>">QL Combo Kit</a></li>
                                <?php } ?>
                                <?php if(isset($permit[6])) { ?>
                                <li><a href="<?php echo Url::createUrl('bColor/index');?>">QL Color</a></li>
                                <?php } ?>
                                <?php if(isset($permit[14])) { ?>
                                <li><a href="<?php echo Url::createUrl('bTimeline/index');?>">QL Timeline</a></li>
                                <?php } ?>
                                <?php if(isset($permit[9])) { ?>
                                <li><a href="<?php echo Url::createUrl('cart/index');?>">QL Giỏ hàng</a></li>
                                <?php } ?>
                                <?php if(isset($permit[24])) { ?>
                                <li><a href="<?php echo Url::createUrl('bill/index');?>">QL Hóa đơn</a></li>
                                <?php } ?>
                                <?php if(isset($permit[10])) { ?>
                                <li><a href="<?php echo Url::createUrl('subscribe/index');?>">QL Email Subscribe</a></li>
                                <?php } ?>
                                
                                <?php if(isset($permit[15])) { ?>
                                <li><a href="<?php echo Url::createUrl('ads/index');?>">QL Quảng cáo</a></li>
                                <?php } ?>
                                 <?php if(isset($permit[16])) { ?>
                                <li><a href="<?php echo Url::createUrl('customer/index');?>">QL Khách hàng</a></li>
                                <?php } ?>
                                <?php if(isset($permit[19])) { ?>
                                <li><a href="<?php echo Url::createUrl('analytics/chart');?>">Thống kê</a></li>
                                <!--<li class="last"><a href="<?php echo Url::createUrl('export/all');?>">Excel Hàng tồn</a></li>-->
                                <?php } ?>
                            </ol>
                        </div>
                        <?php } ?>
                        <?php if(isset($permit[11]) || isset($permit[12])  || isset($permit[13]) || isset($permit[22])){ ?>
                        <div class="col30">
                            <h1><strong>QUẢN LÝ TIN TỨC</strong></h1>
                            <ol>
                                <?php if(isset($permit[11])) { ?>
                                <li><a href="<?php echo Url::createUrl('news/index');?>">Danh sách Tin</a></li>
                                <li><a href="<?php echo Url::createUrl('news/add');?>">Thêm mới Tin</a></li>
                                <?php } ?>
                                <?php if(isset($permit[12])) { ?>
                                <li><a href="<?php echo Url::createUrl('topic/index');?>">DS Chuyên đề</a></li>
                                <li class="last"><a href="<?php echo Url::createUrl('topic/add');?>">Thêm mới chuyên đề</a></li>
                                <?php } ?>
                                <?php if(isset($permit[22])) { ?>
                                <li><a href="<?php echo Url::createUrl('bStaticContent/edit/static_id/1');?>">Sửa Liên hệ</a></li>
                                <?php } ?>
                                <li class="last"><a href="<?php echo Url::createUrl('bContact/edit/contact_id/1');?>">QL Liên hệ</a></li>
                            </ol>
                        </div>
                        <?php } ?>
                        
                        <?php if(isset($permit[21])){ ?>
                        <div class="col30">
                            <h1><strong>QUẢN LÝ TÀI KHOẢN ADMIN</strong></h1>
                            <ol>
                                <li><a href="<?php echo Url::createUrl('admin/index');?>">DS tài khoản Admin</a></li>
                                <li class="last"><a href="<?php echo Url::createUrl('admin/add');?>">Thêm mới tài khoản Admin</a></li>
                            </ol>
                        </div>
                        <?php }?>
                        <?php if(isset($permit[100])){ ?>
                        <div class="col30">
                            <h1><strong>QUẢN LÝ LOGS</strong></h1>
                            <ol>
                                <li><a href="<?php echo Url::createUrl('logs/index');?>">Logs</a></li>
                            </ol>
                        </div>
                        <?php } ?>
                        
                        <div class="col30">
                            <h1><strong>Giỏ hàng</strong></h1>
                            <ol>
                            	<?php
								if($total_order)
								foreach($total_order as $row)
								{
									if($row['order_status']=='pending' && $row['total']!=0)
									{
										?>
                                        <li><strong><a style="color:red;" href="<?php echo Url::createUrl('cart/index',array('order_status'=>'pending'));?>">Đơn hàng mới</a></strong>(<?php echo $row['total'];?>)</li>
                                        <?php
										break;
									}
									
								}
								if($total_order)
								foreach($total_order as $row)
								{
									if($row['order_status']=='processing' && $row['total']!=0)
									{
										?>
                                        <li><strong><a style="color:blue;" href="<?php echo Url::createUrl('cart/index',array('order_status'=>'processing'));?>">Đang xử lý</a></strong>(<?php echo $row['total'];?>)</li>
                                        <?php
										break;
									}
									
								}
								if($total_order)
								foreach($total_order as $row)
								{
									if($row['order_status']=='completed' && $row['total']!=0)
									{
										?>
                                        <li><strong><a href="<?php echo Url::createUrl('cart/index',array('order_status'=>'completed'));?>">Hoàn thành</a></strong>(<?php echo $row['total'];?>)</li>
                                        <?php
									}
									else if($row['order_status']=='canceled' && $row['total']!=0)
									{
										?>
                                        <li><strong><a href="<?php echo Url::createUrl('cart/index',array('order_status'=>'canceled'));?>">Cancel</a></strong>(<?php echo $row['total'];?>)</li>
                                        <?php
									}
								}
                                ?>
                                
                            </ol>
                        </div>
                        <div class="col30">
                            <textarea style="width: 358px; height: 161px;" onkeypress="updateNotes($(this).val());" onchange="updateNotes($(this).val());"><?php echo $notes;?></textarea>
                        </div>
                        
                    </div>
                    <?php } else if($user_id==1){ ?>
                    <div class="admin clearfix">
                    	<div class="col30">
                            <h1><strong>Quản lý CAMERA</strong></h1>
                            <ol>
                                <li><a href="<?php echo Url::createUrl('cat/index');?>">Danh mục</a></li>
                                <li><a href="<?php echo Url::createUrl('bList/index');?>">Danh sách CAMERA</a></li>
                                <li><a href="<?php echo Url::createUrl('bModel/index');?>">QL Model</a></li>
                                <li><a href="<?php echo Url::createUrl('access/index');?>">QL Phụ kiện</a></li>
                                <li><a href="<?php echo Url::createUrl('combos/index');?>">COMBOS</a></li>
                                <li><a href="<?php echo Url::createUrl('bBrand/index');?>">QL Brand</a></li>
                                <li><a href="<?php echo Url::createUrl('bBody/index');?>">QL Body</a></li>
                                <li><a href="<?php echo Url::createUrl('bKit/index');?>">QL Combo Kit</a></li>
                                <li><a href="<?php echo Url::createUrl('bColor/index');?>">QL Color</a></li>
                                <li><a href="<?php echo Url::createUrl('bTimeline/index');?>">QL Timeline</a></li>
                                <li><a href="<?php echo Url::createUrl('cart/index');?>">QL Giỏ hàng</a></li>
                                <li><a href="<?php echo Url::createUrl('bill/index');?>">QL Hóa đơn</a></li>
                                <li><a href="<?php echo Url::createUrl('subscribe/index');?>">QL Email Subscribe</a></li>
                                <li><a href="<?php echo Url::createUrl('bStaticContent/edit/static_id/1');?>">Sửa Liên hệ</a></li>
                                <li><a href="<?php echo Url::createUrl('ads/index');?>">QL Quảng cáo</a></li>
                                <li><a href="<?php echo Url::createUrl('customer/index');?>">QL Khách hàng</a></li>
                                <li><a href="<?php echo Url::createUrl('analytics/index');?>">Thống kê</a></li>
                                <li class="last"><a href="<?php echo Url::createUrl('export/all');?>">Excel Hàng tồn</a></li>
                            </ol>
                        </div>
                        <div class="col30">
                            <h1><strong>Quản lý Tin Tức</strong></h1>
                            <ol>
                            	<li><a href="<?php echo Url::createUrl('news/index');?>">Danh sách Tin</a></li>
                            	<li><a href="<?php echo Url::createUrl('news/add');?>">Thêm mới Tin</a></li>
                                <li><a href="<?php echo Url::createUrl('topic/index');?>">DS Chuyên đề</a></li>
                                <li><a href="<?php echo Url::createUrl('topic/add');?>">Thêm mới chuyên đề</a></li>
                                <li class="last"><a href="<?php echo Url::createUrl('bContact/edit/contact_id/1');?>">QL Liên hệ</a></li>
                            </ol>
                        </div>
                        <div class="col30">
                            <h1><strong>QUẢN LÝ TÀI KHOẢN ADMIN</strong></h1>
                            <ol>
                                <li><a href="<?php echo Url::createUrl('admin/index');?>">DS tài khoản Admin</a></li>
                                <li class="last"><a href="<?php echo Url::createUrl('admin/add');?>">Thêm mới tài khoản Admin</a></li>
                            </ol>
                        </div>
                        <div class="col30">
                            <h1><strong>QUẢN LÝ LOGS</strong></h1>
                            <ol>
                                <li><a href="<?php echo Url::createUrl('logs/index');?>">Logs</a></li>
                            </ol>
                        </div>
                        <div class="col30">
                            <h1><strong>Giỏ hàng</strong></h1>
                            <ol>
                            	<?php
								if($total_order)
								foreach($total_order as $row)
								{
									if($row['order_status']=='pending' && $row['total']!=0)
									{
										?>
                                        <li><strong><a style="color:red;" href="<?php echo Url::createUrl('cart/index',array('order_status'=>'pending'));?>">Đơn hàng mới</a></strong>(<?php echo $row['total'];?>)</li>
                                        <?php
										break;
									}
									
								}
								if($total_order)
								foreach($total_order as $row)
								{
									if($row['order_status']=='processing' && $row['total']!=0)
									{
										?>
                                        <li><strong><a style="color:blue;" href="<?php echo Url::createUrl('cart/index',array('order_status'=>'processing'));?>">Đang xử lý</a></strong>(<?php echo $row['total'];?>)</li>
                                        <?php
										break;
									}
									
								}
								if($total_order)
								foreach($total_order as $row)
								{
									if($row['order_status']=='completed' && $row['total']!=0)
									{
										?>
                                        <li><strong><a href="<?php echo Url::createUrl('cart/index',array('order_status'=>'completed'));?>">Hoàn thành</a></strong>(<?php echo $row['total'];?>)</li>
                                        <?php
									}
									else if($row['order_status']=='canceled' && $row['total']!=0)
									{
										?>
                                        <li><strong><a href="<?php echo Url::createUrl('cart/index',array('order_status'=>'canceled'));?>">Cancel</a></strong>(<?php echo $row['total'];?>)</li>
                                        <?php
									}
								}
                                ?>
                                
                            </ol>
                        </div>
                        <div class="col30">
                            <textarea style="width: 358px; height: 161px;" onkeypress="updateNotes($(this).val());" onchange="updateNotes($(this).val());"><?php echo $notes;?></textarea>
                        </div>
                    </div>
                    <?php } ?>
                    <?php $this->renderPartial('application.views.static.footer') ;  ?>
                </div></td>
        </tr>
    </table>
</div>
<script>
function updateNotes(notes)
{
	//loadingAjax();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/updateNotes');?>',
		type: "POST",
		data:({
			notes:notes
		}),
		success: function(resp){
			//closeLoadingAjax();
		}
	});
}
</script>
