<div style="width: 470px; display: block;" class="popup">
    <h3><span><strong>Chuyển tất cả tin đã chọn sang dang mục khác </strong></span></h3>
    <div class="popup-cont clearfix">
        <ul class="form1">
            <li class="clearfix">
                <label><strong>Chọn lại danh mục </strong></label>
                <div class="filltext">
                    <select style="width:206px" onchange="$('#cat_id').val($(this).val());">
                        <option value="0">- Chọn danh mục -</option>
                        <?php
                            if($categories)
							{
                                foreach($categories as $row)
                                {
                                    if($row['parent_id']==0 && $row['cat_type']==2)
                                    {
                                        $parent_id=$row['id'];

										?>
										<option value="<?php echo $row['id'];?>" <?php echo $cat_id == $row['id'] ? 'selected="selected"' : ''; ?>><?php echo $row['title'];?></option>
										<?php
                                        foreach($categories as $row2)
                                        {
                                            if($row2['parent_id']==$parent_id)
                                            {
                                                $parent_id_2=$row2['id'];

                                            ?>
                                            <option value="<?php echo $row2['id'];?>" <?php echo $cat_id == $row2['id'] ? 'selected="selected"' : ''; ?>>--<?php echo $row2['title'];?></option>
                                            <?php
                                                foreach($categories as $row3)
                                                {
                                                    if($row3['parent_id']==$parent_id_2) {
                                                    ?>
                                                    <option value="<?php echo $row3['id'];?>" <?php echo $cat_id == $row3['id'] ? 'selected="selected"' : ''; ?>>----<?php echo $row3['title'];?></option>
                                                    <?php
                                                    }
                                                }
                                            }
                                        }
                                    }
								}
                            }
                        ?>
                    </select>
                    <input type="hidden" id="cat_id" name="cat_id" />
                </div>
            </li>
            <li class="clearfix">
                <label>&nbsp;</label>
                <div class="filltext">
                    <input type="button" value="&nbsp; OK &nbsp;" onclick="moveCatNews();"class="buton-radi">
                </div>
            </li>
        </ul>
    </div>
</div>