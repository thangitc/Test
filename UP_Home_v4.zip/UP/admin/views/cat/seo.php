<script>
    $(function(){
        $('#submit').click(function(){
            var cid=$('#cid').val();
            $.ajax({
                url: '<?php echo Url::createUrl('ajax/seoCat');?>',
                type: "POST",
                data:({
                    cid:cid,
                    meta_title:$('#meta_title').val(),
                    meta_keyword:$('#meta_keyword').val(),
                    meta_description:$('#meta_description').val(),
                    bottom_des:$('#bottom_des').val(),
                    top_des:$('#top_des').val(),
                    //title_box_above:$('#title_box_above').val(),
                    //content_box_above:$('#content_box_above').val(),
                    //title_box_below:$('#title_box_below').val(),
                    //content_box_below:$('#content_box_below').val(),
                    meta_is_index:$('#meta_is_index').val(),
                    meta_is_follow:$('#meta_is_follow').val()
                }),
                success: function(resp){
                    var result = jQuery.parseJSON(resp);
                    if(result!= null && result.status == "noPermis"){
                        alert("Bạn không đủ quyền thực hiện hành động này.");
                        return false;                
                    }

                    if(resp['status']=='false')    
                        $('#result_seo').html(resp['error']);
                    else
                        {
                        $('#result_seo').css('color','blue');
                        $('#result_seo').html(resp['error']);
                    }
                }
            });                                
        });
        $('#meta_is_index,#meta_is_follow').click(function(){
            if($(this).is(":checked"))
                $(this).val(1);
            else
                $(this).val(0);
        });
    });
    
function showFormEditSeo()
{
    var cid=$('#cid').val();
    if(!cid)
    {
        alert('Bạn chưa chọn danh mục để sửa!');
        return false;
    }
    else
    $.ajax({
        url: '<?php echo Url::createUrl('ajax/showFormEditCate');?>',
        type: "POST",
        data:({
            cid:cid
        }),
        success: function(resp){
            var result = jQuery.parseJSON(resp);
            if(result!= null && result.status == "noPermis"){
                alert("Bạn không đủ quyền thực hiện hành động này.");
                return false;                
            }
            
            //Load thong tin ra form
            $('#meta_title').val(resp['meta_title']);
            $('#meta_description').val(resp['meta_description']);
            $('#bottom_des').val(resp['bottom_des']);
            $('#top_des').val(resp['top_des']);
            $('#meta_keyword').val(resp['meta_keyword']);
            $('#meta_is_follow').val(resp['meta_is_follow']);
            $('#meta_is_index').val(resp['meta_is_index']);
            if(resp['meta_is_follow']==1)
            {
                $('#meta_is_follow').attr('checked','checked');
            }
            else
            {
                $('#meta_is_follow').removeAttr('checked');
            }
            if(resp['meta_is_index']==1)
            {
                $('#meta_is_index').attr('checked','checked');
            }
            else
            {
                $('#meta_is_index').removeAttr('checked');
            }
            
        }
    });
    
    $('#cid').val(cid);
}

</script>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?> 
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <div class="box_tab">
                            <?php $this->renderPartial('path_way');?>
                        </div>
                        <div class="box_form">  
                            <div class="box bottom30">
                                <ul class="form">
                                    <li class="clearfix">
                                        <label><strong>Tên danh mục: </strong></label>
                                        <div class="filltext">
                                            <!--<select onchange="showFormEditSeo();" id="cid" name="cid" style="width:210px">
                                            <option>--Chọn Danh Mục--</option>
                                            <?php if($cats)
												foreach($cats as $row)
												{                                                      
												   if($row['parent_id']==0) echo "<option  value='".$row['id']."'>".$row['title']." </option>" ; ?> 
													
												  <?php foreach($cats as $row2)
													{   
												?>
										   <?php if ($row2['parent_id'] == $row['id']) echo " <option  value='".$row2['id']."'>-- ".$row2['title']."</option>"; ?>
																				 
												<?php } 
												}
											?>
                                            </select>-->
                                            <select onchange="showFormEditSeo();" id="cid" name="cid" style="width:210px">
                                                <option value="0">--Chọn Danh Mục--</option>
                                                <?php
                                                    $selected='';
                                                    if($cats)
                                                        foreach($cats as $row)
                                                        {
                                                            if($row['parent_id']==0)
                                                            {
                                                                $parent_id=$row['id'];

                                                            ?>
                                                            <option value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
                                                            <?php
                                                                foreach($cats as $row2)
                                                                {
                                                                    if($row2['parent_id']==$parent_id)
                                                                    {
                                                                        $parent_id_2=$row2['id'];

                                                                    ?>
                                                                    <option value="<?php echo $row2['id'];?>">--<?php echo $row2['title'];?></option>
                                                                    <?php
                                                                        foreach($cats as $row3)
                                                                        {
                                                                            if($row3['parent_id']==$parent_id_2) {
                                                                            ?>
                                                                            <option value="<?php echo $row3['id'];?>">----<?php echo $row3['title'];?></option>
                                                                            <?php
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                    }
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Title Tag:</strong></label>
                                        <div class="filltext">
                                            <input type="text" id="meta_title" name="meta_title" style="width:45%" value="">
                                        </div>
                                    </li>

                                    <li class="clearfix">
                                        <label><strong>Meta Description:</strong></label>
                                        <div class="filltext">
                                            <textarea style="width:45%; height:45%" rows="5" cols="5" id="meta_description"></textarea>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Top Des:</strong></label>
                                        <div class="filltext">
                                            <textarea style="width:45%; height:45%" rows="5" cols="5" id="top_des"></textarea>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Bottom Des:</strong></label>
                                        <div class="filltext">
                                            <textarea style="width:45%; height:45%" rows="5" cols="5" id="bottom_des"></textarea>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label><strong>Meta Keywords</strong><p>(separate with commas):</p></label>
                                        <div class="filltext">
                                            <input type="text" name="meta_keyword" id="meta_keyword" style="width:45%" value="">
                                        </div>
                                    </li>
                                    <!--
                                    <li class="clearfix">
                                        <label><strong>Meta Robots Tag :</strong></label>
                                        <div class="filltext">
                                            <p><input type="checkbox" name="meta_is_index"  id="meta_is_index" value="0">Noindex: Tell search engines not to index this webpage.</p>
                                            <p> <input type="checkbox" name="meta_is_follow"  id="meta_is_follow" value="0">NoFollow: Tell search engines not to index this webpage.</p>
                                        </div>
                                    </li>
                                    -->
                                    <li class="clearfix">
                                        <label>&nbsp;</label>
                                        <div class="filltext">
                                            <input type="button" id="submit" value="Cập nhật" class="btn-orange">
                                            <input type="hidden" id="cid" name="cid" />
                                        </div>
                                    </li>
                                    <li class="clearfix" id="result_seo" style="color:red;">

                                    </li>
                                </ul>           
                            </div>
                        </div>
                        <?php $this->renderPartial('application.views.static.footer') ;  ?> 
                    </div> 
                </td>
            </tr>
        </tbody>
    </table>
        </div>
