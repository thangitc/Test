<?php
$action_id = Yii::app()->controller->action->id;
$controller_id = Yii::app()->controller->id;
?>
<ul class="clearfix">
<li <?php if($action_id=='index') echo 'class="fl active"'; else echo 'class="fl"';?>><span><a href="<?php echo Url::createUrl('cat/index');?>">Danh mục</a></span></li>
<li <?php if($action_id=='orderMenu') echo 'class="fl active"'; else echo 'class="fl"';?>><span><a href="<?php echo Url::createUrl('cat/orderMenu');?>">DM menu ngang</a></span></li>
<li <?php if($action_id=='orderCatHome') echo 'class="fl active"'; else echo 'class="fl"';?>><span><a href="<?php echo Url::createUrl('cat/orderCatHome');?>">DM trang chủ</a></span></li>
<li <?php if($action_id=='orderCatHomeBottom') echo 'class="fl active"'; else echo 'class="fl"';?>><span><a href="<?php echo Url::createUrl('cat/orderCatHomeBottom');?>">DM trang chủ (Bottom)</a></span></li>
<li <?php if($action_id=='seo') echo 'class="fl active"'; else echo 'class="fl"';?>><span><a  href="<?php echo Url::createUrl('cat/seo');?>">Seo DM Tin</a></span></li>
</ul>