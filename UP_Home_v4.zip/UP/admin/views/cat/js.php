<link rel="stylesheet" href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.widget.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.mouse.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.sortable.js"></script>

<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['tiny_url'];?>/js/tinymce_des.js"></script>

<link rel="stylesheet" href="<?php echo Yii::app()->params['upload_url'];?>/css/swfupload.css" type="text/css" />
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.queue.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/fileprogress.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers_cat.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers_file.js"></script>

<script>
$(function(){
	$('#img_0').sortable();
	window.onload = function() {
		var configUploadData = {
			upload_url: upload_url_new+"upload_cat.php"
			, create_date:'<?php $create_date=isset($detail["create_date"])? $detail["create_date"]:''; echo $create_date;?>'
			, file_types: "*.jpg;*.jpeg;*.png;*.gif;*.doc;*.docx;*.xls;*.xlsx;*.pdf;*.swf"
			, file_upload_limit : 5
			, file_queue_limit : 5
			, debug : false
		};
		
		configUpload(configUploadData);
		/*
		var configUploadDataOther = {
			upload_url: upload_url_new+"upload_cat.php"
			, create_date:'<?php $create_date=isset($detail["create_date"])? $detail["create_date"]:''; echo $create_date;?>'
			, file_types: "*.jpg;*.jpeg;*.png;*.gif;*.doc;*.docx;*.xls;*.xlsx;*.pdf;*.swf;*.txt"
			, file_upload_limit : 5
			, file_queue_limit : 5
			, debug : false
		};
		configUploadOther(configUploadDataOther);
		*/
	};
	
	
	$("#list_cate1").sortable({disable:true});
	$('#submit').click(function(){
		//tinyMCE.triggerSave();
		if($('#title').val()=='')
		{
			alert('Vui lòng nhập tên danh mục!');
			$('#title').focus();
			return false;
		}
		else if($('#parent_id').val()=='')
		{
			alert('Vui lòng nhập danh mục cha!');
			$('#parent_id').focus();
			return false;
		}
		else if($('#is_link').val()!=0 && $('#links').val()=='')
			{
			alert('Vui lòng chưa nhập link cho danh mục!');
			$('#links').focus();
			return false;
		}
		/*
		else if($('#cat_type').val()==0)
		{
			alert('Vui lòng chọn loại danh mục!');
			$('#cat_type').focus();
			return false;
		}
		*/
		else
			{
			var title=$('#title').val();
			var alias=$('#alias').val();
			var parent_id=$('#parent_id').val();
			var cid=$('#cid').val();
			var status=$('#status').val();
			var ordering=$('#ordering').val();
			var level=$('#level').val();
			var is_hot=$('#is_hot').val();
			var is_home_bottom=$('#is_home_bottom').val();
			var is_link=$('#is_link').val();
			var is_menu=$('#is_menu').val();
			var links=$('#links').val();
			var picture = $('#filename1').val();
			var price = $('#price').val();
			var cat_type=$('#cat_type').val();
			/*
			var file = $('#filename2').val();			
			var c_focus = $('#focus').val();
			var camera_type = $('#camera_type').val();
			var info = $('#info').val();
			var info_other = $('#info_other').val();
			var description = $('#description').val();
			*/
			$.ajax({
				url: '<?php echo Url::createUrl('ajax/editCat');?>',
				type: "POST",
				data:({
					cid:cid,
					title:title,
					alias:alias,
					parent_id:parent_id,
					status:status,
					ordering:ordering,
					level:level,
					is_hot:is_hot,
					is_home_bottom:is_home_bottom,
					is_link:is_link,
					links:links,
					is_menu:is_menu,
					picture:picture,
					price:price,
					cat_type:cat_type,
					/*					
					c_focus:c_focus,
					camera_type:camera_type,
					info:info,
					info_other:info_other,
					description:description,
					file:file
					*/
				}),
				success: function(resp){
					alert(resp['error']);
					if(parent_id==0)
					{
						window.location.reload();
					}
					else
					{
						loadSubCate(parent_id,(parseInt(resp['level'])-1));
						showFormAdd(parent_id);
					}
				}
			});

		}
	});
	$('#status,#is_hot,#is_menu,#is_home_bottom').click(function(){
		if($(this).val()==1)
		{
			$(this).removeAttr('checked');
			$(this).val(0);
		}
		else
		{
			$(this).attr('checked','checked');            
			$(this).val(1);
		}
	});
	$('#is_link').click(function(){
		if($(this).val()==1)
			{
			$(this).removeAttr('checked');
			$(this).val(0);
			$('#links').removeAttr('disabled').attr('disabled','disabled');
		}
		else
			{
			$(this).attr('checked','checked');            
			$(this).val(1);
			$('#links').removeAttr('disabled');
		}
	});
});

function loadSubCate(cid,level)
{
	showFormAdd(0);
	//an cac box ko can load
	var total=$('.itemt').size();
	for(var i=level+1;i<=total;i++)
		{
		$('#itemt'+i+'').remove();
	}
	//active khi click
	$('#list_cate'+level+'').find('li').each(function(){
		if($(this).attr('rel')==cid)
			$(this).find('a').removeClass().addClass('active');
		else
			$(this).find('a').removeClass();
	});    
	loadingAjax();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/loadSubCate');?>',
		type: "POST",
		data:({
			cid:cid,
			level:level
		}),
		success: function(resp){
			var result = jQuery.parseJSON(resp);
			if(result!= null && result.status == "noPermis"){
				alert("Bạn không đủ quyền thực hiện hành động này.");
				closeLoadingAjax();
				return false;                
			}
			$('#list_cate').append(resp['html']);
			$('#path_select').html(resp['path_way']);
			showFormEdit(cid);
			closeLoadingAjax();    
		}
	});
	$('#level'+level+'').find('li').children().removeClass('active');
	$('#edit_'+level+'').attr('rel',cid);
	$('#delete_'+level+'').attr('rel',cid);
}

function showFormAdd(parent_id)
{
	$('#form_cate').show();
	$('#form_subject').hide();
	$('#title').val('');
	$('#alias').val('');
	$('#cid').val(0);
	$('#ordering').val('');
	$('#parent_id').val(parent_id);
	$('#submit').val('Thêm mới');
}
function showFormEdit(cid)
{
	if(!cid)
	{
		alert('Bạn chưa chọn danh mục để sửa!');
		return false;
	}
	else
	{
		$('#submit').val('Sửa');
		$.ajax({
		url: '<?php echo Url::createUrl('ajax/showFormEditCate');?>',
		type: "POST",
		data:({
			cid:cid
		}),
		success: function(resp){
			var result = jQuery.parseJSON(resp);
			if(result!= null && result.status == "noPermis"){
				alert("Bạn không đủ quyền thực hiện hành động này.");
				return false;                
			}

			//Load thong tin ra form
			$('#title').val(resp['title']);
			$('#alias').val(resp['alias']);
			$('#alias2').val(resp['alias_2']);
			$('#ordering').val(resp['ordering']);
			$('#parent_id').val(resp['parent_id']);
			if(resp['status']==1)
			{
				$('#status').attr('checked','checked');
			}
			else
				{
				$('#status').removeAttr('checked');
			}
			if(resp['is_hot']==1)
				{
				$('#is_hot').attr('checked','checked');
			}
			else
				{
				$('#is_hot').removeAttr('checked');
			}
			if(resp['is_home_bottom']==1)
			{
				$('#is_home_bottom').attr('checked','checked');
			}
			else
			{
				$('#is_home_bottom').removeAttr('checked');
			}
			/*Box diem*/
			if(resp['is_lession']==1)
				{
				$('#is_lession').attr('checked','checked');
			}
			else
				{
				$('#is_lession').removeAttr('checked');
			}
			/*Menu Ngang*/
			if(resp['is_menu']==1)
				{
				$('#is_menu').attr('checked','checked');
			}
			else
				{
				$('#is_menu').removeAttr('checked');
			}
			/*DM co link*/
			if(resp['is_link']==1)
				{
				$('#is_link').attr('checked','checked');
				$('#links').removeAttr('disabled');
			}
			else
				{
				$('#is_link').removeAttr('checked');
				$('#links').attr('disabled','disabled');
			}
			$('#status').val(resp['status']);
			$('#is_hot').val(resp['is_hot']);
			$('#is_lession').val(resp['is_lession']);
			$('#is_menu').val(resp['is_menu']);
			$('#is_link').val(resp['is_link']);
			$('#links').val(resp['links']);
			$('#price_real').val(resp['price_real']);
			$('#price').val(resp['price']);
			$('#cat_type').val(resp['cat_type']);
			$('#is_layout').val(resp['is_layout']);
			$('#icon').val(resp['icon']);
			$('#price').val(resp['price']);
			$('#filename1').val(resp['picture']);
			var url=url_images+'cat/'+resp['picture'];
			if(resp['picture']!='')
			{
				$('#img_0').html('<div style="width:150px; float:left;"><a href="'+url+'"><img width="150px;" height="150px;" src="'+url+'" alt="'+resp['picture']+'"></a><a href="javascript:" onclick="$(\'#filename1\').val(\'\');$(this).parent(\'div\').remove();">Xóa</a></div>');
			}
			
			$('#filename2').val(resp['file']);
			var url2=url_images+'cat/'+resp['file'];
			if(resp['file']!='')
			{
				$('#img_2').html('<div style="width:150px; float:left;"><a href="'+url2+'">'+url2+'</a> | <a href="javascript:" onclick="$(\'#filename2\').val(\'\');$(this).parent(\'div\').remove();">Xóa</a></div>');
			}
			$('#camera_type').val(resp['camera_type']);
			$('#focus').val(resp['focus']);
			tinyMCE.get('description').setContent(resp['description']);
			tinyMCE.get('info').setContent(resp['info']);
			tinyMCE.get('info_other').setContent(resp['info_other']);
		}
	});
	}
	$('#cid').val(cid);
}
function deleteCate(cid)
{
	if(cid!=0)
		{
		if(confirm('Bạn có chắc chắn xóa bản ghi này không?'))
			{
			loadingAjax();
			$.ajax({
				url: '<?php echo Url::createUrl('cat/deleteCate');?>',
				type: "POST",
				data:({
					cid:cid
				}),
				success: function(resp){
					if(resp['status']!=1 || resp['status']!=0)
					{
						alert(resp);
						closeLoadingAjax();
						return false;
					}
					var result = jQuery.parseJSON(resp);
					if(result!= null && result.status == "noPermis"){
						alert("Bạn không đủ quyền thực hiện hành động này.");
						closeLoadingAjax();
						return false;                
					}

					if(resp['status']==1)
						{
						if(resp['parent_id']==0)
							{
							window.location.reload();
						}
						else
							{
							loadSubCate(resp['parent_id'],(parseInt(resp['level'])-1),resp['type']);
						}
					}
					else
						{
						alert(resp['error']);
					}
					closeLoadingAjax();    
				}
			});
		}
	}
	else
		{
		alert('Bạn chưa chọn danh mục để xóa!');
	}
}

function saveOrder(level)
{    
	var list_cate_order='';
	var cate_id=0;
	var cate_order=0;
	$('#list_cate'+level+'').find('li').each(function(i){
		cate_id=$(this).attr('rel');
		cate_order=i;
		list_cate_order+=cate_id+'|'+cate_order+',';
	});
	if(list_cate_order!='')
	{
		loadingAjax();
		$.ajax({
			url: '<?php echo Url::createUrl('ajax/saveOrderCate');?>',
			type: "POST",
			data:({
				list_cate_order:list_cate_order
			}),
			success: function(resp){
				var result = jQuery.parseJSON(resp);
				if(result!= null && result.status == "noPermis"){
					alert("Bạn không đủ quyền thực hiện hành động này.");
					closeLoadingAjax();
					return false;                
				}
				if(resp == 1) {
					alert("Cập nhật dữ liệu thành công.");    
				}
				else {
					alert("Cập nhật dữ liệu lỗi.");
				}
				closeLoadingAjax();
			}
		});
	}
}

</script>