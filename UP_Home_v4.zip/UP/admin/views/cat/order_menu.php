<link rel="stylesheet" href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.widget.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.mouse.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.sortable.js"></script>
<script>
    $(function(){
        $("#list_cat tbody").sortable({disable:true});
    });

    function saveOrder()
    {    
        var list_cat_order='';
        var cat_id=0;
        var cat_order=0;
        $('#list_cat tbody>tr').each(function(i){
            cat_id=$(this).attr('rel');
            if(cat_id)
                {
                cat_order=i;
                list_cat_order+=cat_id+'|'+cat_order+',';
            }
        });
        if(list_cat_order!='')
		{
			loadingAjax();
			$.ajax({
				url: '<?php echo Url::createUrl('ajax/saveOrderCatMenu');?>',
				type: "POST",
				data:({
					list_cat_order:list_cat_order
				}),
				success: function(resp){
					var result = jQuery.parseJSON(resp);
					if(result!= null && result.status == "noPermis"){
						alert("Bạn không đủ quyền thực hiện hành động này.");
						closeLoadingAjax();
						return false;                
					}
					if(resp == 1) {
						alert("Cập nhật dữ liệu thành công.");    
					}
					else {
						alert("Cập nhật dữ liệu lỗi.");
					}
					closeLoadingAjax();
				}
            });
        }
    }
</script>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?> 
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <div class="box_tab">
                            <?php $this->renderPartial('path_way');?>
                        </div>
                        <div class="box_form">
                            <div class="box bottom30">
                            </div>
                            <div class="box">
                                <input type="button" value="Save Order" class="btn-orange" onclick="saveOrder();"><br /><br />
                                <table width="100%" cellspacing="0" cellpadding="0" border="0" class="col_list txt-right" id="list_cat">
                                    <tbody>
                                    <tr class="bg-grey" rel="0">
                                        <td width="5%"><strong>ID</strong></td>
                                        <td width="21%"><strong>Tên Danh mục</strong></td>
                                        <td width="25%"><strong>Danh mục cha</strong></td>
                                    </tr>
                                    <tbody>
                                        <?php
                                            if($cats)
                                            {
                                                foreach($cats as $row)
                                                {
                                                ?>
                                                <tr rel="<?php echo $row['id'];?>">
                                                    <td><?php echo $row['id'];?></td>
                                                    <td class="text-left"><?php echo $row['title'];?></td>
                                                    <td><?php echo $row['parent_id'];?></td>
                                                </tr>
                                                <?php
                                                }
                                            }
                                        ?>
                                    </tbody>
                                </table>

                            </div>

                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?> 
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
        </div>
