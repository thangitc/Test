<script>
$(function(){    
    $(".search_access").keypress(function(e){
        switch(e.which)
        {
            case 13: 
                pagingAccess(1);
                break;
            default:
                break; 
        }
    });     
});

function pagingAccess(page)
{
    var keyword = $("#keyword_access").val();
    var cat_id = $("select[name='cat_id'] option:selected").val();
    var numperpage = $("select[name='numperpage'] option:selected").val();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/pagingAccess');?>',
		type: "POST",
		data:({
			page:page,
			keyword:keyword,
			cat_id:cat_id,
			numperpage:numperpage
		}),
		success: function(resp){
			$("#AccessData").replaceWith(resp);
		}
	});
}
/*
function chooseAccess()
{
	var html_select='';
	var list_access_id=$('#list_access_id').val();
	var list_access_id2=$('#list_access_id2').val();
	var tab = '<?php echo $tab;?>';
	$('.access_select').each(function(){
		if($(this).is(":checked"))
		{
			var access_id=$(this).attr('rel');
			if(tab==2)
			{
				if(list_access_id2!='')
				{
					list_access_id2+=','+access_id;
				}
				else
				{
					list_access_id2+=access_id;
				}
			}
			else
			{
				if(list_access_id!='')
				{
					list_access_id+=','+access_id;
				}
				else
				{
					list_access_id+=access_id;
				}

			}
			var title=$('#access_title_'+access_id+'').html();
			html_select+='<div class="fl" rel="'+access_id+'"><a href="javascript:">'+title+'</a><a class="ic_del" onclick="updateListAccess('+access_id+');$(this).parent(\'div\').remove();" href="javascript:">&nbsp;</a></div>';
		}
	});
	list_access_id=rtrim(list_access_id,',');
	list_access_id2=rtrim(list_access_id2,',');
	if(tab==2)
	{
		$("#list_access_view2").append(html_select);
		$('#list_access_id2').val(list_access_id2);
	}
	else
	{
		$("#list_access_view").append(html_select);
		$('#list_access_id').val(list_access_id);
	}
    $.fn.colorbox.close();
}
*/

function chooseAccess()
{
	var html_select='';
	var list_access_id=$('#list_access_id').val();
	$('.access_select').each(function(){
		if($(this).is(":checked"))
		{
			var access_id=$(this).attr('rel');
			if(list_access_id!='')
			{
				list_access_id+=','+access_id;
			}
			else
			{
				list_access_id+=access_id;
			}
			var title=$('#access_title_'+access_id+'').html();
			html_select+='<div class="fl" rel="'+access_id+'"><a href="javascript:">'+title+'</a><a class="ic_del" onclick="updateListAccess('+access_id+');$(this).parent(\'div\').remove();" href="javascript:">&nbsp;</a></div>';
		}
	});
	list_access_id=rtrim(list_access_id,',');
	$("#list_access_view").append(html_select);
	$('#list_access_id').val(list_access_id);
    $.fn.colorbox.close();
}
function insertAccessCamera() 
{
	var list_camera_id = $("#list_id").val();
	var list_access_id = $("#list_access_id").val();
	
	if(list_camera_id != '')
	{
		$.ajax({
	        url:'<?php echo Url::createUrl('ajax/insertAccessCamera');?>',
	        type:"POST",
	        data:({
	        	list_access_id:list_access_id,
				list_camera_id:list_camera_id
	        }),
	        success:function(response){
	            closeLoadingAjax();
	            location.reload();
	        },
	        error:function(){
	            alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
	            closeLoadingAjax();
	        }
	    });
	}
	else {
		alert("Bạn chưa chọn chuyên đề. Hãy làm lại.");
	}
}

</script>
<div style="width:770px; height:430px; display: block; padding: 10px;" class="popup">
	<p align="center"><strong class="clblue s18">Chọn phụ kiện liên quan</strong></p>
	<div class="popup-cont clearfix">
		<div class="box">
			<p>
				<input type="text" id="keyword_access" class="search_access" style="width: 430px;" />
                <input type="button" onclick="pagingAccess(1);" value="Tìm" class="btn-orange">
				&nbsp;
                <select name="cat_id" style="width:258px">
                <option value="0">--Chọn DM--</option>
                <?php
                if($cat)
                foreach($cat as $row)
                {
                    if($row['parent_id']==0 && $row['cat_type']==3)
                    {
                        
                        ?>
                        <option <?php if($row['id']==$cat_id) echo "selected"; ?> value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
                        <?php
                        foreach($cat as $row2)
                        {
                            if($row2['parent_id']==$row['id'])
                            {
                                ?>
                                <option <?php if($row2['id']==$cat_id) echo "selected"; ?> value="<?php echo $row2['id'];?>">--<?php echo $row2['title'];?></option>
                                <?php
                                foreach($cat as $row3){
                                    if($row3['parent_id']==$row2['id'])
                                    {
                                        ?>
                                        <option <?php if($row3['id']==$cat_id) echo "selected"; ?> value="<?php echo $row3['id'];?>">----<?php echo $row3['title'];?></option>
                                        <?php
                                    }
                                }
                            }
                        }
                    }
                }
                ?>
                </select>
			</p>
		</div>
		<div class="box" id="AccessData">
			<div class="fillter clearfix" style="border-bottom:1px solid #ccc">
				<?php if($num_page >1) { ?>
				<div class="fl">
                    <ul class="pages fl magT5 clearfix">
						<?php echo Paging::show_paging_ajax("pagingAccess", array(),$num_page, $page, 9, ''); ?>						
					</ul>
				</div>
				<?php } ?>
				<div class="fr"> Hiển thị
					<select style="width:44px" name="numperpage">
						<option value="10" <?php if($num_per_page == 10) echo ("selected");?>>10 tin</option>
						<option value="20" <?php if($num_per_page == 20) echo ("selected");?>>20 tin</option>
						<option value="30" <?php if($num_per_page == 30) echo ("selected");?>>30 tin</option>
					</select>
				</div>
				<br/>&nbsp;
			</div>
            <input type="hidden" id="listAccessId" name="listAccessId" />
			<?php
            foreach($access as $row)
			{
				?>
                <p>
                	<input onclick="doCheckMuti('access_select', 'listAccessId');" class="access_select" rel="<?php echo $row["id"];?>" type="checkbox" id="access_id_<?php echo $row["id"];?>" name="access_id_<?php echo $row["id"];?>" value="<?php echo $row["id"];?>"/>
                    <span id="access_title_<?php echo $row["id"];?>"><?php echo $row["title"];?></span>
                </p>
                <?php
			}
			?>
		</div>
        <p align="center">
        <?php
		if($boolean==0)
		{
			?>
            <button type="submit" onclick="chooseAccess();" class="button">Lưu</button>	
            <?php
		}
		else
		{
			?>
            <button type="submit" onclick="insertAccessCamera();" class="button">Lưu</button>	
            <?php
		}
        ?>
		</p>
	</div>
</div>