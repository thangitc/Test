<script>
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/calendar.png';?>"
	});
	$('#formSearch').keypress(function(e){
		switch(e.which)
		{
			case 13:
				$('#formSearch').submit();
			break;
		}
	});
});

function searchForm(tab)
{
	$('#tab').val(tab);
    $('#formSearch').submit();
}

function quickUpdateAccess(quick_type,list_id)
{
	if(list_id=='')
	{
		alert('Bạn chưa chọn tin. Hãy làm lại.');
		return false;
	}
	else
	{
		loadingAjax();
		$.ajax({
			url:"<?php echo Url::createUrl('ajax/quickUpdateAccess');?>",
			type:"POST",
			data:({
				quick_type:quick_type,
				list_id:list_id
			}),
			success:function(response){
				var result = eval( "(" + response + ")" );
				if(result.status !== "noPermis"){
					/*alert("Cập nhật thành công.");*/
				} else {
					alert("Bạn không đủ quyền thực hiện hành động này.");    
				}
				location.reload();
				closeLoadingAjax();
			},
			error:function(){
				alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
				closeLoadingAjax();
			}
		});
	}
}
function showTopic()
{
	var list_news_id = $("#list_id").val();
	if(list_news_id == '') {
		alert("Bạn chưa chọn tin. Hãy làm lại.");
		return;
	}
	else {
		$.fn.colorbox(
		    {href:"<?php echo Url::createUrl('ajax/showTopic', array('boolean'=>1));?>", open:true, innerWidth:800, innerHeight:460}
		);		 
	}
}
function showCat()
{
	var list_artilces_id = $("#list_id").val();
	if(list_artilces_id == '') {
		alert("Bạn chưa chọn tin. Hãy làm lại.");
		return;
	}
	else {
		$.fn.colorbox(
		    {href:"<?php echo Url::createUrl('cat/showCat');?>", open:true, innerWidth:800, innerHeight:460}
		);		 
	}
}

function moveCatNews()
{
	var list_id = $("#list_id").val();
	var cat_id = $("#cat_id").val();
	
	if(cat_id != '')
	{
		$.ajax({
	        url:"<?php echo Url::createUrl('ajax/moveCatNews');?>",
	        type:"POST",
	        data:({
	        	list_id:list_id,
	        	cat_id:cat_id
	        }),
	        success:function(response){
	            var result = eval( "(" + response + ")" );
	            if(result.status !== "noPermis"){
	            	/*alert("Cập nhật thành công.");*/
	            } else {
	                alert("Bạn không đủ quyền thực hiện hành động này.");
	            }
	            closeLoadingAjax();
	            $.fn.colorbox.close();
	            location.reload();
	        },
	        error:function(){
	            alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
	            closeLoadingAjax();
	        }
	    });
	}
	else {
		alert("Bạn chưa chọn danh muc. Hãy làm lại.");
	}
}

function deleteAccess(access_id)
{
    var answer = confirm("Bạn có chắc chắn muốn xóa?");
    if(answer){
        $.ajax({
            url:"<?php echo Url::createUrl('access/deleteAccess');?>",
            type:"POST",
            data:({
            	access_id:access_id                                                   
            }),
            success:function(response){
				if(response!=1)
				{
					alert(response);
				}
                location.reload();
            },
            error:function(){
                alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
            }
        });
    }
}
function isActiveAccess(access_id)
{
    $.ajax({
		url:"<?php echo Url::createUrl('ajax/isActiveAccess');?>",
		type:"POST",
		data:({
			access_id:access_id                                                   
		}),
		success:function(response){
			location.reload();
		},
		error:function(){
			alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
		}
	});
}

function isApprovedList(access_id)
{
    $.ajax({
		url:"<?php echo Url::createUrl('ajax/isApprovedList');?>",
		type:"POST",
		data:({
			access_id:access_id                                                   
		}),
		success:function(response){
			location.reload();
		},
		error:function(){
			alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
		}
	});
}

function setHotList(access_id)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/setHotList');?>',
		type: "POST",
		data:({
			access_id:access_id
		}),
		success: function(resp){
			location.reload();
		}
	});
}

function updateOrderAccess()
{    
	var list_order='';
	var access_id=0;
	var access_order=0;

	$('#list tbody>tr').each(function(i){
		access_id=$(this).attr('rel');
		if(access_id)
		{               
			access_order=$('#orderaccess_'+access_id+'').val();
			list_order+=access_id+'|'+access_order+',';
		}
	});

	if(list_order!='')
		{
		loadingAjax();
		$.ajax({
			url: '<?php echo Url::createUrl('ajax/updateOrderAccess');?>',
			type: "POST",
			data:({
				list_order:list_order
			}),
			success: function(resp){
				closeLoadingAjax();
				location.reload();
			}
		});
	}
}

function updateNumProduct()
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/updateNumProduct');?>',
		type: "POST",
		data:({
			
		}),
		success: function(resp){
			alert('Cap nhat thanh cong!');
		}
	});
}

function addProductBill(product_id, bill_id, product_type)
{
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addProductBill');?>',
		type: "POST",
		data:({
			product_id:product_id,
			bill_id:bill_id,
			product_type:product_type
		}),
		success: function(resp){
			if(resp==0)
			{
				alert('Thêm sản phẩm lỗi');
				return false;
			}
			else if(resp==1)
			{
				alert('Thêm sản phẩm vào hóa đơn thành công!');
				location.reload();
			}
			else
			{
				alert(resp);
				return false;
			}
			
		}
	});
}
</script>
<div class="body_pages clearfix">
<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
    <tr>
        <td class="first" valign="top"><?php $this->renderPartial('application.views.static.sidebar') ;  ?></td>
        <td valign="top" class="last"><div class="content_pages" id="container">
                <?php $this->renderPartial('tab', array('bill_id'=>$bill_id));?>
                <div class="box_form">
                    <form method="GET" action="<?php echo Url::createUrl('access/index', array('bill_id'=>$bill_id));?>" id="formSearch">
                        <div class="box bottom30">
                            <ul class="form4">
                                <li class="clearfix">
                                    <label><strong>Từ khóa:</strong></label>
                                    <div class="filltext">
                                        <input type="text" value="<?php echo $keyword;?>" style="width: 300px;" id="keyword" name="keyword">
                                        Trong
                                        <select id="keyword_in" name="keyword_in">
                                            <option value="1" <?php if($keyword_in==1) echo 'selected';?>>Tên sản phẩm</option>
                                            <option value="2" <?php if($keyword_in==2) echo 'selected';?>>Người nhập</option>
                                            <option value="3" <?php if($keyword_in==3) echo 'selected';?>>ID</option>
                                        </select>
                                    </div>                                     
                                </li>
                                <li class="clearfix">
                                    <label><strong>Danh mục :</strong></label>
                                    <div class="filltext">
                                        <select id="cat_id" name="cat_id" style="width:200px;">
                                            <option value="0">--Chọn--</option>
                                            <?php
											if($cats)
											foreach($cats as $row)
											{
												if($row['cat_type']==3)
												{
													$select='';
													if($row['id']==$cat_id) $select='selected';
													?>
													<option <?php echo $select;?> value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
													<?php
													foreach($cats as $row2)
													{
														if($row2['parent_id']==$row['id'])
														{
															$select='';
															if($row2['id']==$cat_id) $select='selected';
															?>
															<option <?php echo $select;?> value="<?php echo $row2['id'];?>">--<?php echo $row2['title'];?></option>
															<?php
														}
													}
												}
											}
                                            ?>
                                        </select>
                                        
                                    </div>                                      
                                </li>                                
                                <li class="clearfix">
                                    <label><strong>Từ ngày: </strong></label>
                                    <div class="filltext">
                                        <input type="text" style="width:170px" value="<?php if(isset($from_date) && $from_date!=0) echo date('d/m/Y',$from_date);?>" id="from_date" name="from_date">
                                        &nbsp; Đến ngày &nbsp;
                                        <input type="text" style="width:170px" id="to_date" name="to_date" value="<?php if(isset($to_date) && $to_date!=0) echo date('d/m/Y',$to_date);?>">
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label>&nbsp;</label>
                                    <div class="filltext">
                                        <input type="button" class="buton-radi" value="Tìm kiếm" onclick="searchForm('');">
                                        <input type="button" value="Hủy" class="buton-radi" onclick="window.location.href='<?php echo Url::createUrl('access/index', array('bill_id'=>$bill_id));?>'" />
                                        
                                        <input type="button" value="Sắp xếp" class="buton-radi" onclick="updateOrderAccess();">
                                        <input type="button" value="Update SL san pham" class="buton-radi" onclick="updateNumProduct();">
                                    </div>
                                </li>
                                <br />
                                <li>
                                    <div class="filltext"> <a href="javascript:" onclick="searchForm(0);">Tất cả <strong style="color:red;">(<?php echo $total_all;?>)</strong></a> &nbsp;&nbsp; <a href="javascript:" onclick="searchForm(1);">Published<strong style="color:red;">(<?php echo $total_active;?>)</strong></a>&nbsp;&nbsp; <a href="javascript:" onclick="searchForm(2);">Pending Reviews<strong style="color:red;">(<?php echo $total_pending;?>)</strong></a>&nbsp;&nbsp; <a href="javascript:" onclick="searchForm(3);">Draft<strong style="color:red;">(<?php echo $total_draft;?>)</strong></a>
                                    <input type="hidden" id="tab" name="tab" />
                                    </div>
                                </li>
                                <br />
                            </ul>
                        </div>
                    </form>
                    <div class="box">
                        <div class="clearfix fillter">
                            <div class="fl reseach"> <strong>Thao tác nhanh </strong>
                                <select style="width:95px;height:23px" id="quick_type">
                                    <option value="1">Kích hoạt</option>
                                    <option value="2">Bỏ kích hoạt</option>
                                    <option value="3">Xóa</option>
                                </select>
                                &nbsp;
                                <input type="submit" class="btn-orange" value="Lưu" onclick="quickUpdateAccess($('#quick_type').val(),$('#list_id').val())">
                            </div>
                            <div class="fr reseach">
                            	<a href="<?php echo Url::createUrl("access/add");?>">
                                <input type="button"class="btn-orange" value="Thêm mới phụ kiện">
                                </a>&nbsp;
                                <ul class="pages fr clearfix">
                                    <?php echo $paging;?>
                                </ul>
                                
                            </div>
                        </div>
                        <input type="hidden" id="list_id" />
                        <table width="100%" cellspacing="0" cellpadding="0" border="0" class="col_list txt-right" id="list">
                            <tbody>
                                <tr class="bg-grey">
                                    <td width="3%"><strong>ID </strong><br>
                                    <input type="checkbox" id="selectAll" onclick="doCheckAll();">
                                    </td>
                                    <td width="15%"><strong>Tên phụ kiện</strong></td>
                                    <td width="8%"><strong>Hình ảnh</strong></td>
                                    <td width="15%"><strong>Thông tin</strong></td>
                                    <td width="15%"><strong>Giá</strong></td>
                                    <td width="8%"><strong>Sắp xếp</strong></td>
                                    <td width="9%"><strong>Thời gian/ Người gửi </strong></td>
                                </tr>
                                <?php
                                
                                $k=0;
                                foreach ($access as $row)
                                {
                                    $class='';
                                    if($k%2==0)
                                    {
                                        $class='class="bg_grays"';
                                    }
                                    $link_front_end = Yii::app()->params['baseUrlFront'].'/'.$row['alias'].'-a'.$row['id'].'.html';
									if($row['picture']!='') $src = Common::getImage($row['picture'], 'access', '');
									else $src = '';
									$color = '';
									if($row['is_hot']==1) $color='style="color:red;"';
                                    ?>
                                    <tr <?php echo $class;?> rel="<?php echo $row['id'];?>">
                                        <td><?php echo ($row['id']);?><br />
                                            <input type="checkbox" value="<?php echo ($row['id']);?>" name="articles_<?php echo ($row['id']);?>" class="selectOne" onclick="doCheck();"></td>
                                        <td class="txt-left">
                                        	<a <?php echo $color;?> href="<?php echo $link_front_end;?>" target="_blank"><strong><?php echo stripslashes($row['title']);?></strong></a>
                                            <div class="clearfix col_30">
                                                <br />
                                                Người nhập: <strong><?php echo $row['admin_name'];?></strong>
                                                <?php
												if($row['link_web']!='')
												{
													$list_link = explode(',', $row['link_web']);
													if(!empty($list_link))
													foreach($list_link as $value)
													{
														$value = trim($value);
														?>
                                                        <br />
                                                        <a style="color:#90F" href="<?php echo $value;?>" target="_blank"><?php echo $value;?></a>
                                                        <?php
													}
												}
												?>
                                                <br />
                                                <div class="row-actions">
                                                	<?php if($bill_id==0) { ?>
                                                	<a href="<?php echo Url::createUrl("access/edit", array("access_id"=>$row['id']));?>" title="Edit this item"><span>Edit</span></a> | <a href="javascript:" onclick="deleteAccess(<?php echo ($row['id']);?>);">Xóa</a> | 
                                                    <a href="javascript:" onclick="isActiveAccess(<?php echo ($row['id']);?>);">
                                                    <?php
													if ($row['status'] == "active")
														echo '<span>Bỏ kích hoạt<span>';
													else
														echo '<span>Kích hoạt<span>';
                                                    ?>
                                                    </a>
                                                     |
                                                    <a href="<?php echo Url::createUrl('access/color', array('access_id'=>$row['id']));?>" class="editinline"> 
													Màu sắc
                                                    </a>
                                                    |
                                                    <a href="<?php echo Url::createUrl('customer/access', array('access_id'=>$row['id']));?>" class="editinline"> 
													Khách hàng
                                                    </a>
                                                    
                                                    |
                                                    <a href="<?php echo Url::createUrl('access/sale', array('access_id'=>$row['id']));?>" class="editinline"> 
													Bán hàng
                                                    </a>
                                                    <?php } ?>
                                                    
                                                    <?php if($bill_id!=0) { ?>
                                                    <a href="<?php echo Url::createUrl('access/color', array('access_id'=>$row['id'],'bill_id'=>$bill_id));?>" class="editinline"> 
													Màu sắc
                                                    </a>
                                                    |
                                                    <a href="<?php echo Url::createUrl('access/sale', array('access_id'=>$row['id'],'bill_id'=>$bill_id));?>" class="editinline"> 
													Bán hàng
                                                    </a>
                                                    |
                                                    <a href="javascript:" onclick="addProductBill(<?php echo $row['id'];?>, <?php echo $bill_id;?>, 1)" class="editinline"> 
													Thêm Phụ kiện vào hóa đơn
                                                    </a>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php
											if($row['picture']!='')
											{
												?>
                                                <img src="<?php echo $src;?>" width="150px;" height="150px;" />
                                                <?php
											}
											?>
                                        </td>
                                        
                                        <td style="text-align:left">
                                            <?php echo $row['introtext'];?>
                                        </td>
                                        
                                        <td style="text-align:left;">
                                            <?php
											echo 'Số lượng nhập: <strong style="color:red;">'.Common::formatNumber($row['num_p']).'</strong><br>';
											echo 'Số lượng bán: <strong style="color:red;">'.Common::formatNumber($row['num_buy']).'</strong><br>';
											echo '-----------------<br>';
											echo 'Giá hiển thị: <strong style="color:red;">'.Common::formatNumber($row['price']).'</strong><br>';
											echo 'Giá nhập: <strong style="color:red;">'.Common::formatNumber($row['price_in']).'</strong><br>';
											echo 'Giá khuyến mại: <strong style="color:red;">'.Common::formatNumber($row['price_deal']).'</strong> - Thời gian: '.date('d/m/Y', $row['time_deal']).'<br>';
											?>
                                        </td>
                                        <td>
                                            <input type="text" id="orderaccess_<?php echo $row['id']; ?>" style="width:70px" value="<?php echo $row['ordering'];?>">
                                        </td>
                                        <td class="txt-left">
                                        	<p>Sửa: <a href="javascript:" rel="nofollow" class="under"><strong><?php echo $row['edit_name'];?> </strong></a><?php echo date('d/m/Y - H:i a',$row['edit_date']);?></p>
                                            <p>
                                            	Active: 
                                                <?php if($row['status']!=1) echo " Chưa Active";else { ?>
                                                <a href="javascript:" rel="nofollow" class="under"><strong><?php echo $row['publish_name'];?> </strong></a><?php echo date('d/m/Y - H:i a',$row['publish_date']);?> <?php if($row['publish_date']!=0) echo "[".round(($row['publish_date']-$row['create_date'])/60/60,1)." giờ]"; ?>
                                                <?php } ?>
                                            </p>
                                            <p>Tạo: <a href="javascript:" rel="nofollow" class="under"><strong><?php echo $row['user_post'];?> </strong></a><?php echo date('d/m/Y - H:i a',$row['create_date']);?></p>
										</td>
                                    </tr>
                                    <?php
                                    $k++;
                                }
                                ?>
                            </tbody>
                        </table>
                        <div class="clearfix fillter">                                	
                            <div class="fr reseach">
                                <ul class="pages fl magT5 clearfix">
                                    <?php echo $paging;?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $this->renderPartial('application.views.static.footer') ;  ?>
            </div>
		</td>
    </tr>
</table>
</div>
