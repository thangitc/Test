<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab_color', array('access_id'=>$access_id));?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div style="border-right:1px solid #ccc;" class="col55">
                                    <ul class="form">
                                        <li class="clearfix"><label><strong>Màu sắc :</strong></label>
                                            <div class="filltext">
                                                <input name="color" id="color" type="text" style="width:100%;">
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label><strong>Ảnh:</strong></label>
                                            <div class="filltext">            
                                            	<input type="text" id="filename1" name="filename1" readonly/>&nbsp;
                                                <span id="spanButtonPlaceHolder"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_0">
                                            	
                                            </div>
                                        </li>
                                    </ul>
                                    <p><input type="button" value="Thêm mới" class="btn-orange" onclick="addColorAccess(0,<?php echo $access_id;?>);"></p>
                                    
                                    <div id="result">
                                    </div>
                                    
                                </div>
                                
                                <div class="col2">&nbsp;</div>
                                <div class="col40">
                                    <ul class="form1">
                                    	<li class="clearfix"><label><strong>Số lượng :</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="num_p" name="num_p" style="width:170px">
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá :</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price" name="price" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá nhập:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_in" name="price_in" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá bán TT:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_buy" name="price_buy" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá khuyến mại:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_deal" name="price_deal" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Thời gian khuyến mại:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="time_deal" name="time_deal">
                                            
                                            </div>
                                        </li>
                                        
                                	</ul>
                                    
                                    <p><input type="button" value="Thêm mới" class="btn-orange" onclick="addColorAccess(0,<?php echo $access_id;?>);"></p>
								</div>
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>