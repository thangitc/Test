<?php $this->renderPartial('js',array('detail'=>$detail));?>
<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        <?php $this->renderPartial('tab');?>
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div style="border-right:1px solid #ccc;" class="col55">
                                    <ul class="form">
                                    	<li class="clearfix"><label><strong>Loại tin :</strong></label>
                                            <div class="filltext">
                                                <select style="width:179px;" name="cat_id" id="cat_id">
                                                	<option value="0" selected="selected">--Danh mục--</option>
                                                    
                                                    <?php
													if($cats)
													foreach($cats as $row)
													{
														if($row['parent_id']==0 && $row['cat_type']==3)
														{
															$parent_id=$row['id'];
															?>
															<option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
															<?php
															foreach($cats as $row2)
															{
																if($row2['parent_id']==$parent_id)
																{
																	$parent_id_2=$row2['id'];
																	?>
																	<option value="<?php echo $row2['id'];?>" >--<?php echo $row2['title'];?></option>
																	<?php
																	foreach($cats as $row3)
																	{
																		if($row3['parent_id']==$parent_id_2)
																		{
																			?>
																			<option value="<?php echo $row3['id'];?>" >----<?php echo $row3['title'];?></option>
																			<?php
																		}
																	}
																}
															}
														}
													}
													?>
                                                </select>
                                            </div>
                                            
                                        </li>
                                        <li class="clearfix"><label><strong>Thương hiệu :</strong></label>
                                            <div class="filltext">
                                            <select style="width:179px;" name="brand_id" id="brand_id">
                                            	<option value="0" selected="selected">Chọn Thương hiệu</option>
												<?php
                                                if($brands)
												foreach($brands as $row)
												{
													if($row['brand_type']==1)
													{
														?>
                                                        <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                                        <?php
													}
												}
                                                ?>
                                            	
                                            </select>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Tên phụ kiện :</strong></label>
                                            <div class="filltext">
                                                <input name="title" id="title" type="text" style="width:100%;" >
                                            </div>
                                        </li>                                        
                                        
                                        <li class="clearfix"><label><strong>Tên khác :</strong></label>
                                            <div class="filltext">
                                                <input name="title_other" id="title_other" type="text" style="width:100%;">
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label><strong>Ảnh đại diện:</strong></label>
                                            <div class="filltext">            
                                            	<input type="text" id="filename1" name="filename1" readonly/>&nbsp;
                                                <span id="spanButtonPlaceHolder"></span>
                                            </div>
                                        </li>
                                        <li class="clearfix bor-bottom"><label>&nbsp;</label>
                                            <div class="filltext" id="img_0">
                                            	
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Xếp hạng: </strong></label>
                                            <div class="filltext">
                                                <select style="width:206px" id="rating" name="rating">
                                                    <option value="0">--Chọn loại--</option>
                                                    <?php
                                                    $arr_rating = LoadConfig::$arr_rating;
                                                    if($arr_rating)
                                                    foreach($arr_rating as $key=>$value)
                                                    {
                                                        ?>
                                                        <option value="<?php echo $key;?>"><?php echo $value;?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Tóm tắt(Product Highlights):</strong> </label>
                                            <div class="filltext">
                                                <textarea style="width: 518px; height: 85px;" rows="5" cols="10" name="introtext" id="introtext"></textarea>
                                            </div>                                            
                                        </li>
                                       	<li class="clearfix">
                                            <label><strong>Nội dung(Overview):</strong></label>
                                            <div class="filltext">
                                                <textarea id="description" name="description"></textarea>
                                            </div>
                                        </li>
                                       	
                                        <li class="clearfix">
                                            <label><strong>Hình ảnh chụp từ sản phẩm </strong></label>
                                            <div class="filltext">
                                                <textarea id="pic_product" name="pic_product"></textarea>
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Thông số kỹ thuật </strong></label>
                                            <div class="filltext">
                                                <textarea id="specs" name="specs"></textarea>
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>In the box </strong></label>
                                            <div class="filltext">
                                                <textarea id="in_the_box" name="in_the_box"></textarea>
                                            </div>
                                        </li>
                                        
                                    </ul>
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addAccess(0,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addAccess(0,'draft');"> &nbsp; </p>
                                    
                                    <div id="result">
                                    </div>
                                    
                                </div>
                                
                                <div class="col2">&nbsp;</div>
                                <div class="col40">
                                    <ul class="form1">
                                    	<li class="clearfix"><label><strong>Số lượng nhập :</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="num_p" name="num_p" style="width:170px">
                                                </div>
                                            </div>
                                        </li>
                                        <li class="clearfix"><label><strong>Giá :</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price" name="price" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá nhập:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_in" name="price_in" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá bán:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_buy" name="price_buy" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Giá khuyến mại:</strong></label>
                                            <div class="filltext">
                                                <div style="float:left;">
                                                <input type="text" id="price_deal" name="price_deal" style="width:170px">
                                                <em style="color:red;"></em> VNĐ
                                                </div>
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Thời gian khuyến mại:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="time_deal" name="time_deal">
                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix">
                                            <label><strong>Thời gian bảo hành </strong></label>
                                            <div class="filltext">
                                                <input style="width:170px" type="text" id="time_bh" name="time_bh" />
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix"><label><strong>Ngày đăng tin:</strong></label>
                                            <div class="filltext">
                                            <input type="text" style="width:170px"  id="publish_date" name="publish_date">
                                            
                                            </div>
                                        </li>
                                        
                                        <li class="clearfix">
                                            <label><strong>Video</strong></label>
                                            <div class="filltext">
                                                <input type="text" id="access_video" name="access_video" style="width:100%;" />
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <label><strong>Từ khóa</strong></label>
                                            <div class="filltext">
                                                <input type="text" id="keyword" name="keyword" style="width:100%;" />
                                            </div>
                                        </li>
                                        <hr />
                                        <li class="clearfix"><label><strong>Link web liên quan:</strong> </label>
                                            <div class="filltext">
                                                <textarea style="height: 152px; width: 322px;" rows="5" cols="10" name="link_web" id="link_web"></textarea>(Danh sách các link cách nhau bằng dấu phẩy)
                                            </div>                                            
                                        </li>
                                	</ul>
                                    
                                    <p><input type="button" value="Đăng bài" class="btn-orange" onclick="addAccess(0,'active');"> &nbsp; <input type="button" value="Lưu nháp" class="btn-orange" onclick="addAccess(0,'draft');"> &nbsp; </p>
								</div>
                            </div>
                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>