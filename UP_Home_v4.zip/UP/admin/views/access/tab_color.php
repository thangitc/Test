<?php
$action_id = Yii::app()->controller->action->id;
$id_controller = Yii::app()->controller->id;
?>
<div class="box_tab">
    <ul class="clearfix">
    	<li <?php if($action_id=='index') echo 'class="fl active"'; else echo'class="fl"';?>><span><a  href="<?php echo Url::createUrl('access/index');?>">Danh sách Phụ kiện</span></a></li>
       	<li <?php if($action_id=='index') echo 'class="fl active"'; else echo'class="fl"';?>><span><a  href="<?php echo Url::createUrl('access/color',array('access_id'=>$access_id));?>">Danh sách màu phụ kiện</span></a></li>
        <li <?php if($action_id=='add') echo 'class="fl active"'; else echo'class="fl"';?>><span><a href="<?php echo Url::createUrl('access/addColor', array('access_id'=>$access_id));?>">Thêm mới màu sắc</span></a></li>
    </ul>                
</div>

