<?php require_once("_header.php"); ?>
<?php echo $content; ?>
<?php require_once("_footer.php"); ?>