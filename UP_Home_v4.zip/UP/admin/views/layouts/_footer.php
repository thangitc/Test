
    </div>
</body>
</html>

<div style="margin-left:160px;">
<?php
if(Yii::app()->user->name=="administrator" || Yii::app()->user->name=="admin")
{
	$connect =Yii::app()->db;
	echo $connect->showSql;	
}
?>
</div>
