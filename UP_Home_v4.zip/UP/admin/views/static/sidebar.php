<?php
    $pcontroller_id = Yii::app()->controller->id;
    $paction_id = Yii::app()->controller->action->id;
    $menu_1='';
    $menu_2='';
    $menu_3='';
    $menu_4='';
    $menu_5='';
    $menu_6='';
    $menu_7='';
    $menu_8='';
    $menu_9='';
    $menu_10='';
    $menu_11='';
    //Camera
    if($pcontroller_id=='bList' || $pcontroller_id=='cat' || $pcontroller_id=='bModel' || $pcontroller_id=='access' || $pcontroller_id=='bBrand' || $pcontroller_id=='bBody' || $pcontroller_id=='bColor' || $pcontroller_id=='bKit' || $pcontroller_id=='bTimeline'|| $pcontroller_id=='customer' || $pcontroller_id=='cart' || $pcontroller_id=='subscribe' || $pcontroller_id=='ads' || $pcontroller_id=='analytics' || $pcontroller_id=='export' || $pcontroller_id=='combos') $menu_1='class="active"';
    //Tin tuc
    if($pcontroller_id=='news') $menu_2='class="active"';	
	if($pcontroller_id=='admin') $menu_3='class="active"';	
	if($pcontroller_id=='logs') $menu_4='class="active"';
	
    $user_id=Yii::app()->user->id;
    $permit=AdminAuthassignment::getPermitByUser($user_id);
?>
<?php if($user_id!=1){ ?>
<div class="sidebar">
    <ul class="nav">
    	<li <?php echo $menu_1;?>>
            <a href="<?php echo Url::createUrl('bList/index');?>" title="">
                <span><em class="ic_adv"></em></span>
                <span><strong>CAMERA</strong></span>
            </a>
            <ul class="menu-sub">
                <li style="border-top:none;border-bottom:none"> <span class="dot"></span></li>
                <?php if(isset($permit[1])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('cat/index');?>">Danh mục</a></li>
                <?php } ?>
                <?php if(isset($permit[2])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bList/index');?>">Danh sách CAMERA</a></li>
                <?php } ?>
                <?php if(isset($permit[3])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bModel/index');?>">QL Model</a></li>
                <?php } ?>
                <?php if(isset($permit[8])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('access/index');?>">QL Phụ kiện</a></li>
                <?php } ?>
                <?php if(isset($permit[25])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('combos/index');?>">COMBOS</a></li>
                <?php } ?>
                <?php if(isset($permit[5])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bBrand/index');?>">QL Brand</a></li>
                <?php } ?>
                <?php if(isset($permit[4])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bBody/index');?>">QL Body</a></li>
                <?php } ?>
                <?php if(isset($permit[7])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bKit/index');?>">QL Combo Kit</a></li>
                <?php } ?>
                <?php if(isset($permit[6])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bColor/index');?>">QL Color</a></li>
                <?php } ?>
                <?php if(isset($permit[14])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bTimeline/index');?>">QL Timeline</a></li>
                <?php }?>
				<?php if(isset($permit[16])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('customer/index');?>">QL Khách hàng</a></li>
                <?php } ?>
                <?php if(isset($permit[9])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('cart/index');?>">QL Giỏ hàng</a></li>
                <?php }?>
                <?php if(isset($permit[24])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bill/index');?>">QL Hóa đơn</a></li>
                <?php }?>
                <?php if(isset($permit[10])){ ?>
				<li class="no_bor"><a href="<?php echo Url::createUrl('subscribe/index');?>">QL Email Subscribe</a></li>
                <?php } ?>
                <?php if(isset($permit[15])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('ads/index');?>">QL Quảng cáo</a></li>
                <?php } ?>
                <?php if(isset($permit[19])){ ?>
                <li><a href="<?php echo Url::createUrl('analytics/chart');?>">Thống kê</a></li>
                <!--<li class="last"><a href="<?php echo Url::createUrl('export/all');?>">Excel Hàng tồn</a></li>-->
                <?php } ?>
            </ul>
        </li>
        <li <?php echo $menu_2;?>>
            <a href="<?php echo Url::createUrl('news/index');?>" title="">
                <span><em class="customers"></em></span>
                <span><strong>Tin tức</strong></span>
            </a>
            <ul class="menu-sub">
                <li style="border-top:none;border-bottom:none"> <span class="dot"></span></li>
                <?php if(isset($permit[11])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('news/index');?>">QL Tin tức</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('news/add');?>">Thêm mới Tin</a></li>
                <?php } ?>
                <?php if(isset($permit[12])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('topic/index');?>">DS Chuyên đề</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('topic/add');?>">Thêm mới chuyên đề</a></li>
                <?php } ?>
                
                <?php if(isset($permit[22])){ ?>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bStaticContent/edit/static_id/1');?>">Sửa Liên hệ</a></li>
                <?php } ?>
                
                <?php if(isset($permit[13])){ ?>
                <li class="last"><a href="<?php echo Url::createUrl('newsComment/index');?>">QL Comment</a></li>
                <?php } ?>
                
            </ul>
        </li>
        <?php if(isset($permit[21])){ ?>
        <li>
            <a <?php echo $menu_3;?> href="<?php echo Url::createUrl('admin/index');?>" title="">
                <span><em class="ic_admin"></em></span>
                <span><strong>Admin User</strong></span>
            </a>
            <ul class="menu-sub">
                <li style="border-top:none;border-bottom:none"> <span class="dot"></span></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('admin/index');?>">DS tài khoản Admin</a></li>
                <li class="last"><a href="<?php echo Url::createUrl('admin/add');?>">Thêm mới tài khoản Admin</a></li> 
            </ul>
        </li>
        <?php } ?>
        <?php if(isset($permit[100])){ ?>
        <li>
            <a <?php echo $menu_4;?> href="<?php echo Url::createUrl('logs/index');?>" title="">
                <span><em class="ic_admin"></em></span>
                <span><strong>Logs</strong></span>
            </a>
            <ul class="menu-sub">
                <li style="border-top:none;border-bottom:none"> <span class="dot"></span></li>
                <li class="last"><a href="<?php echo Url::createUrl('logs/index');?>">Logs</a></li>
            </ul>
        </li>
        <?php } ?>
    </ul>
</div>
<?php } else if($user_id==1){ ?>
<div class="sidebar">
    <ul class="nav">
    	<li <?php echo $menu_1;?>>
            <a href="<?php echo Url::createUrl('bList/index');?>" title="">
                <span><em class="ic_adv"></em></span>
                <span><strong>CAMERA</strong></span>
            </a>
            <ul class="menu-sub">
                <li style="border-top:none;border-bottom:none"> <span class="dot"></span></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('cat/index');?>">Danh mục</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bList/index');?>">Danh sách CAMERA</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bModel/index');?>">QL Model</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('access/index');?>">QL Phụ kiện</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('combos/index');?>">COMBOS</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bBrand/index');?>">QL Brand</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bBody/index');?>">QL Body</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bKit/index');?>">QL Combo Kit</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bColor/index');?>">QL Color</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bTimeline/index');?>">QL Timeline</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('cart/index');?>">QL Giỏ hàng</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bill/index');?>">QL Hóa đơn</a></li>
				<li class="no_bor"><a href="<?php echo Url::createUrl('subscribe/index');?>">QL Email Subscribe</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('bStaticContent/edit/static_id/1');?>">Sửa Liên hệ</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('ads/index');?>">QL Quảng cáo</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('customer/index');?>">QL Khách hàng</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('analytics/chart');?>">Thống kê</a></li>
                <li class="last"><a href="<?php echo Url::createUrl('export/all');?>">Excel Hàng tồn</a></li>
            </ul>
        </li>
        <li <?php echo $menu_2;?>>
            <a href="<?php echo Url::createUrl('news/index');?>" title="">
                <span><em class="customers"></em></span>
                <span><strong>Tin tức</strong></span>
            </a>
            <ul class="menu-sub">
                <li style="border-top:none;border-bottom:none"> <span class="dot"></span></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('news/add');?>">Thêm mới Tin</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('topic/index');?>">DS Chuyên đề</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('topic/add');?>">Thêm mới chuyên đề</a></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('newsComment/index');?>">QL Comment</a></li>
                <li class="last"><a href="<?php echo Url::createUrl('bContact/edit/contact_id/1');?>">QL Liên hệ</a></li>
            </ul>
        </li>
        <li>
            <a <?php echo $menu_3;?> href="<?php echo Url::createUrl('admin/index');?>" title="">
                <span><em class="ic_admin"></em></span>
                <span><strong>Admin User</strong></span>
            </a>
            <ul class="menu-sub">
                <li style="border-top:none;border-bottom:none"> <span class="dot"></span></li>
                <li class="no_bor"><a href="<?php echo Url::createUrl('admin/index');?>">DS tài khoản Admin</a></li>
                <li class="last"><a href="<?php echo Url::createUrl('admin/add');?>">Thêm mới tài khoản Admin</a></li> 
            </ul>
        </li>
        <li>
            <a <?php echo $menu_4;?> href="<?php echo Url::createUrl('logs/index');?>" title="">
                <span><em class="ic_admin"></em></span>
                <span><strong>Logs</strong></span>
            </a>
            <ul class="menu-sub">
                <li style="border-top:none;border-bottom:none"> <span class="dot"></span></li>
                <li class="last"><a href="<?php echo Url::createUrl('logs/index');?>">Logs</a></li>
            </ul>
        </li>
        
    </ul>
</div>
<?php } ?>