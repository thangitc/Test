<?php $url = new Url();?>    
   <div class="body_pages clearfix">
            <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
                <tbody>
                    <tr>
                        <td class="first" valign="top">
                              <?php $this->renderPartial('application.views.static.sidebar') ;  ?>
                        </td>
                        <td valign="top" class="last">
                            <div class="content_pages">
                            
                                <div class="box_form">
                                 <div class="box magt20 bottom30">
            <ul class="form">
          <li class="clearfix">
            <label><strong>Họ tên  </strong><span class="clred">*</span></label>
            <div class="filltext">
                        <input type="text"  id="full_name" name="full_name" style="width:220px">
                    </div>
          </li>
          <li class="clearfix">
            <label><strong>Tên đăng nhập  </strong><span class="clred">*</span></label>
            <div class="filltext">
                        <input type="text" id="username" name="username" style="width:220px">
                    </div> 
          </li>
          <li class="clearfix">
            <label><strong>Email </strong><span class="clred">*</span></label>
            <div class="filltext">
                        <input type="text" id="email" name="email" style="width:220px">
                    </div>
          </li>
          <li class="clearfix">
                        <label><strong>Vị trí </strong><span class="clred">*</span></label>
                        <div class="filltext">
                        <select style="width: 100px;" id="type_admin" name="type_admin">
                            <option value="1">Admin</option>
                            <option value="2">Biên tập viên</option>
                            <option value="3">Cộng tác viên</option>
                        </select>
                    </div>
                        
                    </li>
                    <li class="clearfix">
                        <label><strong>Mật khẩu </strong> <span class="clred">*</span></label>
                        <div class="filltext">
                        <input type="password" id="password" name="password" style="width:220px">
                    </div>
                    </li>
                      <li class="clearfix">
                        <label><strong>Mật khẩu xác nhận </strong> <span class="clred">*</span></label>
                        <div class="filltext">
                        <input type="password" id="re_pass" name="re_pass" style="width:220px">
                    </div>
                    </li>
          <li class="clearfix">
                        <label><strong>Thông tin khác </strong> </label>
                        <div class="filltext">
                              <div class="filltext">
                        <textarea style="width:70%; height:120px" id="info_admin" name="info_admin"></textarea>
                    </div>
                        </div>
                    </li>                    
          <li class="clearfix">
            <label>&nbsp;</label>
            <div class="filltext">
          <input  type="submit" class="buton-radi" onclick="saveAdmin()" value=" Thêm mới ">
            </div>
          </li>
          <li id="result_login" style="color:red;">
                </li>
        </ul>
        </div>
            
                                
        </div> 
                                 <?php $this->renderPartial('application.views.static.footer') ;  ?>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
<script>
function check_editemail(mail) {
    emailRegExp = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.([a-z]){2,4})$/;
    if (emailRegExp.test(mail)) {
        return 1;
    }
    else {
        return 0;
    }
}
function saveAdmin(){
    var username = $("#username").val();
    var password = $("#password").val();
    var re_pass = $("#re_pass").val();
    var full_name = $("#full_name").val();
    var email = $("#email").val();
    var type_admin=$('#type_admin').val();
    if(full_name ==""){
        $('#result_login').html('Vui lòng nhập họ tên');
        return false;
    }
    
    if(username==""){
        $('#result_login').html('Vui lòng nhập tên đăng nhập');
        return false;
    }
    if(check_editemail(email) !=1){
        $('#result_login').html('Không đúng định dạng email');
        return false;  
    }
    if(password==""){
        $('#result_login').html('Mật khẩu không được để trống!');
        return false;
    }
    if(password.length <6){
        $('#result_login').html('Mật khẩu phải lớn hơn 6 ký tự');
        return false;
    }
    if(password != re_pass){
        $('#result_login').html('Mật khẩu nhập lại không đúng!');
        return false;
    }
    
    var strUrl = "<?=$url->createUrl("admin/create") ?>"; 
    $.ajax({
        type: "POST",
        url: strUrl,
        data: {username:username,password:password,email:email,full_name:full_name,type_admin:type_admin,active:1},
        success: function(msg){

            if(msg==-1){
                $('#result_login').html('Đã tồn tại tên tài khoản này rồi!');
                return false;
            }else if(msg==0){
                $('#result_login').html('Có vấn đề xảy ra!');
                return false;
            }else{
                $('#result_login').html('Thêm mới thành công');
                window.location = '<?=$url->createUrl("admin/index") ?>';
                }
            },
            beforeSend:function(){
                $("#save_admin").attr("disabled","disabled");
            },
            complete:function(){
                $("#save_admin").removeAttr("disabled");
            }   
        });
    }
</script>