<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
    <tbody>
    <tr>
    <td class="first" valign="top">
        <?php $this->renderPartial('application.views.static.sidebar') ;  ?>
    </td>
    <td valign="top" class="last">
    <div class="content_pages">

        <div class="box_form">
            <div class="box magt20 bottom30 clearfix">
                <div class="col55">
                    <form action="<?php echo Url::createUrl('admin/permit',array('id'=>$user_infor['id']));?>" method="post">
                        <table width="100%" cellspacing="0" cellpadding="0" border="0" class="col_list txt-right">
                            <tbody>
                                <tr class="bg_grblue">
                                    <td width="37%"><strong>Module</strong></td>
                                    <td width="11%"><strong>Tạo mới </strong></td>
                                    <td width="11%"><strong>Cập nhật </strong></td>
                                    <td width="11%"><strong>Xóa</strong></td>
                                    <td width="11%"><strong>Danh sách</strong></td>
                                    <!--<td width="11%"><strong>Seo</strong></td>-->
                                </tr>
                                <?php
                                    if($array_module)
                                    {
                                        foreach($array_module as $key=>$row)
                                        {
                                        ?>
                                        <tr>
                                            <td class="text-left bg-grey"><?php echo $row;?></td>
                                            <td><input type="checkbox" value="2" name="<?php echo $user_infor['id'];?>_2_<?php echo $key;?>" <?php if(isset($authassignment[$user_infor['id']."_2_".$key]) || isset($_POST[$user_infor['id']."_2_".$key])) echo 'checked';?> ></td>
                                            <td><input type="checkbox" value="4" name="<?php echo $user_infor['id'];?>_4_<?php echo $key;?>" <?php if(isset($authassignment[$user_infor['id']."_4_".$key]) || isset($_POST[$user_infor['id']."_4_".$key])) echo 'checked';?>></td>
                                            <td><input type="checkbox" value="8" name="<?php echo $user_infor['id'];?>_8_<?php echo $key;?>" <?php if(isset($authassignment[$user_infor['id']."_8_".$key]) || isset($_POST[$user_infor['id']."_8_".$key])) echo 'checked';?>></td>
                                            <td><input type="checkbox" value="1" name="<?php echo $user_infor['id'];?>_1_<?php echo $key;?>" <?php if(isset($authassignment[$user_infor['id']."_1_".$key]) || isset($_POST[$user_infor['id']."_1_".$key])) echo 'checked';?>></td>
                                            <!--<td><input type="checkbox" value="1" name="<?php echo $user_infor['id'];?>_1_<?php echo $key;?>" <?php if(isset($authassignment[$user_infor['id']."_1_".$key]) || isset($_POST[$user_infor['id']."_1_".$key])) echo 'checked';?>></td>-->
                                        </tr>
                                        <?php
                                        }
                                    }
                                ?>

                            </tbody>
                        </table>
                        <div class="clearfix fillter">
                        <div class="fl reseach">
                        <input type="submit" class="btn-orange fl magr10" value="Lưu">
                    </form>
                </div>


            </div>
        </div>
    </div>


</div> 
 <?php $this->renderPartial('application.views.static.footer') ;  ?>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>