<link rel="stylesheet" href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>
<script>
$(function(){
    $("#from_date, #to_date").datepicker({
        dateFormat:"dd/mm/yy",
        showOn: "button",
        buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/ic-date.png';?>",
    });
    $('.delete_user').click(function(){
        if(confirm("Bạn có chắc chắn muốn xóa?"))
        {
            $.ajax({
                type: "POST",
                url: '<?php echo Url::createUrl("admin/deleteUser"); ?>',
                data: {
                    uid:$(this).attr('rel')
                },
                success: function(msg){
					if(msg!=0 || msg!=1)
					{
                    	alert(msg);
					}
                    window.location.reload();
                }
            });
        }
        else
        {
            return false;
        }
    });
	
	$('#formSearch').keypress(function(e){
		switch(e.which)
		{
			case 13:
				$('#formSearch').submit();
			break;
		}
	});
});
</script>
<div class="body_pages clearfix">
            <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
                <tbody>
                    <tr>
                        <td class="first" valign="top">
                               <?php $this->renderPartial('application.views.static.sidebar') ;  ?>
                        </td>
                        <td valign="top" class="last">
                            <div class="content_pages">
                            
                                <div class="box_form">
                                 <div class="box bottom30">
            <form action="<?php echo Url::createUrl('admin/index');?>" method="post">
            <ul class="form4">
          <li class="clearfix">
            <label><strong>Từ khóa:</strong></label>
            <div class="filltext">
              <input type="text" style="width:200px;margin-right:16px;" id="keyword" name="keyword" value="<?php echo $array_input['keyword'];?>"> <label><strong>Trong </strong></label> 
              <select style="width:100px" name="in_keyword">
                  <option value="1" <?php if ($array_input['in_keyword']==1) echo 'selected';?>>Username</option>
                    <option value="2" <?php if ($array_input['in_keyword']==2) echo 'selected';?>>ID</option>
                    <option value="3" <?php if ($array_input['in_keyword']==3) echo 'selected';?>>Tên</option>
            </select>
            </div>
          </li>
          <li class="clearfix">
                        <label><strong>Trạng thái :</strong></label>
                        <div class="filltext">
            <select style="width:208px;" id="status">
                 <option value="-1" <?php if ($array_input['status']==-1) echo 'selected';?>>All</option>
                            <option value="1" <?php if ($array_input['status']==1) echo 'selected';?>>Active</option>
                            <option value="0" <?php if ($array_input['status']==0) echo 'selected';?>>InActive</option>
            </select>
                        </div>
                    </li>
                    <li class="clearfix">
                        <label><strong>Vị trí :</strong></label>
                        <div class="filltext" id="type_admin">
                            <select style="width:208px;">
                  <option value="0" <?php if ($array_input['type_admin']==0) echo 'selected';?>>All</option>
                            <option value="1" <?php if ($array_input['type_admin']==1) echo 'selected';?>>Admin</option>
                            <option value="2" <?php if ($array_input['type_admin']==2) echo 'selected';?>>Biên tập viên</option>
                            <option value="3" <?php if ($array_input['type_admin']==3) echo 'selected';?>>Cộng tác viên</option>
            </select>
                        </div>
                    </li>
                    <li class="clearfix">
                        <label><strong>Từ ngày:</strong></label>
                        <div class="filltext">
                             <input type="text" style="width:150px" name="from_date" id="from_date" value="<?php if($array_input['from_date']!=0) echo date('d/m/Y',$array_input['from_date']); ?>" > 
                            <input type="button" class="ic_caleda">
                            &nbsp; <strong>Đến ngày</strong> &nbsp;
                        <input type="text" style="width:150px" name="to_date" id="to_date" value="<?php if($array_input['to_date']!=0) echo date('d/m/Y',$array_input['to_date']); ?>">
                        <input type="button" class="ic_caleda">
                        </div>
                    </li>
          <li class="clearfix">
            <label>&nbsp;</label>
            <div class="filltext">
             <input type="submit" class="buton-radi" value="&nbsp; Tìm kiếm &nbsp;">
            </div>
          </li>
        </ul>
            </form> 
        </div>
            <div class="box bottom30">
               <div class="clearfix fillter">
               <div class="fl reseach">
                        Tìm thấy <strong class="bg-orage"><?php echo $total;?></strong> kết quả trong <strong class="cl-orage"><?php echo ceil($total/$array_input['num_per_page']);?></strong> trang
                    </div>
                  <div class="fr reseach">
                  <a href="<?php echo Url::createUrl("admin/add"); ?>"><input type="button" class="btn-orange fl magr10" value="Thêm mới user"></a>
                        <ul class="pages fl clearfix">
                            <?php echo $paging;?>
                        </ul>
                    </div>
                    
                    
                </div>
                        <table width="100%" cellspacing="0" cellpadding="0" border="0" class="col_list txt-right">
                            <tbody>
                                <tr class="bg-grey">
                                    <td width="6%"><strong>ID </strong><br>
                                    <input type="checkbox" name=""></td>
                                    <td width="12%" class="text-left"><strong>User Name </strong></td>
                                    <td width="14%" class="text-left"><strong>Họ tên</strong></td>
                                    <td width="14%"><strong>Email</strong></td>
                                    <td width="12%"><strong>Last Login Time </strong></td>
                                    <td width="8%"><strong>Kích hoạt </strong></td>
                                    <td width="11%"><strong>Vị trí </strong></td>
                                    <td width="9%"><strong>Ngày tạo</strong></td>
                                    <td width="14%"><strong>Công cụ </strong><br>
                                    <a href="javascript:"> Xóa </a> | <a href="javascript:"> Phân quyền </a></td>
                                </tr>
                                <?php
                                if($rows)
                                {
                                $k=1;
                                foreach($rows as $row)
                                {
                                    
                                    ?>
                                <tr>
                                    <td><?php echo ($k+($array_input['page']-1)*$array_input['num_per_page']);?><br>
                                    <input type="checkbox" class="selectOne" onclick="doCheck();" value="<?php echo $row["id"];?>" />
                                    </td>
                                    <td class="text-left"><?php echo $row['username'];?></td>
                                <td class="text-left"><?php echo $row['full_name'];?></td>
                                <td><a href="mailto:<?php echo $row['email'];?>"><?php echo $row['email'];?></a></td>
                                <td><?php echo date('d/m/Y',$row['last_login_time']);?></td>
                                <td>
                                    <input id="active_<?php echo ($row['id']);?>" type="checkbox" value="1" <?php if($row['active']==1) echo ("checked");?> onclick="ActiveAdminUser(<?php echo ($row['id']);?>);">
                                </td>
                                <td>
                                    <?php
                                    if(isset($row['type_admin']) && $row['type_admin']==1) echo 'Admin';
                                    else if( isset($row['type_admin']) && $row['type_admin']==2) echo 'Biên tập viên';
                                    else echo 'Cộng tác viên';
                                    ?>
                                </td>
                                <td><?php echo date('d/m/Y',$row['create_date']);?></td>
                                <td><a href="<?php echo Url::createUrl('admin/edit',array('id'=>$row['id']));?>"> Sửa </a> | <a href="javascript:" class="delete_user" rel="<?php echo $row['id'];?>"> Xóa </a> <br>
                                    <a href="<?php echo Url::createUrl('admin/change',array('id'=>$row['id']));?>">Đổi mật khẩu </a> | <a href="<?php echo Url::createUrl('admin/permit',array('id'=>$row['id']));?>"> Phân quyền </a></td>
                                </tr>
                                <?php
                                    $k++;
                                }
                                }
                                ?>
                               
                                                                 
                            </tbody>
                        </table>

            <div class="clearfix fillter">
               <div class="fl reseach">
                                            Tìm thấy <strong class="bg-orage"><?php echo $total;?></strong> kết quả trong <strong class="cl-orage"><?php echo ceil($total/$array_input['num_per_page']);?></strong> trang
                                        </div>
                                      <div class="fr reseach">
                                            <ul class="pages fl clearfix">
                                                <?php echo $paging;?>  
                                            </ul>
                                        </div>
                                        
                                        
                                    </div>
            </div>
                                
        </div> 
                                 <?php $this->renderPartial('application.views.static.footer') ;  ?>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
<script type="text/javascript">
function ActiveAdminUser(adminId)
{
    loadingAjax();
    var active = 0;
    if ($("#active_"+adminId).is(':checked')) {
        active = 1;
    }
    
    $.ajax({
        url:base_url_ajax+"ActiveAdminUser",
        type:"POST",
        data:({
            adminId:adminId
            , active:active                                                   
        }),
        success:function(response){
            var result = eval( "(" + response + ")" );
            if(result.status !== "noPermis"){
                if(result.status==true){
                    /*alert("Cập nhật thành công.");*/
                }
            } else {
                alert("Bạn không đủ quyền thực hiện hành động này.");
            }
            closeLoadingAjax();
        },
        error:function(){
            alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
            closeLoadingAjax();
        }
    });   
}
</script>