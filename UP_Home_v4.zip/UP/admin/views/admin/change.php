   <div class="body_pages clearfix">
            <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
                <tbody>
                    <tr>
                        <td class="first" valign="top">
                             <?php $this->renderPartial('application.views.static.sidebar') ;  ?>
                        </td>
                        <td valign="top" class="last">
                            <div class="content_pages">
                            
                                <div class="box_form">
                                 <div class="box magt20 bottom30">
            <ul class="form bottom20">
          <li class="clearfix">
            <label><strong>Tên đăng nhập </strong><span class="clred">*</span></label>
             <div class="filltext">
                        <label><?php echo $infor['username'];?></label>
                    </div>
          </li>
          <li class="clearfix">
            <label><strong>Mật khẩu </strong><span class="clred">*</span></label>
            <div class="filltext">
                        <input type="password" style="width:25%" id="oldpass" name="oldpass">
                    </div>
          </li>
          <li class="clearfix">
            <label><strong>Mật khẩu mới  </strong><span class="clred">*</span></label>
             <div class="filltext">
                        <input type="password" style="width:25%" id="newpass" name="newpass">
                    </div>
          </li>
          <li class="clearfix">
            <label><strong>Mật khẩu xác nhận  </strong><span class="clred">*</span></label>
            <div class="filltext">
                        <input type="password" style="width:25%" id="re_newpass" name="re_newpass">
                    </div>
          </li>
         <li class="clearfix">
            <label>&nbsp;</label>
            <div class="filltext">
           <input  type="submit" id="changepass" onclick="changePass();" class="buton-radi" value="&nbsp; Lưu &nbsp;">
            </div>
          </li>
          <li id="result_login" style="color:red;">
                </li>
        </ul>
        </div>
            
                                
        </div> 
                    <?php $this->renderPartial('application.views.static.footer') ;  ?>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
<script>

function changePass()
{
    var newpass = $("#newpass").val();
    var re_newpass = $("#re_newpass").val();
    var oldpass = $("#oldpass").val();
    if(oldpass ==""){
        $('#result_login').html('Vui lòng nhập mật khẩu cũ');
        return false;
    }
    if(newpass ==""){
        $('#result_login').html('Vui lòng nhập mật khẩu mới');
        return false;
    }
    if(re_newpass ==""){
        $('#result_login').html('Vui lòng nhập lại mật khẩu mới');
        return false;
    }
    if(newpass!=re_newpass){
        $('#result_login').html('Mật khẩu mới không đúng');
        return false;
    }
    
    var strUrl = "<?php echo Url::createUrl("admin/changePass"); ?>"; 
    $.ajax({
        type: "POST",
        url: strUrl,
        data: {oldpass:oldpass,newpass:newpass,re_newpass:re_newpass,user_id:'<?php echo $infor['id'];?>'},
        success: function(msg){
            $('#result_login').html(msg);
        }
    });
}
</script>