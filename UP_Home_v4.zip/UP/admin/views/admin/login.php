<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Trang chủ</title>
<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->params['static_url'];?>/style/theme.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->params['static_url'];?>/style/login.css"/>
</head>

<body style="background:#3E9ACB">
    
<div class="box-admin">
    <div class="title-box-admin"></div>
    <div class="box-admin-cont clearfix">
        <?php echo CHtml::beginForm()?> 
        <label style="color: red; text-align: center;"><?php echo CHtml::errorSummary($model,"&nbsp;")?></label>
        <ul class="form3">
            <li class="clearfix"><label>Tên đăng nhập:</label>
                <div class="filltext clearfix">
                <p>
                    <?php echo CHtml::activeTextField($model,"username",array("class"=>"input1"));?>
                </p>                
                </div>
            </li>
            <li class="clearfix"><label>Mật khẩu:</label>
                <div class="filltext clearfix">
                    <p>
                    <?php echo CHtml::activePasswordField($model,"password",array("class"=>"input1"));?>
                    </p>
                    <p>
                    <?php echo CHtml::activeCheckBox($model,"remember")?>
                    Nhớ mật khẩu
                    </p>
                    <p><input type="submit" value="Đăng nhập" class="btn-orange"></p>
                </div>
            </li>
        </ul>
        <?php echo CHtml::endForm();?>   
    </div>
</div>
<!-- End wrapper-->

    
</body>
</html>
