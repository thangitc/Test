<div class="body_pages clearfix">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
        <tbody>
            <tr>
                <td class="first" valign="top">
                    <?php $this->renderPartial('application.views.static.sidebar') ;  ?>                         
                </td>
                <td valign="top" class="last">
                    <div class="content_pages">
                        
                        <div class="box_form">
                            <div class="box bottom30 clearfix">
                                <div class="table clearfix">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td class="txt-left"><strong class="s14 cl-orage fl">THÔNG TIN THÀNH VIÊN - <?php echo $detail['email'] ?> - <?php echo $detail['fullname'] ?> :</strong> 
                                                    
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="txt-left">
                                                    <ul class="form4">
                                                        <li class="clearfix">
                                                            <label><strong>Họ Tên: </strong></label>
                                                            <div class="filltext">
                                                                <?php echo $detail['fullname']; ?>
                                                            </div>
                                                        </li>
                                                        <li class="clearfix">
                                                            <label><strong>Email:</strong></label>
                                                            <div class="filltext">
                                                                <span class="clblue"><?php echo $detail['email']; ?></span>
                                                            </div>
                                                        </li>
                                                        <li class="clearfix">
                                                            <label><strong>Avatar:</strong></label>
                                                            <div class="filltext">
                                                                <?php
																if($detail['avatar']!='')
																	$picture = Common::getImage($detail['avatar'],'avatar','');	
																else $picture = '';
																if($picture!='')
																{
																	?>
																	<img width="100px;" height="100px;" src="<?php echo $picture;?>" />
																	<?php
																}
																?>
                                                            </div>
                                                        </li>
                                                        <li class="clearfix">
                                                            <label><strong>Điện thoại: </strong></label>
                                                            <div class="filltext">
                                                                <?php echo $detail['mobile']; ?>
                                                            </div>
                                                        </li>
                                                        <li class="clearfix">
                                                            <label><strong>Địa chỉ: </strong></label>
                                                            <div class="filltext">
															<?php
                                                            	$city_info = isset($citys[$detail['city_id']]) ? $citys[$detail['city_id']] : array();
																$district_info = isset($citys[$detail['district_id']]) ? $citys[$detail['district_id']] : array();
																$text_city = '';
																if(!empty($district_info)) $text_city .= $district_info['title'];
																if(!empty($city_info) && $text_city!='') $text_city .= ', '.$city_info['title'];
																
																echo $text_city;
                                                            ?>
                                                            </div>
                                                        </li>
                                                        <li class="clearfix">
                                                            <label><strong>Yahoo: </strong></label>
                                                            <div class="filltext">
                                                                <?php echo $detail['yahoo']; ?>
                                                            </div>
                                                        </li>
                                                        <li class="clearfix">
                                                            <label><strong>Skype: </strong></label>
                                                            <div class="filltext">
                                                                <?php echo $detail['skype']; ?>
                                                            </div>
                                                        </li>
                                                        <li class="clearfix">
                                                            <label><strong>Loại tài khoản: </strong></label>
                                                            <div class="filltext">
                                                                <?php if($detail['account_type']==1) echo 'Cá nhân'; else echo 'Doanh nghiệp'; ?>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div> 
                        <?php $this->renderPartial('application.views.static.footer') ;  ?> 
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
        </div>
