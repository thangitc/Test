<script>
$(function(){
	$('#type').change(function(){
		if($(this).val()==1)
			$('#box_more').show();
		else $('#box_more').hide();
	});
});
function addMoneyJapan(money_id)
{	
	var type=$('#type').val();
	var title=$('#title').val();
	var description=$('#description').val();	
	var money_send_japan=$('#money_send_japan').val();
	var money_rate=$('#money_rate').val();
	var money_yen_received_japan=$('#money_yen_received_japan').val();
	loadingAjax();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addMoneyJapan');?>',
		type: "POST",
		data:({
			type:type,  
			title:title,
			description:description,
			money_send_japan:money_send_japan,
			money_rate:money_rate,
			money_yen_received_japan:money_yen_received_japan,
			money_id:money_id
		}),
		success: function(resp){
			closeLoadingAjax();
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
		}
	});
}

function format_number(num)
{
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
	num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num*100+0.50000000001);
	cents = num%100;
	num = Math.floor(num/100).toString();
	if(cents<10)
	cents = "0" + cents;
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	num = num.substring(0,num.length-(4*i+3))+','+
	num.substring(num.length-(4*i+3));
	return (((sign)?'':'-') + num);
}
$(function(){
	//format_number
	$('#money_send_japan,#money_rate,#money_yen_received_japan').keypress(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	$('#money_send_japan,#money_rate,#money_yen_received_japan').keyup(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
	$('#money_send_japan,#money_rate,#money_yen_received_japan').keydown(function(){
		$(this).next('em').html(format_number($(this).val()));
	});
});
</script>