<script>
function addCustomer(customer_id, camera_id, access_id)
{	
	var title=$('#title').val();
	var mobile=$('#mobile').val();
	var email=$('#email').val();
	var address=$('#address').val();
	var city_id=$('#city_id').val();
		
	if($('#title').val()=='')
	{
		alert('Vui lòng nhập tên khách hàng!');
		$('#title').focus();
		return false;
	}
	if($('#mobile').val()=='')
	{
		alert('Vui lòng nhập số điện thoại!');
		$('#mobile').focus();
		return false;
	}
	if($('#address').val()=='')
	{
		alert('Vui lòng nhập địa chỉ!');
		$('#mobile').focus();
		return false;
	}
	
	loadingAjax();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addCustomer');?>',
		type: "POST",
		data:({
			title:title,
			mobile:mobile,
			email:email,
			address:address,
			city_id:city_id,
			customer_id:customer_id,
			camera_id:camera_id,
			access_id:access_id
		}),
		success: function(resp){
			closeLoadingAjax();
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
		}
	});
}
</script>