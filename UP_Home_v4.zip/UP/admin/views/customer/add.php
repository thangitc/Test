<?php $this->renderPartial('js');?>
<div class="body_pages clearfix">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
<tbody>
<tr>
    <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
    <td valign="top" class="last">
        <div class="content_pages">
        <?php //$this->renderPartial('application.views.eExam._box_tab');?>
        <div class="box_form">
          
        <div class="box bottom30 clearfix">
        <div class="box bottom30 clearfix">
        <p>
        	<strong class="s14 clblue">Thêm mới Khách hàng</strong><?php if($camera_info) echo ' ('.$camera_info['title'].')';?></p>
            <ul class="form4">
                <li class="clearfix"><label><strong>Tên khách hàng :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="title" name="title"> 
                    </div>
                </li>
                <li class="clearfix"><label><strong>Số điện thoại :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="mobile" name="mobile"> 
                    </div>
                </li>
                <li class="clearfix"><label><strong>Email :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="email" name="email"> 
                    </div>
                </li>
                <li class="clearfix"><label><strong>Địa chỉ :</strong> </label>
                    <div class="filltext">
                    <input type="text" style="width:370px" id="address" name="address"> 
                    </div>
                </li>
                <li class="clearfix"><label><strong>Chọn tỉnh :</strong></label>
                    <div class="filltext">
                        <select style="width:179px;" name="city_id" id="city_id">
                            <option value="0" selected="selected">--Chọn Tỉnh--</option>
                            
                            <?php
                            if($citys)
                            foreach($citys as $row)
                            {
                                ?>
                                <option value="<?php echo $row['id'];?>" ><?php echo $row['title'];?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    
                </li>
                <li class="clearfix"><label>&nbsp;</label>
                    <div class="filltext">
                    <input type="button" class="buton-radi" value="Thêm mới" onclick="addCustomer(0,<?php echo $camera_id;?>,<?php echo $access_id;?>);">
                    </div>
                </li>
                <li style="color:red;" id="result"></li>
            </ul>
        
        </div>
        </div>
        
        </div> 
            <?php $this->renderPartial('application.views.static.footer');?>
        </div>
    </td>
</tr>
</tbody>
</table>
</div>