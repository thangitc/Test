<link href="<?php echo Yii::app()->params['static_url'];?>/js/picker/base/jquery.ui.all.css" rel="stylesheet">
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.core.js"></script>
<script src="<?php echo Yii::app()->params['static_url'];?>/js/picker/ui/jquery.ui.datepicker.js"></script>
<script>
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/ic-date.png';?>"
	});
});
function searchForm(tab)
{       
	$('#formSearch').submit();
}

/*Xoa*/
function deleteCustomer(customer_id)
{
	if(confirm('Bạn có chắc chắn muốn xóa bản ghi và những dữ liệu liên quan?'))
		$.ajax({
		url: '<?php echo Url::createUrl('ajax/deleteCustomer');?>',
		type: "POST",
		data:({
			customer_id:customer_id
		}),
		success: function(resp){
			location.reload();
		}
	});
}

</script>

<div class="body_pages clearfix">
    <table width="100%" cellspacing="0" cellpadding="0" border="0" class="table_pages">
        <tr>
            <td valign="top" class="first"><?php $this->renderPartial('application.views.static.sidebar');?></td>
            <td valign="top" class="last"><div class="content_pages">
                    <?php $this->renderPartial('application.views.access.tab_color', array('access_id'=>$access_id));?>
                    <div class="box_form">
                        <div class="box bottom30 clearfix">
                            <form method="get" id="formSearch">
                                <ul class="form4">
                                    <li class="clearfix">
                                        <label><strong>Từ khóa :</strong> </label>
                                        <div class="filltext">
                                            <input type="text" style="width:196px;margin-right:20px" name="keyword" id="keyword" value="<?php echo $keyword;?>">
                                            &nbsp; Trong &nbsp;
                                            <select style="width:145px;margin-left:62px" id="keyword_in" name="keyword_in">
                                                <option value="1" <?php if($keyword_in==1) echo 'selected';?>>Tên khách hàng</option>
                                                <option value="2" <?php if($keyword_in==2) echo 'selected';?>>Mobile</option>
                                                <option value="3" <?php if($keyword_in==3) echo 'selected';?>>Tỉnh</option>
                                            </select>
                                        </div>
                                    </li>
                                    <li class="clearfix">
                                        <label>&nbsp;</label>
                                        <div class="filltext">
                                            <input type="button" class="buton-radi" value="Tìm kiếm" onclick="searchForm('');">
                                            <input type="button" value="Hủy" class="buton-radi" onclick="window.location.href='<?php echo Url::createUrl('customer/access');?>'" />
                                            
                                        </div>
                                    </li>
                                </ul>
                                <input type="hidden" id="tab" name="tab" />
                            </form>
                        </div>
                        <div class="box clearfix">
                            <div class="clearfix fillter">
                                <div class="fl">
                                    
                                </div>
                                </br >
                                </br >
                                <div class="fl"><strong>Tìm Thấy : </strong>  <strong style="color:red;"><?php echo $total;?> </strong><strong> Khách hàng mua phụ kiện: <?php echo $access_info['title'];?> trong </strong> <strong><?php echo $page.' trang' ?></strong></div>
                                <div class="fr reseach">
                                    <input type="button" class="btn-orange fl magr10" value="Thêm mới Khách hàng" onclick="window.location.href='<?php echo Url::createUrl('customer/add', array('access_id'=>$access_id));?>'">
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0" id="list" class="col_list txt-right">
                                <tbody>
                                    <tr class="bg_grblue">
                                        <td width="2%">
                                            <strong>STT/ID</strong>
                                            <br>
                                            <input type="checkbox" id="selectAll" onclick="doCheckAll();">
                                            <input type="hidden" id="list_id" />
                                        </td>
                                        <td width="19%"><strong>Tên khách hàng </strong></td>
                                        <td width="15%"><strong>Mobile</strong></td>
                                        <td width="15%"><strong>Địa chỉ</strong></td>
										<td width="15%"><strong>Tỉnh, thành phố</strong></td>
                                        <td width="15%"><strong>Email</strong></td>
                                    </tr>
                                    <?php
									$k=0;
									if($customer)
									foreach($customer as $row)
									{
										?>
										<tr>
											<td>
												<?php echo (($page-1)*$num_per_page+$k);?>
												<hr />
												<?php echo $row['id'];?>
												<br />
												<input type="checkbox" value="<?php echo $row['id'];?>" class="selectOne" onclick="doCheck();">
											</td>
											<td class="txt-left">
												<div class="clearfix col_30">
												<p><strong><?php echo $row['title'];?></strong></p>
												<div class="row-actions">
                                                	<a href="<?php echo Url::createUrl('customer/edit',array('customer_id'=>$row['id']));?>"><span>Sửa</span></a> 
                                                    | <a href="javascript:" onclick="deleteCustomer(<?php echo $row['id'];?>);"><span>Xóa</span></a> 
                                                </div>
                                                </div>
											</td>
                                            <td>
                                            	<?php echo $row['mobile'];?>
                                            </td>
                                             <td>
                                            	<?php echo $row['address'];?>
                                            </td>
                                            <td>
                                            	<?php echo $row['city_title'];?>
                                            </td>
                                            <td>
                                            	<?php echo $row['email'];?>
                                            </td>
										</tr>
										<?php 
									}
									?>
                                </tbody>
                            </table>
                            <div class="clearfix fillter">
                                <div class="fr reseach">
                                    <ul class="pages fl magT5 clearfix">
                                        <?php echo $paging;?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $this->renderPartial('application.views.static.footer');?>
                </div>
            </td>
        </tr>
    </table>
</div>