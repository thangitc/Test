<script>
var is_hot = '<?php echo $is_hot;?>';
$(function(){
	$("#from_date,#to_date").datepicker({
		dateFormat:"dd/mm/yy",
		showOn: "button",
		buttonImage: "<?php echo Yii::app()->params['static_url'].'/images/calendar.png';?>"
	});
	if(is_hot==1)
	{
		$("#list tbody").sortable({disable:true});
	}
})

if(is_hot==1)
{
    function saveOrderNews()
    {    
        var list_order='';
        var news_id=0;
        var news_order=0;
        $('#list tbody>tr').each(function(i){
            news_id=$(this).attr('rel');
            if(news_id)
			{
				news_order=$('#order_'+news_id+'').val();
				list_order+=news_id+'|'+news_order+',';
            }
        });
        if(list_order!='')
		{
			loadingAjax();
			$.ajax({
				url: '<?php echo Url::createUrl('ajax/saveOrderNews');?>',
				type: "POST",
				data:({
					list_order:list_order
				}),
				success: function(resp){
					closeLoadingAjax();
				}
			});
        }
    }
}
function searchForm(status)
{
    if(status=='hot')
    {
        $('#is_hot').val(1);
    }
    else
    {
        $('#status').val(status);
    }
    $('#formSearch').submit();
}

function addNewsToTopic(news_id)
{
	if(news_id>0)
	{
		$("#list_id").val(news_id);
		$.fn.colorbox(
		    {href:"<?php echo Url::createUrl('topic/showTopic',array('boolean'=>1));?>", open:true, innerWidth:800, innerHeight:460}
		);
	}
	else
	{
		alert("Bạn chưa chọn tin thêm vào chuyên đề. Hãy làm lại.");
		return;
	}
}
function quickUpdateNews(quick_type,list_id)
{
	if(list_id=='')
	{
		alert('Bạn chưa chọn tin. Hãy làm lại.');
		return false;
	}
	else
	{
		if(quick_type==4)
		{
			showTopic();
			return false;
		}
		if(quick_type==6)
		{
			showCat();
			return false;
		}
		loadingAjax();
		$.ajax({
			url:"<?php echo Url::createUrl('ajax/quickUpdateNews');?>",
			type:"POST",
			data:({
				quick_type:quick_type,
				list_id:list_id
			}),
			success:function(response){
				var result = eval( "(" + response + ")" );
				if(result.status !== "noPermis"){
					/*alert("Cập nhật thành công.");*/
				} else {
					alert("Bạn không đủ quyền thực hiện hành động này.");    
				}
				location.reload();
				closeLoadingAjax();
			},
			error:function(){
				alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
				closeLoadingAjax();
			}
		});
	}
}
function showTopic()
{
	var list_news_id = $("#list_id").val();
	if(list_news_id == '') {
		alert("Bạn chưa chọn tin. Hãy làm lại.");
		return;
	}
	else {
		$.fn.colorbox(
		    {href:"<?php echo Url::createUrl('ajax/showTopic', array('boolean'=>1));?>", open:true, innerWidth:800, innerHeight:460}
		);		 
	}
}
function showCat()
{
	var list_artilces_id = $("#list_id").val();
	if(list_artilces_id == '') {
		alert("Bạn chưa chọn tin. Hãy làm lại.");
		return;
	}
	else {
		$.fn.colorbox(
		    {href:"<?php echo Url::createUrl('cat/showCat');?>", open:true, innerWidth:800, innerHeight:460}
		);		 
	}
}

function moveCatNews()
{
	var list_id = $("#list_id").val();
	var cat_id = $("#cat_id").val();
	
	if(cat_id != '')
	{
		$.ajax({
	        url:"<?php echo Url::createUrl('ajax/moveCatNews');?>",
	        type:"POST",
	        data:({
	        	list_id:list_id,
	        	cat_id:cat_id
	        }),
	        success:function(response){
	            var result = eval( "(" + response + ")" );
	            if(result.status !== "noPermis"){
	            	/*alert("Cập nhật thành công.");*/
	            } else {
	                alert("Bạn không đủ quyền thực hiện hành động này.");
	            }
	            closeLoadingAjax();
	            $.fn.colorbox.close();
	            location.reload();
	        },
	        error:function(){
	            alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
	            closeLoadingAjax();
	        }
	    });
	}
	else {
		alert("Bạn chưa chọn danh muc. Hãy làm lại.");
	}
}

function deleteNewsOfTopic(topic_id,news_id)
{
    var answer = confirm("Bạn có chắc chắn muốn xóa?");
    if(answer){
        $.ajax({
            url:"<?php echo Url::createUrl('ajax/deleteNewsOfTopic');?>",
            type:"POST",
            data:({
				topic_id:topic_id,
            	news_id:news_id                                                   
            }),
            success:function(response){
                location.reload();
            },
            error:function(){
                alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
            }
        });
    }
}
</script>
<div class="body_pages clearfix">
<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table_pages">
    <tr>
        <td class="first" valign="top"><?php $this->renderPartial('application.views.static.sidebar') ;  ?></td>
        <td valign="top" class="last"><div class="content_pages" id="container">
                <?php //$this->renderPartial('tab');?>
                <div class="box_form">
                    <form method="GET" action="<?php echo Url::createUrl('news/index');?>" id="formSearch">
                        <div class="box bottom30">
                            <ul class="form4">
                                <li class="clearfix">
                                    <label><strong>Từ khóa:</strong></label>
                                    <div class="filltext">
                                        <input type="text" value="<?php echo $keyword;?>" style="width: 300px;" id="keyword" name="keyword">
                                        Trong
                                        <select id="keyword_in" name="keyword_in">
                                            <option value="1" <?php if($keyword_in==1) echo 'selected';?>>Title</option>
                                            <option value="2" <?php if($keyword_in==2) echo 'selected';?>>Username</option>
                                        </select>
                                    </div>                                     
                                </li>
                                
                                <li class="clearfix">
                                    <label><strong>Trạng thái :</strong></label>
                                    <div class="filltext">
                                        <select style="width:150px" onchange="$('#status').val($(this).val());">
                                            <option value="" <?php if($status == '') echo "selected"; ?>>All</option>
                                            <option value="active" <?php if($status == 'active') echo "selected"; ?>>Active</option>
                                            <option value="pending" <?php if($status == 'pending') echo "selected"; ?>>Pending</option>
                                            <option value="draft" <?php if($status == 'draft') echo "selected"; ?>>Draft</option>
                                        </select>
                                        <input type="hidden" id="status" name="status" value="" />
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label><strong>Sắp xếp theo :</strong></label>
                                    <div class="filltext">
                                        <select style="width:150px" name="orderby">
                                            <option value="id" <?php if($orderby == "id") echo "selected"; ?>>ID</option>
                                            <option value="hit" <?php if($orderby == "hit") echo "selected"; ?>>Lượt view</option>
                                        </select>
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label><strong>Chiều :</strong></label>
                                    <div class="filltext">
                                        <select style="width:150px" name="order">
                                            <option value="1" <?php if($order == 1) echo "selected"; ?>>Giảm dần</option>
                                            <option value="0" <?php if($order == 0) echo "selected"; ?>>Tăng dần</option>
                                        </select>
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label><strong>SEO :</strong></label>
                                    <div class="filltext">
                                        <select style="width:150px" name="seo">
                                            <option value="" <?php if($seo == '') echo "selected"; ?>>Tất cả</option>
                                            <option value="1" <?php if($seo == 1) echo "selected"; ?>>Đã Seo</option>
                                            <option value="0" <?php if($seo == 0) echo "selected"; ?>>Chưa Seo</option>
                                        </select>
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label><strong>Từ ngày: </strong></label>
                                    <div class="filltext">
                                        <input type="text" style="width:170px" value="<?php if(isset($from_date) && $from_date!=0) echo date('d/m/Y',$from_date);?>" id="from_date" name="from_date">
                                        &nbsp; Đến ngày &nbsp;
                                        <input type="text" style="width:170px" id="to_date" name="to_date" value="<?php if(isset($to_date) && $to_date!=0) echo date('d/m/Y',$to_date);?>">
                                    </div>
                                </li>
                                <li class="clearfix">
                                    <label>&nbsp;</label>
                                    <div class="filltext">
                                        <input type="button" class="buton-radi" value="Tìm kiếm" onclick="searchForm('');">
                                        <input type="button" value="Hủy" class="buton-radi" onclick="window.location.href='<?php echo Url::createUrl('news/index');?>'" />
                                        <?php
                                        if($is_hot==1)
                                        {
                                            ?>
                                            <input type="button" value="Save Order" class="buton-radi" onclick="saveOrderNews();">
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </li>
                                
                            </ul>
                        </div>
                    </form>
                    <div class="box">
                        <div class="clearfix fillter">
                            <div class="fl reseach"> <strong>Thao tác nhanh </strong>
                                <select style="width:95px;height:23px" id="quick_type">
                                    <option value="1">Kích hoạt</option>
                                    <option value="2">Bỏ kích hoạt</option>
                                    <option value="3">Xóa</option>
                                    <option value="4">Chọn tin cho chuyên đề</option>
                                    <option value="5">Chọn tin nổi bật</option>
                                    <option value="6">Chuyển danh mục</option>
                                </select>
                                &nbsp;
                                <input type="submit" class="btn-orange" value="Lưu" onclick="quickUpdateNews($('#quick_type').val(),$('#list_id').val())">
                            </div>
                            <div class="fr reseach">
                            	<a href="<?php echo Url::createUrl("news/add");?>">
                                <input type="button"class="btn-orange" value="Thêm tin tức">
                                </a>&nbsp;
                                <ul class="pages fr clearfix">
                                    <?php echo $paging;?>
                                </ul>
                                
                            </div>
                        </div>
                        <input type="hidden" id="list_id" />
                        <table width="100%" cellspacing="0" cellpadding="0" border="0" class="col_list txt-right" id="list">
                            <tbody>
                                <tr class="bg-grey">
                                    <td width="3%"><strong>ID </strong><br>
                                        <input type="checkbox" id="selectAll" onclick="doCheckAll();"></td>
                                    <td width="28%"><strong>Tiêu đề bài viết </strong></td>
                                    <td width="12%"><strong>Danh mục</strong></td>
                                    <td width="13%"><strong>Chuyên đề</strong></td>
                                    <td width="14%"><strong>Tags </strong></td>
                                    <td width="9%"><strong>Thống kê </strong></td>
                                    
                                    <td width="6%"><strong>Trạng thái </strong></td>
                                    <td width="12%"><strong>Thời gian/ Người gửi </strong></td>
                                </tr>
                                <?php
                                $k=0;
                                foreach ($news as $row)
                                {
                                    $class='';
                                    if($k%2==0)
                                    {
                                        $class='class="bg_grays"';
                                    }
                                    $link_front_end=Yii::app()->params['baseUrl'].'/'.$row['alias'].'-c'.$row['cat_id'].'a'.$row['id'].'.html';
									$total_hit=isset($hits[$row['id']]) ? intval($hits[$row['id']]):0;
									$list_topic = isset($topics[$row['id']]) ? $topics[$row['id']] : array();
									$row_comment = isset($comments[$row['id']]) ? $comments[$row['id']] : array();
                                    ?>
                                    <tr <?php echo $class;?> rel="<?php echo $row['id'];?>">
                                        <td>
											<?php echo ($row['id']);?><br />
                                            <input type="checkbox" value="<?php echo ($row['id']);?>" name="articles_<?php echo ($row['id']);?>" class="selectOne" onclick="doCheck();">
										</td>
                                        <td class="text-left"><a href="<?php echo $link_front_end;?>" target="_blank" <?php if($row['is_hot']==1) echo 'style="color:red;"';?>><strong><?php echo stripslashes($row['title']);?></strong></a>
                                            <p><?php echo stripslashes($row['introtext']);?></p>
                                            <div class="row-actions">
                                            <a href="<?php echo Url::createUrl("news/edit", array("news_id"=>$row['id']));?>" title="Edit this item"><span>Edit</span></a>
                                            | <a href="javascript:" onclick="deleteNewsOfTopic(<?php echo $topic_id;?>,<?php echo $row['id'];?>);">Xóa tin khỏi chuyên đề</a>
                                            | <a href="<?php echo Url::createUrl("news/seo", array("news_id"=>$row['id']));?>" class="editinline"><span>Seo</span></a>
                                            | <a href="javascript:" class="editinline" onclick="addNewsToTopic(<?php echo $row['id'];?>);"><span>Thêm tin vào chuyên đề</span></a>
                                            | <a href="javascript:" class="editinline" onclick="setHotNews(<?php echo ($row['id']);?>)"> <span>
                                            <?php
                                                if($row['is_hot']==1) echo 'Bỏ nổi bật';
                                                else echo 'Nổi bật';
                                            ?>
                                            </span> </a> | <a href="javascript:" onclick="SaveArticles(<?php echo ($row['id']);?>);">
                                            <?php
                                                if ($row['status'] == "active")
                                                    echo '<span>Bỏ kích hoạt<span>';
                                                else
                                                    echo '<span>Kích hoạt<span>';
                                            ?>
                                            </a>
                                            	
                                            </div>
                                        </td>
                                        
                                        <td>
                                             <br />
                                        </td>
                                        <td class="text-left">
                                            <?php
                                            if(!empty($list_topic))
                                            foreach ($list_topic as $r)
                                            {
                                                if(is_array($r))
                                                {
                                                    $link_topic=Yii::app()->params['baseUrlFront'].'/'.$r['alias'].'-t'.$r['id'].'.html';
                                                    ?>
                                                    <a target="_blank" href="<?php echo ($link_topic);?>">- <?php echo ($r['title']);?></a>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </td>
                                        <td class="text-left">
                                            <?php
                                            $keyword = $row['keyword'];
                                            $keyword=explode(',',$keyword);
                                            if($keyword)
                                            foreach($keyword as $value)
                                            {
                                                $alias = str_replace(' ','+',trim($value));
                                                $alias = str_replace('/',' ',$alias);
                                                $link_tag = Yii::app()->params['baseUrlFront'].'/s/'.$alias;
                                                ?>
                                                <a href="<?php echo $link_tag;?>" target="_blank"><?php echo $value;?></a>
                                                <?php
                                            }
                                            ?>
                                        </td>
                                        <td class="text-left">
                                            <p> Lượt view: <?php echo $total_hit;?></p>
                                            <p>
                                            <?php
											if(!empty($row_comment))
											foreach($row_comment as $value)
											{
												?>
                                                BL <?php echo $value['status'];?> <a href="<?php echo Url::createUrl("news/comment", array('id'=>$row['id']));?>"><?php echo ($value['total']);?></a>
                                                <br />
                                                <?php
											}
                                            ?>                                            
                                            </p>
                                        </td>
                                        
                                        <td><?php echo $row['status'];?></td>
                                        <td>
                                            <?php
                                            if(!empty($row['edit_name']))
                                            {
                                                ?>
                                                <p>
                                                    <?php if(!empty($row['edit_name'])) echo $row['edit_name'].' edit:';?>
                                                </p>
                                                <p>
                                                <?php 
                                                    if($row['edit_date']!=0) echo (date('d-m-Y -- H:i', $row['edit_date']));
                                                ?>
                                                </p>
                                                <hr />
                                                <?php
                                            }
                                            ?>
                                            <p>
                                            <?php
                                                if(empty($row['admin_id']) && empty($row['user_id'])) echo ("Auto");
                                                else if(!empty($row['admin_id'])) echo ($row['admin_name']);
                                                else if(!empty($row['user_id'])) echo ('<span style="color:blue;">'.$row['username'].'</span>');
                                            ?>
                                            </p>
                                            <p><?php echo (date('d-m-Y -- H:i', $row['create_date']));?></p></td>
                                    </tr>
                                    <?php
                                    $k++;
                                }
                                ?>
                            </tbody>
                        </table>
                        <div class="clearfix fillter">                                	
                            <div class="fr reseach">
                                <ul class="pages fl magT5 clearfix">
                                    <?php echo $paging;?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $this->renderPartial('application.views.static.footer') ;  ?>
            </div>
		</td>
    </tr>
</table>
</div>
