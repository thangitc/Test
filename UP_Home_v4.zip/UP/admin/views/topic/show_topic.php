<script>
$(function(){    
    $(".search_topic").keypress(function(e){
        switch(e.which)
        {
            case 13: 
                pagingTopic(1);
                break;
            default:
                break; 
        }
    });     
});

function pagingTopic(page)
{
    var keyword = $("#keyword_topic").val();
    var cat_id = $("select[name='cat_id'] option:selected").val();
    var numperpage = $("select[name='numperpage'] option:selected").val();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/pagingTopic');?>',
		type: "POST",
		data:({
			page:page,
			keyword:keyword,
			cat_id:cat_id,
			numperpage:numperpage
		}),
		success: function(resp){
			$("#TopicData").replaceWith(resp);
		}
	});
}

function chooseTopic()
{
	var html_select='';
	var list_topic_id=$('#list_topic_id').val();
	$('.topic_select').each(function(){
		if($(this).is(":checked"))
		{
			var topic_id=$(this).attr('rel');
			if(list_topic_id!='')
			{
				list_topic_id+=','+topic_id+',';
			}
			else
			{
				list_topic_id+=topic_id+',';
			}
			var title=$('#topic_title_'+topic_id+'').html();
			html_select+='<div class="fl" rel="'+topic_id+'"><a href="javascript:">'+title+'</a><a class="ic_del" onclick="updateListTopic('+topic_id+');$(this).parent(\'div\').remove();" href="javascript:">&nbsp;</a></div>';
		}
	});
    $("#list_topic_view").append(html_select);
	list_topic_id=rtrim(list_topic_id,',');
	$('#list_topic_id').val(list_topic_id);
    $.fn.colorbox.close();
}

function insertTopicNews() 
{
	var list_news_id = $("#list_id").val();
	var list_topic_id = $("#listTopicId").val();
	
	if(list_news_id != '')
	{
		$.ajax({
	        url:'<?php echo Url::createUrl('ajax/insertTopicNews');?>',
	        type:"POST",
	        data:({
	        	list_topic_id:list_topic_id,
				list_news_id:list_news_id
	        }),
	        success:function(response){
	            closeLoadingAjax();
	            location.reload();
	        },
	        error:function(){
	            alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
	            closeLoadingAjax();
	        }
	    });
	}
	else {
		alert("Bạn chưa chọn chuyên đề. Hãy làm lại.");
	}
}

</script>
<div style="width:770px; height:430px; display: block; padding: 10px;" class="popup">
	<p align="center"><strong class="clblue s18">Chọn chuyên đề liên quan</strong></p>
	<div class="popup-cont clearfix">
		<div class="box">
			<p>
				<input type="text" id="keyword_topic" class="search_topic" style="width: 430px;" />
                <input type="button" onclick="pagingTopic(1);" value="Tìm" class="btn-orange">
				&nbsp;
                <select name="cat_id" style="width:258px">
                <option value="0">--Chọn DM--</option>
                <?php
                if($cat)
                foreach($cat as $row)
                {
                    if($row['parent_id']==0 && $row['cat_type']==3)
                    {
                        
                        ?>
                        <option <?php if($row['id']==$cat_id) echo "selected"; ?> value="<?php echo $row['id'];?>"><?php echo $row['title'];?></option>
                        <?php
                        foreach($cat as $row2)
                        {
                            if($row2['parent_id']==$row['id'])
                            {
                                ?>
                                <option <?php if($row2['id']==$cat_id) echo "selected"; ?> value="<?php echo $row2['id'];?>">--<?php echo $row2['title'];?></option>
                                <?php
                                foreach($cat as $row3){
                                    if($row3['parent_id']==$row2['id'])
                                    {
                                        ?>
                                        <option <?php if($row3['id']==$cat_id) echo "selected"; ?> value="<?php echo $row3['id'];?>">----<?php echo $row3['title'];?></option>
                                        <?php
                                    }
                                }
                            }
                        }
                    }
                }
                ?>
                </select>
			</p>
		</div>
		<div class="box" id="TopicData">
			<div class="fillter clearfix" style="border-bottom:1px solid #ccc">
				<?php if($num_page >1) { ?>
				<div class="fl">
                    <ul class="pages fl magT5 clearfix">
						<?php echo Paging::show_paging_ajax("pagingTopic", array(),$num_page, $page, 9, ''); ?>						
					</ul>
				</div>
				<?php } ?>
				<div class="fr"> Hiển thị
					<select style="width:44px" name="numperpage">
						<option value="10" <?php if($num_per_page == 10) echo ("selected");?>>10 tin</option>
						<option value="20" <?php if($num_per_page == 20) echo ("selected");?>>20 tin</option>
						<option value="30" <?php if($num_per_page == 30) echo ("selected");?>>30 tin</option>
					</select>
				</div>
				<br/>&nbsp;
			</div>
            <input type="hidden" id="listTopicId" name="listTopicId" />
			<?php
            foreach($topic as $row)
			{
				?>
                <p>
                	<input onclick="doCheckMuti('topic_select', 'listTopicId');" class="topic_select" rel="<?php echo $row["id"];?>" type="checkbox" id="topic_id_<?php echo $row["id"];?>" name="topic_id_<?php echo $row["id"];?>" value="<?php echo $row["id"];?>"/>
                    <span id="topic_title_<?php echo $row["id"];?>"><?php echo $row["title"];?></span>
                </p>
                <?php
			}
			?>
		</div>
        <p align="center">
        <?php
		if($boolean==0)
		{
			?>
            <button type="submit" onclick="chooseTopic();" class="button">Lưu</button>	
            <?php
		}
		else
		{
			?>
            <button type="submit" onclick="insertTopicNews();" class="button">Lưu</button>	
            <?php
		}
        ?>
		</p>
	</div>
</div>