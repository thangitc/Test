<script>
function addColor(color_id)
{	
	var title=$('#title').val();
	var code=$('#code').val();
	var model_id=$('#model_id').val();
	
	if($('#model_id').val()==0)
	{
		alert('Vui lòng chọn model!');
		$('#model_id').focus();
		return false;
	}
	if($('#title').val()=='')
	{
		alert('Vui lòng nhập tên dự án!');
		$('#title').focus();
		return false;
	}
	if($('#code').val()=='')
	{
		alert('Vui lòng nhập mã màu!');
		$('#code').focus();
		return false;
	}
	
	loadingAjax();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/addColor');?>',
		type: "POST",
		data:({
			title:title,
			code:code,
			color_id:color_id,
			model_id:model_id
		}),
		success: function(resp){
			closeLoadingAjax();
			if(resp>=0)	
			{
				alert('Cập nhật thành công!');
				history.go(-1);
				$('#result').html('Cập nhật thành công!');
				$('#result').css('color','blue');
			}
			else
			{
				$('#result').css('color','red');
				$('#result').html('Lỗi!');
			}
		}
	});
}
</script>