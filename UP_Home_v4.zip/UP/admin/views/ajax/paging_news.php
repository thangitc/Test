<div class="box" id="NewsData">
	<div class="fillter clearfix" style="border-bottom:1px solid #ccc">
		<?php if($num_page > 1) { ?>
		<div class="fl">
			<ul class="pages fl magT5 clearfix">
				<?php echo Paging::show_paging_ajax("pagingNews", array(), $num_page, $page, 9, ''); ?>						
			</ul>
		</div>
		<?php } ?>
		<div class="fr"> Hiển thị
			<select style="width:44px" name="numperpage">
				<option value="10" <?php if($num_per_page == 10) echo ("selected");?>>10 tin</option>
				<option value="20" <?php if($num_per_page == 20) echo ("selected");?>>20 tin</option>
				<option value="30" <?php if($num_per_page == 30) echo ("selected");?>>30 tin</option>
			</select>
		</div>
		<br/>&nbsp;
	</div>    
    <?php
	foreach($news as $row)
	{
		?>
		<p>
			<input class="news_select" rel="<?php echo $row["id"];?>" type="checkbox" id="news_id_<?php echo $row["id"];?>" name="news_id_<?php echo $row["id"];?>" value="<?php echo $row["id"];?>"/>
			<span id="news_title_<?php echo $row["id"];?>"><?php echo $row["title"];?></span>
		</p>
		<?php
	}
	?>
</div>