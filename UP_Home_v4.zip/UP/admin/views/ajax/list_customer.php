<?php
if(!empty($list_customer))
foreach($list_customer as $row)
{
	?>
    <a href="javascript:" onclick="setOneCustomer(<?php echo $row['id']?>);"><?php echo $row['title'];?></a> - Mobile: <?php echo $row['mobile'];?> - Email: <?php echo $row['email'];?> - Địa chỉ: <?php echo $row['address'];?><br />
    <?php
}
?>