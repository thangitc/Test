<div class="box" id="AccessData">
    <div class="fillter clearfix" style="border-bottom:1px solid #ccc">
        <?php if($num_page > 1) { ?>
        <div class="fl">
            <ul class="pages fl magT5 clearfix">
                <?php echo Paging::show_paging_ajax("pagingAccess", array(), $num_page, $page, 9, ''); ?>                        
            </ul>
        </div>
        <?php } ?>
        <div class="fr"> Hiển thị
			<select style="width:44px" name="numperpage">
				<option value="10" <?php if($num_per_page == 10) echo ("selected");?>>10 chuyên đề</option>
				<option value="20" <?php if($num_per_page == 20) echo ("selected");?>>20 chuyên đề</option>
				<option value="30" <?php if($num_per_page == 30) echo ("selected");?>>30 chuyên đề</option>
			</select>
		</div>
        <br/>&nbsp;
    </div>
    <input type="hidden" id="listAccessId" name="listAccessId" />
    <?php
	foreach($access as $row)
	{
		?>
		<p>
			<input onclick="doCheckMuti('access_select', 'listAccessId');" class="access_select" rel="<?php echo $row["id"];?>" type="checkbox" id="access_id_<?php echo $row["id"];?>" name="access_id_<?php echo $row["id"];?>" value="<?php echo $row["id"];?>"/>
			<span id="access_title_<?php echo $row["id"];?>"><?php echo $row["title"];?></span>
		</p>
		<?php
	}
	?>
</div>