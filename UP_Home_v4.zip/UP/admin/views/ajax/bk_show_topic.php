<script>
$(function(){    
    $(".search_topic").keypress(function(e){
        switch(e.which)
        {
            case 13: 
                pagingTopic(1);
                break;
            default:
                break; 
        }
    });     
});

function pagingTopic(page)
{
    var keyword = $("#keyword_topic").val();
    var cat_id = $("select[name='cat_id'] option:selected").val();
    var numperpage = $("select[name='numperpage'] option:selected").val();
    $.ajax({
        type: "POST",
        url: '<?php echo Url::createUrl('ajax/pagingTopic')?>',
        data: "page=" + page + "&keyword=" + keyword + "&cat_id=" + cat_id + "&numperpage=" + numperpage,
        dataType: "text",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("Ajax-Request", "true");
        },
        success: function(response) {
            $("#TopicData").replaceWith(response);
        },
        error: function(){}
    });   
}

function chosseTopic()
{
    var topic_name = '';
    var topic_id = '';
    var ListTopicId = $("#ListTopicId").val();
    if(ListTopicId == '') {
    	alert("Bạn chưa chọn chuyên đề.");
    	return false;
    }
    
    ListTopicId = ListTopicId.split(",");
    var html = '';
    for(i in ListTopicId){
        topic_name = $("#topic_name_value_"+ListTopicId[i]).text();        
   		
        html += '<div class="fl  TopicView_'+ListTopicId[i]+'" style="margin-right:10px;">';
        html +=     '<textarea name="topic_name_'+ListTopicId[i]+'" style="display:none;">'+unescape(topic_name)+'</textarea>';
        html += 	'<a href="#">';
        html +=		 	unescape(topic_name);
        html += 	'</a>';
        html += 	'<a href="javascript:" onclick="DeleteTopic('+ListTopicId[i]+')" class="ic_del">&nbsp;</a>';
        html += '</div>';
    }
    
    list_topic_id = $("#list_topic_id").val();
    if(list_topic_id == ""){
    	list_topic_id = ListTopicId;
    } else {
    	list_topic_id += ","+ListTopicId;    
    }        
    $("#list_topic_id").val(list_topic_id)
    
    $("#topic_view").append(html);
    $.fn.colorbox.close();
}

function insertNewsTopic() 
{
	var list_news_id = $("#list_id").val();
	var list_topic_id = $("#ListTopicId").val();
	
	if(list_topic_id != '') {
		$.ajax({
	        url:'<?php echo Url::createUrl('ajax/insertNewsTopic')?>',
	        type:"POST",
	        data:({
	        	list_news_id:list_news_id,
				list_topic_id:list_topic_id
	        }),
	        success:function(response){
	            var result = eval( "(" + response + ")" );
	            if(result.status !== "noPermis"){
	            	/*alert("Cập nhật thành công.");*/
	            } else {
	                alert("Bạn không đủ quyền thực hiện hành động này.");    
	            }
	            closeLoadingAjax();
	            $.fn.colorbox.close();
	            location.reload();
	        },
	        error:function(){
	            alert("Có lỗi trong quá trình xử lý. Hãy làm lại.");
	            closeLoadingAjax();
	        }
	    });
	}
	else {
		alert("Bạn chưa chọn sự kiên. Hãy làm lại.");
	}
}

</script>
<div style="width:770px; height:430px; display: block; padding: 10px;" class="popup">
	<p align="center"><strong class="clblue s18">Chọn chuyên đề</strong></p>
	<div class="popup-cont clearfix">
		<div class="box">
			<p>
				<input type="text" id="keyword_topic" class="search_topic" style="width: 430px;" />
            	<input type="button" onclick="pagingTopic(1);" value="Tìm" class="btn-orange">
				&nbsp;
				<select name="cat_id" style="width:258px">
					<option value="">-- Chọn chuyên mục --</option>
					<?php
                    	foreach ($cats as $row)
						{
							if($row['cat_type']==2 && $row['parent_id']==0)
							{
								?>
								<option value="<?php echo ($row['id']);?>"><?php echo ($row['title']);?></option>	
								<?php 
							}
						}
					?>
				</select>
			</p>
			<input type="hidden" id="ListTopicId" />
		</div>
		<div class="box" id="TopicData">
			<div class="fillter clearfix" style="border-bottom:1px solid #ccc">
				<?php if($numberPage > 1) { ?>
				<div class="fl">
					<ul class="pages fl magT5 clearfix">
						<?php echo Paging::show_paging_ajax("pagingTopic", array(), $numberPage, $currentPage, 9, ''); ?>						
					</ul>
				</div>
				<?php } ?>
				<div class="fr"> Hiển thị
					<select style="width:44px" name="numperpage">
						<option value="10" <?php if($numberRecordPerPage == 10) echo ("selected");?>>10 chuyên đề</option>
						<option value="20" <?php if($numberRecordPerPage == 20) echo ("selected");?>>20 chuyên đề</option>
						<option value="30" <?php if($numberRecordPerPage == 30) echo ("selected");?>>30 chuyên đề</option>
					</select>
				</div>
				<br/>&nbsp;
			</div>
			<?php foreach($topic as $row) { ?>
			<p>
				<input type="checkbox" class="topicIdValue" onclick="doCheckMuti('topicIdValue', 'ListTopicId');" name="topicIdValue_<?php echo $row["id"];?>" value="<?php echo $row["id"];?>"/>
				<span id="topic_name_value_<?php echo $row["id"];?>"><?php echo $row["title"];?></span>
				</p>
			<?php } ?>			
		</div>
		<p align="center">
            <?php if(empty($boolean)) { ?>
				<input type="button" onclick="choseTopic();" value="Lưu" class="btn-orange">	
			<?php } else { ?>
				<input type="button" onclick="insertNewsTopic();" value="Lưu" class="btn-orange">	
			<?php }?>
		</p>
	</div>
</div>