<div class="box" id="TopicData">
    <div class="fillter clearfix" style="border-bottom:1px solid #ccc">
        <?php if($num_page > 1) { ?>
        <div class="fl">
            <ul class="pages fl magT5 clearfix">
                <?php echo Paging::show_paging_ajax("pagingTopic", array(), $num_page, $page, 9, ''); ?>                        
            </ul>
        </div>
        <?php } ?>
        <div class="fr"> Hiển thị
			<select style="width:44px" name="numperpage">
				<option value="10" <?php if($num_per_page == 10) echo ("selected");?>>10 chuyên đề</option>
				<option value="20" <?php if($num_per_page == 20) echo ("selected");?>>20 chuyên đề</option>
				<option value="30" <?php if($num_per_page == 30) echo ("selected");?>>30 chuyên đề</option>
			</select>
		</div>
        <br/>&nbsp;
    </div>
    <input type="hidden" id="listTopicId" name="listTopicId" />
    <?php
	foreach($topic as $row)
	{
		?>
		<p>
			<input onclick="doCheckMuti('topic_select', 'listTopicId');" class="topic_select" rel="<?php echo $row["id"];?>" type="checkbox" id="topic_id_<?php echo $row["id"];?>" name="topic_id_<?php echo $row["id"];?>" value="<?php echo $row["id"];?>"/>
			<span id="topic_title_<?php echo $row["id"];?>"><?php echo $row["title"];?></span>
		</p>
		<?php
	}
	?>
</div>