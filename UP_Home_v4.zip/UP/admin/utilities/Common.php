<?php
    class Common{
        // hàm lấy tên ảnh
        static function getImage($nameImage,$folder,$date='',$type='')
        {  
            if($type!='')
            {
                $name=substr($nameImage,0,-4);
                $extent=str_replace($name,'',$nameImage);
                $nameImage=$name.'_'.$type.$extent;
            }
            if($date!='')
                return Yii::app()->params['urlImages'].$folder.'/'.date('Y',$date).'/'.date('md',$date).'/'.$nameImage;
            else
                return Yii::app()->params['urlImages'].$folder.'/'.$nameImage;
        }
		
		static function getVideo($nameVideo,$folder)
        {
			return Yii::app()->params['urlVideo'].$folder.'/'.$nameVideo;
        }
		
        static function str_replace_once($str_pattern, $str_replacement, $string){

            if (strpos($string, $str_pattern) !== false){
                $occurrence = strpos($string, $str_pattern);
                return substr_replace($string, $str_replacement, strpos($string, $str_pattern), strlen($str_pattern));
            }

            return $string;
        }

        static function genTextHour($int)
        {  
            $second = time() - $int;
            $minute = $second / 60;
            $second = $second % 60;
            $hour = $minute / 60;
            $minute = $minute % 60;
            $day = $hour / 24;                                  
            $hour = $hour % 24;
            $year = $day / 365;
            $day = $day % 365;

            if($year >= 1){
                $text_hour = "Ngày ".date("d-m-Y", $int)." lúc ".date("H:i:s", $int);
            } else {
                if($day >= 1){
                    $text_hour = "Ngày ".date("d-m-Y", $int)." lúc ".date("H:i:s", $int);
                } else {
                    if($hour >= 1){
                        $text_hour = " ".$hour." giờ ".$minute." phút trước";
                    } else {
                        if($minute >= 1){
                            $text_hour = " ".$minute." phút trước";    
                        } else {
                            if($second >= 1)
                                $text_hour = " ".$second." giây trước";    
                            else 
                                $text_hour = " 1 giây trước";    
                        }
                    }
                }
            }
            return $text_hour;    
        }

        /*Tạo keyword*/
        function genKeyword($str)
        {
            $url= new Url();
            if($str!='')
            {
                $tags=explode(',',$str);
                $str='';
                if(sizeof($tags)>0)
                {
                    $str.='<strong class="tags_gray">Từ khóa liên quan đến bài viết:</strong> ';
                    foreach($tags as $tag)
                    {
                        $link_search=$url->createUrl('search/index', array('alias'=>Common::generate_slug($tag)));
                        $str.='<a rel="nofollow" href="'.$link_search.'"><strong>'.$tag.'</strong></a>, ';
                    }
                }
                $str=rtrim($str,', ');
            }
            return $str;
        }
        /*Kiểm tra session và colorbox*/
        function setColorBox($url,$class)
        {
            if(!isset($_SESSION['ID']) && !isset($_COOKIE['reply_name']) && !isset($_COOKIE['reply_email']))
                //if(!isset($_SESSION['ID']))
                return 'class="'.$class.'"  href="'.$url.'"';
            else
                return '';
        }

        /**
        * Chuyển strRank
        * 
        * @param mixed $str
        */
        static function fectStrRankToArray($str_input)
        {
            $results=array();
            $array_input = explode(',',$str_input);
            $n_input     = count($array_input);
            for($i=0;$i<$n_input;$i++)
            {            
                $str_rank=$array_input[$i];
                $array_rank = explode(':',$str_rank);
                if(count($array_rank)>1)
                    $results[$array_rank[0]]=$array_rank[1];  
            }
            return $results;   
        }
        /**
        * Đánh giá
        * 
        * @param mixed $rating
        */
        static function softRating($rating) {
            $link = Yii::app()->params['static_url']."/images/star";
            $half_star = 'star6.gif';
            $full_star = 'star7.gif';
            $no_star = 'star8.gif';
            $str = '';
            $rate = (isset($rating))?$rating:0;
            if($rate == 0){ 
                for($i = 0; $i < 10; $i++) {
                    $str .= '<img src="'.$link.'/'.$no_star.'" />';  
                }
            }
            else {
                if(intval($rate / 2) == $rate / 2) {
                    for($i = 0; $i < 10; $i++) {
                        if($i < intval($rate / 2)) $str .= '<img  src="'.$link.'/'.$full_star.'" />';
                        else  $str .= '<img  src="'.$link.'/'.$no_star.'" />';
                    }
                }
                else {
                    $half = intval($rate / 2);
                    for($i = 0; $i < 10; $i++) {
                        if($i < intval($rate / 2)) $str .= '<img src="'.$link.'/'.$full_star.'" />';
                        else {
                            if($i == $half) $str .= '<img src="'.$link.'/'.$half_star.'" />';
                            else  $str .= '<img src="'.$link.'/'.$no_star.'" />';
                        }
                    }
                }
            }
            return $str;
        }    
        /**
        * put your comment there...
        *     
        * @param mixed $listkey
        */
        static function getRelatedSearch($listkey) {
            $str = '';
            if($listkey) {
                $info = explode(',',$listkey);
                foreach($info as $key => $value) {
                    $value = str_replace('"','',$value);
                    $str .= '<a title="'.$value.' tag" target="_blank" href="'.Yii::app()->baseUrl.'/s/'.$value.'/">'.$value.'</a>';
                }
            }
            return $str;
        }
        /**
        * Lấy ip
        *        
        */
        static function getRealIpAddr()
        {
            if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
            {
                $ip=$_SERVER['HTTP_CLIENT_IP'];
            }
            elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
            {
                $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
            }
            else
            {
                $ip=$_SERVER['REMOTE_ADDR'];
            }
            return $ip;
        } 
        /**
        * kiểm tra username
        * 
        * @param mixed $username
        */
        static function validate_username($username)
        {
            $check = eregi_replace('([a-zA-Z0-9_]+)', "", $username);

            if(empty($check))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /**
        * làm 
        *        
        * @param mixed $value
        * @return string
        */
        static function formatNumber($value)
        {
            /*
            if($value == 500)
            {
            $str = intval($value);
            } 
            else 
            {
            //$str = number_format(round($value/1000)*1000,0,"",".");
            $str = number_format($value,0,"",".");
            }
            */
            $str = number_format($value,0,"",".");
            return $str;
        } 
        /**
        * put your comment there...
        *  
        * @param mixed $email
        */
        static function validateEmailSyntax($email) {
            $atom = '[-a-z0-9!#$%&\'*+/=?^_`{|}~]'; // allowed characters for part before "at" character
            $domain = '([-a-z0-9]*[a-z0-9]+)'; // allowed characters for part after "at" character
            $regex = '^'.$atom.'+'. // One or more atom characters.
            '(\.'.$atom.'+)*'. // Followed by zero or more dot separated sets of one or more atom characters.
            '@'. // Followed by an "at" character.
            '('.$domain.'{1,63}\.)+'. // Followed by one or max 63 domain characters (dot separated).
            $domain.'{2,63}'. // Must be followed by one set consisting a period of two
            '$'; // or max 63 domain characters.
            if(eregi($regex,$email)) return true;
            else  return false;
        } //validate_email_syntax

        static function arrayCategory()
        {
            $connect=Yii::app()->db;
            //Cache
            $cacheService = new CacheService("genCategory","","");
            $key = $cacheService->createKey();
            $cache = Yii::app()->cache->get($key);

            if ($cache == false) 
            {
                $sql = "SELECT * FROM tbl_categories";
                $command=$connect->createCommand($sql);
                $rows=$command->queryAll();
                Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_10800);
            }
            else
            {
                $rows=$cache;
            }
            return $rows;
        }

        static function configWidthEmbed($width, $height, $embed){
            if(strpos($embed, "width")){
                $patterns = '/width="(\d+)"/';                    
                $replacements= 'width="'.$width.'"';                
                $embed = preg_replace($patterns, $replacements, $embed);
                $patterns = '/height="(\d+)"/';                    
                $replacements= 'height="'.$height.'"';                
                $embed = preg_replace($patterns, $replacements, $embed);
            }else{
                $patterns = '/<embed/';            
                $replacements= '<embed width="'.$width.'" height="'.$height.'" ';                  
                $embed = preg_replace($patterns, $replacements, $embed);
                $patterns = '/<object/';            
                $replacements= '<object width="'.$width.'" height="'.$height.'" ';
                $embed = preg_replace($patterns, $replacements, $embed);
            }
            return $embed;
        }

        static function getIntroText($str,$len,$more){
            if ($str=="" || $str==NULL) 
                return $str;
            if (is_array($str)) 
                return $str;
            $str = trim($str);
            if (strlen($str) <= $len) 
                return $str;
            $str = substr($str,0,$len);
            if ($str != "") 
            {
                if (!substr_count($str," ")) 
                {
                    if ($more) 
                        $str .= " ...";
                    return $str;
                }
                while(strlen($str) && ($str[strlen($str)-1] != " ")) 
                {
                    $str = substr($str,0,-1);
                }
                $str = substr($str,0,-1);
                if ($more) 
                    $str .= " ...";
            }
            return $str;
        }

        function generate_slug($string) {
            $string=Common::change($string);
            $string = preg_replace("/(^|&\S+;)|(<[^>]*>)/U","",$string);
            $string = strtolower(preg_replace('/[\s\-]+/','-',trim(preg_replace('/[^\w\s\-]/','',$string))));
            $slug = preg_replace("/[^A-Za-z0-9\-]/","",$string);
            return $slug;
        }
        function gen_title_kodau($string) {
            $string=Common::change($string);
            return $string;
        }
        function change($text)
        {
            $chars = array("a","A","e","E","o","O","u","U","i","I","d","D","y","Y");
            $uni[0] = array("á","à","ạ","ả","ã","â","ấ","ầ","ậ","ẩ","ẫ","ă","ắ","ằ","ặ","ẳ","ẵ","� �");
            $uni[1] = array("Á","À","Ạ","Ả","Ã","Â","Ấ","Ầ","Ậ","Ẩ","Ẫ","Ă","Ắ","Ằ","Ặ","Ẳ","Ẵ","� �");
            $uni[2] = array("é","è","ẹ","ẻ","ẽ","ê","ế","ề","ệ","ể","ễ");
            $uni[3] = array("É","È","Ẹ","Ẻ","Ẽ","Ê","Ế","Ề","Ệ","Ể","Ễ");
            $uni[4] = array("ó","ò","ọ","ỏ","õ","ô","ố","ồ","ộ","ổ","ỗ","ơ","ớ","ờ","ợ","ở","ỡ","� �");
            $uni[5] = array("Ó","Ò","Ọ","Ỏ","Õ","Ô","Ố","Ồ","Ộ","Ổ","Ỗ","Ơ","Ớ","Ờ","Ợ","Ở","Ỡ","� �");
            $uni[6] = array("ú","ù","ụ","ủ","ũ","ư","ứ","ừ","ự","ử","ữ");
            $uni[7] = array("Ú","Ù","Ụ","Ủ","Ũ","Ư","Ứ","Ừ","Ự","Ử","Ữ");
            $uni[8] = array("í","ì","ị","ỉ","ĩ");
            $uni[9] = array("Í","Ì","Ị","Ỉ","Ĩ");
            $uni[10] = array("đ");
            $uni[11] = array("Đ");
            $uni[12] = array("ý","ỳ","ỵ","ỷ","ỹ");
            $uni[13] = array("Ý","Ỳ","Ỵ","Ỷ","Ỹ");

            for($i=0; $i<=13; $i++) {
                $text = str_replace($uni[$i],$chars[$i],$text);
            }
            return $text;
        }

        function createFolder($dir)
        {
            if(!is_dir($dir))
            {
                $a=mkdir($dir);
                if($a) return $dir;
                else
                    return false;
            }
            return $dir;
        }

        function run_browser($url){
            if ( function_exists('curl_init') ) {
                $ch = curl_init();
                //curl_setopt($ch, CURLOPT_USERAGENT, "Gulper Web Bot 0.2.4 (www.ecsl.cs.sunysb.edu/~maxim/cgi-bin/Link/GulperBot)");
                curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 'Content-type: application/x-www-form-urlencoded;charset=UTF-8');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_TIMEOUT, 60);
                $response = curl_exec($ch);
                curl_close($ch);
            } else { 
                $response = @file_get_contents($url);
            }

            return $response;
        }
        /*Danh sách các nguồn tin*/
        function source_articles()
        {
            $a1=array('0'=>'All','1'=>'vietnamnet.vn','2'=>'tienphong.vn','3'=>'vneconomy.com','4'=>'thethaovanhoa.vn','5'=>'sohoa.vn','6'=>'vnexpress.net','7'=>'autopro.vn','8'=>'afamily.vn','9'=>'kenh14.vn','10'=>'dothi.net','11'=>'ione.net','12'=>"dvt.vn",'13'=>"thiennhien.net",'14'=>"dantri.com.vn","15"=>"vtc.vn","16"=>"tinthethao.com.vn","17"=>"ngoisao.net","18"=>"tinnhanhchungkhoan.vn","19"=>"svvn.vn","20"=>"24h.com.vn","21"=>"vnmedia.vn","22"=>"tuoitre.vn","23"=>"dantri.vn","24"=>"xahoithongtin.vn",
            "25"=>"zing.vn","26"=>"nld.com.vn","27"=>"vov.vn","28"=>"vtc.vn","29"=>"giaoduc.net.vn","30"=>"khoahoc.com.vn","31"=>"anninhthudo.vn","32"=>"antg.cand.com.vn"
            );
            $a2=ECity::getCity();
            if($a2)
                foreach($a2 as $row)
                {
                    $a1[$row['cit_id']]='Báo '.$row['cit_name'];
            }
            return $a1;
        }

        function time_stamp($date)
        {
            $TotalSeconds = $date;
            $Seconds = $TotalSeconds % 60;
            $Minutes = ( ( $TotalSeconds - $Seconds) / 60 ) % 60;
            $Hours = ( ( ( ( $TotalSeconds - $Seconds ) / 60 ) - $Minutes ) / 60 ) % 24;
            $Days = ( ( ( ( ( $TotalSeconds - $Seconds ) / 60 ) - $Minutes ) / 60 ) - $Hours ) / 24;

            $date_current=date("Y-m-d H:i:s");
            $TotalSeconds_current = strtotime($date_current);
            $Seconds_current = $TotalSeconds_current % 60;
            $Minutes_current = ( ( $TotalSeconds_current - $Seconds_current) / 60 ) % 60;
            $Hours_current = ( ( ( ( $TotalSeconds_current - $Seconds_current ) / 60 ) - $Minutes_current ) / 60 ) % 24;
            $Days_current = ( ( ( ( ( $TotalSeconds_current - $Seconds_current ) / 60 ) - $Minutes_current ) / 60 ) - $Hours_current ) / 24;				

            $sub_day=$Days_current-$Days;

            $t=$TotalSeconds_current-$TotalSeconds;
            $Seconds_sb = $t % 60;
            $Minutes_sb = ( ( $t - $Seconds_sb) / 60 ) % 60;
            $Hours_sb = ( ( ( ( $t - $Seconds_sb ) / 60 ) - $Minutes_sb ) / 60 ) % 24;


            if($sub_day>7)
            {
                $strtime=date("H:i a d/m/Y",$TotalSeconds); 
            }
            else if($sub_day>0)
                {
                    $strtime = $sub_day.' days ago ';
                }
                else 
                {
                    if($Hours_sb>0)
                    {
                        //$strtime = 'Today at '.date("H:i:s a",$TotalSeconds);
                        $strtime = $Hours_sb.' hours ago ';
                    }
                    else
                    {
                        if($Minutes_sb>0)
                        {
                            $strtime = $Minutes_sb.' minutes ago ';

                        }
                        else
                        {
                            $strtime = $Seconds_sb.' seconds ago ';					
                        }

                    }	
            }
            if($t==0)
                $strtime = '2 seconds ago ';
            return $strtime;		 
        }

        function array_module()
        {
            return array(1=>'Danh Mục', 2=>'SP Camera', 3=>'QL Model' ,4 =>'QL Body', 5=>'QL Brand', 6=>'QL Color', 7=>'QL Kit', 8=>'Phụ Kiện', 9=>'Giỏ hàng', 10=>'Email Subscribe', 11=>'Tin Tức',12=>'Sự Kiện', 13=>'Comment', 14=>'TimeLine', 15=> 'Quảng Cáo', 16=>'QL Khách hàng', 17=>'QL Tiền Japan', 18=>'QL Tiền VN', 19=>'Thống Kê', 20=>'User', 21=>'Admin',22=>'QL Liên Hệ', 23=>'Ajax', 24=>'Hóa đơn', 25=>'COMBOS', '100'=>'Logs');
        }

        function array_permit()
        {
            //return array('1'=>'Tạo mới','2'=>'Cập nhật','3'=>'Xóa','4'=>'List','5'=>'Seo');
			return array('2'=>'Tạo mới','4'=>'Cập nhật','8'=>'Xóa','1'=>'List');
        }

        public function remove_duplicate($list_id)
        {
            $list_id = explode(",", $list_id);
            $new_id = array();
            foreach($list_id as $value){
                if(!in_array($value, $new_id)){
                    $new_id[] = $value;
                }
            }            
            $list_new_id = "";
            foreach($new_id as $value){
                $list_new_id .= $value.",";   
            }
            $list_new_id = rtrim($list_new_id, ",");
            return $list_new_id;
        }

        static function cleanQuery($string)
        {            
            $string = mysql_escape_string(trim($string));

            $badWords = array(
            "/Select(.*)From/i"
            , "/Union(.*)Select/i"
            , "/Update(.*)Set/i"
            , "/Delete(.*)From/i"
            , "/Drop(.*)Table/i"
            , "/Insert(.*)Into/i"                
            , "/http/i"
            , "/--/i"
            );

            $string = preg_replace($badWords, "", $string);

            return $string;
        }
        static function genCode($id)
        {
            return $id.rand(10000,99999);
        }

        function listCatPoll()
        {
            return array(            
            '1'		=> 'Ngắn hạn'
            , '2'	=> 'Ngành học dài hạn'
            , '3'	=> 'Tin tức'
            , '4'	=> 'Bậc đào tạo'
            , '5'	=> 'Trang chủ'            
            );
        }

        function listPositionSeo()
        {
            return array(            
            '1'		=> 'Header'
            , '2'	=> 'Body'
            , '3'	=> 'Footer'
            );
        }

        function listTypeTags(){
            return array(            
            '1'		=> 'Khóa học ngắn hạn'
            , '2'	=> 'Tuyển sinh dài hạn'
            , '3'	=> 'Nhà đào tạo'
            , '4'	=> 'Tin tức'
            );
        }
        function validateMobile($phone)
        {
            if(!is_numeric($phone)){
                return false;
            }
            else if(strlen($phone)>12){
                    return false;
                }
                else if(strlen($phone)<10){             
                        return false;
                    } 

                    return true;   
        }
        function checkPassword($pwd)
        {        
            if(strlen($pwd) < 6 )
            {
                //echo "Mật khẩu phải dài hơn 8 ký tự!";
                return false;
            }
            if(strlen($pwd) > 20 ) {
                //echo "Mật khẩu phải nhỏ hơn 20 ký tự!";
                return false;
            }
            return true;          
        }

        function urlExist($url)
        {  
            /*$handle = @fopen($url,'r');
            if($handle !== false){
            return true;
            }
            else {
            $file_headers = @get_headers($url);
            if($file_headers[0] != 'HTTP/1.1 404 Not Found') {
            return true;
            }
            }
            return false;*/
            return true;
        }
        function saveImgCurl($url_post,$url_img,$img_name)
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,$url_post); // set url to post to
            curl_setopt($ch, CURLOPT_FAILONERROR, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); // allow redirects
            curl_setopt($ch, CURLOPT_RETURNTRANSFER,1); // return into a variable
            curl_setopt($ch, CURLOPT_TIMEOUT, 0); // times out after Ns
            curl_setopt($ch, CURLOPT_POST, 1); // set POST method
            curl_setopt($ch, CURLOPT_POSTFIELDS, "img_name=".$img_name."&url_img=".urlencode($url_img)); // add POST fields

            curl_setopt($ch, CURLOPT_FAILONERROR, 0);
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_HEADER, 1);
            curl_setopt($ch, CURLOPT_COOKIEFILE, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

            $result = curl_exec($ch); // run the whole process
            curl_close($ch);
            return $result;
        }
        function genSubject($subject)
        {
            $subject=Common::change($subject);
            $subject=trim(preg_replace('/Mon|Tieng/si','',$subject));
            $subject=strtoupper($subject);
            return $subject;
        }
        function genUrlRewrite()
        {
            $url_rewrite = (!empty($_SERVER['HTTPS'])) ? "https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] : "http://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
            $url_rewrite=preg_replace('/&page=(.*)/si','',$url_rewrite);
            $url_rewrite=preg_replace('/page=(.*)/si','',$url_rewrite);
            if(strpos($url_rewrite,'?')===false)
            {
                $url_rewrite.='?page=';
            }
            else
            {
                $url_rewrite.='&page=';	
            }
            return $url_rewrite;
        }
        function genUsername($str,$limit)
        {
            $str.=rand(1,10000000000);
            $str=md5(base64_encode($str));
            $username=substr($str,0,$limit);
            return $username;
        }
        function genPassword()
        {
            $password=rand(1,10000000000);
            $password=substr($password,0,6);
            return $password;
        }
		public function genPass($password)
		{
			return md5(md5($password) . "bds!@#$");
		}

        function bitly_shorten($url)
        {
            $query = array(
            "version" => "2.0.1"
            , "longUrl"=>$url
            , "login"=>"taoviec"
            , "apiKey"=>"R_7d8c389d12d73f4e4f18b17ed6cd4f6a"
            );

            $query = http_build_query($query);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "http://api.bit.ly/shorten?".$query);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

            $response = curl_exec($ch);
            curl_close($ch);

            $response = json_decode($response);

            if($response->errorCode == 0 && $response->statusCode == "OK") {
                return $response->results->{$url}->shortUrl;
            } else {
                return null;
            }
        }
        /*Tao ma nhac cho*/
        function genCodeNC($limit)
        {
            $code=rand(1000000,10000000000);
            $code=substr($code,0,$limit);
            return $code;
        }

        function getTotalLikeComment($content_id,$link)
        {
            $str='https://graph.facebook.com/?id='.$link;
            $a=file_get_contents($str);
            $a=json_decode($a,true);
            return array($a['shares'],$a['comments']);
        }

        function getCommentsFacebook($content_id,$link,$link_paging,$output)
        {
            if($link_paging=='')
            {
                $str='https://graph.facebook.com/comments/?ids='.$link;
                $a=file_get_contents($str);
                $a=json_decode($a,true);
                foreach($a as $key=>$value)
                {
                    $comments=isset($value['comments']['data']) ? $value['comments']['data']:array();
                    $link_paging=isset($value['comments']['paging']['next']) ? $value['comments']['paging']['next']:'';
                    break;
                }
            }
            else
            {
                $str=$link_paging;
                $a=file_get_contents($str);
                $a=json_decode($a,true);
                $comments=isset($a['data']) ? $a['data']:array();
                $link_paging=isset($a['paging']['next']) ? $a['paging']['next']:'';
            }
            //Lay comment
            if(!empty($comments))
            {
                foreach($comments as $row)
                {
                    $create_date=strtotime($row['created_time']);
                    $fb_comment_id=$row['id'];
                    $output[]=array('content_id'=>$content_id,'fb_comment_id'=>$fb_comment_id,'fb_reply_id'=>0,'fb_user_id'=>$row['from']['id'],'fb_username'=>$row['from']['name'],'fb_like_count'=>$row['like_count'],'description'=>$row['message'],'create_date'=>$create_date);
                    $reply=isset($row['comments']['data']) ? $row['comments']['data']:array();
                    if(!empty($reply))
                        foreach($reply as $row2)
                        {
                            $create_date2=strtotime($row2['created_time']);
                            $like_count=isset($row2['like_count']) ? $row2['like_count']:0;
                            $output[]=array('content_id'=>$content_id,'fb_comment_id'=>$row2['id'],'fb_reply_id'=>$fb_comment_id,'fb_user_id'=>$row2['from']['id'],'fb_username'=>$row2['from']['name'],'fb_like_count'=>$like_count,'description'=>$row2['message'],'create_date'=>$create_date2);
                    }
                }
                if($link_paging!='')
                {
                    $output=Common::getCommentsFacebook($content_id,$link,$link_paging,$output);
                }
            }
            return $output;
        }
		
		function save_image($picture,$path,$image_path)
		{
			if ($picture)
			{
				$contents = @file_get_contents($picture);
				if ($contents)
				{
					$fp = fopen($path.'/'.$image_path, 'w');
					fwrite($fp, $contents);
					fclose($fp);
				}
			}
			return;
		}
		
		public function getCurrentUrl(){
            $pageURL = (@$_SERVER["HTTPS"] == "on") ? "https://" : "http://";
            if ($_SERVER["SERVER_PORT"] != "80")
            {
                $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
            } 
            else 
            {
                $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
            }
            return $pageURL;
        }
		
		static function getImgProduct($name_video,$type='',$folder='')
        {
            if($type!='')
            {
                $type=$type.'_';
                $name_video=str_replace($type,'small_',$name_video);
            }
            return Yii::app()->params['urlProduct'].$folder.$name_video;
        }

    }
?>
