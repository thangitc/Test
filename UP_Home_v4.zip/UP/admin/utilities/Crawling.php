<?php
class Crawling
{
	static function saveImage($picture,$path,$image_path)
	{
		if ($picture)
		{
			$contents = @file_get_contents($picture);
			if ($contents)
			{
				$fp = fopen($path.'/'.$image_path, 'w');
				fwrite($fp, $contents);
				fclose($fp);
			}
		}
		return;
	}
	
	static function urlExist($url)
	{
		$handle = @fopen($url,'r');
		if($handle !== false){
			return true;
		}
		else{
			return false;
		}
	}
	static function getIntroText($str,$len,$more)
	{
        if ($str=="" || $str==NULL) 
            return $str;
        if (is_array($str)) 
            return $str;
            $str = trim($str);
        if (strlen($str) <= $len) 
            return $str;
            $str = substr($str,0,$len);
        if ($str != "") 
        {
            if (!substr_count($str," ")) 
            {
                if ($more) 
                    $str .= " ...";
                    return $str;
            }
            while(strlen($str) && ($str[strlen($str)-1] != " ")) 
            {
                $str = substr($str,0,-1);
            }
            $str = substr($str,0,-1);
            if ($more) 
                $str .= " ...";
        }
        return $str;
    }
	
	static function getContentByCurl($url,$proxy)
	{
		$ch = curl_init();
		curl_setopt( $ch, CURLOPT_USERAGENT,"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6");
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_PROXY, $proxy);
		//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		$result = curl_exec($ch);
		if ( $result==false ) {
		  return curl_errno($ch).' '.curl_error($ch);
		}
		curl_close($ch);
		return $result;
	}
	
	static function change($text)
	{
		$chars = array("a","A","e","E","o","O","u","U","i","I","d","D","y","Y");
		$uni[0] = array("á","à","ạ","ả","ã","â","ấ","ầ","ậ","ẩ","ẫ","ă","ắ","ằ","ặ","ẳ","ẵ","� �");
		$uni[1] = array("Á","À","Ạ","Ả","Ã","Â","Ấ","Ầ","Ậ","Ẩ","Ẫ","Ă","Ắ","Ằ","Ặ","Ẳ","Ẵ","� �");
		$uni[2] = array("é","è","ẹ","ẻ","ẽ","ê","ế","ề","ệ","ể","ễ");
		$uni[3] = array("É","È","Ẹ","Ẻ","Ẽ","Ê","Ế","Ề","Ệ","Ể","Ễ");
		$uni[4] = array("ó","ò","ọ","ỏ","õ","ô","ố","ồ","ộ","ổ","ỗ","ơ","ớ","ờ","ợ","ở","ỡ","� �");
		$uni[5] = array("Ó","Ò","Ọ","Ỏ","Õ","Ô","Ố","Ồ","Ộ","Ổ","Ỗ","Ơ","Ớ","Ờ","Ợ","Ở","Ỡ","� �");
		$uni[6] = array("ú","ù","ụ","ủ","ũ","ư","ứ","ừ","ự","ử","ữ");
		$uni[7] = array("Ú","Ù","Ụ","Ủ","Ũ","Ư","Ứ","Ừ","Ự","Ử","Ữ");
		$uni[8] = array("í","ì","ị","ỉ","ĩ");
		$uni[9] = array("Í","Ì","Ị","Ỉ","Ĩ");
		$uni[10] = array("đ");
		$uni[11] = array("Đ");
		$uni[12] = array("ý","ỳ","ỵ","ỷ","ỹ");
		$uni[13] = array("Ý","Ỳ","Ỵ","Ỷ","Ỹ");

		for($i=0; $i<=13; $i++) {
			$text = str_replace($uni[$i],$chars[$i],$text);
		}
		return $text;
	}

}
?>
