<?php
class SynCache
{
	/*Tin tuc*/
	static public function setCacheCat($row)
	{
		Yii::app()->cache->keyPrefix = '39151f0d';
		$cacheService = new CacheService("Cat","getCats");
		$key = $cacheService->createKey ();
		Yii::app ()->cache->set ($key,false);
		$cacheService = new CacheService("Cat","getCatMenuHot");
		$key = $cacheService->createKey ();
		Yii::app ()->cache->set ($key,false);
		$cacheService = new CacheService("Cat","getCatMenu");
		$key = $cacheService->createKey ();
		Yii::app ()->cache->set ($key,false);
	}

	static public function setCacheNews($row)
	{
		Yii::app()->cache->keyPrefix = '39151f0d';
		//Sitemap articles
		$begin_time = mktime(0,0,0,date('m'),1,date('Y'));
		$end_time = mktime(23,59,59,date('m'),date("t",$begin_time),date('Y'));
		$num_of_page = 600;
		$cacheService = new CacheService("TsArticles","getArticlesSiteMap",$begin_time.$end_time.$num_of_page);
		$key = $cacheService->createKey();
		Yii::app ()->cache->set ($key,false);
	}
}
?>