<?php
/**
-------------------------
GNU GPL COPYRIGHT NOTICES
-------------------------
/**
 * $Id$
 *
 * @author thangtt <ducnv@az24.com>
 * @link http://www.az24.vn/
 * @copyright Copyright &copy; 2009-2010 HDC.
 *
 */

class ConstantsUtil
{
    const TIME_CACHE_300  = 300;  // 5 phút
    const TIME_CACHE_900  = 900;  // 15 phút
    const TIME_CACHE_1800 = 1800; // nửa giờ
    const TIME_CACHE_3600  = 3600; // một tiếng
    const TIME_CACHE_7200  = 7200; // hai tieng
    const TIME_CACHE_10800  = 10800; // ba tieng
    const TIME_CACHE_86400 = 86400; // một ngày
    const TIME_CACHE_259200 = 259200; // một tháng
    const TIME_CACHE_31536000 = 31536000; // một năm 
    const SEASON_CATE ='season_cate' ;
    
    //so cau hoi,tra loi,comment 1 trang
    const QUESTION_PER_PAGE = 10;      
    const ANSWER_PER_PAGE = 8;
    const COMMENT_PER_PAGE = 5;
    
    // diem hoi dap
    const MARK_CREATE_QUESTION = -5;
    const MARK_CHOICE_ANSWER_FIRST_GOOD = 3;
    const MARK_ANSWER = 5;
    const MARK_QUESTION_THANKS = 5;
    const MARK_ANSWER_THANKS = 5;
    const MARK_ANSWER_MEDAL = 15;
    const MARK_LOGIN = 1;
    const MARK_WRITE_COMMENT = 3;
    const MARK_SEND_LINK = 20;
    const MARK_SEND_LINK_SUCCESS = 50;
    const MARK_VOTE_POLL = 1;

    // loai hoat dong hoi dap
    const CREATE_QUESTION = 1;
    const CREATE_ANSWER = 2;
    const CREATE_COMMENT = 3;
    
    //key word cam trong hoi dap
    public static $arr_keyword = array(
       'tran dan tien','dang cong san vn','csvn','dang cong san','truong sa hoang sa','truong sa','hoang sa','bieu tinh','viet cong','viet minh','hcm','ho chi minh','bac ho','dcs','hcm','ho chi minh','bac ho','dcs','le duc anh','nguyen phu trong','truong tan sang','phung quang thanh','nguyen tan dung','nguyen sinh hung','le hong anh','le thanh hai','to huy rua','pham quang nghi','tran dai quang','tong thi phong','ngo van du','dinh the huynh','nguyen xuan phuc','nong duc manh','nguyen minh triet','pham gia khiem','truong vinh trong','ho duc viet','nguyen van chi','nguyen xuan han','nguyen van an','vo nguyen giap','do muoi','bat bao dong','dang cs','dcsvn','phimsex','tu do dan chu','huynh tan phat','giai the dang cong san','tau cong','dang csvn','csdchb','chien si dan chu hoa binh','giai the dang cong san','tau cong','dang csvn','csdchb','chien si dan chu hoa binh','xa hoi do','xa hoi den','cong san vn','giac tau','chong cong','viet nam da nguyen da dang','giai the dang cong san','bau cu quoc hoi da dang','da nguyen da dang muon nam','cncs','bcvp','nguoi cs','boxit','dkm','chu nghia cs','che do dan chu hoa binh dao duc nhan ai','chong cong','hoang-truong sa','dcsvn','nguyen trung linh','kien dinh on hoa','nguyen van ly','ly thuy','quan su viet cong','lanh tu thanh nien cs','chien si viet cong','tu do ton giao','le cong dinh','viet nam cong hoa','chinh quyen nguy','viet gian','phan dong','nguyen tien trung','tran anh kim','viet tan','le cong dinh','nguyen van dai','le thi cong nhan','khoi 8460','to chuc 8406','doan van dien','tran thi le hong','doan huy chuong','nguyen cong bang','hoang co minh','nguyen thanh van','phong trao dan chu cho viet nam','radio hoa mai','ly thai hung','do hoang diem','nguyen xuan ngai','cong san la tu ban do','ngo quang kiet','chong pha','che do xa hoi chu nghia','lon gia ho chi minh','vo van kiet','nong thi xuan','nguyen sinh cung','lat dong chinh quyen','vnch','viet nam cong hoa','nguy quan','nguy quyen','thang ho','cu ho','viet tan','viet nam quoc dan dang','lanh tu','ton giao viet nam','ong ho','ong diem','quyen tu do dan chu o viet nam','nguyen cao ky','tham nhung','may thang phan dong','dang vien cs','phan dong','viet gian','dang dan chu','bon ban nuoc','bao loan lat do','dang viet tan','chinh quyen cs vn','giai the che do cs','tuoc doat quyen','lat do che do','dang cong san viet nam','dm & lm','dm va lm','may thang, may con cong san','nguyen thien nhan','nha nuoc cong san','cuong quoc cong san','quang boxit tay nguyen','cac dang phai chinh tri','bach dang giang foundation','da dao chinh quyen cai tri','dang an hai','che do bat cong','toi ac cua mot che do','dang phai','dang cong san trung cong','dang cong san viet gian','tho mac, tho le, tho mao, tho ho chu tich','ho chu tich','giai the che do cong san','toi ac cua dang cs','cs trung quoc','toi ac cua cs trung quoc','gian manh cua cs','phan dong cs','thang ho','thang manh','ho tao bo may','con oi nho lay loi tao, may la thang manh, ho tao bo may','loi tran troi cua hcm','naq','xac ho chi minh','bac ho co vo con','tong bi thu','con cho con va cu ho','dcm','dkm','chu tich nuoc','lon gia ho chi minh','ho chi minh xui','thu tuong','mong se de len mat ho','bac ho chet','chu tich quoc hoi','ctqh','bo quoc phong','bo cong an','tong cuc an ninh','che do da dang','tieu cuc trong','canh sat giao thong','the che dan chu','mot dang','tan viet cach mang dang','tu do ngon luan','dang hoa dong','bon cong san','phan chau trinh','giet nguoi','giet phat','bchtu','day to nhan dan','dot co do, giuong cao co vang','am binh noi day','anh ho cong tu','xoa bo dan toc','ly thuyet cong san','quyen tu do ngon luan','dang hoa dong','hoang van hoan','che do dan chu da dang','bac ho cua chung ta','tu do chinh tri','co ba soc','huyen tay sa','lang bac ho','ong minh chua bao gio','vung tay sa','nguyen thanh giang','tau khua','con re cua vo nguyen giap','duong luoi cho','tranh chap bien dong','chong chinh phu','thich quang do','bao quyen','chim bac ho','giac trung quoc','viet nam canh tan','uy ban thon dao','chien dich co vang','chu nghia dan toc ho chi minh','hoi dan oan','dien bien hoa binh','tay chay trung quoc','nua nha nuoc','thien dang cs','giai phong loai nguoi','khu tu tri trung quoc','quy che khu tu tri','wikileaks','chinh quyen cong san','tu dao hanh','ho chi minh giet vo','the tu cua ho chi minh','bo mat that cua ho chi minh','tang tuyet minh','ho chi minh giet hai','cam ghet ong ho','cam ghet nguoi trung quoc','nguoi viet nam va nguoi trung quoc',
    );
    
    

}
?>
