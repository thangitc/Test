<?php
class DateUtils {
    public static function convertDateToStringFormat($datetime){  
        $time_format = "";
        $arr_datetime = explode(" ",$datetime);
        if(count($arr_datetime) >2 ){
            $arr_date = explode("/",$arr_datetime[0]);
            $arr_time = explode(":",$arr_datetime[1]);
            if(count($arr_date) >2 && count($arr_time) >2){
                $time = mktime($arr_time[0],$arr_time[1],0,$arr_date[1],$arr_date[0],$arr_date[2]);               
                $sub_time = time()-$time;  
                if($sub_time > 0){
                    $date = floor ( $sub_time/ 86400 );
                    $hour = floor ( $sub_time / 3600 );
                    $minutes = floor ( $sub_time / 60 );
                    if($minutes < 1 ){
                        $time_format = 'vài giây trước';
                    }elseif ($minutes < 60 && $minutes >= 1) {
                        $time_format = $minutes . ' phút trước';
                    } elseif ($hour < 24 && $hour >= 1) {
                        $time_format = $hour . ' giờ trước';
                    } elseif ($date < 30 && $date >= 1) {
                        $time_format = $date . ' ngày trước';
                    } else{
                        $time_format = $arrDate [0] . '/' . $arrDate [1] . '/' . $arrDate [2];
                    }
                    return $time_format;
                }else{
                    $time_format =  $datetime;
                    return $time_format;
                }
            }else{
                $time_format ="hơn 1 tháng trước";
                return $time_format;
            }
        }else{
            $time_format ="vài tháng trước";
            return $time_format;
        }
    }
    public static function convertIntToDate($date){
        $date_format ="";
        if($date != 0){
            $default = mktime(0,0,0,8,15,2010);
            if($date> $default){
                $date_format = date("d/m/Y",$date);
            }else{
                $date_format = "22/8/2010";
            }
        }else{
            $date_format = "20/8/2010";
        }
        return $date_format;
    }
    public static function convertToNumberTime($i){
        $time = $i*8;
        $number_time = '1 phút trước';
        if($time<60){
            $number_time = $time .' phút trước';
        }elseif ($time >= 60 && $time < 1440){
            $number_time = floor($time/60).' giờ trước';
        }else{
            $number_time = 'vài ngày trước';
        }
        return $number_time;
    }
    public static function convertToThu()
    {
        $date = gmdate("l",time() + 7*3600);
        $str_in = array ( "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");            
        $str_out = array ( "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy", "Chủ nhật");
        $thu  = str_replace( $str_in, $str_out, $date);
        return $thu;
    }
    public static function convertThuToNumber()
    {
        $date = gmdate("l",time() + 7*3600);
        $str_in = array ( "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");            
        $str_out = array ( "2", "3", "4", "5", "6", "7", "8");
        $thu  = str_replace( $str_in, $str_out, $date);
        return $thu;
    }
    public static function subtractionWeek($w)
    {
        $date = date('Y-m-j');
        $new_date = strtotime ( '-'.$w.' week' , strtotime ($date) ) ;
        $new_date = date ( 'Y-m-j' ,$new_date );        
        return $new_date;
    }
    public static function convertDatedb($date)
    {
        $dtmp = explode('/',$date);
        $dadate = mktime(0,0,0,$dtmp[1],$dtmp[0],$dtmp[2]);
        return  date('Y-m-d',$dadate);                    
    }
    public static function convertDateweb($date)
    {
        $dtmp = explode('-',$date);         
        return  date("d/m/Y", mktime(0, 0, 0, $dtmp[1],$dtmp[2], $dtmp[0]));
    }
    public static function calculateDaysFromDate($date)
    {
        $days = round((strtotime(date("Y-m-d")) - strtotime($date)) / (60 * 60 * 24));
        return $days;        
    }
    public static function subDates($date1,$date2)
    {
        $days = round((strtotime($date1) - strtotime($date2)) / (60 * 60 * 24));
        return $days;        
    }
    
    function convertDateTime($strDate = "", $strTime = ""){
        //Break string and create array date time
        $strDate         = str_replace("/", "-", $strDate);
        $strDateArray    = explode("-", $strDate);
        $countDateArr    = count($strDateArray);
        $strTime            = str_replace("-", ":", $strTime);
        $strTimeArray    = explode(":", $strTime);
        $countTimeArr    = count($strTimeArray);
        //Get Current date time
        $today            = getdate();
        $day                = $today["mday"];
        $mon                = $today["mon"];
        $year                = $today["year"];
        $hour                = $today["hours"];
        $min                = $today["minutes"];
        $sec                = $today["seconds"];
        //Get date array
        switch($countDateArr){
            case 2:
                $day    = intval($strDateArray[0]);
                $mon    = intval($strDateArray[1]);
                break;
            case $countDateArr >= 3:
                $day    = intval($strDateArray[0]);
                $mon    = intval($strDateArray[1]);
                $year = intval($strDateArray[2]);
                break;
        }
        //Get time array
        switch($countTimeArr){
            case 2:
                $hour    = intval($strTimeArray[0]);
                $min    = intval($strTimeArray[1]);
                break;
            case $countTimeArr >= 3:
                $hour    = intval($strTimeArray[0]);
                $min    = intval($strTimeArray[1]);
                $sec    = intval($strTimeArray[2]);
                break;
        }
        //Return date time integer
        if(@mktime($hour, $min, $sec, $mon, $day, $year) == -1) return $today[0];
        else return mktime($hour, $min, $sec, $mon, $day, $year);
    }
}