<?php
class Paging
{
    public static function show_paging($num_page,$page,$iSEGSIZE,$url,$url1='')
    {
        $cur_page = $page;
        $lastpage = $num_page;
        $seg_size = $iSEGSIZE;
        $alink = '';
        $seg_page = '';
        $seg_num = ceil($num_page / $seg_size);
        $seg_cur = ceil(($page+1) / $seg_size);
        //echo $seg_cur;
        $first_page = 1;
        $back_page = $page - 1;
        //so trang tren moi phan doan
        $n = ($seg_cur * $seg_size <= $lastpage)?$seg_cur * $seg_size:$lastpage;
        //in ra cac trang trong moi phan doan
        if($seg_cur ==1)
        for($p = ($seg_cur - 1) * $seg_size +1; $p <= $n; $p++) {
            $seg_page[] = $p;
        }
        else
        for($p = ($page - 4); $p <= ($page+4<=$lastpage?$page+4:$lastpage); $p++) {
            $seg_page[] = $p;
        }
        //show/hide back
        $next_page = $page + 1;
        $last_page = $lastpage;
        if($seg_cur > 1) {
            $back = $cur_page - 1;
            //$alink.='<li><a class="fl active" href="'.$url.$back.'" ><span class="nomal">Trước</span></a></li>';
            $alink .= '<li class="fl"><a  href="'.$url.$back.'"><strong>Trước</a></strong></li>';
        }
        else {
            $back = $cur_page - 1;
            if($back>0)
                //$alink.='<li><a class="fl active" href="'.$url.$back.'"><span class="nomal">Trước</span></a></li>';
                $alink .= '<li class="fl"><a  href="'.$url.$back.'"><strong>Trước</a></strong></li>';
        }

        if(count($seg_page) <= 0) return;
        if($seg_page)
        foreach($seg_page as $page) {
            if($page == $cur_page) {
                //<li class="fl active"><a href="#" title=""><strong>1</strong></a></li>
                //$alink.='<li><a href="'.$url.$page.'"  class="fl active"><span>'.$page.'</span></a></li>';
                $alink.='<li class="fl active"><a title="" href="'.$url.$page.'"><strong>'.$page.'</strong></a></li>';
            }
            else {
                if ($url1 && $page==1)
                    //$alink .= "<li><a class='fl' href='".$url1.$page."'><span>".$page."</span></a></li>";
                    $alink .= '<li class="fl"><a title="" href="'.$url1.$page.'"><strong>'.$page.'</strong></a></li>';
                else
                    //$alink .= "<li><a href='$url$page'><span>$page</span></a></li>";
                    $alink .= '<li class="fl"><a title="" href="'.$url.$page.'"><strong>'.$page.'</strong></a></li>';
            }
        }
        //show/hide next
        if($seg_cur <= $seg_num && $cur_page<$num_page) {
            $next = $cur_page + 1;
            //$alink .= "<li><a class='next1' href='$url$next'><span class='nomal'>Sau</span></a></li>";
            $alink .= '<li class="fl"><a  href="'.$url.$next.'"><strong>Sau</a></strong></li>';
        }

        return $alink;
    }
    
    public static function show_paging2($num_page,$page,$iSEGSIZE,$url,$url1='')
    {
        $cur_page = $page;
        $lastpage = $num_page;
        $seg_size = $iSEGSIZE;
        $alink = '';
        $seg_page = '';
        $seg_num = ceil($num_page / $seg_size);
        $seg_cur = ceil(($page+1) / $seg_size);
        //echo $seg_cur;
        $first_page = 1;
        $back_page = $page - 1;
        //so trang tren moi phan doan
        $n = ($seg_cur * $seg_size <= $lastpage)?$seg_cur * $seg_size:$lastpage;
        //in ra cac trang trong moi phan doan
        if($seg_cur ==1)
        for($p = ($seg_cur - 1) * $seg_size +1; $p <= $n; $p++) {
            $seg_page[] = $p;
        }
        else
        for($p = ($page - 4); $p <= ($page+4<=$lastpage?$page+4:$lastpage); $p++) {
            $seg_page[] = $p;
        }
        //show/hide back
        $next_page = $page + 1;
        $last_page = $lastpage;
        if($seg_cur > 1) {
            $back = $cur_page - 1;
            $alink.='<li><a class="chose_event" href="'.$url.$back.'" ><span class="nomal">Trước</span></a></li>';
        }
        else {
            $back = $cur_page - 1;
            if($back>0)
                $alink.='<li><a class="chose_event" href="'.$url.$back.'"><span class="nomal">Trước</span></a></li>';
        }

        if(count($seg_page) <= 0) return;
        if($seg_page)
        foreach($seg_page as $page) {
            if($page == $cur_page) {
                $alink.='<li><a class="chose_event" href="'.$url.$page.'" class="active"><span>'.$page.'</span></a></li>';
            }
            else {
                if ($url1 && $page==1)
                    $alink .= "<li><a class='chose_event' href='$url1'><span>$page</span></a></li>";
                else
                    $alink .= "<li><a class='chose_event' href='$url$page'><span>$page</span></a></li>";
            }
        }
        //show/hide next
        if($seg_cur <= $seg_num && $cur_page<$num_page) {
            $next = $cur_page + 1;
            $alink .= "<li><a class='next1' href='$url$next'><span class='nomal'>Sau</span></a></li>";
        }

        return $alink;
    }
    
    public static function show_paging_ajax($funcName,$variable=array(),$num_page,$page,$iSEGSIZE,$url,$url1='')
    {
        $vari = "";
        if(isset($variable)){
            foreach($variable as $var){
                $vari .= '"'.$var.'",';
            }
        }
        $vari = rtrim($vari, ",");
        $cur_page = $page;
        $lastpage = $num_page;
        $seg_size = $iSEGSIZE;
        $alink = '';
        $seg_page = '';
        $seg_num = ceil($num_page / $seg_size);
        $seg_cur = ceil(($page+1) / $seg_size);
        //echo $seg_cur;
        $first_page = 1;
        $back_page = $page - 1;
        //so trang tren moi phan doan
        $n = ($seg_cur * $seg_size <= $lastpage)?$seg_cur * $seg_size:$lastpage;
        //in ra cac trang trong moi phan doan
        if($seg_cur ==1)
        for($p = ($seg_cur - 1) * $seg_size +1; $p <= $n; $p++) {
            $seg_page[] = $p;
        }
        else
        for($p = ($page - 4); $p <= ($page+4<=$lastpage?$page+4:$lastpage); $p++) {
            $seg_page[] = $p;
        }
        //show/hide back
        $next_page = $page + 1;
        $last_page = $lastpage;
        if($seg_cur > 1) {
            $back = $cur_page - 1;
            if(empty($vari)) {
                //$alink.='<li><a href="javascript:'.$funcName."(".$back.')" class="back1"><span class="nomal">Trước</span></a></li>';
                $alink.='<li class="fl"><a href="javascript:'.$funcName."(".$back.')" title=""><strong>Trước</strong></a></li>';
                
            } else {
                //$alink.='<li><a href="javascript:'.$funcName."(".$vari.", ".$back.')" class="back1"><span class="nomal">Trước</span></a></li>';
                $alink.='<li class="fl"><a href="javascript:'.$funcName."(".$vari.", ".$back.')" title=""><strong>Trước</strong></a></li>';
            }
             
        }
        else {
            $back = $cur_page - 1;
            if($back>0)
            if(empty($vari)) {
                //$alink.='<li><a href="javascript:'.$funcName."(".$back.')" class="back1"><span class="nomal">Trước</span></a></li>';
                $alink.='<li class="fl"><a href="javascript:'.$funcName."(".$back.')" title=""><strong>Trước</strong></a></li>';
            } else {
                //$alink.='<li><a href="javascript:'.$funcName.'('.$vari.', '.$back.')" class="back1"><span class="nomal">Trước</span></a></li>';
                $alink.='<li class="fl"><a href="javascript:'.$funcName.'('.$vari.', '.$back.')" title=""><strong>Trước</strong></a></li>';
            }
        }

        if(count($seg_page) <= 0) return;
        if($seg_page)
        foreach($seg_page as $page) {
            if($page == $cur_page) {
                //$alink.='<li><a href="javascript:void(0)" class="active"><span>'.$page.'</span></a></li>';
                $alink.='<li class="fl active"><a href="javascript:void(0)" title=""><strong>'.$page.'</strong></a></li>';
            }
            else {
                if ($url1 && $page==1)
                    if(empty($vari)) {
                        //$alink .= "<li><a href='javascript:".$funcName."(".$url1.")'><span>$page</span></a></li>";
                        $alink .= '<li class="fl"><a href="javascript:'.$funcName.'('.$url1.')" title=""><strong>'.$page.'</strong></a></li>';
                    } else {
                        //$alink .= "<li><a href='javascript:".$funcName."(".$vari.",".$url1.")'><span>$page</span></a></li>";
                        $alink .= '<li class="fl"><a href="javascript:'.$funcName.'('.$vari.','.$url1.')" title=""><strong>'.$page.'</strong></a></li>';
                    }
                else {
                    if(empty($vari)) {
                        //$alink .= "<li><a href='javascript:".$funcName."(".$page.")'><span>$page</span></a></li>";
                        $alink .= '<li class="fl"><a href="javascript:'.$funcName.'('.$page.')" title=""><strong>'.$page.'</strong></a></li>';
                    } else {
                        //$alink .= "<li><a href='javascript:".$funcName."(".$vari.",".$page.")'><span>$page</span></a></li>";
                        $alink .= '<li class="fl"><a href="javascript:'.$funcName.'('.$vari.','.$page.')" title=""><strong>'.$page.'</strong></a></li>';
                            
                    }
                }
            }
        }
        //show/hide next
        if($seg_cur <= $seg_num && $cur_page<$num_page) {
            $next = $cur_page + 1;
            if(empty($vari)) {
                //$alink .= "<li><a class='next1' href='javascript:".$funcName."(".$next.")'><span class='nomal'>Sau</span></a></li>";
                $alink .= '<li class="fl"><a href="javascript:'.$funcName.'('.$next.')" title=""><strong>Sau</strong></a></li>';
            } else {
                //$alink .= "<li><a class='next1' href='javascript:".$funcName."(".$vari.",".$next.")'><span class='nomal'>Sau</span></a></li>";
                $alink .= '<li class="fl"><a href="javascript:'.$funcName.'('.$vari.','.$next.')" title=""><strong>Sau</strong></a></li>';
            }
        }

        return $alink;
    }
    public static function show_paging_ajax2($funcName,$num_page,$page,$num_per_page,$iSEGSIZE)
    {
        $cur_page = $page;
        $lastpage = $num_page;
        $seg_size = $iSEGSIZE;
        $alink = '';
        $seg_page = '';
        $seg_num = ceil($num_page / $seg_size);
        $seg_cur = ceil(($page+1) / $seg_size);
        //echo $seg_cur;
        $first_page = 1;
        $back_page = $page - 1;
        //so trang tren moi phan doan
        $n = ($seg_cur * $seg_size <= $lastpage)?$seg_cur * $seg_size:$lastpage;
        //in ra cac trang trong moi phan doan
        if($seg_cur ==1)
        for($p = ($seg_cur - 1) * $seg_size +1; $p <= $n; $p++) {
            $seg_page[] = $p;
        }
        else
        for($p = ($page - 4); $p <= ($page+4<=$lastpage?$page+4:$lastpage); $p++) {
            $seg_page[] = $p;
        }
        //show/hide back
        $next_page = $page + 1;
        $last_page = $lastpage;
        if($seg_cur > 1) {
            $back = $cur_page - 1;
            if(empty($vari)) {
                $alink.='<li><a href="javascript:'.$funcName."(".$back.','.$num_per_page.')" class="back1"><span class="nomal">Trước</span></a></li>';
            } else {
                $alink.='<li><a href="javascript:'.$funcName."(".$back.','.$num_per_page.')" class="back1"><span class="nomal">Trước</span></a></li>';
            }
             
        }
        else {
            $back = $cur_page - 1;
            if($back>0)
            if(empty($vari)) {
                $alink.='<li><a href="javascript:'.$funcName."(".$back.','.$num_per_page.')" class="back1"><span class="nomal">Trước</span></a></li>';
            } else {
                $alink.='<li><a href="javascript:'.$funcName.'('.$back.','.$num_per_page.')" class="back1"><span class="nomal">Trước</span></a></li>';
            }
        }

        if(count($seg_page) <= 0) return;
        if($seg_page)
        foreach($seg_page as $page) {
            if($page == $cur_page) {
                $alink.='<li><a href="javascript:void(0)" class="active"><span>'.$page.'</span></a></li>';
            }
            else {
                $alink .= "<li><a href='javascript:".$funcName."(".$page.",".$num_per_page.")'><span>$page</span></a></li>";
            }
        }
        //show/hide next
        if($seg_cur <= $seg_num && $cur_page<$num_page) {
            $next = $cur_page + 1;
            if(empty($vari)) {
                $alink .= "<li><a class='next1' href='javascript:".$funcName."(".$next.",".$num_per_page.")'><span class='nomal'>Sau</span></a></li>";
            } else {
                $alink .= "<li><a class='next1' href='javascript:".$funcName."(".$next.",".$num_per_page.")'><span class='nomal'>Sau</span></a></li>";
            }
        }

        return $alink;
    }
	
	public static function show_paging_cp($maxPage,$currentPage, $path = '',$object = '',$first = '',$last = '') {
            if($maxPage <=1) return '';
            $url = new Url();        
            if($maxPage <=1){
                $html = "";return $html;
            }
            $nav = array(
                // bao nhiêu trang bên trái currentPage
                'left' => 2,
                // bao nhiêu trang bên phải currentPage
                'right' => 2,
            );

            // nếu maxPage < currentPage thì cho currentPage = maxPage
            if ($maxPage < $currentPage) {
                $currentPage = $maxPage;
            }

            // số trang hiển thị
            $max = $nav['left'] + $nav['right'];

            // phân tích cách hiển thị
            if ($max >= $maxPage) {
                $start = 1;
                $end = $maxPage;
            } elseif ($currentPage - $nav['left'] <= 0) {
                $start = 1;
                $end = $max + 1;
            } elseif (($right = $maxPage - ($currentPage + $nav['right'])) <= 0) {
                $start = $maxPage - $max;
                $end = $maxPage;
            } else {
                $start = $currentPage - $nav['left'];
                if ($start == 2) {
                    $start = 1;
                }

                $end = $start + $max;
                if ($end == $maxPage - 1) {
                    ++$end;
                }
            }
            $navig = '';
            if ($currentPage >= 2) {
                // thêm nút "Trước"
                $navig .= '<li class="fl"><a href="' . $path . 'page'.$object.'=' . ceil($currentPage - 1) . '"><strong>Trước</strong></a></li>';
                if ($currentPage >= $nav['left']) {
                    if ($currentPage - $nav['left'] > 2 && $max < $maxPage) {
                        // thêm nút "1"
                        $navig .= '<li class="fl"><a href="' . $path . 'page'.$object.'=1' . '"><strong>'. $first .'1'. $last .'</strong></a></li>';
                        $navig .= '<li class="fl">...</li>';
                    }
                }
            }

            for ($i = $start; $i <= $end; $i++) {
                // trang hiện tại
                if ($i == $currentPage) {
                    $navig .= '<li class="fl active"><a href="' . $path . 'page'.$object.'=' . $i . '"><strong>'. $first . $i . $last .'</strong></a></li>';
                }
                // trang khác
                else {
                    //     $pg_link = $path.'page='.$i;
                    $navig .= '<li class="fl"><a href="' . $path . 'page'.$object.'=' . $i . '"><strong>'. $first . $i . $last .'</strong></a></li>';
                }
            }

            if ($currentPage <= $maxPage - 1) {
                if ($currentPage + $nav['right'] < $maxPage - 1 && $max + 1 < $maxPage) {
                    // trang cuoi
                    $navig .= '<li class="fl">...</li>';
                    $navig .= '<li class="fl"><a href="' . $path . 'page'.$object.'=' . $maxPage . '"><strong>'. $first . $maxPage . $last .'</strong></a></li>';
                }
                $navig .= '<li class="fl"><a href="' . $path . 'page'.$object.'=' . ($currentPage + 1) . '"><strong>Sau</strong></a></li>';
            }

            // hiển thị kết quả
            return $navig;
        }
}
?>
