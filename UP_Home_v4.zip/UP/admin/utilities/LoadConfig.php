﻿<?php
class LoadConfig
{
	static public $arr_cat_type = array(1=>'CAMERA',2=>'Tin CAMERA', 3=>'Phụ kiện');
	static public $arr_pos = array(1=>'Top Home', 2=>'Bottom', 3=>'Left', 4=>'Home Welcome');
	static public $arr_camera_type = array(1=>'Lens zoom', 2=>'Lens fix', 3=>'Body crop', 4=>'Body full frame', 5=>'Phụ kiện');
	static public $arr_rating = array(1=>'AA', 2=>'A', 3=>'AB+', 4=>'AB', 5=>'B', 6=>'C', 7=>'J', 8=>'S');
	static public $arr_order_status = array('canceled'=>'Hủy bỏ', 'completed'=>'Hoàn thành', 'pending'=>'Chưa  giải quyết', 'processing'=>'Đang xử lý');
	static public $arr_special = array(1=>'SP sắp về', 2=>'SP bán chạy', 3=>'SP đang HOT', 4=>'SP giá tốt', 5=>'SP Khuyến mại');
	
	static public $list_user_full_permit = array('admin', 'hieunc');
	static public $list_chi_nhanh = array(0=>'HN', 1=>'HCM', 2=>'Đà Nẵng', 3=>'Hải Phòng');
}
?>