<?php
class PermitConfig{  
    public static $permission = array(
        "can_view"=>1,
        "can_create"=>2,
        "can_edit"=>4,
        "can_del"=>8,
    );
	
    public static $permission_module = array(
        1=>array("label"=>"Danh Mục","value"=>"cat"),
        2=>array("label"=>"SP Camera","value"=>"bList"),
        3=>array("label"=>"QL Model","value"=>"bModel"),
        4=>array("label"=>"QL Body","value"=>"bBody"),
        5=>array("label"=>"QL Brand","value"=>"bBrand"),
        6=>array("label"=>"QL Color","value"=>"bColor"),
        7=>array("label"=>"QL Kit","value"=>"bKit"),
        8=>array("label"=>"Phụ kiện","value"=>"access"),
        9=>array("label"=>"Giỏ hàng","value"=>"cart"),
		10=>array("label"=>"Email Subscribe","value"=>"subscribe"),
        11=>array("label"=>"Tin Tức","value"=>"news"),
        12=>array("label"=>"Sự kiện","value"=>"topic"),
		13=>array("label"=>"Comment","value"=>"comment"),
        14=>array("label"=>"Timeline","value"=>"bTimeline"),
        15=>array("label"=>"Quảng cáo","value"=>"ads"),
		16=>array("label"=>"QL Khách hàng","value"=>"customer"),
        17=>array("label"=>"QL Tiền Japan","value"=>"bMoneyJapan"),
        18=>array("label"=>"QL Tiền VN","value"=>"bMoneyVn"),
		19=>array("label"=>"Thống kê","value"=>"analytics"),
		20=>array("label"=>"User","value"=>"user"),
		21=>array("label"=>"Admin","value"=>"admin"),
		22=>array("label"=>"QL Liên Hệ","value"=>"bStaticContent"),
		23=>array("label"=>"Ajax","value"=>"ajax"),
		24=>array("label"=>"Hóa đơn","value"=>"bill"),
		25=>array("label"=>"COMBOS","value"=>"combos"),
		100=>array("label"=>"QL Logs","value"=>"logs")
    );
    
	public static $cat = array(
        "can_view"=>array("index", "seo", "orderMenu", 'showCat', 'orderCatHome', 'orderCatHomeBottom'),
        "can_create"=>array(),
        "can_edit"=>array('updateSubCat'),
        "can_del"=>array('deleteCate')
    );
	
    public static $bList = array(
        "can_view"=>array("index", "showNews", 'sale', 'seo'),
        "can_create"=>array("add","new", "addReall"),
        "can_edit"=>array("edit", 'editNew', 'editSale'),
        "can_del"=>array('deleteList'),
    );
	
	public static $bModel = array(
        "can_view"=>array("index", 'seo'),
        "can_create"=>array("add"),
        "can_edit"=>array("edit"),
        "can_del"=>array('deleteModel')
    );
	
	public static $bBody = array(
        "can_view"=>array("index"),
        "can_create"=>array("add"),
        "can_edit"=>array("edit"),
        "can_del"=>array('deleteBody'),
    );
	
	public static $bBrand = array(
        "can_view"=>array("index"),
        "can_create"=>array("add"),
        "can_edit"=>array("edit"),
        "can_del"=>array('deleteBrand')
    );
	
	public static $bColor = array(
        "can_view"=>array("index"),
        "can_create"=>array("add"),
        "can_edit"=>array("edit"),
        "can_del"=>array('deleteColor')
    );
	
	public static $bKit = array(
        "can_view"=>array("index"),
        "can_create"=>array("add"),
        "can_edit"=>array("edit"),
        "can_del"=>array('deleteKit')
    );
	
	public static $access = array(
        "can_view"=>array("index", 'seo', 'sale', 'color','showAccess' ),
        "can_create"=>array("add", 'addColor'),
        "can_edit"=>array("edit", 'editColor', 'editSale'),
        "can_del"=>array('deleteAccess')
    );
	
	public static $cart = array(
        "can_view"=>array("index"),
        "can_create"=>array(),
        "can_edit"=>array(),
        "can_del"=>array()
    );
	public static $subscribe = array(
        "can_view"=>array("index"),
        "can_create"=>array(),
        "can_edit"=>array(),
        "can_del"=>array()
    );
	
    public static $news = array(
        "can_view"=>array("index", "showNews"),
        "can_create"=>array("add"),
        "can_edit"=>array("edit"),
        "can_del"=>array('deleteNews')
    );		
	
    public static $topic = array(
        "can_view"=>array("index", 'showTopic', "news"),
        "can_create"=>array("add"),
        "can_edit"=>array("edit"),
        "can_del"=>array('deleteTopicNews')
    );
	public static $comment = array(          
        "can_view"=>array("index"),
        "can_create"=>array(),
        "can_edit"=>array(),
        "can_del"=>array()
    );
	
	public static $bTimeline = array(
        "can_view"=>array("index"),
        "can_create"=>array("add"),
        "can_edit"=>array("edit"),
        "can_del"=>array('deleteTimeline')
    );
	
	public static $ads = array(
        "can_view"=>array("index"),
        "can_create"=>array('add'),
        "can_edit"=>array('edit'),
        "can_del"=>array('deleteAds')
    );
	
	public static $customer = array(
        "can_view"=>array("index", "product", 'access'),
        "can_create"=>array('add'),
        "can_edit"=>array('edit'),
        "can_del"=>array('deleteCustomer')
    );
	
	public static $bMoneyJapan = array(
        "can_view"=>array("index"),
        "can_create"=>array('add'),
        "can_edit"=>array('edit'),
        "can_del"=>array('deleteMoneyJapan')
    );
	
	public static $bMoneyVn = array(
        "can_view"=>array("index", 'day'),
        "can_create"=>array('add'),
        "can_edit"=>array('edit'),
        "can_del"=>array('deleteMoneyVn')
    );
	
	public static $analytics = array(
        "can_view"=>array("index", 'access', 'chart','lazada'),
        "can_create"=>array(),
        "can_edit"=>array(),
        "can_del"=>array()
    );
	
    public static $user = array(          
        "can_view"=>array("index","detail"),
        "can_create"=>array(),
        "can_edit"=>array(),
        "can_del"=>array()
    );
	
	public static $admin = array(
        "can_view"=>array("index", 'login', 'logout'),
        "can_create"=>array('add', 'create'),
        "can_edit"=>array('edit','change', 'updateProfile', 'changePass', 'permit'),
        "can_del"=>array('deleteUser')
    );
	
	public static $bStaticContent = array(          
        "can_view"=>array("index", 'edit'),
        "can_create"=>array(),
        "can_edit"=>array('edit'),
        "can_del"=>array()
    );
	
	public static $ajax = array(          
        "can_view"=>array("pagingTopic", 'pagingNews', 'pagingAccess'),
        "can_create"=>array(),
        "can_edit"=>array('edit'),
        "can_del"=>array()
    );
    public static $logs = array(
        "can_view"=>array("index"),
        "can_create"=>array(),
        "can_edit"=>array(),
        "can_del"=>array()
    );
	
	public static $bill = array(
        "can_view"=>array("index"),
        "can_create"=>array('add'),
        "can_edit"=>array('edit'),
        "can_del"=>array('deleteBill')
    );
	
	public static $combos = array(
        "can_view"=>array("index"),
        "can_create"=>array('add', 'addProduct'),
        "can_edit"=>array('edit'),
        "can_del"=>array('deleteCombo')
    );
}
    
?>