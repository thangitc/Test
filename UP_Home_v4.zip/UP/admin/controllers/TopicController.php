<?php
class TopicController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		$cat_id = isset($_GET['cat_id']) ?  intval($_GET['cat_id']):0;
		$tab=isset($_GET['tab']) ? intval($_GET['tab']) : -1;
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$url_rewrite=Common::genUrlRewrite();
		
		list($topic ,$paging,$total,$cat_topic,$news_total)=Topic::getTopic($cat_id,$keyword,$keyword_in,$tab,$from_date,$to_date,$page,$num_per_page,$url_rewrite);
		
		//Danh muc
		$cats=$this->cats;
		
		//Dem so ban ghi tung tab
		list($total_all,$total_publish,$total_pending) = Topic::countTabTopic();
		
		$this->render('index',
				array('topic'=>$topic,'paging'=>$paging,'total'=>$total,'cat_topic'=>$cat_topic,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'total_all'=>$total_all,'total_publish'=>$total_publish,'total_pending'=>$total_pending,
					  'cat_id'=>$cat_id,'cats'=>$cats,'news_total'=>$news_total,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,'tab'=>$tab,
					  'from_date'=>$from_date,'to_date'=>$to_date
		));	
	}
	public function actionAdd()
	{
		//Danh muc
		$cats = Cat::getCats();
		$this->render('add',array('cats'=>$cats));
	}
	public function actionEdit()
	{
		$topic_id=isset($_GET['topic_id']) ? intval($_GET['topic_id']) :0;
		//Danh muc
		$cats = Cat::getCats();
		$detail = Topic::getTopicById($topic_id);
		$this->render('edit',array('detail'=>$detail,'cats'=>$cats));
	}
	public function actionShowTopic()
	{
        $page=isset($_GET['page']) ? intval($_GET['page']):1;
        $cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;
		$num_per_page=10;
		$keyword='';
		$cat = $this->cats;
		$boolean = isset($_GET['boolean']) ? intval($_GET['boolean']):0;
		list($topic,$total) = Topic::getTopicPopup($keyword,$cat_id,$page,$num_per_page);
		$num_page=ceil($total/$num_per_page);
		
		$this->renderPartial("show_topic",
				array('topic'=>$topic,'cat'=>$cat,'num_page'=>$num_page,'boolean'=>$boolean,
					  'num_per_page'=>$num_per_page,'page'=>$page,'total'=>$total,'cat_id'=>$cat_id,
		));
	}
	
	public function actionNews()
	{
		$topic_id = isset($_GET['topic_id']) ? intval($_GET['topic_id']):1;
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;		
		$status = isset($_GET['status']) ? $_GET['status']:'';
		$is_hot = isset($_GET["is_hot"]) ? $_GET["is_hot"] : "";
        $orderby = isset($_GET["orderby"]) ? $_GET["orderby"] : "id";
        $order = isset($_GET["order"]) ? $_GET["order"] : 0;
        $seo = isset($_GET["seo"]) ? $_GET["seo"] : "";
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		
		$url_rewrite=Common::genUrlRewrite();		
		
		list($news,$paging,$total,$hits, $topics, $comments)=News::getNewsTopic($topic_id,$keyword,$keyword_in,$status, $is_hot,$orderby, $order, $seo, $from_date, $to_date,$page,$num_per_page,$url_rewrite);
		$this->render("news",
				array('news'=>$news,'paging'=>$paging,'total'=>$total,'hits'=>$hits, 'comments'=>$comments, 'topics'=>$topics,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,
					  'seo'=>$seo,'status'=>$status, 'is_hot'=>$is_hot, 'orderby'=>$orderby, 'order'=>$order,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'topic_id'=>$topic_id
		));
	}
	
	public function actionDeleteTopicNews()
	{
		$topic_id=isset($_POST['topic_id']) ? intval($_POST['topic_id']) : 0;
		if($topic_id!=0)
		{
			//Xoa su kien
			CommonModel::deleteObject(array('id'=>$topic_id),'b_topic');
			//Xoa bai viet su kien
			CommonModel::deleteObject(array('topic_id'=>$topic_id),'b_topic_news');
            /*Log*/
            $user_id=Yii::app()->user->id;
            $user_name=Yii::app()->user->name;
            $object_log['input']=array('id'=>$topic_id);   
            $module_log=4;
            $name_action='Xóa';
            $object_log['output']='Success!';
            header('Content-Type: text/html; charset=utf-8');
            $object_log=json_encode($object_log);
            $object_log=trim(mysql_escape_string($object_log));
            $content_log='<strong>'.$user_name.'</strong> Xóa Chuyên đề. Mã Chuyên đề : <strong>'.$topic_id.'</strong>';
            $content_log=trim(mysql_escape_string($content_log));
            Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
            /*End log*/
		}
		echo 1;
	}
}
?>