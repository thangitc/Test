<?php
class CustomerController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		$camera_id=isset($_GET['camera_id']) ? intval($_GET['camera_id']):0;
		$url_rewrite=Common::genUrlRewrite();
		
		list($customer ,$paging,$total )=Customer::getCustomer($keyword,$keyword_in ,$page,$num_per_page,$url_rewrite);
		
		$this->render('index',
				array('customer'=>$customer,'paging'=>$paging,'total'=>$total,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,
					  'camera_id'=>$camera_id
		));	
	}
	
	public function actionProduct()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		$camera_id=isset($_GET['camera_id']) ? intval($_GET['camera_id']):0;
		$url_rewrite=Common::genUrlRewrite();
		$camera_info = BList:: getListById($camera_id);
		list($customer ,$paging,$total )=Customer::getCustomerByProduct($camera_id,$keyword,$keyword_in ,$page,$num_per_page,$url_rewrite);
		
		$this->render('product',
				array('customer'=>$customer,'paging'=>$paging,'total'=>$total,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,
					  'camera_info'=>$camera_info, 'camera_id'=>$camera_id
		));	
	}
	
	public function actionAccess()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		$access_id=isset($_GET['access_id']) ? intval($_GET['access_id']):0;
		$url_rewrite=Common::genUrlRewrite();
		$access_info = Access::getAccessById($access_id);
		list($customer ,$paging,$total )=Customer::getCustomerByAccess($access_id,$keyword,$keyword_in ,$page,$num_per_page,$url_rewrite);
		
		$this->render('access',
				array('customer'=>$customer,'paging'=>$paging,'total'=>$total,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,
					  'access_info'=>$access_info, 'access_id'=>$access_id
		));	
	}
	
	public function actionAdd()
	{
		$camera_id=isset($_GET['camera_id']) ? intval($_GET['camera_id']):0;
		$camera_info = BList:: getListById($camera_id);
		$access_id=isset($_GET['access_id']) ? intval($_GET['access_id']):0;
		$access_info = Access:: getAccessById($access_id);
		$citys = BCity::getCity();
		$this->render('add', array('citys'=>$citys, 'camera_id'=>$camera_id,'access_id'=>$access_id, 'camera_info'=>$camera_info, 'access_info'=>$access_info));
	}
	public function actionEdit()
	{
		$camera_id=isset($_GET['camera_id']) ? intval($_GET['camera_id']):0;
		$customer_id=isset($_GET['customer_id']) ? intval($_GET['customer_id']) :0;
		$camera_info = BList:: getListById($camera_id);
		$access_id=isset($_GET['access_id']) ? intval($_GET['access_id']):0;
		$access_info = Access:: getAccessById($access_id);
		$detail = Customer::getCustomerById($customer_id);
		$citys = BCity::getCity();
		$this->render('edit',array('detail'=>$detail, 'citys'=>$citys, 'camera_id'=>$camera_id, 'access_id'=>$access_id, 'camera_info'=>$camera_info,'access_info'=>$access_info));
	}
	
	public function actionDeleteCustomer()
	{
		$customer_id=isset($_POST['customer_id']) ? intval($_POST['customer_id']) : 0;
		if($customer_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$customer_id),'b_customer');
		}
		echo 1;
	}
}
?>