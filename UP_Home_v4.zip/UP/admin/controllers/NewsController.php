<?php
class NewsController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		$cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;
		$status = isset($_GET['status']) ? $_GET['status']:'';
		$is_hot = isset($_GET["is_hot"]) ? $_GET["is_hot"] : "";
        $orderby = isset($_GET["orderby"]) ? $_GET["orderby"] : "";
        $order = isset($_GET["order"]) ? $_GET["order"] : 1;
        $seo = isset($_GET["seo"]) ? $_GET["seo"] : "";
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		
		$url_rewrite=Common::genUrlRewrite();
		$cats = $this->cats;
		list($total_all, $total_active, $total_pending, $total_draft, $total_hot) = News::countTabNews();
		
		list($news,$paging,$total,$hits, $topics, $comments)=News::getNews($cat_id,$keyword,$keyword_in,$status, $is_hot,$orderby, $order, $seo, $from_date, $to_date,$page,$num_per_page,$url_rewrite);
		$this->render("index",
				array('news'=>$news,'paging'=>$paging,'total'=>$total,'hits'=>$hits, 'topics'=>$topics, 'comments'=>$comments,
					  'total_all'=>$total_all,'total_active'=>$total_active, 'total_pending'=>$total_pending, 'total_draft'=>$total_draft, 'total_hot'=>$total_hot,
					  'cat_id'=>$cat_id, 'cats'=>$cats,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,
					  'seo'=>$seo,'status'=>$status, 'is_hot'=>$is_hot, 'orderby'=>$orderby, 'order'=>$order,
					  'page'=>$page,'num_per_page'=>$num_per_page
		));
	}
	public function actionAdd()
	{
		$news_id=isset($_GET['news_id']) ? intval($_GET['news_id']):0;
		$detail=News::getNewsById($news_id);		
		$cats = $this->cats;
        $this->render("add",
				array('detail'=>$detail,'news_id'=>$news_id,'cats'=>$cats
		));
	}
	public function actionEdit()
	{
		$news_id=isset($_GET['news_id']) ? intval($_GET['news_id']):0;
		$detail = News::getNewsById($news_id);
		$cats = $this->cats;
		
		$related=News::getNewsRelated($news_id);
		$list_news_id='';
		if($related)
		foreach($related as $row)
		{
			if($row['related_id']!=0) $list_news_id.=$row['related_id'].',';
		}
		$list_news_id=rtrim($list_news_id,',');
		$news_related=array();
		if($list_news_id!='')
		{
			$news_related=News::getNewsByListId($list_news_id);
		}
		//$topic
		$topic = Topic::getTopicByNewsId($news_id);
        $this->render("edit",
				array('detail'=>$detail,'cats'=>$cats,'news_id'=>$news_id,
					  'list_news_id'=>$list_news_id,'news_related'=>$news_related,'related'=>$related,'topic'=>$topic
		));
	}
	public function actionSeo()
	{
		$news_id=isset($_GET['news_id']) ? intval($_GET['news_id']):0;
		$detail=News::getNewsById($news_id);
		$this->render("seo",
				array('detail'=>$detail,'news_id'=>$news_id
		));
	}
	public function actionShowNews()
	{
		$page = isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page = 10;
		$keyword = '';
		$cat_id = 0;
		$cats = $this->cats;
		$boolean = isset($_GET['boolean']) ? intval($_GET['boolean']):0;
		list($news,$total)=News::getNewsPopup($keyword,$cat_id,$page,$num_per_page);
		$num_page=ceil($total/$num_per_page);
		$this->renderPartial("show_news",
				array('news'=>$news,'cats'=>$cats,'num_page'=>$num_page,
					  'num_per_page'=>$num_per_page,'page'=>$page,'total'=>$total,
					  'boolean'=>$boolean
		));
	}
	
	public function actionDeleteNews()
	{
		/*Xoa noi dung cau hoi va tra loi*/
		$news_id=isset($_POST['news_id']) ? intval($_POST['news_id']):0;
		$ok=CommonModel::deleteObject(array('id'=>$news_id),'b_news');
		/*Xoa comment binh luan*/
		//$ok=CommentNews::deleteCommentByNews($news_id);
		echo 1;
	}
}
?>