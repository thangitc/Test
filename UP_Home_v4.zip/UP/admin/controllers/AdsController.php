<?php
class AdsController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		$cat_id = isset($_GET['cat_id']) ?  intval($_GET['cat_id']):0;
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$url_rewrite=Common::genUrlRewrite();
		
		list($ads ,$paging,$total, $cat_ads )=Ads::getAds($cat_id,$keyword,$keyword_in ,$from_date,$to_date,$page,$num_per_page,$url_rewrite);
		
		//Danh muc
		$cats=$this->cats;
		
		$this->render('index',
				array('ads'=>$ads,'paging'=>$paging,'total'=>$total,'cat_ads'=>$cat_ads,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'cat_id'=>$cat_id,'cats'=>$cats,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,
					  'from_date'=>$from_date,'to_date'=>$to_date
		));	
	}
	public function actionAdd()
	{		
		$cats = Cat::getCats();
		$models = BModel::getAllModel();
		$this->render('add',array('cats'=>$cats, 'models'=>$models));
	}
	public function actionEdit()
	{
		$ads_id=isset($_GET['ads_id']) ? intval($_GET['ads_id']) :0;		
		//Danh muc
		$cats = Cat::getCats();
		$models = BModel::getAllModel();
		$detail = Ads::getAdsById($ads_id);
		$this->render('edit',array('detail'=>$detail,'cats'=>$cats, 'models'=>$models));
	}
	
	public function actionDeleteAds()
	{
		$ads_id=isset($_POST['ads_id']) ? intval($_POST['ads_id']) : 0;
		if($ads_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$ads_id),'b_ads');
		}
		echo 1;
	}
}
?>