<?php
class AdminController extends Controller
{
	public function actionIndex()
	{
		$pathway='<li><span>Quản trị User</span></li><li class="active"><a href="'.Url::createUrl('admin/index').'"><span>Danh sách Users</span></a></li>';
	   	$url_rewrite = Url::createUrl('articles/index').'/';
       	//Xác định tham số
		$page = isset ( $_GET ['page'] ) ? intval ( $_GET ['page'] ) : 1;
		$num_per_page=20;
		$keyword = isset ( $_POST ['keyword'] ) ?  $_POST ['keyword'] : '';
		$in_keyword = isset ( $_POST ['in_keyword'] ) ?  $_POST ['in_keyword'] : '';
		$status = isset ( $_POST ['status'] ) ?  $_POST ['status'] : -1;
		$type_admin = isset ( $_POST ['type_admin'] ) ?  $_POST ['type_admin'] : 0;
		$from_date = isset ( $_POST ['from_date'] ) ?  $_POST ['from_date']:0;
		$to_date = isset ( $_POST ['to_date'] ) ?  $_POST ['to_date']:0;
		
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		list($rows,$total,$paging)=AdminUser::getDataAdmin($keyword,$in_keyword,$status,$type_admin,$from_date,$to_date,$page,$num_per_page);
		$array_input=array('page'=>$page,'num_per_page'=>$num_per_page,'keyword'=>$keyword,'in_keyword'=>$in_keyword,'status'=>$status,'type_admin'=>$type_admin,'from_date'=>$from_date,'to_date'=>$to_date);
        $this->render("index",array('array_input'=>$array_input,'rows'=>$rows,'total'=>$total,'paging'=>$paging,'pathway'=>$pathway));
	}
	public function actionAdd()
	{
		$pathway='<li><span>Quản trị User</span></li><li class="active"><a href="'.Url::createUrl('admin/add').'"><span>Thêm mới User</span></a></li>';
        $this->render("add",array('pathway'=>$pathway));
	}
	public function actionEdit()
	{
		$id = isset ( $_GET ['id'] ) ? intval ( $_GET ['id'] ) : 1;
		$infor=AdminUser::getDataById($id);
		$pathway='<li><span>Quản trị User</span></li><li class="active"><a href="'.Url::createUrl('admin/edit').'"><span>Edit User</span></a></li>';
        $this->render("edit",array('infor'=>$infor,'pathway'=>$pathway));
	}
	public function actionChange()
	{
		$id = isset ( $_GET ['id'] ) ? intval ( $_GET ['id'] ) : 1;
        if($id!=1){
		$infor=AdminUser::getDataById($id);
		$pathway='<li><span>Quản trị User</span></li><li class="active"><a href="'.Url::createUrl('admin/edit').'"><span>Change Password</span></a></li>';
        
        $this->render("change",array('infor'=>$infor,'pathway'=>$pathway));
        }
	}
    public function actionLogin()
	{
		$url = new Url();
        if(Yii::app()->user->isGuest){
            $model = new AdminLogin();            
            if(isset($_POST["AdminLogin"])){
                $model->username = $_POST["AdminLogin"]["username"];
                $model->password = $_POST["AdminLogin"]["password"];
                $model->remember = $_POST["AdminLogin"]["remember"];                
                if($model->validate()){
                    $identity=new UserIdentity($model->username,$model->password);                    
                    //var_dump($identity);die;
                    if($identity->authenticate()){                        
                        if($model->remember==1){
                            Yii::app()->user->login($identity,3600*24*7);
                        }else{
                            Yii::app()->user->login($identity);
                        }
                        AdminUser::updateLastLogin(Yii::app()->user->id,time());
                        $this->redirect($url->createUrl("home/index"));
                    }
                    else{                                                
                        echo $identity->errorMessage;  
                    }
                }
            }
			$this->renderPartial("login",array("model"=>$model));
        }else{
            $this->redirect($url->createUrl("home/index"));
        }
		
    }
    public function actionLogout() {
        $url = new Url();
        Yii::app()->user->logout();                           
        $this->redirect($url->createUrl("admin/login"));
    }
	
	public function actionCreate(){
        $user = Yii::app()->user->name;
        $username = isset($_POST["username"]) ? trim($_POST["username"]):"";
        $password = isset($_POST["password"]) ? $_POST["password"]:"";
        $email = isset($_POST["email"]) ? $_POST["email"]:"";
        $full_name = isset($_POST["full_name"]) ? trim($_POST["full_name"]):"";
        $active = isset($_POST["active"]) ? intval($_POST["active"]):0;
		$type_admin = isset($_POST["type_admin"]) ? intval($_POST["type_admin"]):1;
		$info_admin = isset($_POST["info_admin"]) ? $_POST["info_admin"]:'';
        $data_count = AdminUser::getCountDataByUsername($username);
        if($data_count["count"] >0){
            echo -1;exit(); // da ton tai tai khoan nay;
        }
        $data = array(
        "username"=>$username,
        "email"=>$email,
        "password"=>AdminLogin::hashPassword($password),
        "full_name"=>$full_name,
		"type_admin"=>$type_admin,
		"info"=>$info_admin,
        "active"=>$active
        ) ;
        if($username !=""){
            $last_id = AdminUser::insertData($data,$user);
            echo $last_id;
			/*Lưu log*/
			if(isset(Yii::app()->user->id))
				$user_id=Yii::app()->user->id;
			else
				$user_id=0;
			if(isset(Yii::app()->user->name))	
				$user_name=Yii::app()->user->name;
			else
				$user_name='';
			$object_log['input']=$data;
			$module_log=9;
			$name_action='Thêm';
			$object_log['output']='Thêm User thành công!';
			header('Content-Type: text/html; charset=utf-8');
			$object_log=json_encode($object_log);
			$object_log=trim(mysql_escape_string($object_log));
			$content_log='<strong>'.$user_name.'</strong> thêm mới user admin, Mã ID user admin: <strong>'.$last_id.'</strong>';
			$content_log=trim(mysql_escape_string($content_log));
			$ok=Logs::insertLogs($user_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
			//End lưu log
			exit();
        }
    }
	
	public function actionUpdateProfile(){
		$user_id = isset($_POST["user_id"]) ? intval($_POST["user_id"]):1;
        $email = isset($_POST["email"]) ? $_POST["email"]:"";
        $full_name = isset($_POST["full_name"]) ? trim($_POST["full_name"]):"";
		$type_admin = isset($_POST["type_admin"]) ? intval($_POST["type_admin"]):1;
		$info_admin = isset($_POST["info_admin"]) ? $_POST["info_admin"]:'';
        $ok=AdminUser::updateProfile($user_id,$full_name,$email,$info_admin,$type_admin);
		if($ok>=0)
		{
			echo 'Cập nhật thành công!';
			/*Lưu log*/
			if(isset(Yii::app()->user->id))
				$user_action_id=Yii::app()->user->id;
			else
				$user_action_id=0;
			if(isset(Yii::app()->user->name))	
				$user_name=Yii::app()->user->name;
			else
				$user_name='';
			$object_log['input']=array('user_id'=>$user_id,'email'=>$email,'full_name'=>$full_name,'type_admin'=>$type_admin,'info_admin'=>$info_admin);
			$module_log=9;
			$name_action='Sửa';
			$object_log['output']='Cập nhật Profile thành công! Mã User: '.$user_id.'';
			header('Content-Type: text/html; charset=utf-8');
			$object_log=json_encode($object_log);
			$object_log=trim(mysql_escape_string($object_log));
			$content_log='<strong>'.$user_name.'</strong> cập nhật profile, Mã ID user admin: <strong>'.$user_id.'</strong>';
			$content_log=trim(mysql_escape_string($content_log));
			$ok=Logs::insertLogs($user_action_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
			//End lưu log
		}
		else echo 'Cập nhật lỗi!';
		
    }
	public function actionChangePass()
	{
		$user_id = isset($_POST["user_id"]) ? intval($_POST["user_id"]):1;
        $oldpass = isset($_POST["oldpass"]) ? $_POST["oldpass"]:"";
        $newpass = isset($_POST["newpass"]) ? trim($_POST["newpass"]):"";
		$re_newpass = isset($_POST["re_newpass"]) ? $_POST["re_newpass"]:'';
		$oldpass_hash=AdminLogin::hashPassword($oldpass);
		$infor=AdminUser::getDataById($user_id);
		if($infor['password']!=$oldpass_hash)
		{
			echo 'Mật khẩu cũ không đúng';
		}
		else
		{
			if($newpass!=$re_newpass)
			{
				echo 'Mật khẩu mới không match!';
			}
			else
			{
				$newpass_hash=	AdminLogin::hashPassword($newpass);
				$ok=AdminUser::updatePass($user_id,$newpass_hash);
				if($ok>=0)
				{
					echo 'Cập nhật thành công!';
					/*Lưu log*/
					if(isset(Yii::app()->user->id))
						$user_action_id=Yii::app()->user->id;
					else
						$user_action_id=0;
					if(isset(Yii::app()->user->name))	
						$user_name=Yii::app()->user->name;
					else
						$user_name='';
					$object_log['input']=array('user_id'=>$user_id,'oldpass'=>$oldpass,'newpass'=>$newpass);
					$module_log=3;
					$name_action='Sửa';
					$object_log['output']='Sửa password thành công!';
					header('Content-Type: text/html; charset=utf-8');
					$object_log=json_encode($object_log);
					$object_log=trim(mysql_escape_string($object_log));
					$content_log='<strong>'.$user_name.'</strong> sửa password, Mã ID user admin: <strong>'.$user_id.'</strong>';
					$content_log=trim(mysql_escape_string($content_log));
					$ok=Logs::insertLogs($user_action_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
					//End lưu log
				}
				else echo 'Cập nhật lỗi!';		
			}
		}
        exit();
	}
	
	public function actionPermit()
	{
		$user_id = isset($_GET["id"]) ? intval($_GET["id"]):'';
		$infor=AdminUser::getDataById($user_id);
		$array_module=Common::array_module();
		$array_permit=Common::array_permit();
		$authassignment=AdminAuthassignment::getAllPermit();
		//If $_POST thi update
		$sql_insert='';
		$sql_delete='';
		foreach($array_module as $key=>$module)
		{
			foreach($array_permit as $key1=>$permit)
			{
				$key_assign=$user_id.'_'.$key1.'_'.$key;
				if(isset($_POST[$key_assign]))
				{
					$sql_insert.='('.$user_id.','.$key1.','.$key.',"'.mysql_escape_string($infor['username']).'","'.mysql_escape_string($permit).'","'.mysql_escape_string($module).'",'.time().'),';
				}
				if(isset($authassignment[$key_assign]))
					$sql_delete.=$authassignment[$key_assign]['id'].',';
			}//End foreach
		}//End foreach
		
		
		if($sql_insert!='')
		{
			if($sql_delete!='')
			{
				$sql_delete=rtrim($sql_delete,',');
				$ok_delete=AdminAuthassignment::deleteAssignPermit($sql_delete);
			}
			$sql_insert=rtrim($sql_insert,',');
			$ok_insert=AdminAuthassignment::insertAssignPermit($sql_insert);
		}
		/*Lưu log*/
		if(isset(Yii::app()->user->id))
			$user_action_id=Yii::app()->user->id;
		else
			$user_action_id=0;
		if(isset(Yii::app()->user->name))	
			$user_name=Yii::app()->user->name;
		else
			$user_name='';
		$object_log['input']=array('user_id'=>$user_id);
		$module_log=9;
		$name_action='Sửa';
		$object_log['output']='Phân quyền thành công!';
		header('Content-Type: text/html; charset=utf-8');
		$object_log=json_encode($object_log);
		$object_log=trim(mysql_escape_string($object_log));
		$content_log='<strong>'.$user_name.'</strong> phân quyền cho user, User được phân quyền: <strong>'.$infor['username'].'</strong>';
		$content_log=trim(mysql_escape_string($content_log));
		$ok=Logs::insertLogs($user_action_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
		//End lưu log
        $this->render("permit",array('array_module'=>$array_module,'array_permit'=>$array_permit,'user_infor'=>$infor,'authassignment'=>$authassignment));
    }
	public function actionDeleteUser()
	{
		$uid=$_POST['uid'];
		if(isset($uid) && $uid!=1)
		{
			$ok1=AdminUser::deleteAdmin($uid);
			$ok2=AdminUser::deleteAdminPermit($uid);
			if($ok1>=0 && $ok2>=0)
			{
				//echo "Xóa thành công!";
				echo 1;
				/*Lưu log*/
				if(isset(Yii::app()->user->id))
					$user_action_id=Yii::app()->user->id;
				else
					$user_action_id=0;
				if(isset(Yii::app()->user->name))	
					$user_name=Yii::app()->user->name;
				else
					$user_name='';
				$object_log['input']=array('user_id'=>$uid);
				$module_log=9;
				$name_action='Xóa';
				$object_log['output']='Xóa user admin thành công!';
				header('Content-Type: text/html; charset=utf-8');
				$object_log=json_encode($object_log);
				$object_log=trim(mysql_escape_string($object_log));
				$content_log='<strong>'.$user_name.'</strong> vừa xóa một user admin, Mã ID user bị xóa: <strong>'.$uid.'</strong>';
				$content_log=trim(mysql_escape_string($content_log));
				$ok=Logs::insertLogs($user_action_id,$user_name,$name_action,$object_log,$content_log,time(),$module_log);
				//End lưu log
			}
			else
			{
				//echo "Xóa lỗi!";
				echo 0;
			}
		}
	}
}
?>
