<?php
class QaController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		$cat_id = isset($_GET['cat_id']) ?  intval($_GET['cat_id']):0;
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$url_rewrite=Common::genUrlRewrite();
		
		list($qa ,$paging,$total, $cat_qa )=Qa::getQa($cat_id,$keyword,$keyword_in ,$from_date,$to_date,$page,$num_per_page,$url_rewrite);
		
		//Danh muc
		$cats=$this->cats;
		
		$this->render('index',
				array('qa'=>$qa,'paging'=>$paging,'total'=>$total,'cat_qa'=>$cat_qa,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'cat_id'=>$cat_id,'cats'=>$cats,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in,
					  'from_date'=>$from_date,'to_date'=>$to_date
		));	
	}
	public function actionAdd()
	{
		$citys =  City::getCity();
		$company = Company::getAllCompany();
		//Danh muc
		$cats = Cat::getCats();
		$this->render('add',array('cats'=>$cats, 'citys'=>$citys, 'company'=>$company));
	}
	public function actionEdit()
	{
		$qa_id=isset($_GET['qa_id']) ? intval($_GET['qa_id']) :0;
		//Danh muc
		$citys =  City::getCity();
		//Danh muc
		$cats = Cat::getCats();
		$detail = Qa::getQaById($qa_id);
		$this->render('edit',array('detail'=>$detail,'cats'=>$cats, 'citys'=>$citys));
	}
}
?>