<?php
class BillController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 0;
		
		$url_rewrite=Common::genUrlRewrite();
		
		list($total_all, $total_active, $total_pending) = Bill::countTabBill();
		
		list($bill,$paging,$total)=Bill::getBill($keyword,$keyword_in, $tab, $from_date, $to_date,$page,$num_per_page,$url_rewrite);
		$this->render("index",
				array('bill'=>$bill,'paging'=>$paging,'total'=>$total, 
					  'total_all'=>$total_all,'total_active'=>$total_active, 'total_pending'=>$total_pending, 
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'from_date'=>$from_date, 'to_date'=>$to_date,
					  'page'=>$page,'num_per_page'=>$num_per_page
		));
	}
	public function actionAdd()
	{
		$bill_id=isset($_GET['bill_id']) ? intval($_GET['bill_id']):0;
		$detail=Bill::getBillById($bill_id);
        $this->render("add",
				array('detail'=>$detail,'bill_id'=>$bill_id
		));
	}
	public function actionEdit()
	{
		$bill_id=isset($_GET['bill_id']) ? intval($_GET['bill_id']):0;
		$detail = Bill::getBillById($bill_id);
		
        $this->render("edit",
				array('detail'=>$detail, 'bill_id'=>$bill_id
		));
	}
	
	public function actionDeleteBill()
	{
		$bill_id=isset($_POST['bill_id']) ? intval($_POST['bill_id']) : 0;
		if($bill_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$bill_id),'tbl_bill');
		}
		echo 1;
	}
}
?>