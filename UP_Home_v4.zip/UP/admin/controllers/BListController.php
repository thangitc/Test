<?php
class BListController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword']:'';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in']:1;
		$cat_id=isset($_GET['cat_id']) ? intval($_GET['cat_id']):0;
		
		$is_sale = isset($_GET['is_sale']) ? $_GET['is_sale'] : '-1';
		$status_new = isset($_GET['status_new']) ? $_GET['status_new'] : '-1';
		$is_show = isset($_GET['is_show']) ? $_GET['is_show'] : '-1';
		$status = isset($_GET['status']) ? $_GET['status'] : '';
		$seri = isset($_GET['seri']) ? $_GET['seri'] : '';
		$branch = isset($_GET['branch']) ? $_GET['branch'] : '';
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 0;
		
		//Hoa don
		$bill_id = isset($_GET['bill_id']) ? intval($_GET['bill_id']):0;
		
		$url_rewrite=Common::genUrlRewrite();
		$cats = $this->cats;
		list($total_all, $total_active, $total_pending, $total_draft, $total_approved, $total_not_approved, $total_ton, $total_buy, $total_hot, $total_deal, $total_soc) = BList::countTabList();
		
		list($list,$paging,$total, $access_free, $total_price_in_japan, $total_fee_vn)=BList::getList($cat_id, $seri, $status_new, $is_show, $status,$keyword,$keyword_in, $is_sale,$tab, $branch, $from_date, $to_date,$page,$num_per_page,$url_rewrite);
		$this->render("index",
				array('list'=>$list,'paging'=>$paging,'total'=>$total, 'access_free'=>$access_free,
					  'total_price_in_japan'=>$total_price_in_japan, 'total_fee_vn'=>$total_fee_vn, 
					  'total_all'=>$total_all,'total_active'=>$total_active, 'total_pending'=>$total_pending, 'total_draft'=>$total_draft,'total_approved'=>$total_approved, 'total_not_approved'=>$total_not_approved,'total_ton'=>$total_ton, 'total_buy'=>$total_buy, 'total_hot'=>$total_hot, 'total_deal'=>$total_deal, 'total_soc'=>$total_soc,
					  'cat_id'=>$cat_id, 'cats'=>$cats, 'seri'=>$seri, 'status_new'=>$status_new, 'status'=>$status, 'is_show'=>$is_show,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'is_sale'=>$is_sale,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'tab'=>$tab,
					  'bill_id'=>$bill_id,
					  'branch'=>$branch
		));
	}
	public function actionAdd()
	{
		$camera_id=isset($_GET['camera_id']) ? intval($_GET['camera_id']):0;
		$detail=BList::getListById($camera_id);		
		$models = BModel::getAllModel();
		$brand = BBrand::getAllBrand();
        $this->render("add",
				array('detail'=>$detail,'camera_id'=>$camera_id,'models'=>$models, 'brand'=>$brand
		));
	}
	public function actionEdit()
	{
		$camera_id=isset($_GET['camera_id']) ? intval($_GET['camera_id']):0;
		$detail = BList::getListById($camera_id);
		$models = BModel::getAllModel();
		$model_info = BModel::getModelById($detail['model_id']);
		//Picture
		$camera_pic = BListPic::getPicById($camera_id);
		//Phu kien free
		$access_free = Access::getAccessFreeByCameraId($camera_id);
		$brand = BBrand::getAllBrand();		
		
        $this->render("edit",
				array('detail'=>$detail, 'camera_id'=>$camera_id,
					  'camera_pic'=>$camera_pic, 'models'=>$models, 'model_info'=>$model_info,
					  'access_free'=>$access_free, 'brand'=>$brand
		));
	}
	
	public function actionNew()
	{
		$camera_id=isset($_GET['camera_id']) ? intval($_GET['camera_id']):0;
		$detail=BList::getListById($camera_id);
		$models = BModel::getAllModel();
		$body = BBody::getAllBody();
		$kit = BKit::getAllKit();
		$color = BColor::getAllColor();
		$brand = BBrand::getAllBrand();		
        $this->render("new",
				array('detail'=>$detail,'camera_id'=>$camera_id,
					  'models'=>$models, 'body'=>$body, 'kit'=>$kit, 'color'=>$color, 'brand'=>$brand
		));
	}
	public function actionEditNew()
	{
		$camera_id=isset($_GET['camera_id']) ? intval($_GET['camera_id']):0;
		$detail = BList::getListById($camera_id);
		$cats = $this->cats;
		
		$models = BModel::getAllModel();
		$body = BBody::getBodyByModel($detail['model_id']);
		$kit = BKit::getKitByModel($detail['model_id']);
		$color = BColor::getColorByModel($detail['model_id']);
		$brand = BBrand::getAllBrand();
		$model_info = BModel::getModelById($detail['model_id']);
		//Picture
		$camera_pic = BListPic::getPicById($camera_id);
		
		//access
		$access = Access::getAccessByCameraId($camera_id);
		$access_free = Access::getAccessFreeByCameraId($camera_id);
        $this->render("edit_new",
				array('detail'=>$detail, 'camera_id'=>$camera_id,
					  'camera_pic'=>$camera_pic,
					  'models'=>$models, 'body'=>$body, 'kit'=>$kit, 'color'=>$color, 'brand'=>$brand,
					  'access'=>$access, 'access_free'=>$access_free, 'model_info'=>$model_info
		));
	}
	
	public function actionAddReall()
	{
		$camera_id=isset($_GET['camera_id']) ? intval($_GET['camera_id']):0;
		$detail=BList::getListById($camera_id);
		
        $this->render("add_real",
				array('detail'=>$detail,'camera_id'=>$camera_id
		));
	}
	
	public function actionSale()
	{
		$camera_id=isset($_GET['camera_id']) ? intval($_GET['camera_id']):0;
		$order_id=isset($_GET['order_id']) ? intval($_GET['order_id']):0;
		$detail=BList::getListById($camera_id);
		$citys = BCity::getCity();
		$customer = Customer::getAllCustomer();
		$list_customer = Customer::getListCustomer($camera_id);
		//Order
		$order_info = Cart::getOrderById($order_id);
		//Hoa don
		$bill_id = isset($_GET['bill_id']) ? intval($_GET['bill_id']):0;
		$bills = Bill::getAllBill();
        $this->render("sale",
				array('detail'=>$detail,'camera_id'=>$camera_id,
					  'citys'=>$citys, 'customer'=>$customer,
					  'list_customer'=>$list_customer, 'order_info'=>$order_info,
					  'bill_id'=>$bill_id, 'bills'=>$bills
		));
	}
	
	public function actionSeo()
	{
		$camera_id=isset($_GET['camera_id']) ? intval($_GET['camera_id']):0;
		$detail=BList::getListById($camera_id);
		$this->render("seo",
				array('detail'=>$detail,'camera_id'=>$camera_id
		));
	}
	public function actionShowNews()
	{
		$page = isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page = 10;
		$keyword = '';
		$cat_id = 0;
		$cats = $this->cats;
		list($news,$total)=BList::getNewsPopup($keyword,$cat_id,$page,$num_per_page);
		$num_page=ceil($total/$num_per_page);
		$this->renderPartial("show_news",
				array('news'=>$news,'cats'=>$cats,'num_page'=>$num_page,
					  'num_per_page'=>$num_per_page,'page'=>$page,'total'=>$total
		));
	}
	
	public function actionDeleteList()
	{
		$camera_id = isset($_POST['camera_id']) ? intval($_POST['camera_id']) : 0;
		CommonModel::deleteObject(array('id'=>$camera_id),'b_camera');
		CommonModel::deleteObject(array('camera_id'=>$camera_id),'b_camera_content');
		echo 1;
	}
	
	public function actionEditSale()
	{
		$sale_id=isset($_GET['sale_id']) ? intval($_GET['sale_id']):0;
		$detail = CameraSale::getCameraSaleById($sale_id);
		$camera_info = BList::getListById($detail['camera_id']);
        $this->render("edit_sale",
				array('detail'=>$detail, 'camera_id'=>$detail['camera_id'],
					  'camera_info'=>$camera_info
		));
	}
}
?>