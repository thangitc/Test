<?php
class CartController extends Controller
{
	//Tien sinh hoat trong thang
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		
		$from_date = isset($_GET['from_date']) ?  $_GET['from_date']:0;
		$to_date = isset($_GET['to_date']) ?  $_GET['to_date']:0;
		if($from_date!=0)
		{
			$from_date=explode('/',$from_date);
			$from_date=mktime(0,0,0,$from_date[1],$from_date[0],$from_date[2]);
		}
		if($to_date!=0)
		{
			$to_date=explode('/',$to_date);
			$to_date=mktime(23,59,59,$to_date[1],$to_date[0],$to_date[2]);
		}
		$tab = isset($_GET['tab']) ? intval($_GET['tab']) : 0;
		$order_status = isset($_GET['order_status']) ? $_GET['order_status'] : '';
		$url_rewrite=Common::genUrlRewrite();
		
		list($total_0, $total_1, $total_2, $total_3, $total_4) = Cart::getTotalOrder();
		
		list($orders ,$paging, $total, $list_products, $list_model)=Cart::getOrder($order_status, $keyword,$keyword_in, $from_date, $to_date,$tab,$page,$num_per_page,$url_rewrite);
		
		$this->render('index',
				array('orders'=>$orders,'paging'=>$paging,'total'=>$total, 'list_products'=>$list_products, 'list_model'=>$list_model,
					  'total_0'=>$total_0,'total_1'=>$total_1, 'total_2'=>$total_2, 'total_3'=>$total_3,'total_4'=>$total_4,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'from_date'=>$from_date, 'to_date'=>$to_date,
					  'tab'=>$tab,
					  'order_status'=>$order_status
		));	
	}
	
}
?>