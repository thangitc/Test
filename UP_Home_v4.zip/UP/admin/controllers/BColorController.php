<?php
class BColorController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) ? intval($_GET['page']):1;
		$num_per_page=20;
		$keyword=isset($_GET['keyword']) ? $_GET['keyword'] : '';
		$keyword_in=isset($_GET['keyword_in']) ? $_GET['keyword_in'] : '';
		$model_id=isset($_GET['model_id']) ? intval($_GET['model_id']):0;
		
		$url_rewrite=Common::genUrlRewrite();
		
		list($color ,$paging,$total,$models)=BColor::getColor($model_id, $keyword,$keyword_in ,$page,$num_per_page,$url_rewrite);
		
		//Models
		$list_models = BModel::getAllModel();
		
		$this->render('index',
				array('color'=>$color,'paging'=>$paging,'total'=>$total,
					  'page'=>$page,'num_per_page'=>$num_per_page,
					  'keyword'=>$keyword,'keyword_in'=>$keyword_in, 'model_id'=>$model_id,
					  'models'=>$models, 'list_models'=>$list_models
		));	
	}
	public function actionAdd()
	{		
		$models = BModel::getAllModel();
		$this->render('add', array('models'=>$models));
	}
	public function actionEdit()
	{
		$color_id=isset($_GET['color_id']) ? intval($_GET['color_id']) :0;
		$detail = BColor::getColorById($color_id);
		$models = BModel::getAllModel();
		$this->render('edit',array('detail'=>$detail, 'models'=>$models));
	}
	
	public function actionDeleteColor()
	{
		$color_id=isset($_POST['color_id']) ? intval($_POST['color_id']) : 0;
		if($color_id!=0)
		{
			CommonModel::deleteObject(array('id'=>$color_id),'b_combo_color');
		}
		echo 1;
	}
}
?>