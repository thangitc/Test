<?php
class CartController extends Controller
{
	public function actionIndex()
	{
		if(isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] == 'POST')
		{
			if(isset($_SESSION['product_order']))
			foreach($_SESSION['product_order'] as $key=>$value)
			{
				if(isset($_POST['product_id'.$value['id'].'_0']))
				{
					$_SESSION['product_order'][$key]['qty']=$_POST['qty'.$value['id'].'_0'];
				}
				if(isset($_POST['product_id'.$value['id'].'_1']))
				{
					$_SESSION['product_order'][$key]['qty']=$_POST['qty'.$value['id'].'_1'];
				}
				if(isset($_POST['product_id'.$value['id'].'_2']))
				{
					$_SESSION['product_order'][$key]['qty']=$_POST['qty'.$value['id'].'_2'];
				}
			}	
		}
		//End
		//Hien thi gio hang
		if(isset($_SESSION['product_order']) && sizeof($_SESSION['product_order'])>0)
			list($camera, $access, $colors, $list_model) = Cart::getProductOrder();
		else
		{
			$camera = array();
			$access = array();
			$colors = array();
            $list_model = array();
		}

		$this->pageTitle = 'Giỏ hàng trên VJCamera';
		$this->metaKeywords = 'gio hang, vjcamera';
		$this->metaDescription = 'Giỏ hàng trên VJCamera';
		$this->render('index', 
				array('camera'=>$camera, 'access'=>$access, 'colors'=>$colors, 'list_model'=>$list_model
		));
	}
	public function actionCheckout()
	{
		//Cap nhat gio hang	
		if(isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] == 'POST')
		{
			if(isset($_SESSION['product_order']))
			foreach($_SESSION['product_order'] as $key=>$value)
			{
				if(isset($_POST['product_id'.$value['id'].'_0']))
				{
					$_SESSION['product_order'][$key]['qty']=$_POST['qty'.$value['id'].'_0'];
				}
				if(isset($_POST['product_id'.$value['id'].'_1']))
				{
					$_SESSION['product_order'][$key]['qty']=$_POST['qty'.$value['id'].'_1'];
				}
				if(isset($_POST['product_id'.$value['id'].'_2']))
				{
					$_SESSION['product_order'][$key]['qty']=$_POST['qty'.$value['id'].'_2'];
				}
			}	
		}
		//End
		//Hien thi gio hang
		if(isset($_SESSION['product_order']) && sizeof($_SESSION['product_order'])>0)
			list($camera, $access, $colors, $list_model) = Cart::getProductOrder();
		else
		{
			$camera = array();
			$access = array();
			$colors = array();
            $list_model = array();
		}
					
		$info_confirm = array();
		if(isset($_SESSION['cart_information']))
		{
			$info_confirm = $_SESSION['cart_information'];
		}
		
		$this->pageTitle = 'Đặt hàng trên VJCamera';
		$this->metaKeywords = 'dat hang, vjcamera';
		$this->metaDescription = 'Đặt hàng trên VJCamera';
		
		$this->render('checkout', 
				array('camera'=>$camera, 'access'=>$access, 'colors'=>$colors, 'list_model'=>$list_model,
					  'info_confirm'=>$info_confirm
		));
	}
	
	public function actionComplete()
	{
		$this->pageTitle = 'Đặt hàng thành công trên VJCamera';
		$this->metaKeywords = 'dat hang, vjcamera';
		$this->metaDescription = 'Đặt hàng thành công trên VJCamera';
		$this->render('complete');
	}
}
?>