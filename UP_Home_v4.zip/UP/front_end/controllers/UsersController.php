<?php
class UsersController extends Controller
{
	public function actionLogin()
	{
		$this->pageTitle = 'Đăng nhập - VJCamera.com';
		$this->metaKeywords = 'dang nhap';
		$this->metaDescription = 'Đăng nhập - VJCamera.com';
		$this->linkCanoncical = Url::createUrl('users/index');
		$this->renderPartial('login');
		exit();
	}
	
	public function actionRegister()
	{
		$this->pageTitle = 'Đăng ký tài khoản - VJCamera.com';
		$this->metaKeywords = 'dang ky';
		$this->metaDescription = 'Đăng ký tài khoản - VJCamera.com';
		$this->linkCanoncical = Url::createUrl('users/register');
		$this->renderPartial('register');
		exit();
	}
	
	public function actionDashboard()
	{
		$this->pageTitle = 'Dashboard - VJCamera';
		$this->metaKeywords = 'dashboard';
		$this->metaDescription = 'Dashboard - VJCamera.com';
		$this->linkCanoncical = Url::createUrl('users/dasboard');
		$this->render('dashboard');
		exit();
	}
	
	public function actionEdit()
	{
		$this->pageTitle = 'Thay đổi thông tin - VJCamera';
		$this->metaKeywords = 'edit';
		$this->metaDescription = 'edit - VJCamera.com';
		$this->linkCanoncical = Url::createUrl('users/edit');
		$this->render('edit');
		exit();
	}
	
	public function actionGifCard()
	{
		$this->pageTitle = 'Điểm - Thẻ khuyến mại';
		$this->metaKeywords = 'điểm, thẻ khuyến mại';
		$this->metaDescription = 'điểm, thẻ khuyến mại - VJCamera.com';
		$this->linkCanoncical = Url::createUrl('users/gifcard');
		$this->render('gifcard');
		exit();
	}
	public function actionProduct()
	{
		$this->pageTitle = 'Sản phẩm đã mua';
		$this->metaKeywords = 'Sản phẩm đã mua';
		$this->metaDescription = 'sản phẩm đã mua - VJCamera.com';
		$this->linkCanoncical = Url::createUrl('users/product');
		$this->render('product');
		exit();
	}
}
?>