<?php
class NewsController extends Controller
{
	public function actionIndex()
	{
		$page=isset($_GET['page']) && $_GET['page']!=1 ? intval($_GET['page']):1;
		$num_per_page=10;
		list($news, $paging, $total) = News::getNews($page, $num_per_page);
		
		$hots = News::getHotNews(3);
		$views = News::getViewsNews(3);
		$this->render('index', 
				array('news'=>$news, 'paging'=>$paging, 'total'=>$total,
					  'hots'=>$hots, 'views'=>$views,
					  'page'=>$page, 'num_per_page'=>$num_per_page
		));
	}
	public function actionCat()
	{
		$page=isset($_GET['page']) && $_GET['page']!=1 ? intval($_GET['page']):1;
		$num_per_page=10;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
		
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
		$alias = isset($_GET['alias']) ? $_GET['alias'] : '';
		$cats = $this->array_category;
		$cat_info = isset($cats[$cat_id]) ? $cats[$cat_id] : array();
		
		if(!empty($cat_info))
		{
			//Seo
			$metaTitle = isset($cat_info['meta_title']) && $cat_info['meta_title']!='' ? $cat_info['meta_title'] : $cat_info['title'];
			$metaTitleKD = Common::change($metaTitle);
			$metaDes = isset($cat_info['meta_description']) && $cat_info['meta_description']!='' ? $cat_info['meta_description'] : $cat_info['title'];
			$metaKeyword = isset($cat_info['meta_keyword']) && $cat_info['meta_keyword']!='' ? $cat_info['meta_keyword'] : $metaTitleKD;
			$this->pageTitle = $metaTitle.$tag_page;
			$this->metaKeywords = $metaKeyword;
			$this->metaDescription = $metaDes.$tag_page;
			$this->linkCanoncical = Url::createUrl('news/cat', array('cat_id'=>$cat_info['id'], 'alias'=>$cat_info['alias']));
			$this->linkRss = '<link rel="alternate" title="RSS - '.$cat_info['title'].'"  href="'.Url::createUrl('news/rss', array('cat_id'=>$cat_info['id'], 'alias'=>$cat_info['alias'])).'" type="application/rss+xml" />';
			
			$sub_cat_id = $cat_info['sub_id'];			
			$hots = News::getHotNewsByCat($cat_id, $sub_cat_id,3);			
			$views = News::getViewsNewsByCat($cat_id, $sub_cat_id,3);
			
			list($news, $paging, $total) = News::getNewsByCat($cat_id, $sub_cat_id, $alias, $page, $num_per_page);
			$render = 'cat';
			
			$this->render($render,
					array('news'=>$news, 'paging'=>$paging, 'total'=>$total, 
						  'hots'=>$hots, 'views'=>$views,
						  'page'=>$page, 'num_per_page'=>$num_per_page,
						  'cat_info'=>$cat_info, 'cats'=>$cats, 'cat_id'=>$cat_id
			));
		}
		else
		{
			$this->redirect(Url::createUrl('home/index'));
			exit();
		}
	}
	public function actionDetail()
	{
		$news_id = isset($_GET['news_id']) ? intval($_GET['news_id']) : 0;
		$detail = News::getNewsById($news_id);
		if(!empty($detail))
		{
			$cats = $this->array_category;
			$cat_info = isset($cats[$detail['cat_id']]) ? $cats[$detail['cat_id']] : array();
			$sub_cat_id = isset($cat_info['sub_id']) ? $cat_info['sub_id'] : '';
			$other_news = News::getNewsOtherCat($news_id, $detail['cat_id'], $sub_cat_id, 5);
			//Tin lien quan
			$related = News::getRelatedNews($news_id);
			//Cap nhat hit
			News::updateHit($news_id);
			$hots = News::getHotNewsByCat($detail['cat_id'], $sub_cat_id,3);
			$views = News::getViewsNewsByCat($detail['cat_id'], $sub_cat_id,3);
			//SEO
			$metaTitle = isset($detail['meta_title']) && $detail['meta_title']!='' ? $detail['meta_title'] : $detail['title'];
			$metaTitleKD = Common::change($metaTitle);
			$metaDes = isset($detail['meta_description']) && $detail['meta_description']!='' ? $detail['meta_description'] : $detail['title'].':'.$detail['introtext'];
			$metaKeyword = isset($detail['meta_keyword']) && $detail['meta_keyword']!='' ? $detail['meta_keyword'] : $metaTitleKD;
			$this->pageTitle = $metaTitle;
			$this->metaKeywords = $metaKeyword;
			$this->metaDescription = $metaDes;
			$this->linkCanoncical = Url::createUrl('news/detail', array('news_id'=>$detail['id'], 'alias'=>$detail['alias']));
			$this->srcImg = Common::getImage($detail['picture'], 'news', '');
			if(!empty($cat_info))
			{
				$this->linkRss = '<link rel="alternate" title="RSS - '.$cat_info['title'].'"  href="'.Url::createUrl('news/rss', array('cat_id'=>$cat_info['id'], 'alias'=>$cat_info['alias'])).'" type="application/rss+xml" />';
			}
			$render = 'detail';		
			$this->render($render,
					array('detail'=>$detail, 'cat_info'=>$cat_info, 'other_news'=>$other_news, 'related'=>$related, 'cats'=>$cats, 'hots'=>$hots, 'views'=>$views
						
			));
		}
		else
		{
			$this->redirect(Url::createUrl('home/index'));
			exit();
		}
	}
	
	
	public function actionSearch()
	{
		$page=isset($_GET['page']) && $_GET['page']!=0 ? intval($_GET['page']):1;
		$num_per_page=20;
		$tag_page = $page!=1 ? ' - Trang '.$page : '';
		
		$keyword_top = isset($_GET['keyword_top']) ? $_GET['keyword_top'] : '';	
		
		list($news, $paging, $total) = News::getNewsBySearch($keyword_top, $page, $num_per_page);
		
		$hots = News::getHotNews(3);
		$views = News::getViewsNews(3);
			
		$h1 = $keyword_top;
		$metaTitle = 'Kết quả tìm kiếm: '.$keyword_top.$tag_page;
		$metaDes = $metaTitle;
		$metaKeyword = $keyword_top;
		
		$this->pageTitle = $metaTitle;
		$this->metaKeywords = $metaKeyword;
		$this->metaDescription = $metaDes;
		$this->linkCanoncical = Url::createUrl('news/search',array('keyword_top'=>Common::generate_slug($keyword_top)));
		$this->linkRss = '<link rel="alternate" title="RSS - '.$h1.'"  href="'.$this->linkCanoncical.'.rss" type="application/rss+xml" />';
				
		$this->render('search', 
				array('news'=>$news, 'paging'=>$paging, 'total'=>$total,'page'=>$page, 'num_per_page'=>$num_per_page,
					  'keyword_top'=>$keyword_top,
					  'hots'=>$hots, 'views'=>$views
		));
	}
	
	public function actionRss()
    {
		$cat_id = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
		$cat_info = Cats::getCatInfo($cat_id);
		if(!empty($cat_info))
		{
			$sub_cat_id = $cat_info['sub_id'];
			header("Content-Type: application/xml; charset=UTF-8");
			echo '<?xml version="1.0" encoding="UTF-8" ?>
			<rss version="2.0">
			<channel>
			<title>'.$cat_info['title'].'</title>
			<description>'.$cat_info['meta_description'].'</description>
			<link>'.Yii::app()->params['baseUrl'].'/'.$cat_info['alias'].'-cn'.$cat_id.'.html</link>
			';
			$news = News::getNewsByCatRss($cat_id, $sub_cat_id, 15);
			if($news)
			{
				foreach($news as $row) 
				{
					$link = Yii::app()->params['baseUrl'].'/'.$row['alias'].'-'.'a'.$row['id'].'.html';
					echo '<item>';
					echo '<title>'.htmlspecialchars($row['title']).'</title>';
					echo '<link>'.$link.'</link>';
					echo '<description>'.htmlspecialchars(strip_tags($row['introtext'])).'</description>';
					echo '<pubDate>'.date('r', $row['publish_date']).'</pubDate>';
					echo '<guid>'.$link.'</guid>';
					echo '</item>';
				}
			}
			echo '</channel></rss>';
			exit();
		}
		else
		{
			$this->redirect('home/index');
		}
    }
	
	public function actionUpdateCat()
	{
		Cats::updateSubQa();
	}		
}
?>