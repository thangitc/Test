<?php
class Combos extends CActiveRecord
{
	public function getComboByProductId($product_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM tbl_combos WHERE id IN (SELECT combo_id FROM tbl_combos_products WHERE product_id=".$product_id." AND product_type=0)";
		$command = $connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
    public function getComboByModelId($product_id)
    {
        $connect=Yii::app()->db;
        $sql = "SELECT * FROM tbl_combos WHERE id IN (SELECT combo_id FROM tbl_combos_products WHERE product_id=".$product_id." AND product_type=2)";
        $command = $connect->createCommand($sql);
        $row = $command->queryRow();
        return $row;
    }

    public function getProductsByCombo($combo_id)
    {
        $connect=Yii::app()->db;
        $sql = "SELECT * FROM tbl_combos_products WHERE combo_id=".$combo_id;
        $command = $connect->createCommand($sql);
        $rows = $command->queryAll();

        $list_camera = array();
        $list_access = array();
        $list_camera_id = '0';
        $list_access_id = '0';

        if($rows){
            foreach($rows as $row)
            {
                if($row['product_type']==0){
                    $list_camera_id.=','.$row['product_id'];
                }else if($row['product_type']==1){
                    $list_access_id.=','.$row['product_id'];
                }
            }
        }

        //Camera
        $sql = "SELECT * FROM b_camera WHERE id IN (".$list_camera_id.")";
        $command = $connect->createCommand($sql);
        $row_cameras = $command->queryAll();
        if($row_cameras){
            foreach($row_cameras as $row){
                $list_camera[$row['id']] = $row;
            }
        }
        //Access
        $sql = "SELECT * FROM b_accessories WHERE id IN (".$list_access_id.")";
        $command = $connect->createCommand($sql);
        $row_access = $command->queryAll();
        if($row_access){
            foreach($row_access as $row){
                $list_access[$row['id']] = $row;
            }
        }
        return array($rows, $list_camera, $list_access);
    }
    public function checkComboProduct($product_id, $product_type, $list_model){
        $connect = Yii::app()->db;
        $sql = "SELECT * FROM tbl_combos_products WHERE product_id=".$product_id." AND product_type=".$product_type;
        $command = $connect->createCommand($sql);
        $row = $command->queryRow();
        $is_combo = 0; //Khong thuoc combo
        if(!empty($row)){
            $is_combo = 1; //Thuoc Combo
            $sql = "SELECT * FROM tbl_combos_products WHERE combo_id=".$row['combo_id']." AND product_type=2";
            $command = $connect->createCommand($sql);
            $row2 = $command->queryRow();
            $model_id = isset($row2['product_id']) ? intval($row2['product_id']) : 0;
            if(!in_array($model_id, $list_model)){ //Kiem tra xem co san pham chinh trong gio hang khong
                $is_combo = 0; //Tra ve gia thuong
            }
        }
        return array($is_combo, $row);
    }
}
?>