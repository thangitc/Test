<?php
class Access extends CActiveRecord
{
	public function getRecentView($limit)
	{
		//Cache
		$cacheService = new CacheService("Access","getRecentView", $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT access_id, update_date FROM b_hit_camera ORDER BY update_date DESC LIMIT 12";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			$lists=array();
			$list_id='';
			if($rows)
			{
				foreach($rows as $row)
				{
					$list_id.=$row['access_id'].',';
					$lists[$row['access_id']]=$row;
				}
			}
			$list_id=rtrim($list_id,',');
			if($list_id!='')
			{
		
				$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, code, rating, is_new, status_p FROM b_accessories WHERE status='active' AND id IN (".$list_id.")";
				$command=$connect->createCommand($sql);
				$rows = $command->queryAll();
				foreach($rows as $row)
				{
					if(!empty($row))
					{
						$a=$lists[$row['id']];
						$lists[$row['id']]=$row;
					}
					else
					{
						unset($lists[$row['id']]);
					}
				}
			}
			Yii::app()->cache->set($key, $lists, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$lists = $cache;
		}
		return $lists;
	}
	
	public function getAccessByCat($cat_id, $sub_id, $alias, $orderby, $page, $num_per_page)
	{	
		//Cache
		$cacheService = new CacheService("Access","getAccessByCatFilter", $cat_id.$orderby.$page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = '1 AND status="active"';
			
			$cond .= $sub_id!='' ? ' AND t1.cat_id IN ('.$sub_id.')' : '';
			
			$cond_count = $cond;
			
			$order = 'ORDER BY ordering DESC, publish_date DESC';
			if($orderby=='date')
			{
				$order = 'ORDER BY publish_date DESC';
			}
			if($orderby=='title_asc')
			{
				$order = 'ORDER BY title ASC';
			}
			if($orderby=='title_desc')
			{
				$order = 'ORDER BY title DESC';
			}
			
			if($orderby=='price')
			{
				$order = 'ORDER BY price ASC';
			}
			if($orderby=='price_desc')
			{
				$order = 'ORDER BY price DESC';
			}
			
			//Tong so tin
			$sql = "SELECT count(*) as total FROM b_accessories t1 WHERE ".$cond."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			
			//Phân trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			
			$url_rewrite = Url::createUrl('access/cat',array('cat_id'=>$cat_id, 'alias'=>$alias));
			$url_rewrite1 = $url_rewrite;
			$url_rewrite = str_replace('.html', '', $url_rewrite).'/';
			$paging = Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite1);
			
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_deal, time_deal, status_buy, publish_date, rating FROM b_accessories t1 WHERE ".$cond." ".$order." LIMIT ".$begin.",".$num_per_page." ";
			
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			
			//Dem so san pham theo thuong hieu
			$list_total_brand = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, brand_id FROM b_accessories t1 WHERE ".$cond_count." GROUP BY brand_id";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_brand[$row['brand_id']] = $row['total'];
			}
			
			//Dem so san pham theo khoang gia
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>100000 AND price<=5000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_1 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>5000000 AND price<=10000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_2 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>10000000 AND price<=15000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_3 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>15000000 AND price<=20000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_4 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>20000000 AND price<=100000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_5 = $row['total'];
			
			$a = array($rows, $paging, $total, $list_total_brand, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	
	public function getAccessFilter($cat_id, $sub_id, $list_brand_id, $list_276_id, $list_273_1_id, $list_273_2_id, $min_price, $max_price, $keyword, $orderby, $page, $num_per_page, $url_rewrite)
	{	
		//Cache
		$cacheService = new CacheService("Access","getAccessFilter", $cat_id.$min_price.$max_price.$orderby.$page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = '1 AND status="active"';
			if($sub_id!='')
				$cond .= ' AND t1.cat_id IN ('.$sub_id.')';
			else
				$cond .= $cat_id!=0 ? ' AND t1.cat_id = '.$cat_id.'' : '';
			$cond_count = $cond;
			
			$cond .= $min_price!=0 ? ' AND t1.price > '.$min_price : '';
			$cond .= $max_price!=0 ? ' AND t1.price <= '.$max_price : '';
			$cond .= $list_brand_id!='' ? ' AND t1.brand_id IN ('.$list_brand_id.')' : '';
			$sub_276 = '';
			if($list_276_id!='')
			{
				$list_276_id = explode(',',$list_276_id);
				$arr_276 = LoadConfig::$arr_276;
				foreach($list_276_id as $key)
				{
					$value = isset($arr_276[$key]) ? $arr_276[$key]:'';
					$sub_276 .= $value!='' ? ' t1.title LIKE "%'.$value.'%" ||' : '';
				}
				$sub_276 = rtrim($sub_276, '||');
				if($sub_276!='') $cond .= ' AND ('.$sub_276.')';
			}
			$sub_273_1 = '';
			if($list_273_1_id!='')
			{
				$list_273_1_id = explode(',',$list_273_1_id);
				$arr_273_1 = LoadConfig::$arr_273_1;
				foreach($list_273_1_id as $key)
				{
					$value = isset($arr_273_1[$key]) ? $arr_273_1[$key]:'';
					$sub_273_1 .= $value!='' ? ' t1.title LIKE "%'.$value.'%" ||' : '';
				}
				$sub_273_1 = rtrim($sub_273_1, '||');
				if($sub_273_1!='') $cond .= ' AND ('.$sub_273_1.')';
			}
			
			$sub_273_2 = '';
			if($list_273_2_id!='')
			{
				$list_273_2_id = explode(',',$list_273_2_id);
				$arr_273_2 = LoadConfig::$arr_273_2;
				foreach($list_273_2_id as $key)
				{
					$value = isset($arr_273_2[$key]) ? $arr_273_2[$key]:'';
					$value = str_replace('/s (', ' ', $value);
					$value = str_replace(')', ' ', $value);
					$list_value = explode(' ', $value);
					if($list_value)
					foreach($list_value as $value2)
					{
						$sub_273_2 .= $value2!='' ? ' t1.title LIKE "%'.$value2.'%" ||' : '';
					}
				}
				$sub_273_2 = rtrim($sub_273_2, '||');
				if($sub_273_2!='') $cond .= ' AND ('.$sub_273_2.')';
			}
			
			$cond .= $keyword!='' ? ' AND t1.title LIKE "%'.$keyword.'%"' : '';
			
			$order = 'ORDER BY ordering DESC, publish_date DESC';
			if($orderby=='date')
			{
				$order = 'ORDER BY publish_date DESC';
			}
			if($orderby=='title_asc')
			{
				$order = 'ORDER BY title ASC';
			}
			if($orderby=='title_desc')
			{
				$order = 'ORDER BY title DESC';
			}
			
			if($orderby=='price')
			{
				$order = 'ORDER BY price ASC';
			}
			if($orderby=='price_desc')
			{
				$order = 'ORDER BY price DESC';
			}
			
			//Tong so tin
			$sql = "SELECT count(*) as total FROM b_accessories t1 WHERE ".$cond."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			
			//Phân trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			
			$paging = Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_deal, time_deal, status_buy, publish_date, rating  FROM b_accessories t1 WHERE ".$cond." ".$order." LIMIT ".$begin.",".$num_per_page." ";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
		   
		   	//Dem so san pham theo thuong hieu
			$list_total_brand = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, brand_id FROM b_accessories t1 WHERE ".$cond_count." GROUP BY brand_id";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_brand[$row['brand_id']] = $row['total'];
			}
			
			//Dem so san pham theo khoang gia
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>100000 AND price<=5000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_1 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>5000000 AND price<=10000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_2 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>10000000 AND price<=15000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_3 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>15000000 AND price<=20000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_4 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>20000000 AND price<=100000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_5 = $row['total'];
			
			$a = array($rows, $paging, $total, $list_total_brand, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	
	public function getAccessById($access_id)
	{	
		$cacheService = new CacheService("Access","getAccessById", $access_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache = false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$sql = "SELECT * FROM b_accessories WHERE id=".$access_id." AND status='active'";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			Yii::app()->cache->set($key, $row, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row = $cache;
		}           
		return $row;
	}		
	
	public function getOtherByCat($access_id, $cat_id)
	{	
		//Cache
		$cacheService = new CacheService("Access","getOtherByCat", $cat_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = '1 AND status="active" AND cat_id='.$cat_id.' AND id!='.$access_id.'';
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_deal, time_deal status_buy, publish_date FROM b_accessories t1 WHERE ".$cond." LIMIT 8";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}
		
		return $rows;
	}
	
	public function getAccessByCameraID($camera_id)
	{	
		$cacheService = new CacheService("Access","getAccessByCameraID", $camera_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache = false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$sql = "SELECT * FROM b_accessories WHERE id IN (SELECT DISTINCT(access_id) FROM b_camera_accessories WHERE camera_id=".$camera_id.") AND status='active'";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}	
	
	public function getAccessByModelID($model_id)
	{	
		$cacheService = new CacheService("Access","getAccessByModelID", $model_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache = false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$sql = "SELECT * FROM b_accessories WHERE id IN (SELECT DISTINCT(access_id) FROM b_model_accessories WHERE model_id=".$model_id.") AND status='active' LIMIT 12";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	
	public function getAccessFreeByCameraID($camera_id)
	{	
		$cacheService = new CacheService("Access","getAccessFreeByCameraID", $camera_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache = false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$sql = "SELECT * FROM b_accessories WHERE id IN (SELECT DISTINCT(access_id) FROM b_camera_access_free WHERE camera_id=".$camera_id.") AND status='active'";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}	
	public function updateHit($access_id)
	{
		$connect = Yii::app()->db;
		$sql = "UPDATE b_accessories SET hit=hit+1 WHERE id=".$access_id."";
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function getAccessRss($limit)
	{
		//Cache
		$cacheService = new CacheService("Access","getAccessRss", $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, code, rating, is_new, status_p, publish_date FROM b_accessories WHERE status='active' ORDER BY publish_date DESC LIMIT ".$limit."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	
	public function getAccessBySearchTop($cat_id, $sub_id, $list_brand_id, $list_276_id, $list_273_1_id, $list_273_2_id, $min_price, $max_price, $keyword, $keyword_top, $orderby, $page, $num_per_page, $url_rewrite)
	{	
		//Cache
		$cacheService = new CacheService("Access","getAccessBySearchTop", $cat_id.$min_price.$max_price.$orderby.$page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = '1 AND status="active"';
			if($sub_id!='')
				$cond .= ' AND t1.cat_id IN ('.$sub_id.')';
			else
				$cond .= $cat_id!=0 ? ' AND t1.cat_id = '.$cat_id.'' : '';
			$cond .= $keyword_top!='' ? ' AND (t1.title LIKE "%'.$keyword_top.'%" || t1.keyword LIKE "%'.$keyword_top.'%")' : '';	
			$cond_count = $cond;
			
			$cond .= $min_price!=0 ? ' AND t1.price > '.$min_price : '';
			$cond .= $max_price!=0 ? ' AND t1.price <= '.$max_price : '';
			$cond .= $list_brand_id!='' ? ' AND t1.brand_id IN ('.$list_brand_id.')' : '';
			$sub_276 = '';
			if($list_276_id!='')
			{
				$list_276_id = explode(',',$list_276_id);
				$arr_276 = LoadConfig::$arr_276;
				foreach($list_276_id as $key)
				{
					$value = isset($arr_276[$key]) ? $arr_276[$key]:'';
					$sub_276 .= $value!='' ? ' t1.title LIKE "%'.$value.'%" ||' : '';
				}
				$sub_276 = rtrim($sub_276, '||');
				if($sub_276!='') $cond .= ' AND ('.$sub_276.')';
			}
			$sub_273_1 = '';
			if($list_273_1_id!='')
			{
				$list_273_1_id = explode(',',$list_273_1_id);
				$arr_273_1 = LoadConfig::$arr_273_1;
				foreach($list_273_1_id as $key)
				{
					$value = isset($arr_273_1[$key]) ? $arr_273_1[$key]:'';
					$sub_273_1 .= $value!='' ? ' t1.title LIKE "%'.$value.'%" ||' : '';
				}
				$sub_273_1 = rtrim($sub_273_1, '||');
				if($sub_273_1!='') $cond .= ' AND ('.$sub_273_1.')';
			}
			
			$sub_273_2 = '';
			if($list_273_2_id!='')
			{
				$list_273_2_id = explode(',',$list_273_2_id);
				$arr_273_2 = LoadConfig::$arr_273_2;
				foreach($list_273_2_id as $key)
				{
					$value = isset($arr_273_2[$key]) ? $arr_273_2[$key]:'';
					$value = str_replace('/s (', ' ', $value);
					$value = str_replace(')', ' ', $value);
					$list_value = explode(' ', $value);
					if($list_value)
					foreach($list_value as $value2)
					{
						$sub_273_2 .= $value2!='' ? ' t1.title LIKE "%'.$value2.'%" ||' : '';
					}
				}
				$sub_273_2 = rtrim($sub_273_2, '||');
				if($sub_273_2!='') $cond .= ' AND ('.$sub_273_2.')';
			}
			
			$cond .= $keyword!='' ? ' AND (t1.title LIKE "%'.$keyword.'%" || t1.keyword LIKE "%'.$keyword.'%")' : '';
			
			$order = 'ORDER BY ordering DESC, publish_date DESC';
			if($orderby=='date')
			{
				$order = 'ORDER BY publish_date DESC';
			}
			if($orderby=='title_asc')
			{
				$order = 'ORDER BY title ASC';
			}
			if($orderby=='title_desc')
			{
				$order = 'ORDER BY title DESC';
			}
			
			if($orderby=='price')
			{
				$order = 'ORDER BY price ASC';
			}
			if($orderby=='price_desc')
			{
				$order = 'ORDER BY price DESC';
			}
			
			//Tong so tin
			$sql = "SELECT count(*) as total FROM b_accessories t1 WHERE ".$cond."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			
			//Phân trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			
			$paging = Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_deal, time_deal, status_buy, publish_date, rating  FROM b_accessories t1 WHERE ".$cond." ".$order." LIMIT ".$begin.",".$num_per_page." ";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
		   
		   	//Dem so san pham theo thuong hieu
			$list_total_brand = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, brand_id FROM b_accessories t1 WHERE ".$cond_count." GROUP BY brand_id";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_brand[$row['brand_id']] = $row['total'];
			}
			
			//Dem so san pham theo khoang gia
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>100000 AND price<=5000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_1 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>5000000 AND price<=10000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_2 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>10000000 AND price<=15000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_3 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>15000000 AND price<=20000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_4 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_accessories t1 WHERE ".$cond_count." AND price>20000000 AND price<=100000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_5 = $row['total'];
			
			$a = array($rows, $paging, $total, $list_total_brand, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	
	
	public function getAccessByCatRss($cat_id, $sub_cat_id,$limit)
	{
		//Cache
		$cacheService = new CacheService("Access","getAccessByCatRss", $cat_id, $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, code, rating, is_new, status_p, publish_date FROM b_accessories WHERE status='active' AND cat_id IN (".$sub_cat_id.") ORDER BY publish_date DESC LIMIT ".$limit."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	//Gia soc
	
	public function getDealAccess($cat_id, $sub_id, $page, $num_per_page)
	{	
		//Cache
		$cacheService = new CacheService("Access","getDealAccess", $cat_id.$page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = '1 AND status="active" AND price_deal!=0 AND time_deal!=0';
			if($sub_id!='')
				$cond .= ' AND cat_id IN ('.$sub_id.')';
			else
				$cond .= $cat_id!=0 ? ' AND cat_id = '.$cat_id.'' : '';
			
			$order = 'ORDER BY ordering DESC, publish_date DESC';
			$sql = 'SELECT count(id) as total FROM b_accessories WHERE '.$cond;
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			
			$begin = 0;
			$num_p = $page*$num_per_page;
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_deal, time_deal, status_buy, publish_date, rating FROM b_accessories WHERE ".$cond." ".$order." LIMIT ".$begin.",".$num_p." ";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			
		   	$a = array($rows, $total);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	
	
}
?>