<?php
class BTimeline extends CActiveRecord
{
	public function getTimeline($page, $num_per_page)
	{
		//Cache
		$cacheService = new CacheService("BTimeline","getTimeline", $page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = 'SELECT count(id) as total FROM b_timeline WHERE status="active"';
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_timeline = $row['total'];
			
			$num_p = $page*$num_per_page;
			$sql = "SELECT * FROM b_timeline WHERE status='active' ORDER BY ordering DESC, publish_date DESC LIMIT 0,".$num_p."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			$a = array($rows, $total_timeline);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		return $a;
	}
}
?>