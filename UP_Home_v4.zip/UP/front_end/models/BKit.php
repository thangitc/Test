<?php
class BKit extends CActiveRecord
{
	public function getKitByModel($model_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_combo_kit WHERE model_id=".$model_id;
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function getKitById($kit_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_combo_kit WHERE id=".$kit_id;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}
?>