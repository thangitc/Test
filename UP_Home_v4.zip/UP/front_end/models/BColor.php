<?php
class BColor extends CActiveRecord
{
	public function getColorByModel($model_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_combo_color WHERE model_id=".$model_id;
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
	
	public function getColorById($color_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM b_combo_color WHERE id=".$color_id;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}
?>