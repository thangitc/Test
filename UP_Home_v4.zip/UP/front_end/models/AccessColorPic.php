<?php
class AccessColorPic extends CActiveRecord
{
	public function getPicAccessColor($color_id)
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_accessories_color_pic WHERE color_id=".$color_id;
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		return $rows;
	}
}
?>