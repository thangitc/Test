<?php
class Cart extends CActiveRecord
{	
	public function getProductOrder() 
	{
		$connect =Yii::app()->db;
		$list_product = $_SESSION['product_order'];
		$list_camera_id="";
		$list_access_id="";
		$list_color_id="";
		foreach($list_product as $row)
		{
			if($row['product_type']==0)
				$list_camera_id.=$row['id'].',';
			else if($row['product_type']==1)
				$list_access_id.=$row['id'].',';
			else
				$list_color_id.=$row['id'].',';
		}
		$list_camera_id=rtrim($list_camera_id,',');
		$list_access_id=rtrim($list_access_id,',');
		$list_color_id=rtrim($list_color_id,',');
		$camera = array();
		$access = array();
		$colors = array();
		if($list_camera_id!='')
		{
			$sql="SELECT * FROM b_camera WHERE id in (".$list_camera_id.")";
			$command = $connect->createCommand($sql);
			$camera = $command->queryAll();
		}
		if($list_color_id!='')
		{
			$sql = "SELECT t2.*, t1.title, t1.alias FROM b_accessories t1, b_accessories_color t2 WHERE t2.id IN (".$list_color_id.") AND t1.id=t2.access_id";
			$command = $connect->createCommand($sql);
			$colors = $command->queryAll();
		}
		if($list_access_id!='')
		{
			$sql = "SELECT * FROM b_accessories WHERE id IN (".$list_access_id.")";
			$command = $connect->createCommand($sql);
			$access = $command->queryAll();
		}
		$list_camera = array();
		$list_access = array();
		$list_color = array();
		$list_model = array();
		if($list_product)
		foreach($list_product as $value)
		{
			if($camera)
			foreach($camera as $row)
			{
				if($value['id']==$row['id'] && $value['product_type']==0)
				{
					$list_camera[] = array_merge($row,array('qty'=>$value['qty'], 'product_type'=>$value['product_type']));
                    $list_model[] = $row['model_id'];
					break;
				}	
			}
			if($access)
			foreach($access as $row)
			{
				if($value['id']==$row['id'] && $value['product_type']==1)
				{
					$list_access[] = array_merge($row,array('qty'=>$value['qty'], 'product_type'=>$value['product_type']));
					break;
				}	
			}
			if($colors)
			foreach($colors as $row)
			{
				if($value['id']==$row['id'] && $value['product_type']==2)
				{
					$list_color[] = array_merge($row,array('qty'=>$value['qty'], 'product_type'=>$value['product_type']));
					break;
				}	
			}
		}
		//usort($result, 'compare_id');
		$a = array($list_camera, $list_access, $list_color, $list_model);
		return $a;
	}
	public function getQuantityOrder(){
		return (isset($_SESSION['order']))?$_SESSION['order']:0;
		
	}
	public function getPriceOrder()
	{
		$product = $_SESSION['product_order'];
		$price=0;
		foreach($product as $value) {
			$price_format=str_replace(".","",$value['price']);
			$price += $value['qty']*$price_format;
		}
		$_SESSION['price_order'] = $price;
		return $price;
	}
	
	public function insertProductOrder($sql)
	{
		$connect =Yii::app()->db;
		$sql = "INSERT IGNORE INTO tbl_order_products(`order_id`, `product_id`, `product_type`, `quantity`, `price`, `price_deal`, `price_show`, `price_in`, `title`) VALUES ".$sql;
		$command = $connect->createCommand($sql);
		$a = $command->execute();
		return $a;
	}
}
?>