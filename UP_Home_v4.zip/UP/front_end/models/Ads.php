<?php
class Ads extends CActiveRecord
{
	public function getAllAds()
	{
		//Cache
		$cacheService = new CacheService("Ads","getAllAds");
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT `title`,introtext, `cat_id`, `picture`, `status`, `ordering`, `ads_link`, `ads_alignment` FROM b_ads WHERE status='active' ORDER BY ordering DESC";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	
	public function getAdsByPos($pos)
	{
		//Cache
		$cacheService = new CacheService("Ads","getAdsByPos", $pos);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT `title`,introtext, `cat_id`, `picture`, `status`, `ordering`, `ads_link`, `ads_alignment` FROM b_ads WHERE status='active' AND ads_alignment=".$pos." ORDER BY ordering DESC";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	
	public function getAdsCatByPos($cat_id,$pos)
	{
		//Cache
		$cacheService = new CacheService("Ads","getAdsCatByPos", $cat_id, $pos);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT `title`,introtext, `cat_id`, `picture`, `status`, `ordering`, `ads_link`, `ads_alignment` FROM b_ads WHERE status='active' AND ads_alignment=".$pos." AND cat_id=".$cat_id." ORDER BY RAND() LIMIT 1";
			$command=$connect->createCommand($sql);
			$row = $command->queryRow();
			Yii::app()->cache->set($key, $row, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row = $cache;
		}           
		return $row;
	}
	
	public function getAdsHome($pos, $limit)
	{
		//Cache
		$cacheService = new CacheService("Ads","getAdsCatByPos", $pos);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT `title`,introtext, `cat_id`, `picture`, `status`, `ordering`, `ads_link`, `ads_alignment` FROM b_ads WHERE status='active' AND ads_alignment=".$pos." AND cat_id=0";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	
	public function getAdsByDetail($cat_id)
	{
		//Cache
		$cacheService = new CacheService("Ads","cat_id", $cat_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT `title`,introtext, `cat_id`, `picture`, `status`, `ordering`, `ads_link`, `ads_alignment` FROM b_ads WHERE status='active' AND cat_id=".$cat_id." ORDER BY RAND() LIMIT 1";
			$command=$connect->createCommand($sql);
			$row = $command->queryRow();
			Yii::app()->cache->set($key, $row, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row = $cache;
		}           
		return $row;
	}
}
?>