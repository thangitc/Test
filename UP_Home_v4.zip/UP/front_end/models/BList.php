<?php
class BList extends CActiveRecord
{
	public function getListSales($limit)
	{
		//Cache
		$cacheService = new CacheService("BList","getListSales", $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$time_sale_expired = mktime(0,0,0, date('m'),date('d'), date('Y'))-86400;
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, rating FROM b_camera WHERE status='active' AND is_show=1 AND price_sale!=0 AND is_sale=0 AND time_sale>=".$time_sale_expired." ORDER BY ordering DESC, publish_date DESC LIMIT ".$limit."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}
		return $rows;
	}
	
	
	public function getRecentView($limit)
	{
		//Cache
		$cacheService = new CacheService("BList","getRecentView", $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT camera_id, update_date FROM b_hit_camera ORDER BY update_date DESC LIMIT 12";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			$lists=array();
			$list_id='';
			if($rows)
			{
				foreach($rows as $row)
				{
					$list_id.=$row['camera_id'].',';
					$lists[$row['camera_id']]=$row;
				}
			}
			$list_id=rtrim($list_id,',');
			if($list_id!='')
			{
		
				$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, code, rating, is_new, status_p FROM b_camera WHERE status='active' AND id IN (".$list_id.")";
				$command=$connect->createCommand($sql);
				$rows = $command->queryAll();
				foreach($rows as $row)
				{
					if(!empty($row))
					{
						$a=$lists[$row['id']];
						$lists[$row['id']]=$row;
					}
					else
					{
						unset($lists[$row['id']]);
					}
				}
			}
			Yii::app()->cache->set($key, $lists, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$lists = $cache;
		}
		return $lists;
	}
	
	public function getListByCat($cat_id, $sub_id, $alias, $page, $num_per_page)
	{	
		//Cache
		$cacheService = new CacheService("BList","getListByCat", $cat_id.$page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = '1 AND status="active" AND is_show=1 AND status_new IN (0,1)';
			if($sub_id!='')
				$cond .= ' AND t1.cat_id IN ('.$sub_id.')';
			else
				$cond .= $cat_id!=0 ? ' AND t1.cat_id = '.$cat_id.'' : '';
			
			$order = 'ORDER BY status_new DESC, ordering DESC, publish_date DESC';
			
			//Tong so tin
			$sql = "SELECT count(*) as total FROM b_camera t1 WHERE ".$cond."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			
			//Phân trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			
			$url_rewrite = Url::createUrl('bList/cat',array('cat_id'=>$cat_id, 'alias'=>$alias));
			
			$url_rewrite1 = $url_rewrite;
			$url_rewrite = str_replace('.html', '', $url_rewrite).'/';
			$paging = Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite1);
			
			$sql = "SELECT id, model_id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, seri, rating, publish_date, is_sale, status_new, time_bh, is_special FROM b_camera t1 WHERE ".$cond." ".$order." LIMIT ".$begin.",".$num_per_page." ";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
		   	
			$list_id = array();
			$list_model_id = array();
			$models = array();
			if($rows)
			foreach($rows as $row)
			{
				$list_model_id[] = $row['model_id'];
				$list_id[] = $row['id'];
			}
			if(!empty($list_model_id))
			{
				$list_model_id = implode(',', $list_model_id);
				$sql = "SELECT * FROM b_model WHERE id IN (".$list_model_id.")";
				$command = $connect->createCommand($sql);
				$array = $command->queryAll();
				if($array)
				foreach($array as $row)
				{
					$models[$row['id']] = $row;
				}
			}
			//Qua tang
			$access_free_price = array();
			if(!empty($list_id))
			{
				$list_id = implode(',', $list_id);
				$sql = "SELECT t1.camera_id, sum(t2.price) as price FROM b_camera_access_free t1, b_accessories t2 WHERE t1.camera_id IN (".$list_id.") AND t1.access_id=t2.id AND status='active' GROUP BY t1.camera_id";
				$command = $connect->createCommand($sql);
				$array = $command->queryAll();
				if($array)
				foreach($array as $row)
				{
					$access_free_price[$row['camera_id']] = $row['price'];
				}
			}
			//Dem so san pham theo Model
			$list_total_model = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, model_id FROM b_camera t1 WHERE ".$cond." GROUP BY model_id";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_model[$row['model_id']] = $row['total'];
			}
			//Dem so san pham theo thuong hieu
			$list_total_brand = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, brand_id FROM b_camera t1 WHERE ".$cond." GROUP BY brand_id";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_brand[$row['brand_id']] = $row['total'];
			}
			
			//Dem so san pham moi cu
			$list_total_new_old = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, status_new FROM b_camera t1 WHERE ".$cond." GROUP BY status_new";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_new_old[$row['status_new']] = $row['total'];
			}
			//Dem so san pham theo khoang gia
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond." AND price>1000000 AND price<=5000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_1 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond." AND price>5000000 AND price<=10000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_2 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond." AND price>10000000 AND price<=15000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_3 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond." AND price>15000000 AND price<=20000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_4 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond." AND price>20000000 AND price<=100000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_5 = $row['total'];
			
			$a = array($rows, $paging, $total, $models, $list_total_model, $list_total_brand, $list_total_new_old, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5, $access_free_price);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	public function getListFilter($cat_id, $sub_id, $list_model_id, $list_brand_id, $list_hang_moi_id, $min_price, $max_price, $keyword, $orderby, $page, $num_per_page, $url_rewrite)
	{	
		//Cache
		$cacheService = new CacheService("BList","getListFilter", $cat_id.$min_price.$max_price.$orderby.$page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond_count = '';
			$cond = '1 AND status="active" AND is_show=1';
			if($sub_id!='')
				$cond .= ' AND t1.cat_id IN ('.$sub_id.')';
			else
				$cond .= $cat_id!=0 ? ' AND t1.cat_id = '.$cat_id.'' : '';
			$cond_count = $cond.' AND status_new IN (0,1)';
			
			$cond .= $min_price!=0 ? ' AND t1.price > '.$min_price : '';
			$cond .= $max_price!=0 ? ' AND t1.price <= '.$max_price : '';
			$cond .= $list_model_id!='' ? ' AND t1.model_id IN ('.$list_model_id.')' : '';
			$cond .= $list_brand_id!='' ? ' AND t1.brand_id IN ('.$list_brand_id.')' : '';
			$cond .= $list_hang_moi_id!='' ? ' AND t1.status_new IN ('.$list_hang_moi_id.')' : ' AND status_new IN (0,1)';
			$cond .= $keyword!='' ? ' AND t1.title LIKE "%'.$keyword.'%"' : '';
			
			//$order = 'ORDER BY ordering DESC, publish_date DESC';
            $order = 'ORDER BY status_new DESC, ordering DESC, publish_date DESC';
			if($orderby=='date')
			{
				$order = 'ORDER BY publish_date DESC';
			}
			if($orderby=='title_asc')
			{
				$order = 'ORDER BY title ASC';
			}
			if($orderby=='title_desc')
			{
				$order = 'ORDER BY title DESC';
			}
			
			if($orderby=='price')
			{
				$order = 'ORDER BY price ASC';
			}
			if($orderby=='price_desc')
			{
				$order = 'ORDER BY price DESC';
			}
			
			//Tong so tin
			$sql = "SELECT count(*) as total FROM b_camera t1 WHERE ".$cond."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			
			//Phân trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			
			$paging = Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			
			$sql = "SELECT id, model_id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, seri, rating, publish_date, is_sale, status_new, time_bh, is_special FROM b_camera t1 WHERE ".$cond." ".$order." LIMIT ".$begin.",".$num_per_page." ";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
		   	
			$list_id = array();
			$list_model_id = array();
			$models = array();
			if($rows)
			foreach($rows as $row)
			{
				$list_id[] = $row['id'];
				$list_model_id[] = $row['model_id'];
			}
			if(!empty($list_model_id))
			{
				$list_model_id = implode(',', $list_model_id);
				$sql = "SELECT * FROM b_model WHERE id IN (".$list_model_id.")";
				$command = $connect->createCommand($sql);
				$array = $command->queryAll();
				if($array)
				foreach($array as $row)
				{
					$models[$row['id']] = $row;
				}
			}
			
			//Qua tang
			$access_free_price = array();
			if(!empty($list_id))
			{
				$list_id = implode(',', $list_id);
				$sql = "SELECT t1.camera_id, sum(t2.price) as price FROM b_camera_access_free t1, b_accessories t2 WHERE t1.camera_id IN (".$list_id.") AND t1.access_id=t2.id AND status='active' GROUP BY t1.camera_id";
				$command = $connect->createCommand($sql);
				$array = $command->queryAll();
				if($array)
				foreach($array as $row)
				{
					$access_free_price[$row['camera_id']] = $row['price'];
				}
			}
			
			//Dem so san pham theo Model
			$list_total_model = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, model_id FROM b_camera t1 WHERE ".$cond_count." GROUP BY model_id";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_model[$row['model_id']] = $row['total'];
			}
			//Dem so san pham theo thuong hieu
			$list_total_brand = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, brand_id FROM b_camera t1 WHERE ".$cond_count." GROUP BY brand_id";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_brand[$row['brand_id']] = $row['total'];
			}
			
			//Dem so san pham moi cu
			$list_total_new_old = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, status_new FROM b_camera t1 WHERE ".$cond_count." GROUP BY status_new";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_new_old[$row['status_new']] = $row['total'];
			}
			//Dem so san pham theo khoang gia
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond_count." AND price>1000000 AND price<=5000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_1 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond_count." AND price>5000000 AND price<=10000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_2 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond_count." AND price>10000000 AND price<=15000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_3 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond_count." AND price>15000000 AND price<=20000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_4 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond_count." AND price>20000000 AND price<=100000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_5 = $row['total'];
			
			$a = array($rows, $paging, $total, $models, $list_total_model, $list_total_brand, $list_total_new_old, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5, $access_free_price);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	
	public function getListById($model_id, $body_id, $kit_id,$color_id, $chinh_hang)
	{	
		$cacheService = new CacheService("BList","getListById", $model_id, $body_id, $kit_id, $color_id, $chinh_hang);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache = false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = 'model_id='.$model_id.' AND status="active" AND status_new=1';
			//$cond = 'id='.$camera_id.' AND status="active"';
			if($chinh_hang!='') $cond .= ' AND chinh_hang='.$chinh_hang;
			if($chinh_hang==0) $cond .= ' AND chinh_hang=0';
			$cond .= $body_id!=0 ? ' AND body_id='.$body_id : '';
			$cond .= $kit_id!=0 ? ' AND kit_id='.$kit_id : '';
			$cond .= $color_id!=0 ? ' AND color_id='.$color_id : '';
			$sql = "SELECT * FROM b_camera WHERE ".$cond."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			Yii::app()->cache->set($key, $row, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row = $cache;
		}           
		return $row;
	}
	
	public function getListInfoById($camera_id)
	{	
		$cacheService = new CacheService("BList","getListInfoById");
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache = false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = 'id='.$camera_id.' AND status="active"';
			$sql = "SELECT * FROM b_camera WHERE ".$cond."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			Yii::app()->cache->set($key, $row, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row = $cache;
		}           
		return $row;
	}
	public function getContentById($camera_id)
	{
		$cacheService = new CacheService("BList","getContentById", $camera_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache = false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT camera_id, description FROM b_camera_content WHERE camera_id=".$camera_id."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			Yii::app()->cache->set($key, $row, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$row = $cache;
		}           
		return $row;
	}
	
	public function getOtherByCat($camera_id, $cat_id)
	{	
		//Cache
		$cacheService = new CacheService("BList","getOtherByCat", $cat_id);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond = '1 AND status="active" AND cat_id='.$cat_id.' AND id!='.$camera_id.'';
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, code, rating, is_new, status_p, publish_date FROM b_camera t1 WHERE ".$cond." LIMIT 8";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}
		
		return $rows;
	}
	
	public function updateHit($camera_id)
	{
		$connect = Yii::app()->db;
		$sql = "UPDATE b_camera SET hit=hit+1 WHERE id=".$camera_id."";
		$command = $connect->createCommand($sql);
		$result = $command->execute();
		return $result;
	}
	
	public function getListRss($limit)
	{
		//Cache
		$cacheService = new CacheService("BList","getListRss", $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, code, rating, is_new, status_p, publish_date FROM b_camera WHERE status='active' ORDER BY publish_date DESC LIMIT ".$limit."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	
	//Search Top
	public function getListBySearchTop($cat_id, $sub_id, $list_model_id, $list_brand_id, $list_hang_moi_id, $min_price, $max_price, $keyword, $keyword_top, $orderby, $page, $num_per_page, $url_rewrite)
	{	
		//Cache
		$cacheService = new CacheService("BList","getListBySearchTop", $cat_id.$min_price.$max_price.$orderby.$page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$cond_count = '';
			$cond = '1 AND status="active" AND is_show=1';
			if($sub_id!='')
				$cond .= ' AND t1.cat_id IN ('.$sub_id.')';
			else
				$cond .= $cat_id!=0 ? ' AND t1.cat_id = '.$cat_id.'' : '';
			$cond .= $keyword_top!='' ? ' AND (t1.title LIKE "%'.$keyword_top.'%" || t1.keyword LIKE "%'.$keyword_top.'%")' : '';
			
			$cond_count = $cond.' AND status_new IN (0,1)';
			
			$cond .= $min_price!=0 ? ' AND t1.price > '.$min_price : '';
			$cond .= $max_price!=0 ? ' AND t1.price <= '.$max_price : '';
			$cond .= $list_model_id!='' ? ' AND t1.model_id IN ('.$list_model_id.')' : '';
			$cond .= $list_brand_id!='' ? ' AND t1.brand_id IN ('.$list_brand_id.')' : '';
			$cond .= $list_hang_moi_id!='' ? ' AND t1.status_new IN ('.$list_hang_moi_id.')' : ' AND status_new IN (0,1)';
			$cond .= $keyword!='' ? ' AND (t1.title LIKE "%'.$keyword.'%" || t1.keyword LIKE "%'.$keyword.'%" )' : '';
			
			//$order = 'ORDER BY ordering DESC, publish_date DESC';
            $order = 'ORDER BY status_new DESC, ordering DESC, publish_date DESC';
			if($orderby=='date')
			{
				$order = 'ORDER BY publish_date DESC';
			}
			if($orderby=='title_asc')
			{
				$order = 'ORDER BY title ASC';
			}
			if($orderby=='title_desc')
			{
				$order = 'ORDER BY title DESC';
			}
			
			if($orderby=='price')
			{
				$order = 'ORDER BY price ASC';
			}
			if($orderby=='price_desc')
			{
				$order = 'ORDER BY price DESC';
			}
			
			//Tong so tin
			$sql = "SELECT count(*) as total FROM b_camera t1 WHERE ".$cond."";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			
			//Phân trang
			$num_page = ceil($total / $num_per_page);
			$begin = ($page - 1) * $num_per_page;
			$iSEGSIZE = 9;
			
			$paging = Paging::show_paging($num_page,$page,$iSEGSIZE,$url_rewrite,$url_rewrite);
			
			$sql = "SELECT id, model_id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, seri, rating, publish_date, is_sale, status_new, time_bh, is_special FROM b_camera t1 WHERE ".$cond." ".$order." LIMIT ".$begin.",".$num_per_page." ";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
		   	
			$list_id = array();
			$list_model_id = array();
			$models = array();
			if($rows)
			foreach($rows as $row)
			{
				$list_id[] = $row['id'];
				$list_model_id[] = $row['model_id'];
			}
			if(!empty($list_model_id))
			{
				$list_model_id = implode(',', $list_model_id);
				$sql = "SELECT * FROM b_model WHERE id IN (".$list_model_id.")";
				$command = $connect->createCommand($sql);
				$array = $command->queryAll();
				if($array)
				foreach($array as $row)
				{
					$models[$row['id']] = $row;
				}
			}
			
			//Qua tang
			$access_free_price = array();
			if(!empty($list_id))
			{
				$list_id = implode(',', $list_id);
				$sql = "SELECT t1.camera_id, sum(t2.price) as price FROM b_camera_access_free t1, b_accessories t2 WHERE t1.camera_id IN (".$list_id.") AND t1.access_id=t2.id AND status='active' GROUP BY t1.camera_id";
				$command = $connect->createCommand($sql);
				$array = $command->queryAll();
				if($array)
				foreach($array as $row)
				{
					$access_free_price[$row['camera_id']] = $row['price'];
				}
			}
			
			//Dem so san pham theo Model
			$list_total_model = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, model_id FROM b_camera t1 WHERE ".$cond_count." GROUP BY model_id";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_model[$row['model_id']] = $row['total'];
			}
			//Dem so san pham theo thuong hieu
			$list_total_brand = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, brand_id FROM b_camera t1 WHERE ".$cond_count." GROUP BY brand_id";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_brand[$row['brand_id']] = $row['total'];
			}
			
			//Dem so san pham moi cu
			$list_total_new_old = array();
			$sql = "SELECT COUNT(DISTINCT(id)) as total, status_new FROM b_camera t1 WHERE ".$cond_count." GROUP BY status_new";
			$command = $connect->createCommand($sql);
			$array = $command->queryAll();
			if($array)
			foreach($array as $row)
			{
				$list_total_new_old[$row['status_new']] = $row['total'];
			}
			//Dem so san pham theo khoang gia
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond_count." AND price>1000000 AND price<=5000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_1 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond_count." AND price>5000000 AND price<=10000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_2 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond_count." AND price>10000000 AND price<=15000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_3 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond_count." AND price>15000000 AND price<=20000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_4 = $row['total'];
			
			$sql = "SELECT COUNT(DISTINCT(id)) as total FROM b_camera t1 WHERE ".$cond_count." AND price>20000000 AND price<=100000000";
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total_price_5 = $row['total'];
			
			$a = array($rows, $paging, $total, $models, $list_total_model, $list_total_brand, $list_total_new_old, $total_price_1, $total_price_2, $total_price_3, $total_price_4, $total_price_5, $access_free_price);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	
	public function getListByCatRss($cat_id, $sub_cat_id,$limit)
	{
		//Cache
		$cacheService = new CacheService("BList","getListByCatRss", $cat_id, $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect =Yii::app()->db;
			$sql = "SELECT id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, code, rating, is_new, status_p, publish_date FROM b_camera WHERE status='active' AND cat_id IN (".$sub_cat_id.") ORDER BY publish_date DESC LIMIT ".$limit."";
			$command=$connect->createCommand($sql);
			$rows = $command->queryAll();
			Yii::app()->cache->set($key, $rows, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$rows = $cache;
		}           
		return $rows;
	}
	
	public function getOneSoc()
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_camera WHERE status='active' AND is_soc=1 ORDER BY publish_date DESC LIMIT 1";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
	public function getAllProductByModel($model_id)
	{
		$connect =Yii::app()->db;
		$sql = "SELECT * FROM b_camera WHERE model_id=".$model_id." AND status='active' AND status_new=1";
		$command=$connect->createCommand($sql);
		$rows = $command->queryAll();
		$list_product = array();
		if($rows)
		foreach($rows as $row)
		{
			$list_product[$row['id']] = $row['model_id'].'_'.$row['chinh_hang'].'_'.$row['color_id'].'_'.$row['body_id'].'_'.$row['kit_id'];
		}
		return $list_product;
	}
	
	public function getDealList($cat_id, $sub_id, $page, $num_per_page)
	{	
		//Cache
		$cacheService = new CacheService("BList","getDealList", $cat_id.$page);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$time_sale_expired = mktime(0,0,0, date('m'),date('d'), date('Y'))-86400;
			$cond = '1 AND status="active" AND is_show=1 AND status_new IN (0,1) AND price_sale!=0 AND time_sale!=0 AND is_sale=0 AND time_sale>='.$time_sale_expired;
			if($sub_id!='')
				$cond .= ' AND cat_id IN ('.$sub_id.')';
			else
				$cond .= $cat_id!=0 ? ' AND cat_id = '.$cat_id.'' : '';
			
			//$order = 'ORDER BY ordering DESC, publish_date DESC';
            $order = 'ORDER BY status_new DESC, ordering DESC, publish_date DESC';
			$sql = 'SELECT count(id) as total FROM b_camera WHERE '.$cond;
			$command = $connect->createCommand($sql);
			$row = $command->queryRow();
			$total = $row['total'];
			
			$begin = 0;
			$num_p = $page*$num_per_page;
			$sql = "SELECT id, model_id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, seri, rating, publish_date, is_sale, status_new, time_bh, is_special FROM b_camera WHERE ".$cond." ".$order." LIMIT ".$begin.",".$num_p." ";
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			
			$list_id = array();
			$access_free = array();
			if($rows)
			foreach($rows as $row)
			{
				$list_id[] = $row['id'];
			}
			if(!empty($list_id))
			{
				$list_id = implode(',', $list_id);
				$sql = "SELECT t1.camera_id, t2.title, t2.alias, t2.id, t2.price FROM b_camera_access_free t1, b_accessories t2 WHERE t1.camera_id IN (".$list_id.") AND t1.access_id=t2.id AND status='active'";
				$command = $connect->createCommand($sql);
				$array = $command->queryAll();
				if($array)
				foreach($array as $row)
				{
					$access_free[$row['camera_id']][] = $row;
				}
			}
			
		   	$a = array($rows, $total, $access_free);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	
	public function getDealListFeature($limit)
	{	
		//Cache
		$cacheService = new CacheService("BList","getDealListFeature", $limit);
		$key = $cacheService->createKey();
		$cache = Yii::app()->cache->get($key);
		$cache=false;
		if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$time_sale_expired = mktime(0,0,0, date('m'),date('d'), date('Y'))-86400;
			$sql = "SELECT id, model_id, `cat_id`, `title`, `alias`, `introtext`, `picture`, price, price_sale, time_sale, num_shot, seri, rating, publish_date, is_sale, status_new, time_bh, is_special FROM b_camera WHERE status='active' AND is_show=1 AND status_new IN (0,1) AND price_sale!=0 AND time_sale!=0 AND is_feature=1 AND is_sale=0 AND time_sale>=".$time_sale_expired;
			$command = $connect->createCommand($sql);
			$rows = $command->queryAll();
			
			$list_id = array();
			$access_free = array();
			if($rows)
			foreach($rows as $row)
			{
				$list_id[] = $row['id'];
			}
			if(!empty($list_id))
			{
				$list_id = implode(',', $list_id);
				$sql = "SELECT t1.camera_id, t2.title, t2.alias, t2.id, t2.price FROM b_camera_access_free t1, b_accessories t2 WHERE t1.camera_id IN (".$list_id.") AND t1.access_id=t2.id AND status='active'";
				$command = $connect->createCommand($sql);
				$array = $command->queryAll();
				if($array)
				foreach($array as $row)
				{
					$access_free[$row['camera_id']][] = $row;
				}
			}
			
		   	$a = array($rows, $access_free);
			Yii::app()->cache->set($key, $a, ConstantsUtil::TIME_CACHE_3600);
		}
		else
		{
			$a = $cache;
		}
		
		return $a;
	}
	
	public function getOneCheap($model_id)
	{
		$connect = Yii::app()->db;
		$sql = "SELECT * FROM b_camera WHERE model_id=".$model_id." AND status_new=0 AND price!=0 AND status='active' ORDER BY price ASC LIMIT 1";
		$command = $connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}
?>