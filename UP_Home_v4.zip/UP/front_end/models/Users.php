<?php
class Users extends CActiveRecord
{
	public function getUserById($user_id)
	{
		$cacheService = new CacheService("Users","getUsersById",$user_id);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$sql="SELECT * FROM b_user WHERE id=".$user_id."";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			Yii::app()->cache->set($key,$row,ConstantsUtil::TIME_CACHE_900);
		}
		else
		{
			$row=$cache;
		}
		return $row;
	}
	
	public function getAccountById($user_id)
	{
		$connect = Yii::app()->db;
		$sql="SELECT * FROM b_user_account WHERE user_id=".$user_id."";
		$command=$connect->createCommand($sql);
		$row= $command->queryRow();
		return $row;
	}
	
	public function getUserByEmail($email)
	{
		$cacheService = new CacheService("Users","getUserByEmail",$email);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$sql="SELECT * FROM b_user WHERE email='".$email."'";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			Yii::app()->cache->set($key,$row,ConstantsUtil::TIME_CACHE_900);
		}
		else
		{
			$row=$cache;
		}
		return $row;
	}
	
	
	public function getUserLogin($email,$password)
	{
		$cacheService = new CacheService("Users","getUsersLogin",$email,$password);
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
		$cache=false;
        if ($cache == false) 
		{
			$connect = Yii::app()->db;
			$sql="SELECT * FROM b_user WHERE email='".$email."' AND password='".$password."'";
			$command=$connect->createCommand($sql);
			$row= $command->queryRow();
			Yii::app()->cache->set($key,$row,ConstantsUtil::TIME_CACHE_900);
		}
		else
		{
			$row=$cache;
		}
		return $row;
	}

    public function getAllUser()
    {
        $cacheService = new CacheService("Users","getAllUsers");
        $key = $cacheService->createKey();
        $cache = Yii::app()->cache->get($key);
        $cache=false;
        if ($cache == false) 
        {
            $connect = Yii::app()->db;
            $sql="SELECT * FROM b_user ";
            $command=$connect->createCommand($sql);
            $row= $command->queryAll();
            Yii::app()->cache->set($key,$row,ConstantsUtil::TIME_CACHE_900);
        }
        else
        {
            $row=$cache;
        }
        return $row;
    }
    
    function getUserBySocial($fbid)
	{
		$connect = Yii::app()->db;
		$sql = "SELECT * FROM b_user WHERE fbid='".$fbid."'";
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}
}
?>
