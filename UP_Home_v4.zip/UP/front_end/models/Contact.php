<?php
class Contact extends CActiveRecord
{
	public function getContactById($contact_id)
	{
		$connect=Yii::app()->db;
		$sql = "SELECT * FROM tbl_contact WHERE id=".$contact_id;
		$command=$connect->createCommand($sql);
		$row = $command->queryRow();
		return $row;
	}	
}
?>