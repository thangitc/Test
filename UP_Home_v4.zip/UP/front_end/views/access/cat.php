<?php
$this->renderPartial('application.views.cart.js') ;
?>
<script>
$(document).on("click", ".js-filter h6", function(t) {
    if ($(t.target).is("h6")) {
        $(this).parent(".js-filter").toggleClass("js-shown js-hidden");
    }
});
$(document).on("click", ".js-toggleShow", function(e) {
    var t = $(this);
    t.toggleClass("js-show js-hide");
    $(t.data("toggleshow")).toggleClass("js-open js-close");
	$('.price-range').toggle();
});
</script>
<div class="t-main js-t-main page-width full-width clearfix" data-selenium="t-main">
    <ul id="breadcrumbs" class="page-width twelve">
        <li class="first"><a href="<?php echo Yii::app()->params['baseUrl'];?>">Trang chủ</a></li>
        <?php
		$parent_info = isset($cats[$cat_info['parent_id']]) ? $cats[$cat_info['parent_id']] : array();
		if(!empty($parent_info))
		{
			?>
            <li> <a href="<?php echo Url::createUrl('access/index',array('alias'=>$parent_info['alias'],'cat_id'=>$parent_info['id']));?>"> <?php echo $parent_info['title'];?> </a> </li>
            <?php
		}
        ?>
        <li> <a href="<?php echo Url::createUrl('access/cat',array('alias'=>$cat_info['alias'],'cat_id'=>$cat_info['id']));?>"> <?php echo $cat_info['title'];?> </a> </li>
    </ul>
    <div class="side nav left js-sideNav" data-selenium="sideNav">
        <div class="bold twelve get-help" data-selenium="get-help">
            <p class="c5">Hotline</p>
            <p class="elevn"> <span class="call"> 0965.505.515</span> <a data-selenium="liveChat" href="https://www.facebook.com/vn.japan" class="chat c2" target="livechat"> Live Chat </a> </p>
        </div>
        <div class="js-filters-cont filters-cont elevn" data-selenium="filters-container">
        	<?php if($cats) {?>
            <div class="catgory js-clickOne bold" data-selenium="catgory">
                <h5 class="filter-head twelve" data-selenium="filter-head">Danh mục</h5>
                <ul>
                <?php
				if($cat_info['sub_id']!=$cat_info['id'])
				{
					if($cats)
					foreach($cats as $row)
					{
						if($row['parent_id']==$cat_info['id'])
						{
							$link_cat = Url::createUrl('access/cat',array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
							?>
							<li class="first clearfix" data-selenium="loadSubCat"> <a href="<?php echo $link_cat;?>" class="c5 fs12" data-selenium="loadSubCatLink"><?php echo $row['title'];?><span class="amt"> (<?php echo $row['num_p'];?>)</span></a> </li>
							<?php
						}
					}
				}
				else
				{
					if($cats)
					foreach($cats as $row)
					{
						if($row['parent_id']==$cat_info['parent_id'] && $cat_info['parent_id']!=0)
						{
							$link_cat = Url::createUrl('access/cat',array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
							?>
							<li class=" first clearfix " data-selenium="loadSubCat"> <a href="<?php echo $link_cat;?>" class="c5 fs12" data-selenium="loadSubCatLink"><?php echo $row['title'];?><span class="amt"> (<?php echo $row['num_p'];?>)</span></a> </li>
							<?php
						}
					}
				}
                ?>
                </ul>
            </div>
            <?php } ?>
            <div class="narrow js-narrow twelve" data-selenium="narrowResults">
                <h5 class="filter-head twelve bold" data-selenium="filter-head">Tìm kiếm</h5>
                <div class="js-shown js-filter filter js-clickMultiple js-brands " data-selenium="filter">
                    <h6 class="fs14 bold c11" data-selenium="allbrands">Thương hiệu</h6>
                    
                    <ul class="js-brandsList" data-selenium="brandsList">
                    <?php
					if($brands)
					foreach($brands as $row)
					{
						if($row['brand_type']==1)
						{
							$link_brand = Url::createUrl('access/search', array('cat_id'=>$cat_id)).'?s=3579'.$row['id'];
							$total_brand_one = isset($list_total_brand[$row['id']]) ? $list_total_brand[$row['id']]:0;
							if($total_brand_one!=0)
							{
								?>
								<li> <a href="<?php echo $link_brand;?>" class="checkbox"><?php echo $row['title'];?> <span class="amt"><?php if($total_brand_one!=0) echo '('.$total_brand_one.')';?> </span></a> </li>
								<?php
							}
						}
					}
                    ?>
                    </ul>
                </div>
                <?php if($cat_id==276 || $cat_info['parent_id']==276){ ?>
                <div class="js-shown js-filter filter js-clickMultiple js-brands " data-selenium="filter">
                    <h6 class="fs14 bold c11" data-selenium="allbrands">Kích thước</h6>
                    
                    <ul class="js-brandsList" data-selenium="brandsList">
                    <?php
					$arr_276 = LoadConfig::$arr_276;
					if($arr_276)
					foreach($arr_276 as $key=>$value)
					{
						$link_276 = Url::createUrl('access/search', array('cat_id'=>$cat_id)).'?s=1235'.$key;
						?>
						<li> <a href="<?php echo $link_276;?>" class="checkbox"><?php echo $value;?></a> </li>
						<?php
					}
                    ?>
                    </ul>
                </div>
                <?php } ?>
                <?php if($cat_id==273 || $cat_info['parent_id']==273){ ?>
                <div class="js-shown js-filter filter js-clickMultiple js-brands " data-selenium="filter">
                    <h6 class="fs14 bold c11" data-selenium="allbrands">Dung lượng thẻ nhớ</h6>
                    
                    <ul class="js-brandsList" data-selenium="brandsList">
                    <?php
					$arr_273_1 = LoadConfig::$arr_273_1;
					if($arr_273_1)
					foreach($arr_273_1 as $key=>$value)
					{
						$link_273_1 = Url::createUrl('access/search', array('cat_id'=>$cat_id)).'?s=3456'.$key;
						?>
						<li> <a href="<?php echo $link_273_1;?>" class="checkbox"><?php echo $value;?></a> </li>
						<?php
					}
                    ?>
                    </ul>
                </div>
                
                <div class="js-shown js-filter filter js-clickMultiple js-brands " data-selenium="filter">
                    <h6 class="fs14 bold c11" data-selenium="allbrands">Tốc độ thẻ</h6>
                    
                    <ul class="js-brandsList" data-selenium="brandsList">
                    <?php
					$arr_273_2 = LoadConfig::$arr_273_2;
					if($arr_273_2)
					foreach($arr_273_2 as $key=>$value)
					{
						$link_273_2 = Url::createUrl('access/search', array('cat_id'=>$cat_id)).'?s=6789'.$key;
						?>
						<li> <a href="<?php echo $link_273_2;?>" class="checkbox"><?php echo $value;?></a> </li>
						<?php
					}
                    ?>
                    </ul>
                </div>
                
                <?php } ?>
                <div class="js-shown js-filter js-clickOne filter" data-selenium="filter">
                    <h6 class="fs14 bold c11">Khoảng giá</h6>
                    <ul class="price-range" data-selenium="price-range">
                        <li><a href="<?php echo Url::createUrl('access/search', array('cat_id'=>$cat_id)).'?s=VND100000+5000000VND';?>">100.000 &ndash; 5.000.000</a> <!--<span class="amt"> (91)</span>--></li>
                        <li><a href="<?php echo Url::createUrl('access/search', array('cat_id'=>$cat_id)).'?s=VND5000000+10000000VND';?>">5.000.000 &ndash; 10.000.000</a> <!--<span class="amt"> (91)</span>--></li>
                        <li><a href="<?php echo Url::createUrl('access/search', array('cat_id'=>$cat_id)).'?s=VND10000000+15000000VND';?>">10.000.000 &ndash; 15.000.000</a> <!--<span class="amt"> (91)</span>--></li>
                        <li><a href="<?php echo Url::createUrl('access/search', array('cat_id'=>$cat_id)).'?s=VND15000000+20000000VND';?>">15.000.000 &ndash; 20.000.000</a> <!--<span class="amt"> (91)</span>--></li>
                        <li><a href="<?php echo Url::createUrl('access/search', array('cat_id'=>$cat_id)).'?s=VND20000000+100000000VND';?>">20.000.000 &ndash; 100.000.000</a> <!--<span class="amt"> (91)</span>--></li>
                    </ul>
                    <form action="<?php echo Url::createUrl('access/search', array('cat_id'=>$cat_id));?>" method="get" class="filter-form clearfix full-width price-form js-price-form">
                        
                        <span>Nhập khoảng giá:</span>
                        <label>VND
                            <input name="min_price" id="min_price" class=" elevn js-mnp" data-selenium="minPrice" type="text">
                            &nbsp;&nbsp;-&nbsp;&nbsp; </label>
                        <label>VND
                            <input name="max_price" id="max_price" class=" elevn js-mxp" data-selenium="maxPrice" type="text">
                        </label> 
                        <script>
						function searchByPrice()
						{
							var min_price = $('#min_price').val();
							var max_price = $('#max_price').val();
							if(min_price=='' || max_price=='')
							{
								alert('Vui lòng nhập khoảng giá cần tìm');
								return false;
							}
							var link_p = '<?php echo Url::createUrl('access/search', array('cat_id'=>$cat_id));?>';
							var cond = '';
							if(min_price!=0 || min_price!='')
								cond += '&min_price='+min_price;
							if(min_price!=0 || min_price!='')
								cond += '&max_price='+max_price+'&s=';
							link_p += '?'+cond;
							window.location.href = link_p;
						}
						</script>                       
                        <button type="button" class="go litGrayBtn" data-selenium="pricerangeBtn" onclick="searchByPrice();">Go</button>
                    </form>
                    <button class="show-range bold js-show toggleShow js-toggleShow" data-selenium="show-range">
                        <span data-selenium="displayShown" class="js-show">
                            Tất cả khoảng giá<span data-selenium="pricearrow" class="arrow">‹</span>
                        </span>
                        <span data-selenium="filterHide" class="js-hide">
                            Ẩn khoảng giá<span data-selenium="pricearrow" class="arrow">›</span>
                        </span>
                    </button>
                </div>
                <div class="no-filter js-clickOne" data-selenium="no-filter">
                    <h6 class="therteen bold c11">Tìm theo tên sản phẩm</h6>
                    <form action="<?php echo Url::createUrl('access/search', array('cat_id'=>$cat_id));?>" method="get" id="search-within-form" class="filter-form clearfix full-width js-filterForm">
                        <input name="keyword" id="keyword" placeholder="Tên sản phẩm" class="search elevn js-searchInput" data-selenium="searchWithin" type="text">
                        <script>
						function searchByKeyword()
						{
							var keyword = $('#keyword').val();
							if(keyword=='')
							{
								alert('Vui lòng nhập từ khóa cần tìm');
								return false;
							}
							var link_p = '<?php echo Url::createUrl('access/search', array('cat_id'=>$cat_id));?>';
							var cond = '';
							if(keyword!='')
							{
								cond = '&keyword='+keyword+'&s=';
							}
							link_p += '?'+cond;
							window.location.href = link_p;
						}
						</script>
                        <button type="button" class="search js-searchButton" data-selenium="searchBtn" onclick="searchByKeyword();">Search</button>
                    </form>
                </div>
            </div>
        </div>
        <div id="adv">
        	<?php
            $ads_info = Ads::getAdsCatByPos($cat_id,3);
			if($ads_info)
			{
				$src_img = Common::getImage($ads_info['picture'], 'ads', '');
				?>
                <img src="<?php echo $src_img;?>" />
                <?php
			}
			?>
        </div>
    </div>
    
    <div class="right main-content js-main-content" data-selenium="main-content">
    	<?php if($cats) {?>
        <div class="page-banner-zone full-width" data-selenium="page-banner-zone">
        	<?php
			$ads_cat = Ads::getAdsCatByPos($cat_id, 1);
			if($ads_cat)
			{
				$src_img = Common::getImage($ads_cat['picture'], 'ads', '');
				?>
				<div data-params="auid=496236&amp;c.category=9811" class="js-externalAdContainer externalAdContainer">
					<div class="externalAd"> <a style="text-align: center" class="overlay-on-hover" href="<?php echo $ads_cat['ads_link'];?>"> <img style="vertical-align: bottom; max-width: 100%;" src="<?php echo $src_img;?>"> </a> </div>
				</div>
				<?php
			} 
			?>
            <div id="searchTermBannerMain" data-selenium="searchTermBannerMain">
                <div id="searchTermBannerHead" data-selenium="searchTermBannerHead">
                    <h1><?php echo $h1;?></h1>
                </div>
                <div id="searchTermBody" data-selenium="searchTermBody">
                    <div id="searchTermLinksWrap" data-selenium="searchTermLinksWrap">
                    <?php
					if($cat_info['sub_id']!=$cat_info['id'])
					{
						$list_sub_id = $cat_info['sub_id'];
						$list_sub_id = explode(',',$list_sub_id);
						$total = sizeof($list_sub_id)-1;
						$style = '';
						if($total==1) $style = 'style="width:100%"';
						if($total==2) $style = 'style="width:48%"';
						if($total==3) $style = 'style="width:33%"';
						if($total==4) $style = 'style="width:24%"';
						if($total>=5) $style = 'style="width:19%"';
						
						foreach($cats as $row)
						{
							if($row['parent_id']==$cat_info['id'])
							{
								$link_cat = Url::createUrl('access/cat',array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
								$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
								$class='';
								if($row['id']==$cat_id) $class = 'border_bottom';
								?>
                        		<a <?php echo $style;?> data-selenium="searchTermLink" href="<?php echo $link_cat;?>" class="searchTermLink <?php echo $class;?>"> <span class="searchLinkImage" data-selenium="searchLinkImage"><img src="<?php echo $src_img;?>" border="0"></span> <span class="searchLinkName" data-selenium="searchLinkName"><?php echo $row['title'];?></span> </a>
								<?php
							}
						}
					}
					else
					{
						$style = '';
						if($cat_info['parent_id']!=0)
						{
							$parent_info = isset($cats[$cat_info['parent_id']]) ? $cats[$cat_info['parent_id']]:array();
							$list_sub_id = $parent_info['sub_id'];
							$list_sub_id = explode(',',$list_sub_id);
							$total = sizeof($list_sub_id)-1;
							if($total==1) $style = 'style="width:100%"';
							if($total==2) $style = 'style="width:48%"';
							if($total==3) $style = 'style="width:33%"';
							if($total==4) $style = 'style="width:24%"';
							if($total>=5) $style = 'style="width:19%"';
						}
						foreach($cats as $row)
						{
							if($row['parent_id']==$cat_info['parent_id'] && $cat_info['parent_id']!=0)
							{
								$link_cat = Url::createUrl('access/cat',array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
								$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
								$class='';
								if($row['id']==$cat_id) $class = 'border_bottom';
								?>
                        		<a <?php echo $style;?> data-selenium="searchTermLink" href="<?php echo $link_cat;?>" class="searchTermLink <?php echo $class;?>"> <span class="searchLinkImage" data-selenium="searchLinkImage"><img src="<?php echo $src_img;?>" border="0"></span> <span class="searchLinkName" data-selenium="searchLinkName"><?php echo $row['title'];?></span> </a>
								<?php
							}
						}
					}
					?>
					</div>
                </div>
            </div>
        </div>
        <?php } ?>
        <div class="page-info top full-width c2" data-selenium="page-info">
            <div class="search-caution elevn c1" data-selenium="search-caution"> </div>
            <div class="pagination top" data-selenium="pagination">
                <div class="top c1 fs24 clearfix">
                    <h1 class="left"><?php echo $h1;?></h1> : 
                    <span class="fs16 bold"> &nbsp;&nbsp;&nbsp;&nbsp;<?php echo ($page-1)*$num_per_page+1;?> - <?php if($total_product<=$page*$num_per_page) echo $total_product; else echo $page*$num_per_page;?> <span class="fs12">của</span> <?php echo $total_product;?> sản phẩm </span>
				</div>
                <div class="page-opts c1 clearfix elevn" data-selenium="page-opts">
                	<!--
                    <div class="sect first" data-selenium="pageSect"> <strong>Sort By:</strong>
                        <div tabindex="0" style="display: inline-block; cursor: default; position: relative;" class="selectbox borderBtn style1 ns-select elevn sort-by ns-close" data-selenium="selectBox">
                            <p style="margin: 0px; display: inline-block;" class="ns-selected-text ns-selected-option" data-selenium="selected-text"> Best Sellers
                                <svg style="width:10px;height:5px;">
                                    <use xlink:href="#arrow-down-light"></use>
                                </svg>
                            </p>
                            <ul class="ns-dropdown" style="display: none; list-style: outside none none; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; position: absolute; z-index: 11111;">
                                <li style="list-style: outside none none;" class="ns-option first" data-selenium="bestSellers"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_POPULARITY%7c1&amp;ci=9811&amp;setNs=p_POPULARITY%7c1&amp;N=4288586282&amp;srtclk=sort">Best Sellers</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="priceLowtoHigh"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_PRICE_2%7c0&amp;ci=9811&amp;setNs=p_PRICE_2%7c0&amp;N=4288586282&amp;srtclk=sort">Price: Low to High</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="priceHightoLow"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_PRICE_2%7c1&amp;ci=9811&amp;setNs=p_PRICE_2%7c1&amp;N=4288586282&amp;srtclk=sort">Price: High to Low</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="userrating"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_OVER_ALL_RATE%7c1&amp;ci=9811&amp;setNs=p_OVER_ALL_RATE%7c1&amp;N=4288586282&amp;srtclk=sort">Top Rated</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="mostRated"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_REVIEWS%7c1&amp;ci=9811&amp;setNs=p_REVIEWS%7c1&amp;N=4288586282&amp;srtclk=sort">Most Rated</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="brandAtoZ"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_PRODUCT_SHORT_DESCR%7c0&amp;ci=9811&amp;setNs=p_PRODUCT_SHORT_DESCR%7c0&amp;N=4288586282&amp;srtclk=sort">Brand: A to Z</a></li>
                                <li style="list-style: outside none none;" class="ns-option" data-selenium="brandZtoA"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_PRODUCT_SHORT_DESCR%7c1&amp;ci=9811&amp;setNs=p_PRODUCT_SHORT_DESCR%7c1&amp;N=4288586282&amp;srtclk=sort">Brand: Z to A</a></li>
                                <li style="list-style: outside none none;" class="ns-option last" data-selenium="newestSort"><a class="c2" href="https://www.bhphotovideo.com/c/search?Ns=p_NEWEST_SORT%7c1&amp;ci=9811&amp;setNs=p_NEWEST_SORT%7c1&amp;N=4288586282&amp;srtclk=sort">Newest</a></li>
                            </ul>
                        </div>
                        <strong>Display:</strong>
                        <div tabindex="0" style="display: inline-block; cursor: default; position: relative;" class="selectbox  borderBtn style1 ns-select elevn ns-close" data-selenium="selectBox">
                            <p style="margin: 0px; display: inline-block;" class="ns-selected-text ns-selected-option" data-selenium="selected-text">24 per page
                                <svg style="width:10px;height:5px;">
                                    <use xlink:href="#arrow-down-light"></use>
                                </svg>
                            </p>
                            <ul class="ns-dropdown" style="display: none; list-style: outside none none; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; position: absolute; z-index: 11111;">
                                <li style="list-style: outside none none;" class="ns-option first"><a data-selenium="view24" class="c2" href="https://www.bhphotovideo.com/c/search?ipp=24&amp;ci=9811&amp;N=4288586282&amp;setIPP=24&amp;srtclk=itemspp">24</a></li>
                                <li style="list-style: outside none none;" class="ns-option"><a data-selenium="view48" class="c2" href="https://www.bhphotovideo.com/c/search?ipp=48&amp;ci=9811&amp;N=4288586282&amp;setIPP=48&amp;srtclk=itemspp">48</a></li>
                                <li style="list-style: outside none none;" class="ns-option"><a data-selenium="view72" class="c2" href="https://www.bhphotovideo.com/c/search?ipp=72&amp;ci=9811&amp;N=4288586282&amp;setIPP=72&amp;srtclk=itemspp">72</a></li>
                                <li style="list-style: outside none none;" class="ns-option last"><a data-selenium="view100" class="c2" href="https://www.bhphotovideo.com/c/search?ipp=100&amp;ci=9811&amp;N=4288586282&amp;setIPP=100&amp;srtclk=itemspp">100</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="sect page-view" data-selenium="page-view"> <a data-selenium="btnList" href="https://www.bhphotovideo.com/c/search?setView=LIST&amp;catName=Digital-Cameras&amp;ci=9811&amp;N=4288586282&amp;view=LIST" class="pn-btn borderBtn first list-view active"><span>List View</span></a> <a data-selenium="btnGrid" href="https://www.bhphotovideo.com/c/search?setView=GRID&amp;catName=Digital-Cameras&amp;ci=9811&amp;N=4288586282&amp;view=GRID" class="pn-btn borderBtn grid-view "><span>Grid View</span></a> <a data-selenium="btnGallery" href="https://www.bhphotovideo.com/c/search?setView=GALLERY&amp;catName=Digital-Cameras&amp;ci=9811&amp;N=4288586282&amp;view=GALLERY" class="pn-btn borderBtn last gallery-view "><span>Gallery View</span></a> </div>
                    <div class="displayNone js-compareBtn">
                        <div class="sect last bold left" data-selenium="compareSect"> <strong class="left">Compare:</strong>
                            <div class="borderBtn left compare-sec"> <span data-selenium="compareItems" class="twelve c5 js-compareItems compareItems  yes-compare js-yes-compare">Compare <span class="js-inCompareTTL inCompareTTL ">0</span> Items</span> <span data-selenium="no-compare" class="no-compare js-no-compare c3">Add Items To Compare</span> <span data-selenium="one-compare" class="one-compare  js-one-compare c3">Add 1 More Item</span> <span data-selenium="clearCompare" class="x c2 clearCompare js-clearCompare yes-compare js-yes-compare">X</span> </div>
                        </div>
                    </div>
                    -->
                </div>
            </div>
        </div>
        <?php $this->renderPartial("_list", array('products'=>$products));?>
        <!-- end list of items -->
        
    </div>
    <!-- end main-content -->
    <div class="bottomSection js-bottomSection clearfix full-width left" data-selenium="bottomSection">
        <div class="bottom pagination js-pagination clearfix left" data-selenium="pagination">
            <div class="back-to-top js-backToTop right bold fs12 c2">Back to top</div>
            <div class="pagination-zone  twelve" data-selenium="pagination-zone"> <?php echo $paging;?></div>
            <div class="twelve c2">
                <p class="pageNuber"> Page <?php echo $page;?> of <?php echo $total_product;?> <span class="c3 eighteen">&nbsp; | &nbsp;</span> <?php echo ($page-1)*$num_per_page;?> - <?php echo $page*$num_per_page;?> of <?php echo $total_product;?> Items </p>
            </div>
        </div>
    </div>
    <!-- BEGIN COREMETRICS This must be before the Coremetrics.jsp include below.-->
    <!-- END COREMETRICS -->
</div>