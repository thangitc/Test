<!--<div id="miniprodLayerOverlay" class="showMiniProdOverlay"></div>-->
<div id="miniprodLayer" class="miniProdLayer miniProdAccItem fadeVisible">
    <div id="miniprodLayerPagination">
    	<!--
    	<span class="arrows prev">
    	
        <svg>
            <use xlink:href="#right-arrow"/>
        </svg>
        </span><span class="arrows next ">
        <svg>
            <use xlink:href="#right-arrow"/>
        </svg>
        </span><span> Item <b class="miniprodpaginationCurrentIndex">2</b> of <b>8</b></span>-->
	</div>
    <span id="miniprodLayerClose" onclick="$('#pop_access').hide();">
    <svg>
        <use xlink:href="#x"/>
    </svg>
    </span>
    <div class="miniprodLayerConatiner">
        <div class="miniProdWidth clearfix" style="width:960px;">
            <div class="js-item js-bhItemObj">
                <div class="miniProdLeftSection">
                    <div class="topRow">
                        <div class="miniProdMainItemImageWrapper"> <img width="150" height="150" src="<?php $src_img = Common::getImage($access_info['picture'], 'access', '', 'small'); echo $src_img;?>"> </div>
                    </div>
                    <div class="bottomRow">
                        <div class="miniProdInTheBoxWrapper">
                            <div class="miniProdInTheBoxTitle">
                                <h3>In the Box</h3>
                            </div>
                            <div class="miniProdInTheBoxBody">
                                <ul>
                                    <li><?php echo $access_info['title'];?></li>
                                </ul>
                                <?php echo $access_info['in_the_box'];?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="miniProdRightSection">
                    <div class="topRow clearfix">
                        <div class="miniProdInfoWrapper">
                            <div class="miniProdInfo">
                                <div class="productTitle"><a href="<?php echo Url::createUrl('access/detail', array('access_id'=>$access_info['id'], 'alias'=>$access_info['alias']));?>"><?php echo $access_info['title'];?></a></div>
                                <!--
                                <div class="bhItemCode"> <span>B&amp;H # CA4028</span> <span>MFR # 6310B002</span> <span class="stockMessage itemAvailable">In Stock</span> </div>
                                -->
                                <div class="miniProdRatingAndPrint clearfix">
                                <span class="miniProdReviewStarWrapper review-stars-medium"> 
                                	<?php
									$arr_rating = LoadConfig::$arr_rating;
									$rating_name = isset($arr_rating[$access_info['rating']]) ? $arr_rating[$access_info['rating']].'' : 'A';
									$rating_img_name = $rating_name.'.png';
									?>
									<img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_img_name;?>" />
                                </span>
                                 <span onclick="window.print();" class="printFromMiniProdLayer">
                                    <svg>
                                        <use xlink:href="#printer"/>
                                    </svg>
                                    Print</span>
								</div>
                                <?php echo $access_info['introtext'];?>
                            </div>
                        </div>
                        <div class="miniProdPriceBoxWrapper">
                            <div class="">
                                <ul class="priceZoneContainer">
                                	<?php
									if($access_info['price_deal']!=0 && $access_info['time_deal'] && $access_info['time_deal']>=time())
									{
										?>
                                        <li class="priceRegular borderDotted">
                                            <!-- Item Price -->
                                            <ul>
                                                <li class="priceSavings borderDotted">
                                                    <ul>
                                                        <li class="clearfix">
                                                            <span class="elevn c2 left">Giá cũ: </span>
                                                            <span class="price elevn c2 right"><?php echo Common::formatNumber($access_info['price']);?> VND</span>
                                                        </li>
                                                        <li class="clearfix">
                                                            <span class="elevn c2 left">Tiết kiệm: </span>
                                                            <span class="savings elevn c2 right"><?php echo Common::formatNumber($access_info['price'] - $access_info['price_deal']);?> VND</span>
                                                        </li>
                                                        <li class="clearfix">
                                                            <span class="elevn c2 left">Thời gian khuyến mại: </span>
                                                            <span class="offerends elevn c2 right"><?php echo date('d/m/Y', $access_info['time_deal']);?></span>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="clearfix"> <span style="line-height: 25px;" class="twelve c2 left">Giá bán: </span> <span class="sixteen c7 bold right"><?php if($access_info['price_deal']!=0 && $access_info['time_deal']) echo Common::formatNumber($access_info['price_deal']); else echo Common::formatNumber($access_info['price']);?></span> </li>
                                            </ul>
                                        </li>
                                        <?php
									}
									else
									{
										?>
                                        <li class="priceRegular borderDotted">                                        
                                            <ul>                                            
                                                <li class="clearfix">
                                                    <span style="line-height: 25px;" class="twelve c2 left">Giá: </span>                                                        <span class="sixteen c7 bold right"><?php echo Common::formatNumber($access_info['price']);?> VND</span>                                                    
                                                </li>
                                            </ul>
                                        </li>
                                        <?php
									}
                                    ?>
                                    
                                    <?php if($is_deal==0) { ?>
                                    <li class="addToCartSection clearfix">
                                        <form class="js-ajaxItemAction" method="POST">
                                            <span class="atc clearfix">
                                            <input type="text" style="margin-left: 6px;" maxlength="3" size="2" value="1" name="qTy" class="atcForminput">
                                            <a class="atc-btn blueBtn pill-shaped-button elevn addToCart" href="javascript:" onclick="addCart(<?php echo $access_info['id'];?>, 1, 1,<?php echo $access_info['price'];?>);">Thêm vào giỏ hàng</a> </span>
                                        </form>
                                    </li>
                                    <?php } ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="bottomRow">
                        <div class="miniProdTabs">
                            <ul>
                                <li class="active" data-tabindex="0"><span>Mô tả</span><span class="miniProdDownArrow">
                                    <svg>
                                        <use xlink:href="#arrow-down-light"/>
                                    </svg>
                                    </span>
								</li>
                                <li data-tabindex="1"><span>Thông số kỹ thuật</span><span class="miniProdDownArrow">
                                    <svg>
                                        <use xlink:href="#arrow-down-light"/>
                                    </svg>
                                    </span>
								</li>
                            </ul>
                        </div>
                        <div class="miniProdTabContents">
                            <div data-tabcontenindex="0">
                                <div class="miniProdOverviewWrapper">
                                    <?php echo $access_info['description'];?>
                                </div>
                            </div>
                            <div data-tabcontenindex="1" style="display: none;">
                                <div class="miniProdSpecSWrapper">
                                    <?php echo $access_info['specs'];?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

