<style>
#greenNav.nav-tabs-outer-wrapper #nav li:not(.empty-li) .navDownArrowIcon {
	bottom: 2px;
	display: none;
	height: 12px;
	left: 0;
	line-height: 8px;
	position: absolute;
	right: 0;
	text-align: center;
}
#greenNav.nav-tabs-outer-wrapper #nav li:not(.empty-li) .navDownArrowIcon svg {
	fill: #018d72;
	height: 12px;
	margin: 0 auto;
	width: 11px;
}
#greenNav.nav-tabs-outer-wrapper #nav li.ui-tabs-active .navDownArrowIcon, #greenNav.nav-tabs-outer-wrapper #nav li.active:not(.empty-li) .navDownArrowIcon {
	display: block;
	opacity: 1;
	visibility: visible;
}
#greenNav.nav-tabs-outer-wrapper #nav li.active a, #greenNav.nav-tabs-outer-wrapper #nav li.ui-tabs-active a {
	background: #fff none repeat scroll 0 0;
	box-shadow: none;
	color: #018d72;
}
#greenNav #nav {
	display: table;
	margin: 0 auto;
	overflow: hidden;
	width: 100%;
}
#greenNav #nav li:not(.empty-li) {
	height: 60px;
	margin-right: 10px;
	padding: 8px 0;
	position: relative;
	text-align: left;
}
#greenNav #nav li.disabled a {
	box-shadow: none;
	cursor: default;
	opacity: 0.5;
}
#greenNav #nav li:not(.empty-li) a {
	background: #018d72 none repeat scroll 0 0;
	border-radius: 4px;
	box-shadow: 0 2px 0 0 #018d72;
	color: #fff;
	display: inline-block;
	font-size: 16px;
	line-height: 44px;
	padding: 0 35px;
	position: relative;
	text-decoration: none;
	transition: background 0.1s ease-in-out 0s;
}
#greenNav #nav li:not(.empty-li):not(.ui-tabs-active):not(.active) a:hover {
	background: #018d72 none repeat scroll 0 0;
}
#greenNav #nav li:hover:not(.active):not(.ui-tabs-active):not(.disabled):not(.empty-li) a, #greenNav #nav li:hover:not(.active):not(.ui-tabs-active):not(.disabled):not(.empty-li) span {
	color: #fff;
}
</style>
<?php
$this->renderPartial('application.views.cart.js') ;
//$time_sale_expired = mktime(0,0,0, date('m'),date('d'), date('Y'))-86400;
$time_sale_expired = time()-86400;
?>
<div class="t-main clearfix featuredPromoPage">
    <div class="js-htmlbanner"></div>
    <div style="display:none;" class="banners-container js-homebanner"></div>
    <?php if($products_feature) { ?>
    <div class="section">
        <div class="new-page-width top-10-featured-items"> <a id="FeaturedItems"></a>
            <h1 class="top">Sản phẩm giảm giá nhiều nhất</h1>
            <div class="sg-slider">
                <div data-direction="false" class="slider-direction" id="left_scroll"></div>
                <div id="carousel_container">
                    <div id="carousel_inner">
					<?php
                    foreach($products_feature as $row)
                    {
                        $arr_rating = LoadConfig::$arr_rating;
                        $src_img = Common::getImage($row['picture'], 'camera', '', 'small');
                        $link_camera = Url::createUrl('bList/detail', array('camera_id'=>$row['id'], 'alias'=>$row['alias']));
                        $rating_name = isset($arr_rating[$row['rating']]) ? $arr_rating[$row['rating']].'.png' : 'A.png';
                        $title_product = $row['title'];
                        $list_access_free = isset($access_free_feature[$row['id']]) ? $access_free_feature[$row['id']]: array();
                        ?>
                        <div class="featured-item" style="opacity: 1;">
                        
                            <div class="featured-item-helper">
                                <div itemtype="http://schema.org/Product" itemscope="" class="item clearfix js-item elevn  js-bhItemObj resized" data-selenium="itemDetail" style="width: 589px; height: 324px;">
                                    <h3 class="bold twelve js-itemHeading resized" data-selenium="itemHeading" style="height: 42px;"> <a title="<?php echo $title_product;?>" itemprop="url" data-selenium="itemHeadingLink" class="c5"  href="<?php echo $link_camera;?>" data-sg-title="<?php echo $title_product;?>"> <span itemprop="name"><?php echo $title_product;?></span> </a> </h3>
                                    <div data-selenium="img-zone" class="img-zone ">
                                        <div class="padding"><a data-selenium="itemImg" href="<?php echo $link_camera;?>"  class="itemImg" name="image"><a data-selenium="itemImg" href="<?php echo $link_camera;?>"  class="itemImg" name="image"><img width="150" height="150" alt="<?php echo $title_product;?>" itemprop="image" src="<?php echo $src_img;?>" data-selenium="imgLoad" /></a></a></div>
                                        <div data-selenium="reviewCont" class="js-reviewCont resized" style="height: 21px;">
                                        <p>
                                            <a class="listDetailStars review-stars-medium ten c2">
                                                <img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_name;?>" />
                                                </a>
                                            </p>
                                        </div>
                                    </div>
                                    <div data-selenium="itemInfo-zone" class="">
                                        <div data-selenium="similarItemCont" class="js-similarItemCont resized" style="height: 0px;"> </div>
                                    </div>
                                    <div data-selenium="conversion-zone" class="conversion-zone">
                                        <div data-selenium="price-zone" class="price-zone ">
                                            <div data-selenium="prices" class="prices js-prices resized" style="height: 0px;"> </div>
                                            <div data-selenium="addToCartPrice" class="js-atc-price resized" style="height: 23px;">
                                                <div data-selenium="addToCartPrice" class="atc-price ">
                                                    <p class="clearfix therteen  bold c7  " data-selenium="finalPrice"> <span data-selenium="youpayPrice" class="youpay">Giá: </span> <span class="price therteen" data-selenium="price"> <?php if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired) echo Common::formatNumber($row['price_sale']); else echo Common::formatNumber($row['price']);?> </span> VND</p>
                                                </div>
                                            </div>
                                            <div data-selenium="addToCartZone" class="atc-zone clearfix">
                                                <div data-selenium="MapMessageCont" class="js-acMapMessageCont resized" style="height: 0px;">
                                                    <div class="acMapMessageCont clearfix c7"> </div>
                                                </div>
                                                <div data-selenium="rebatesCont" class="rebatesCont js-rebatesCont resized" style="height: 42px;">
                                                    <?php if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired) { ?>
                                                    <div class="clearfix">
                                                        <p class="left ten c2 Savings"> <span> Giảm giá <?php echo Common::formatNumber($row['price']-$row['price_sale']);?> </span> VND</p>
                                                    </div>
                                                    <?php } ?>
                                                    <?php if(!empty($list_access_free)) {?>
                                                    <div class="rebateLinks clearfix">
                                                        <p class="includesFreeLink c5 left"><span class=" fs16 bold">+ </span><span class="cursor-pointer underline-on-hover bold js-popover-opener">Quà tặng</span></p>    
                                                    </div>
                                                    <?php } ?>
                                                </div>
                                                <button class="addToCart right blueBtn cursor-pointer atc-btn fs11 bold one-line" data-selenium="submitBtn" type="button" onclick="addCart(<?php echo $row['id'];?>, 0, 1,<?php if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired) echo $row['price_sale']; else echo $row['price'];?>);">Thêm vào giỏ hàng</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-selenium="itemBottom" class="itemBottom">
                                        <div data-selenium="stockInfo" class="clearfix js-stockInfo resized" style="height: 282px;"> </div>
                                    </div>
                                </div>
                                <!-- end .item -->
                                <?php if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired) { ?>
                                <div class="how-much-saving fs14">
                                    <p class="fs11">Giảm giá</p>
                                    <p class="bold"> <?php echo ceil(($row['price']-$row['price_sale'])/$row['price']*100)?>% </p>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                        
                        
                    </div>
                </div>
                <div data-direction="true" class="slider-direction" id="right_scroll"></div>
                
            </div>
        </div>
    </div>
    <?php } ?>
    <!-- not deleting, to be able to put it back when needed -->
    <div class="section">
        <div class="new-page-width">
            <div class="additional-savings-header">
                <div class="nav-tabs-outer-wrapper js-nav-tabs-outer-wrapper stick-nav--bottom" id="greenNav">
                    <div id="navTabs" class="nav-tabs-inner-wrapper">
                        <ul role="tablist" id="nav">
                            <li style="width:20%; float:left"> <a class="ui-tabs-anchor" href="<?php echo Url::createUrl('bList/dealList');?>#nav"> <span>Máy ảnh giảm giá khác</span> <span class="navDownArrowIcon">
                                <svg>
                                    <use xlink:href="#arrow-down-light"></use>
                                </svg>
                                </span> </a>
                            </li>
                            <li style="width:30%; float:left" class="ui-tabs-active"> <a class="ui-tabs-anchor" href="<?php echo Url::createUrl('access/dealAccess');?>#nav"> <span>Phụ kiện giảm giá khác</span> <span class="navDownArrowIcon">
                                <svg>
                                    <use xlink:href="#arrow-down-light"></use>
                                </svg>
                                </span> </a>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </div>
            <div class="allPromotions js-allPromotions">
                <ul class="tabs full-width categories">
                    <li class="fs16">Danh mục:</li>
                    <li  onclick="window.location.href=$(this).attr('data-loadlink')" data-loadlink="<?php echo Url::createUrl('access/dealAccess');?>#nav" class="<?php if($cat_id==0) echo 'current';?> loadLink js-loadLink fs16">Tất cả</li>
                    <?php
					$list_id = array();
					$k=0;
					if($cats)
					foreach($cats as $row)
					{
						if($row['cat_type']==3 && $row['level']==2)
						{
							$k++;
							$link_cat_detal = Url::createUrl('access/dealAccess', array('alias'=>$row['alias'], 'cat_id'=>$row['id'])).'#nav';
							$list_id[] = $row['id'];
							$class = '';
							if($row['id']==$cat_id) $class = 'current ';
							?>
                            <li onclick="window.location.href=$(this).attr('data-loadlink')" data-loadlink="<?php echo $link_cat_detal;?>" class="loadLink js-loadLink fs16 js-photography <?php echo $class;?>"><?php echo $row['title'];?></li>
                            <?php
							if($k==9) break;
						}
					}
                    ?>
                    
                    
                    <li class="moreCategories"> <span class="moreCatOpener fs14 bold">More</span>
                        <div class="displayNone moreCategoriesList clearfix">
                            <ul>
                                <?php
								if($cats)
								foreach($cats as $row)
								{
									if($row['cat_type']==3 && $row['level']==2 && !in_array($row['id'],$list_id))
									{
										$link_cat_detal = Url::createUrl('access/dealAccess', array('alias'=>$row['alias'], 'cat_id'=>$row['id'])).'#nav';
										$class = '';
										if($row['id']==$cat_id) $class = 'current ';
										?>
										<li onclick="window.location.href=$(this).attr('data-loadlink')" data-loadlink="<?php echo $link_cat_detal;?>" class="js-loadLink fs16 js-mobile_devices <?php echo $class;?>"><?php echo $row['title'];?></li>
										<?php
									}
								}
								?>
                            </ul>
                        </div>
                    </li>
                </ul>
                <div class="promotionItems js-promotionItems">
                    <div class="items js-items clearfix">
                        <?php	
						$k = 0;
						$arr_rating = LoadConfig::$arr_rating;
						if($access_deal)
						foreach($access_deal as $row)
						{
							$k++;
							$src_img = Common::getImage($row['picture'], 'access', '', 'small');
							$link_access = Url::createUrl('access/detail', array('access_id'=>$row['id'], 'alias'=>$row['alias']));
							$rating_name = isset($arr_rating[$row['rating']]) ? $arr_rating[$row['rating']].'.png' : 'A.png';
							$title_access = $row['title'];
							?>
                            <div <?php if($k==sizeof($access_deal)) echo 'id="loadMore"';?> itemtype="http://schema.org/Product" class="item clearfix js-item elevn js-bhItemObj resized" data-selenium="itemDetail" style="height: 427px;">
                                <div data-selenium="img-zone" class="img-zone ">
                                    <div class="padding"> <a data-selenium="itemImg" href="<?php echo $link_access;?>" class="itemImg" name="image"> <img width="150" height="150" alt="<?php echo $title_access;?>" itemprop="image" src="<?php echo $src_img;?>"> </a> </div>
                                    <div data-selenium="reviewCont" class="js-reviewCont resized" style="height: 23px;">
                                        <p>
                                        <a class="listDetailStars review-stars-medium ten c2">
                                        	<img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_name;?>" />
											</a>
										</p>
                                    </div>
                                    <h3 class="bold twelve js-itemHeading resized" data-selenium="itemHeading" style="height: 54px;"> <a title="<?php echo $title_access;?>" itemprop="url" data-selenium="itemHeadingLink" class="c5" href="<?php echo $link_access;?>" data-sg-title="<?php echo $title_access;?>"> <span itemprop="name"><?php echo $title_access;?></span> </a> </h3>
                                </div>
                                <div data-selenium="itemInfo-zone" class="">
                                    <div data-selenium="similarItemCont" class="js-similarItemCont resized" style="height: 0px;"> </div>
                                </div>
                                <div data-selenium="conversion-zone" class="conversion-zone">
                                    <div data-selenium="price-zone" class="price-zone ">
                                        <div data-selenium="prices" class="prices js-prices resized" style="height: 0px;"> </div>
                                        <div data-selenium="addToCartPrice" class="js-atc-price resized" style="height: 23px;">
                                            <div data-selenium="addToCartPrice" class="atc-price ">
                                                <p class="clearfix therteen  bold c7  " data-selenium="finalPrice"> <span data-selenium="youpayPrice" class="youpay">Giá: </span> <span class="price therteen" data-selenium="price"> <?php if($row['price_deal']!=0 && $row['time_deal']!=0 && $row['time_deal']>=time()) echo Common::formatNumber($row['price_deal']); else echo Common::formatNumber($row['price']);?></span> </p>
                                            </div>
                                        </div>
                                        <div data-selenium="addToCartZone" class="atc-zone clearfix">
                                            <div data-selenium="MapMessageCont" class="js-acMapMessageCont resized" style="height: 0px;">
                                                <div class="acMapMessageCont clearfix c7"> </div>
                                            </div>
                                            <div data-selenium="rebatesCont" class="rebatesCont js-rebatesCont resized" style="height: 65px;">
                                            	<?php if($row['price_deal']!=0 && $row['time_deal']!=0 && $row['time_deal']>=time()) {?>
                                                <div class="clearfix">
                                                    <p class="left ten c2 Savings"> <span>Giảm giá <?php echo Common::formatNumber($row['price']-$row['price_deal']);?></span> </p>
                                                </div>
                                                <?php } ?>
                                            </div>
                                            <button class="addToCart right blueBtn cursor-pointer atc-btn fs11 bold one-line" data-selenium="submitBtn" type="button" onclick="addCart(<?php echo $row['id'];?>, 1, 1,<?php if($row['price_deal']!=0 && $row['time_deal']!=0 && $row['time_deal']>=time()) echo $row['price_deal']; else echo $row['price'];?>);">Thêm vào giỏ hàng</button>
                                        </div>
                                    </div>
                                </div>
                                <div data-selenium="itemBottom" class="itemBottom">
                                    <div data-selenium="stockInfo" class="clearfix js-stockInfo resized" style="height: 0px;"> </div>
                                </div>
                            </div>
                            <?php
						}
                        ?>
                    </div>
                    <?php
					$num_page = ceil($total / $num_per_page);
					if($page+1<=$num_page)
					{
						if($cat_id!=0 && !empty($cat_info))
							$link_page = Url::createUrl('access/dealAccess', array('cat_id'=>$cat_id, 'alias'=>$cat_info['alias'], 'page'=>$page+1)).'#loadMore';
						else
							$link_page = Url::createUrl('access/dealAccess', array('page'=>$page+1)).'#loadMore';
						?>
                        <div id="loadMore" onclick="window.location.href=$(this).attr('data-loadlink')" data-loadlink="<?php echo $link_page;?>" class="loadMore fs16 upper js-loadMore">Xem thêm</div>
                        <?php
					}
                    ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<script>

$(function(){
	showHideSlide('carousel_inner','right_scroll','left_scroll',<?php echo sizeof($products_feature);?>,2,'div',0);
	$(window).click(function() {
		$('.popover').hide();
	});		   
});
</script>