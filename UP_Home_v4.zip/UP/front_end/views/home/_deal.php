<?php
//$time_sale_expired = mktime(0,0,0, date('m'),date('d'), date('Y'))-86400;
$time_sale_expired = time()-86400;
?>
<?php if(!empty($row_soc)) { ?>
<script>
$(function(){
	$('.productView').hover(function(){
		$(this).removeClass('hoverLayerContainer').addClass('hoverLayerContainer');
	},function(){
		$(this).removeClass('hoverLayerContainer');
	});
});
</script>
<section class="newRegion moduleDealZoneRegion">
    <div class="bhView ">
        <section>
            <header class="section-header">
                <h1>Khuyến mại & Giảm giá</h1>
            </header>
            <div class="dealZoneSavings ">
            	<?php
				if(!empty($row_soc))
				{
					$price_deal_show = $row_soc['price'];
					$price_deal = $row_soc['price_sale'];
					$saving  = $price_deal_show - $price_deal;
					?>
					<div id="homePageDealZone">
						<div class="bhView ">
							<div>
                            	<a data-track-link="USE_ITEM" href="<?php echo Url::createUrl('bList/detail', array('camera_id'=>$row_soc['id'], 'alias'=>$row_soc['alias']));?>"> <img src="<?php  echo Yii::app()->params['static_url']; ?>/images/Deal-Zone-Logo.png" class="dz-logo">
                                
                                <?php if($row_soc['price_sale']!=0 && $row_soc['time_sale']!=0 && $row_soc['time_sale']>=$time_sale_expired) { ?>
								<div data-percent="15" class="countDownTimer">
									<canvas height="120" width="120"></canvas>
									<div class="countDownText timeRemaining"><span class="timer-text">DEAL ENDS</span><span class="tcd tcd-no-days"><span class="tcd-days"><span class="tcd-days-count">0&nbsp;</span><span class="tcd-days-days">days&nbsp;</span></span><span class="tcd-hours"><?php echo date('d', $row_soc['time_sale']);?></span><span class="tcd-minutes">/<?php echo date('m', $row_soc['time_sale']);?></span><span class="tcd-seconds">/<?php echo date('Y', $row_soc['time_sale']);?></span></span></div>
								</div>
                                <?php } ?>
                                
								<img src="<?php echo Common::getImage($row_soc['picture'], 'camera', '', '');?>">
								<div class="dealZoneinfo" style="bottom:10px;">
                                	<?php if($row_soc['price_sale']!=0 && $row_soc['time_sale']!=0 && $row_soc['time_sale']>=time()) { ?>
									<p class="left" style="width:50%;"> <em class="c16">Giảm: <?php echo Common::formatNumber($saving);?> VND</em> on <?php echo $row_soc['title'];?> </p>
									<span class="dz-price c16 right fs24 bold"><?php echo Common::formatNumber($price_deal);?> VND</span> <span class="clearfix"></span> 
                                    <?php } else { ?>
                                    <p class="left" style="width:50%;"> <?php echo $row_soc['title'];?> </p>
									<span class="dz-price c16 right fs24 bold"><?php echo Common::formatNumber($price_deal_show);?> VND</span> <span class="clearfix"></span>
                                    <?php } ?>
                                    <!--
                                    <span class="rating review-stars-tiny clearfix"> <span class="review-stars">
									<svg class="review-stars-grey">
										<use xlink:href="#stars"/>
									</svg>
									<span style="width: 90%;" class="review-stars-inner">
									<svg class="review-stars-green">
										<use xlink:href="#stars"/>
									</svg>
									</span> </span> <span class="numberOfReviews">3</span> </span>-->
                                    <span class="rating review-stars-tiny clearfix">
                                    <?php
									$arr_rating = LoadConfig::$arr_rating;
									$rating_name = isset($arr_rating[$row_soc['rating']]) ? $arr_rating[$row_soc['rating']].'' : 'A';
									$rating_img_name = $rating_name.'.png';
									?>
                                    <span class="review-stars"><img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_img_name;?>" /></span>
                                    </span>
                                    
								</div>
								</a>
							</div>
						</div>
					</div>
					<?php
				}
                ?>
                <div class="homePageSavings-id" id="homePageSavings">
                    <div class="bhView ">
                        <div class="savingsCollection">
                        <?php
						$arr_rating = LoadConfig::$arr_rating;
						if($products_deal)
						foreach($products_deal as $row)
						{
							$src_img = Common::getImage($row['picture'], 'camera', '', 'small');
							$link_camera = Url::createUrl('bList/detail', array('camera_id'=>$row['id'], 'alias'=>$row['alias']));
							$price_deal_show = $row['price'];
							$price_deal = $row['price_sale'];
							$saving  = $price_deal_show - $price_deal;
							$rating_name = isset($arr_rating[$row['rating']]) ? $arr_rating[$row['rating']] : 'A'	;
							?>
                            <div class="productView">
                                <div class="item non-hover-item">
                                	<a href="<?php echo $link_camera;?>" class="overlay-on-hover detailsLink">
                                    <div class="clearfix"> <img src="<?php echo $src_img;?>" class="itemImage">
                                        <div class="itemInfo">
                                            <h2 style="height:55px;">
                                            <?php if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired) { ?>
                                            <b>Giảm  <?php echo Common::formatNumber($saving);?> VND trên &nbsp;</b>
                                            <?php } ?>
											<?php echo $row['title'];?>
                                            </h2>
                                            <span class="rating review-stars-tiny clearfix">
                                                <img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_name;?>.png" />(<?php echo $rating_name;?>)
											</span>
                                            <div class="itemPrice">
											<?php
											if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired)
											{
												echo Common::formatNumber($price_deal).' VND';
											}
											else
											{
												echo Common::formatNumber($price_deal_show). 'VND';
											}
											?>
                                            </div>
                                        </div>
                                    </div>
                                    </a>
								</div>
                                
                                <div class="productHoverLayer">
                                    <div class="productHoverLayer-inner">
                                        <div class="item"> <a data-track-link="USE_ITEM" class="detailsLink clearfix" href="<?php echo $link_camera;?>">
                                            <div class="itemImage"> <img src="<?php echo $src_img;?>"> </div>
                                            <div class="itemInfo">
                                                <div class="product-title">
                                                    <h2><?php echo $row['title'];?></h2>
                                                </div>
                                                <span class="rating review-stars-tiny clearfix">
                                                <img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_name;?>.png" />(<?php echo $rating_name;?>)
                                                </span>
                                                <?php if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired) { ?>
                                                <div class="itemPrice"> <span class="beforeRebate"><?php echo Common::formatNumber($price_deal_show);?> VND</span> <?php echo Common::formatNumber($price_deal);?> VND</div>
                                                <?php } else {?>
                                                <div class="itemPrice"><?php echo Common::formatNumber($price_deal_show);?> VND</div>
                                                <?php } ?>
                                            </div>
                                            </a>
                                            <div class="atc-atw">
                                                <button onclick="addCart(<?php echo $row['id'];?>, 0, 1,<?php if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired) echo $row['price_sale']; else echo $row['price']; ?>);" data-attach="addToCart" class="overlay-on-hover button atc bluesvg">
                                                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" class="circle-loader circle-loader20">
                                                    <g>
                                                        <circle r="40%" cy="50%" cx="50%" class="fixed"/>
                                                    </g>
                                                    <g>
                                                        <circle r="40%" cy="50%" cx="50%" class="rotate"/>
                                                    </g>
                                                </svg>
                                                <span>Thêm vào giỏ hàng</span> 
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
						}
                        ?>
                        </div>
                        <div class="see-all"> <a href="<?php echo Url::createUrl('bList/dealList');?>" class="see-all-savings overlay-on-hover">Xem tất cả sản phẩm khuyến mại</a> </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</section>
<?php } ?>