<div class="infotextwrap">
    <div class="infotext">
        <h2>Everything for passion <span><a href="<?php echo Url::createUrl('home/contact');?>" title="Về chúng tôi">Về chúng tôi</a></span></h2>
    </div>
</div>
<div class="clear"></div>
<div class="homeBoxAll">
    <div class="homeBox ">
        <div class="one_third first"> <a href="javascript:" rel="nofollow">
            <div class="imageBox"> <img src="<?php  echo Yii::app()->params['static_url']; ?>/images/featured-icon-11.png" alt="Hình ảnh sản phẩm"> </div>
            </a>
            <h3><a class="overdefultlink" href="javascript:" rel="nofollow">Hình ảnh sản phẩm</a></h3>
            <div class="recentdescription">
                <div class="descriptionHomePort">
                    <div>
                        <p>Sản phẩm đã qua sử dụng luôn có hình ảnh thật, chụp chi tiết, được đánh giá chất lượng rõ ràng, mô tả khách quan.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="one_third second">
            <h3><a class="overdefultlink" href="javascript:" rel="nofollow">Chế độ bảo hành</a></h3>
            <div class="recentdescription">
                <div class="descriptionHomePort">
                    <div>
                        <p>1 đổi 1 trong 15 ngày, cam kết BH nghiêm chỉnh 3-6-12 tháng, trong thời gian chờ BH, vn-japan cho khách hàng mượn miễn phí thiết bị tương đương.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="one_third third last"> <a href="jascript:" rel="nofollow">
            <div class="imageBox"> <img src="<?php  echo Yii::app()->params['static_url']; ?>/images/supportIcon1.png" alt="Hỗ trợ 24/7"> </div>
            </a>
            <h3><a class="overdefultlink" href="javascript:" rel="nofollow">Hỗ trợ 24/7</a></h3>
            <div class="recentdescription">
                <div class="descriptionHomePort">
                    <div>
                        <p>Tư vấn, giải đáp thắc mắc với khách hàng 1 cách khách quan, chính xác nhất, luôn đưa cho khách hàng các sự lựa chọn khác nhau.</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="one_third second">
            <h3><a class="overdefultlink" href="javascript:" rel="nofollow">Dịch vụ Order</a></h3>
            <div class="recentdescription">
                <div class="descriptionHomePort">
                    <div>
                        <p><!--Đặt hàng trực tiếp từ website Nhật hoặc đặt trước hàng chính hãng ờ VN, Vn-japan cam kết luôn có mức giá tốt nhất.-->
                        Những mặt hàng khó tìm ở VN, đặt hàng trực tiếp từ Nhật, Vn-Japan luôn có mức giá tốt nhất.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="one_third first">
        	<a href="javascript:" rel="nofollow">
            <div class="imageBox"> <img alt="FREE SHIPPING" src="<?php  echo Yii::app()->params['static_url']; ?>/images/gift2.png"> </div>
            </a>
            <h3><a class="overdefultlink" href="javascript:" rel="nofollow">FREE SHIPPING</a></h3>
            <div class="recentdescription">
                <div class="descriptionHomePort">
                    <div>
                        <p>Free ship mọi miền tổ quốc, không giới hạn khoảng cách với khách hàng của VJ.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="one_third last second">
            <h3><a class="overdefultlink" href="javascript:" rel="nofollow">Giá sốc trong ngày</a></h3>
            <div class="recentdescription">
                <div class="descriptionHomePort">
                    <div>
                        <p>Hàng ngày sẽ có sản phẩm giảm giá sốc, cập nhật vào lúc 10h sáng, chỉ áp dụng đến hết ngày.</p>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>