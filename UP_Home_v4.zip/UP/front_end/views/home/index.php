<?php
$this->renderPartial('application.views.cart.js') ;
$ads_welcome = Ads::getAdsHome(4,1);
?>
<div class="t-main clearfix">
    <div class="js-htmlbanner "></div>
    <div class="banner-welcome" <?php if(!empty($ads_welcome)) { ?>style="margin-bottom:0; height:485px;" <?php }?>>
        <div class="banners-container js-homebanner"></div>
        <div class="welcome-msg">
            <div class="new-page-width">
                <p id="timeOfDay"></p>
                <?php
				
				if(!empty($ads_welcome))
				foreach($ads_welcome as $row)
				{
					$src_img = Common::getImage($row['picture'], 'ads', '');
					?>
                    <a title="<?php echo $row['title'];?>" href="<?php echo $row['ads_link'];?>"><img alt="<?php echo $row['title'];?>" src="<?php echo $src_img;?>" /></a>
                    <?
				}
				else
				{
					?>
                    <h2>Welcome to VJCamera!</h2>
					<script type="text/javascript">
                        var homeMLT = {
                                Morning: "Good morning",
                                Afternoon: "Good afternoon",
                                Evening: "Good evening"
                        };
                        (function(){
                            hour = (new Date()).getHours();	
                            nightStart = 18;
                            nightEnd = 4;
                            greeting = hour > nightEnd && hour < 12 ? homeMLT.Morning : hour > 11 && hour < nightStart ?  homeMLT.Afternoon : homeMLT.Evening;00000000
                            document.getElementById("timeOfDay").textContent = greeting;
                            if (window.userFirstName)
                            {
                                
                                document.getElementById("firstName").textContent = decodeURIComponent(window.userFirstName.replace(/%20/g, " "))+".";
                            } else {
                                document.querySelector('.welcome-msg p').innerText = document.querySelector('.welcome-msg p').innerText.replace(/,/g, '.');
                            
                            }
                        }());
                            
                    </script>
                    <?php
				}
                ?>
            </div>
        </div>
    </div>
    <div id="centerRegionContainer" class="centerRegionContainer ">
        <section id="homePageCategiriesMain" class="categoriesWrapper" data-selenium="categoriesWrapper">
            <div class="clearfix">
            <?php
			$cats = $this->array_category;
			if($cats)
			foreach($cats as $row)
			{
				if($row['is_hot']==1)
				{
					if($row['cat_type']==1)
					{
						if($row['is_child_level3']==1)
							$link_cat = Url::createUrl('bList/index', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
						else
							$link_cat = Url::createUrl('bList/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
					}
					else if($row['cat_type']==2)
					{
						$link_cat = Url::createUrl('news/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
					}
					else
					{
						if($row['is_child_level3']==1)
							$link_cat = Url::createUrl('access/index', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
						else
							$link_cat = Url::createUrl('access/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
					}
					$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
					?>
                    <div class="category <?php echo $row['title'];?>" data-selenium="<?php echo $row['title'];?>">
                    	<a class="overlay-on-hover" href="<?php echo $link_cat;?>" title="<?php echo $row['title'];?>">
                    	<!--<div class="categoryImagePlaceholder"></div>-->
                        <img style="padding-bottom:9%; margin-top:0;" class="categoryImagePlaceholder" src="<?php echo $src_img;?>" data-src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>" >
                    	<span><?php echo $row['title'];?></span>
                        </a>
                    </div>
                    <?php
				}
			}
			?>
            </div>
        </section>
        <?php $this->renderPartial('_slide');?>
        <?php $this->renderPartial('_deal', array('row_soc'=>$row_soc, 'products_deal'=>$products_deal));?>
        <?php $this->renderPartial('_timeline', array('timeline'=>$timeline, 'total_timeline'=>$total_timeline, 'page'=>$page, 'num_per_page'=>$num_per_page));?>
        <section class="styled-async sub-categories">
            <div>
                <header class="section-header">
                    <h1>Top Categories</h1>
                </header>
                <div class="categoriesWrapper clearfix" data-selenium="categoriesWrapper">
                <?php
				$cats = $this->array_category;
				$cats_home_bottom = Cats::getCatHomeBottom();
				if($cats_home_bottom)
				foreach($cats_home_bottom as $row)
				{
					if($row['parent_id']==0)
					{
						if($row['cat_type']==1)
						{
							if($row['is_child_level3']==1)
								$link_cat = Url::createUrl('bList/index', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
							else
								$link_cat = Url::createUrl('bList/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
						}
						else if($row['cat_type']==2)
						{
							$link_cat = Url::createUrl('news/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
						}
						else
						{
							if($row['is_child_level3']==1)
								$link_cat = Url::createUrl('access/index', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
							else
								$link_cat = Url::createUrl('access/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
						}
						$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
						?>
						<div style="height: 252px;" class="subCategories photography" data-selenium="photography">
							<div class="ipWrapper" onclick="window.location.href='<?php echo $link_cat;?>'">
								<!--<div class="categoryImagePlaceholder"></div>-->
								<img style="padding-bottom:9%; margin-top:0;" class="categoryImagePlaceholder" src="<?php echo $src_img;?>" data-src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>" >
							</div>
							<span onclick="window.location.href=$(this).attr('data-href');" data-selenium="photographyLink" class="pseudoLink" data-href="<?php echo $link_cat;?>"><?php echo $row['title'];?></span>
							<div>
								<ul>
								<?php
								$k=0;
								foreach($cats as $row2)
								{
									if($row2['parent_id']==$row['id'])
									{
										if($k<5)
										{
											if($row2['cat_type']==1)
											{
												$link_cat2 = Url::createUrl('bList/cat', array('cat_id'=>$row2['id'], 'alias'=>$row2['alias']));
											}
											else if($row2['cat_type']==2)
											{
												$link_cat2 = Url::createUrl('news/cat', array('cat_id'=>$row2['id'], 'alias'=>$row2['alias']));
											}
											else
											{
												$link_cat2 = Url::createUrl('access/cat', array('cat_id'=>$row2['id'], 'alias'=>$row2['alias']));
											}
											
											?>
											<li><a title="<?php echo $row2['title'];?>" data-selenium="<?php echo $row2['title'];?>" href="<?php echo $link_cat2;?>"><?php echo $row2['title'];?></a></li>
											<?php
										}
										$k++;
									}
								}
								?>
									
								</ul>
								<p><a name="Center-<?php echo $row['title'];?>-See All" data-selenium="<?php echo $row['title'];?>All" href="<?php echo $link_cat;?>">Xem thêm</a></p>
							</div>
						</div>
						<?php
					}
					else
					{
						if($row['level']==2)
						{
							if($row['cat_type']==1)
							{
								if($row['is_child_level3']==1)
									$link_cat = Url::createUrl('bList/index', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
								else
									$link_cat = Url::createUrl('bList/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
							}
							else if($row['cat_type']==2)
							{
								$link_cat = Url::createUrl('news/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
							}
							else
							{
								if($row['is_child_level3']==1)
									$link_cat = Url::createUrl('access/index', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
								else
									$link_cat = Url::createUrl('access/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
							}
							$src_img = Common::getImage($row['picture'], 'cat', '', 'small');
							?>
							<div style="height: 252px;" class="subCategories photography" data-selenium="photography">
								<div class="ipWrapper" onclick="window.location.href='<?php echo $link_cat;?>'">
									<!--<div class="categoryImagePlaceholder"></div>-->
									<img style="padding-bottom:9%; margin-top:0;" class="categoryImagePlaceholder" src="<?php echo $src_img;?>" data-src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>" >
								</div>
								<span onclick="window.location.href=$(this).attr('data-href');" data-selenium="photographyLink" class="pseudoLink" data-href="<?php echo $link_cat;?>"><?php echo $row['title'];?></span>
								<div>
									<ul>
									<?php
									$k=0;
									foreach($cats as $row2)
									{
										if($row2['parent_id']==$row['id'])
										{
											if($k<5)
											{
												if($row2['cat_type']==1)
												{
													$link_cat2 = Url::createUrl('bList/cat', array('cat_id'=>$row2['id'], 'alias'=>$row2['alias']));
												}
												else if($row2['cat_type']==2)
												{
													$link_cat2 = Url::createUrl('news/cat', array('cat_id'=>$row2['id'], 'alias'=>$row2['alias']));
												}
												else
												{
													$link_cat2 = Url::createUrl('access/cat', array('cat_id'=>$row2['id'], 'alias'=>$row2['alias']));
												}
												
												?>
												<li><a title="<?php echo $row2['title'];?>" data-selenium="<?php echo $row2['title'];?>" href="<?php echo $link_cat2;?>"><?php echo $row2['title'];?></a></li>
												<?php
											}
											$k++;
										}
									}
									?>
										
									</ul>
									<p><a name="Center-<?php echo $row['title'];?>-See All" data-selenium="<?php echo $row['title'];?>All" href="<?php echo $link_cat;?>">Xem thêm</a></p>
								</div>
							</div>
							<?php
						}
					}
				}
                ?>
                </div>
            </div>
        </section>
    </div>
    <div class="connect-with-us new-page-width reg-box-shadow styled-async" data-selenium="bannerZone">
        <div class="socialLinksContainer">
            <h2><span>Connect</span> with us.</h2>
            <p class="fs16">Join our community! Stay on top of all the latest 
                technology, industry events and consumer electronics content from around
                the web. </p>
            <div class="sLinksContainer" data-selenium="slinksCont"> <a class="singleLink facebookL" data-selenium="faceBookL" href="https://www.facebook.com/vjcamera" target="_blank" name="SocialMediaBar-_-HomePage-_-Facebook" manual_cm_sp="SocialMediaBar-_-HomePage-_-Facebook">
                <svg>
                    <use xlink:href="#facebook"></use>
                </svg>
                </a> <a class="singleLink twitterL" data-selenium="twitterL" href="https://twitter.com/vjcamera" target="_blank" name="SocialMediaBar-_-HomePage-_-Twitter" manual_cm_sp="SocialMediaBar-_-HomePage-_-Twitter">
                <svg>
                    <use xlink:href="#twitter"></use>
                </svg>
                </a> <a class="singleLink googlePlusL" data-selenium="googleplusL" href="https://plus.google.com/+vjcamera" target="_blank" name="SocialMediaBar-_-HomePage-_-GooglePlus" manual_cm_sp="SocialMediaBar-_-HomePage-_-GooglePlus">
                <svg>
                    <use xlink:href="#gplus"></use>
                </svg>
                </a> <a class="singleLink pinterestL" data-selenium="pinterestL" href="http://pinterest.com/vjcamera/" target="_blank" name="SocialMediaBar-_-HomePage-_-Pinterest" manual_cm_sp="SocialMediaBar-_-HomePage-_-Pinterest">
                <svg>
                    <use xlink:href="#pintrest"></use>
                </svg>
                </a> <a class="singleLink youTubeL" data-selenium="youtubeL" href="http://youtube.com/vjcamera" target="_blank" name="SocialMediaBar-_-HomePage-_-YouTube" manual_cm_sp="SocialMediaBar-_-HomePage-_-YouTube">
                <svg>
                    <use xlink:href="#youtube"></use>
                </svg>
                </a> <a class="singleLink FlickrL" data-selenium="flickerL" href="http://www.flickr.com/groups/vjcamera/" target="_blank" name="SocialMediaBar-_-HomePage-_-Flickr" manual_cm_sp="SocialMediaBar-_-HomePage-_-Flickr">
                <svg>
                    <use xlink:href="#flickr"></use>
                </svg>
                </a> <a class="singleLink tumblrL" data-selenium="tumblerL" href="http://vjcamera.tumblr.com/" target="_blank" name="SocialMediaBar-_-HomePage-_-Tumblr" manual_cm_sp="SocialMediaBar-_-HomePage-_-Tumblr">
                <svg>
                    <use xlink:href="#tumblr"></use>
                </svg>
                </a> <a class="singleLink instagramL" data-selenium="instagramL" href="http://instagram.com/vjcamera" target="_blank" name="SocialMediaBar-_-HomePage-_-Integram" manual_cm_sp="SocialMediaBar-_-HomePage-_-Integram">
                <svg>
                    <use xlink:href="#instagram"></use>
                </svg>
                </a> </div>
        </div>
    </div>
</div>