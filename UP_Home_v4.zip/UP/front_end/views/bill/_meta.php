<?php
$controller_id = Yii::app()->controller->id;
$action_id = Yii::app()->controller->action->id;
?>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta content="vi" http-equiv="content-language" />
<title><?php echo CHtml::encode($this->pageTitle); ?></title>
<meta name="keywords" content="<?php echo CHtml::encode($this->metaKeywords) ;?>,Shop Digital Cameras, 35MM Camera Equipment, Photography, Photo Printers,  Computers, Home Theater, Authorized Dealer Canon, Sony, Nikon, Apple, Olympus, Panasonic, Kodak, JBL"/>  
<meta name="description" content="<?php echo $this->metaDescription; ?>"/> 
<meta property="fb:admins" content=""/>
<meta property="fb:app_id" content=""/>
<meta property="og:type" content="article" />
<meta property="og:title" content="<?php echo CHtml::encode($this->pageTitle); ?>" />
<meta property="og:description" content="<?php echo $this->metaDescription; ?>" />
<?php if($this->srcImg!='') { ?>
<meta property="og:image" content="<?php echo $this->srcImg; ?>" />
<?php } ?>
<?php
if($this->prevLink!='')
{
?>
<link rel="prev" href="<?php echo $this->prevLink;?>"/>
<?php
}
if($this->linkCanoncical!='')
{
?>
<link rel="canonical" href="<?php echo $this->linkCanoncical;?>" />
<?php
}
if($this->nextLink!='')
{
?>
<link rel="next" href="<?php echo $this->nextLink;?>"/>
<?php
}
?>
<?php
if($this->linkRss!='') echo $this->linkRss;
else
{
?>
<link rel="alternate" title="RSS - VJCamera"  href="<?php echo Url::createUrl('home/rss');?>" type="application/rss+xml" />    
<?php
}
?>
<meta name="robots" content="<?php echo $this->metaIndex;?>,<?php echo $this->metaFollow;?>" />

<meta name="revisit-after" content="1 days"/>
<meta name="placename" content="Việt Nam" />
<meta name="author" content="vjcamera.com" />
<meta name="owner" content="vjcamera.com" />
<meta name="generator" content="Cửa hàng bán buôn, bán lẻ hàng chính hãng Camera Canon, Fujifilm..." />
<meta name="distribution" content="Global" />
<meta name="COPYRIGHT" content="vjcamera.com - Cửa hàng bán buôn, bán lẻ hàng chính hãng Camera Canon, Fujifilm..." />
<link rel="index" title="Cửa hàng bán buôn, bán lẻ hàng chính hãng Camera Canon, Fujifilm..." href="http://vjcamera.com" />
<link rel="icon" href="<?php  echo Yii::app()->params['static_url']; ?>/images/favico.ico" />
<?php
//Cart
if($controller_id=='cart' || $controller_id=='bill')
{
	?>
	<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_cart.css">
    <?php
}

if(($controller_id=='bList' && $action_id=='dealList') || ($controller_id=='access' && $action_id=='dealAccess'))
{
	?>
	<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_deal_list.css">
    <?php
}
if($controller_id=='bList' && $action_id=='deal')
{
	?>
	<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_deal.css">
    <?php
}
if(($action_id=='index' && $controller_id=='bList') || ($action_id=='index' && $controller_id=='access'))
{
	?>
	<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_cat.css">
    <?php
}
if((($action_id=='cat' || $action_id=='search' || $action_id=='searchTop') && $controller_id=='bList') || (($action_id=='cat' || $action_id=='search' || $action_id=='searchTop') && $controller_id=='access'))
{
	?>
	<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_cat_filter.css">
    <?php
}
if(($action_id=='index' && $controller_id=='home') || ($action_id=='index' && $controller_id=='bList'))
{
	?>
	<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet.css">
	<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_002.css">
    <?php
}
if(($action_id=='detail' && $controller_id=='access') || ($action_id=='detail' && $controller_id=='bList') )
{
	?>
	<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_detail.css">
    <?php
}
?>
<?php	
	if($action_id=='contact')
	{
		?>
		<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_cat.css">
		<?php
	}
?>
<link href="<?php  echo Yii::app()->params['static_url']; ?>/images/appboy.css" rel="stylesheet">
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/js_v1.js"></script>
<!--<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/jquery.cookie.js"></script>-->
<?php if(($controller_id=='access' && $action_id=='detail') || ($controller_id=='bList' && $action_id=='detail') || ($controller_id=='bList' && $action_id=='sale')) { ?>
<script>
(function() {
	var _onDemandHash = {}, _onDemandURL;

	// status codes - based on XMLHttpRequest.readyState ( see: https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest#Properties)
	var UNSENT = 0,
		LOADING = 3,
		DONE = 4;

	
	var lazyLoad = {
		js : function(url,main,cb){


			var isMainJs = (main === true);
			if(!isMainJs){
				cb = main;
				if(document.jsState === "loading"){
					setTimeout(function(){
						lazyLoad.js(url,cb);
					},5);
					return;
				}
			}else{
				document.jsState = "loading";
			}
			
			lazyLoad.appendScript(url, cb, isMainJs);
		},
		jsOnReady: function(url, cb) {
			lazyLoad.onLoad(function(){
				lazyLoad.appendScript(url, cb);
			})
		},
		css : function(url){
			var link = document.createElement("link");
			link.href=url;
			link.rel="stylesheet";link.type="text/css";
			var a = document.getElementsByTagName("link")[0];
			a.parentNode.insertBefore(link,a);
		},
		onLoad : function(cb){
			if(document.readyState == "complete"){
				cb();
			}else{
				if(window.addEventListener)window.addEventListener("load",cb,false);
				else window.attachEvent("onload",cb);
			}	
		},
		lazyJs : function(url,main,cb){
			if(main === true)document.jsState = "loading";
			lazyLoad.onLoad(function(){
				lazyLoad.js(url,main,cb);
			});
		},
		lazyCss : function(url, delay){
			delay = delay || 0;
			lazyLoad.onLoad(function(){
				setTimeout(function(){
					lazyLoad.css(url);
				}, delay)
			});
		},
		lazyRunJs : function(func){
			var callOnTime = function(){
				if(document.jsState === "loading"){
					setTimeout(function(){
						lazyLoad.lazyRunJs(func);
					},5);
					return;
				}else{
					func();
				}
			}
			
			lazyLoad.onLoad(callOnTime);
		},
		appendScript: function(url, cb, isMainJs) {
			var h=document.getElementsByTagName("head")[0],d=false,s=document.createElement("script");
			
			s.src=url;
			s.onload=s.onreadystatechange=function(){
				if(!d&&(!this.readyState||this.readyState=="loaded"||this.readyState=="complete")){
					d=true;
					if(isMainJs) document.jsState = "complete";
					if(typeof cb==='function'){
						cb();
					}
				}
			};
			h.appendChild(s);
		},
		setOdUrl : function(url) {
			_onDemandURL = url;
		},
		onDemand : function(moduleName) {

			// fail if _onDemandURL is undefined
			if(!_onDemandURL){
				throw "_onDemandURL in not yet defined";
			}
			
			var record = _onDemandHash[moduleName];

			//create a record if it doesn't exist
			if(! record){
				record = _onDemandHash[moduleName] = {
					"readyState" : UNSENT
				};
				this.js( _onDemandURL + moduleName , function() {
					record.readyState = DONE;
					if(record.deferred){
						record.deferred.resolve();
					}
				});
				record.readyState = LOADING;
			}

				
			// if jQuery.Deferred is available; use it.
			if( !record.deferred && jQuery && jQuery.Deferred ){
				record.deferred = new jQuery.Deferred;
				/*
					It is possible (however unlikely) that jQuery.Deferred will become
					available between the first and second requests for the same module.
					In that case we want to resolve the deferred immidiately
				*/
				if(record.readyState === DONE){
					record.deferred.resolve();
				}
			}
				
			return record.deferred || null;			
		},
		prefetch : function(urls){
			if(!urls || !urls.length)return;
			if(typeof urls === "string")urls = [urls];
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function(){
				if(xhr.readyState === 4){
					loader.prefetch(urls);
				}
			}
			xhr.open("GET",urls.splice(0,1),true);
			xhr.send();
		}
	}

	if(! window.lazyLoad){
		window.lazyLoad = lazyLoad;
	}

})();
</script>
<script>
	mainItemSource = "REG";
	mainSkuNum = "821151";
	cartPage = false;
	var BH = BH || {};
	BH.globals = BH.globals || {};
	BH.user = BH.user || {};
	BH.globals.detailPageGlobals = BH.globals.detailPageGlobals || {};
	BH.globals.mainItemSku = "821151";
	BH.globals.mainItemIs = "REG";
	BH.globals.detailPageGlobals.mainItemSku = "821151"; 
	BH.globals.detailPageGlobals.mainItemIs = "REG";
	BH.globals.detailPageGlobals.mainItemSkuForReviews = "821151";
	BH.user.email = '';

	BH.globals.detailPageGlobals.ABTestVersion = null; // default
	
</script>
<script type="text/javascript">
	var detailMLT = {
			Product_images: "Product images",
			customerPhotos: "Customer Photos",
			recAccessories: "Recommended Accessories"
	};
</script>
<script src="<?php  echo Yii::app()->params['static_url']; ?>/images/javascripts.js"></script>
<?php } ?>