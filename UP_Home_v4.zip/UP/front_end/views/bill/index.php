<?php
$this->renderPartial('_header') ;
?>
<div class="t-main clearfix">
    <svg xmlns="http://www.w3.org/2000/svg" style="display:none;">
        <symbol id="questionmarks" viewBox="0 0 108 108">
            <g>
                <path d="M54,8c25.1,0,45.6,20.2,46,45.4c0.3,25.4-20,46.3-45.4,46.6c-0.2,0-0.4,0-0.6,0C28.9,100,8.3,79.8,8,54.6C7.7,29.2,28,8.3,53.4,8C53.6,8,53.8,8,54,8 M54,0c-0.2,0-0.5,0-0.7,0C23.5,0.4-0.4,25,0,54.7C0.2,69,5.9,82.4,16.1,92.5C26.3,102.5,39.7,108,54,108c0.2,0,0.5,0,0.7,0c29.8-0.4,53.7-24.9,53.3-54.7c-0.2-14.3-5.9-27.7-16.1-37.7C81.7,5.5,68.3,0,54,0L54,0z"></path>
            </g>
            <path d="M53.2,82L53,82c-3.9-0.1-6.7-3-6.6-6.9c0.1-3.8,2.9-6.5,6.7-6.5l0.2,0c4,0.1,6.7,3,6.6,6.9C59.9,79.3,57.1,82,53.2,82z"></path>
            <path d="M69.7,49.3c-0.9,1.3-2.9,2.9-5.5,4.9l-2.8,1.9c-1.5,1.2-2.5,2.3-2.8,3.4c-0.3,0.9-0.4,1.1-0.4,2.9l0,0.5H47.4l0-0.9c0.1-3.7,0.2-5.9,1.8-7.7c2.4-2.8,7.8-6.3,8-6.4c0.8-0.6,1.4-1.2,1.9-1.9c1.1-1.6,1.6-2.8,1.6-4c0-1.7-0.5-3.2-1.5-4.6c-0.9-1.3-2.7-2-5.3-2c-2.6,0-4.3,0.8-5.4,2.5c-1.1,1.7-1.6,3.5-1.6,5.3v0.5H35.9l0-0.5c0.3-6.8,2.7-11.6,7.2-14.5c2.8-1.8,6.3-2.7,10.4-2.7c5.3,0,9.9,1.3,13.4,3.9c3.6,2.6,5.4,6.5,5.4,11.6C72.4,44.3,71.5,46.9,69.7,49.3z"></path>
        </symbol>
        <symbol id="info-light" viewBox="0 0 108 108">
            <path d="M91.912 15.549C81.742 5.5 68.3 0 54 0c-0.244 0-0.487 0.001-0.732 0.005C23.507 0.403-0.391 24.9 0 54.7 C0.196 69 5.9 82.4 16.1 92.45C26.26 102.5 39.7 108 54 108c0.244 0 0.485-0.001 0.73-0.005 c29.771-0.4 53.669-24.948 53.273-54.721C107.804 39 102.1 25.6 91.9 15.549z M54.616 100 C54.406 100 54.2 100 54 100c-25.118 0-45.65-20.197-45.987-45.381C7.667 29.2 28 8.3 53.4 8 C53.595 8 53.8 8 54 8c25.116 0 45.6 20.2 46 45.381C100.334 78.8 80 99.7 54.6 99.996z"></path>
            <path d="M55.768 36.568c5.293 0 8.396-3.584 8.396-7.461c0-3.102-1.381-5.815-6.057-5.815c-6.154 0-8.753 4.264-8.753 7.4 C49.231 34.3 51.3 36.6 55.8 36.568z"></path>
            <path d="M56.125 73.404c-0.742 0-1.063-0.969-0.318-3.779l4.199-15.9c1.596-5.814 1.064-9.594-2.131-9.594 c-3.832 0-12.771 3.808-20.544 10.299l1.598 2.617c2.449-1.648 6.598-3.322 7.557-3.322c0.744 0 0.6 1 0 3.393l-3.666 15.1 c-2.236 8.5 0.1 10.5 3.3 10.467c3.193 0 11.443-2.912 19.003-10.471l-1.811-2.424 C60.227 72.2 57.1 73.4 56.1 73.404z"></path>
        </symbol>
        <symbol id="questionmarks" viewBox="0 0 108 108">
            <g>
                <path d="M54,8c25.1,0,45.6,20.2,46,45.4c0.3,25.4-20,46.3-45.4,46.6c-0.2,0-0.4,0-0.6,0C28.9,100,8.3,79.8,8,54.6C7.7,29.2,28,8.3,53.4,8C53.6,8,53.8,8,54,8 M54,0c-0.2,0-0.5,0-0.7,0C23.5,0.4-0.4,25,0,54.7C0.2,69,5.9,82.4,16.1,92.5C26.3,102.5,39.7,108,54,108c0.2,0,0.5,0,0.7,0c29.8-0.4,53.7-24.9,53.3-54.7c-0.2-14.3-5.9-27.7-16.1-37.7C81.7,5.5,68.3,0,54,0L54,0z"></path>
            </g>
            <path d="M53.2,82L53,82c-3.9-0.1-6.7-3-6.6-6.9c0.1-3.8,2.9-6.5,6.7-6.5l0.2,0c4,0.1,6.7,3,6.6,6.9C59.9,79.3,57.1,82,53.2,82z"></path>
            <path d="M69.7,49.3c-0.9,1.3-2.9,2.9-5.5,4.9l-2.8,1.9c-1.5,1.2-2.5,2.3-2.8,3.4c-0.3,0.9-0.4,1.1-0.4,2.9l0,0.5H47.4l0-0.9c0.1-3.7,0.2-5.9,1.8-7.7c2.4-2.8,7.8-6.3,8-6.4c0.8-0.6,1.4-1.2,1.9-1.9c1.1-1.6,1.6-2.8,1.6-4c0-1.7-0.5-3.2-1.5-4.6c-0.9-1.3-2.7-2-5.3-2c-2.6,0-4.3,0.8-5.4,2.5c-1.1,1.7-1.6,3.5-1.6,5.3v0.5H35.9l0-0.5c0.3-6.8,2.7-11.6,7.2-14.5c2.8-1.8,6.3-2.7,10.4-2.7c5.3,0,9.9,1.3,13.4,3.9c3.6,2.6,5.4,6.5,5.4,11.6C72.4,44.3,71.5,46.9,69.7,49.3z"></path>
        </symbol>
        <symbol id="trash-can" viewBox="0 0 11 12">
            <g>
                <rect x="3" y="5" width="1" height="4"></rect>
                <rect x="5" y="5" width="1" height="4"></rect>
                <rect x="7" y="5" width="1" height="4"></rect>
                <path d="M9,2H2H0v1h1v8c0,0.6,0.4,1,1,1h7c0.6,0,1-0.4,1-1V3h1V2H9z M9,11H2V3h7V11z"></path>
            </g>
            <path d="M7,0H4C3.4,0,3,0.4,3,1v1c0,0.6,0.4,1,1,1h3c0.6,0,1-0.4,1-1V1C8,0.4,7.6,0,7,0z M7,2H4V1h3V2z"></path>
        </symbol>
        <symbol id="move" viewBox="0 0 59.6 39">
            <polygon points="39.6,39 59.6,19.5 39.6,0 39.6,12 21.3,12 21.3,27 39.6,27 "></polygon>
            <rect class="st0" width="14.3" height="39"></rect>
        </symbol>
        <symbol id="accessories" viewBox="0 0 100 90">
            <path d="M90,15h-5v75h5c5.5,0,10-4.5,10-10V25C100,19.5,95.5,15,90,15z M0,25v55c0,5.5,4.5,10,10,10h5V15h-5C4.5,15,0,19.5,0,25z M67,4.5C63.6,3,58.2,0,50,0S36.4,3,33,4.5V15H22v75h56V15H67V4.5z M61,15H39V8.3C41.7,7.2,45.5,6,50,6s8.3,1.2,11,2.3V15z"></path>
        </symbol>
        <symbol id="savings" viewBox="0 0 18.7 22.1">
            <path d="M0.3,14.3L8.6,6c0.5-0.5,1.4-0.9,2-0.9L15,4.9c0.2,0,0.4,0,0.6,0c0.2-0.2,0.3-0.4,0.4-0.5c0.3-0.3,0.5-0.6,0.7-0.9c0.8-1.1,0.6-2.1,0.6-2c0,0,0.1,0.2,0.1,0.6c0,0.4-0.1,1-0.4,1.6c-0.2,0.3-0.4,0.6-0.6,1c-0.1,0.1-0.2,0.3-0.3,0.4C16.4,5.3,16.8,5.6,17,6c-0.1,0.1-0.2,0.2-0.3,0.3c0,0,0,0,0,0c-0.1,0.1-0.3,0.2-0.4,0.2c-0.1,0-0.1,0-0.2,0c0-0.1-0.1-0.1-0.1-0.2c-0.1-0.1-0.2-0.1-0.3-0.2c0,0.3,0,0.5,0.2,0.6c0.3,0.2,0.7,0.2,1-0.1c0.4-0.3,0.6-0.7,0.9-1.1c0.2-0.4,0.3-0.8,0.4-1.3c0.2-0.9,0.2-1.7,0.12.3C18,0.6,17.3,0,17.3,0c0,0,0.9,0.5,1.2,1.9c0.2,0.7,0.3,1.5,0.2,2.5c-0.1,0.9-0.5,2-1.5,2.8c-0.5,0.4-1.3,0.5-1.8,0.1C15.1,7,15,6.6,15,6.3c0-0.1,0-0.2,0-0.3c-0.2,0-0.4,0.1-0.6,0.3c-0.4,0.4-0.4,1,0,1.4C14.8,8,15.4,8,15.8,7.7c0.1,0,0.3,0.1,0.4,0.1c0.3,0,0.7-0.1,1-0.3L17,11.5c0,0.7-0.4,1.6-0.9,2l-8.3,8.3c-0.5,0.5-1.2,0.5-1.7,0l-2.9-2.9L0.3,16C-0.1,15.5-0.1,14.8,0.3,14.3z M8.2,18.6l1,1l0.5-0.5l-1-1L8.2,18.6z M6.8,17.1l1,1l0.5-0.5l-1-1L6.8,17.1zM5.4,15.7l1,1l0.5-0.5l-1-1L5.4,15.7z M3.9,14.3l1,1l0.5-0.5l-1-1L3.9,14.3z M2.5,12.9l1,1L4,13.4l-1-1L2.5,12.9z"></path>
        </symbol>
        <symbol id="printer" viewBox="0 0 98 85">
            <path d="M6.5 25h85c2.854 0 2.385-3.04 0.965-3.535C91.045 21 75.2 15 72.5 15H68V0H30v15h-4.5 c-2.75 0-18.545 5.969-19.965 6.465C4.115 22 3.6 25 6.5 25z M92.5 30.5h-87c-2.75 0-5.5 3.25-5.5 6V54c0 2.8 2.8 6 5.5 6 h9.912L11 85h76l-4.412-25H92.5c2.75 0 5.5-3.25 5.5-6V36.5C98 33.8 95.2 30.5 92.5 30.5z M21 75l7-32.5h42L77 75H21z"></path>
        </symbol>
        <symbol id="info-dark" viewBox="0 0 20 20">
            <path d="M10,0.4c-5.303,0-9.601,4.298-9.601,9.6c0,5.303,4.298,9.601,9.601,9.601c5.301,0,9.6-4.298,9.6-9.601 C19.6,4.698,15.301,0.4,10,0.4z M10.896,3.866c0.936,0,1.211,0.543,1.211,1.164c0,0.775-0.62,1.492-1.679,1.492 c-0.886,0-1.308-0.445-1.282-1.182C9.146,4.719,9.665,3.866,10.896,3.866z M8.498,15.75c-0.64,0-1.107-0.389-0.66-2.094l0.733-3.025 c0.127-0.484,0.148-0.678,0-0.678c-0.191,0-1.022,0.334-1.512,0.664L6.74,10.094c1.555-1.299,3.343-2.061,4.108-2.061 c0.64,0,0.746,0.756,0.427,1.92l-0.84,3.18c-0.149,0.562-0.085,0.756,0.064,0.756c0.192,0,0.82-0.232,1.438-0.719l0.362,0.486 C10.786,15.168,9.137,15.75,8.498,15.75z"></path>
        </symbol>
        <symbol id="info-light" viewBox="0 0 108 108">
            <path d="M91.912 15.549C81.742 5.5 68.3 0 54 0c-0.244 0-0.487 0.001-0.732 0.005C23.507 0.403-0.391 24.9 0 54.7 C0.196 69 5.9 82.4 16.1 92.45C26.26 102.5 39.7 108 54 108c0.244 0 0.485-0.001 0.73-0.005 c29.771-0.4 53.669-24.948 53.273-54.721C107.804 39 102.1 25.6 91.9 15.549z M54.616 100 C54.406 100 54.2 100 54 100c-25.118 0-45.65-20.197-45.987-45.381C7.667 29.2 28 8.3 53.4 8 C53.595 8 53.8 8 54 8c25.116 0 45.6 20.2 46 45.381C100.334 78.8 80 99.7 54.6 99.996z"></path>
            <path d="M55.768 36.568c5.293 0 8.396-3.584 8.396-7.461c0-3.102-1.381-5.815-6.057-5.815c-6.154 0-8.753 4.264-8.753 7.4 C49.231 34.3 51.3 36.6 55.8 36.568z"></path>
            <path d="M56.125 73.404c-0.742 0-1.063-0.969-0.318-3.779l4.199-15.9c1.596-5.814 1.064-9.594-2.131-9.594 c-3.832 0-12.771 3.808-20.544 10.299l1.598 2.617c2.449-1.648 6.598-3.322 7.557-3.322c0.744 0 0.6 1 0 3.393l-3.666 15.1 c-2.236 8.5 0.1 10.5 3.3 10.467c3.193 0 11.443-2.912 19.003-10.471l-1.811-2.424 C60.227 72.2 57.1 73.4 56.1 73.404z"></path>
        </symbol>
        <symbol id="check" viewBox="0 0 14.276 14.974">
            <path d="M13.573,0.225c-0.7-0.435-1.619-0.221-2.056,0.478L5.194,10.856L2.68,7.536C2.183,6.88,1.249,6.75,0.591,7.247 C-0.066,7.744-0.195,8.68,0.302,9.334l3.823,5.05c0.283,0.372,0.723,0.59,1.189,0.59c0.022,0,0.045,0,0.068,0c0.491-0.023,0.938-0.285,1.198-0.702l7.47-11.993C14.486,1.58,14.271,0.66,13.573,0.225z"></path>
        </symbol>
        <symbol id="plus" viewBox="0 0 3948.6 3948.6">
            <path d="M3744.3,1633.9H2314.7V204.2c0-188-152.4-204.2-340.4-204.2c-188,0-340.4,16.2-340.4,204.2v1429.6H204.2C16.2,1633.9,0,1786.3,0,1974.3c0,188,16.2,340.4,204.2,340.4h1429.6v1429.6c0,188,152.4,204.2,340.4,204.2c188,0,340.4-16.2,340.4-204.2V2314.7h1429.6c188,0,204.2-152.4,204.2-340.4C3948.6,1786.3,3932.3,1633.9,3744.3,1633.9z"></path>
        </symbol>
        <symbol id="help-dark" viewBox="0 0 92 92">
            <path d="M45.4,0C20,0.3-0.3,21.2,0,46.6C0.3,72,21.2,92.3,46.6,92C72,91.7,92.3,70.8,92,45.4C91.7,20,70.8-0.3,45.4,0z M45.3,74L45,74c-3.9-0.1-6.7-3-6.6-6.9c0.1-3.8,2.9-6.5,6.7-6.5l0.2,0c4,0.1,6.7,3,6.6,6.9C51.9,71.3,49.1,74,45.3,74z M61.7,41.3c-0.9,1.3-2.9,2.9-5.5,4.9l-2.8,1.9c-1.5,1.2-2.5,2.3-2.8,3.4c-0.3,0.9-0.4,1.1-0.4,2.9l0,0.5H39.4l0-0.9c0.1-3.7,0.2-5.9,1.8-7.7c2.4-2.8,7.8-6.3,8-6.4c0.8-0.6,1.4-1.2,1.9-1.9c1.1-1.6,1.6-2.8,1.6-4c0-1.7-0.5-3.2-1.5-4.6c-0.9-1.3-2.7-2-5.3-2c-2.6,0-4.3,0.8-5.4,2.5c-1.1,1.7-1.6,3.5-1.6,5.3v0.5H27.9l0-0.5c0.3-6.8,2.7-11.6,7.2-14.5c2.8-1.8,6.3-2.7,10.4-2.7c5.3,0,9.9,1.3,13.4,3.9c3.6,2.6,5.4,6.5,5.4,11.6C64.4,36.3,63.5,38.9,61.7,41.3z"></path>
        </symbol>
        <symbol id="x" viewBox="0 0 16 16">
            <polygon points="16,1.8 14.2,0 8,6.2 1.8,0 0,1.8 6.2,8 0,14.2 1.8,16 8,9.8 14.2,16 16,14.2 9.8,8 "></polygon>
        </symbol>
        <symbol id="lock" viewBox="0 0 21.5 9.4">
            <path d="M17,10V7c0,0,0-0.1,0-0.2C17,5.1,16.7,0,10,0C3.4,0,3,5,3,6.7C3,6.9,3,7,3,7v3H0v14h20V10H17z M11,17.7V21H9v-3.3c-0.6-0.3-1-1-1-1.7c0-1.1,0.9-2,2-2c1.1,0,2,0.9,2,2C12,16.7,11.6,17.4,11,17.7z M14.6,10H5.4V6.6c0-1,0-4.6,4.6-4.6c4.6,0,4.6,3.6,4.6,4.6V10z"></path>
        </symbol>
        <symbol id="envelope" viewBox="0 0 90 58">
            <path d="M2.97 5.428c2.441 1.3 36.2 19.5 37.5 20.144c1.259 0.7 2.9 1 4.5 1.002s3.272-0.326 4.531-1.002 C50.789 24.9 84.6 6.7 87 5.428C89.473 4.1 91.8 0 87.3 0H2.703C-1.781 0 0.5 4.1 3 5.428z M88.064 15.4 c-2.773 1.447-36.835 19.259-38.533 20.144c-1.699 0.887-2.889 1.002-4.531 1.002s-2.832-0.115-4.531-1.002 C38.771 34.7 4.7 16.9 1.9 15.428C-0.017 14.4 0 15.6 0 16.526s0 36.7 0 36.679C0 55.3 2.8 58 5 58h80.082 C87.208 58 90 55.3 90 53.205c0 0 0-35.757 0-36.679S90.019 14.4 88.1 15.428z"></path>
        </symbol>
    </svg>
    <div id="tContent">
        <!--B2B print Logo-->
        <!--End B2B print Logo-->
        <div class="new-page-width OpenSans-400-normal c13" data-selenium="tMain">
            <div class="tBlock" data-selenium="tBlock">
                <div class="cart-top" style="margin-top:85px;">
                	<hr style="color:red;" />
                	<div class="fs30" style="width:100%; padding-top:30px;"><center>
                    HÓA ĐƠN BÁN HÀNG<br />
                   <em class="fs20"> (Kèm phiếu bảo hành)</em>
                    </center></div>
                    <div class="cart-header-left" style="width:45%;">
                        <span class="c1 light" style="line-height:20px;"><span>
                        Họ và tên: <strong><?php echo $bill_info['fullname'];?></strong>
                        <br />
                        Số điện thoại: <strong><?php echo $bill_info['mobile'];?></strong>
                        <br />
                        Địa chỉ: <strong><?php echo $bill_info['address'];?></strong>
                        <br />
                        Ngày: <?php echo date('d/m/Y', $bill_info['create_date']);?>
                        </span> </span>
                    </div>
                    <!--
                    <div style="width:35%;float:right; padding-top: 16px;">
                        <span class="c1 light" style="line-height:20px;"><span>Ghi chú: <input style="height:30px;width:300px;" type="text"></span> </span>
                    </div>
                    -->
                    <br class="clearfix">
                </div>
                <!-- .cart-top -->
                <div id="cartWrapper" class="borderBoxBlock clearfix" data-selenium="cartWrapper" data-itemsincart="2">
                    <div class="cart-items" style="width:100%;">
                        <div id="cartMessages" class="clearfix" data-selenium="cartMessages">

                        </div>
                        <div class="itemInCart" style="background:none; box-shadow:none; margin-bottom:0; padding:0;">
                            <div class="table">
                                <div class="table-row">
                                    <div class="item-details">
                                        <div class="table">
                                            <div class="item-image">
                                               &nbsp;
                                            </div>
                                            <!-- END .table-cell.item-image -->
                                            <div class="table-row">
                                                <div class="item-title"> 
                                                <strong class="fs18">Tên sản phẩm</strong>
                                                </div>
                                                <!-- END .table-cell.item-title -->
                                                <div class="stock-msg">
                                                    <strong class="fs18">Thời gian bảo hành</strong>
                                                </div>
                                                <div class="item-qty">
                                                   <strong class="fs18">SL</strong>
                                                </div>
                                                <!-- END .table-cell.item-qty -->
                                                <div class="fs18 item-price">
                                                    <strong>Giá tiền</strong>
                                                </div>
                                                
                                                
                                            </div>
                                        </div>
                                        <!-- END .item-details > .table -->
                                    </div>
                                    <!-- END .table-cell.item-details -->
                                </div>
                                <!-- END .itemInCart > .table > .table-row -->
                                <br class="clearfix">
                            </div>
                            
                        </div>
                        <!-- start bundled item - ADM -->
                        <!-- end bundled item - ADM -->
                        <?php
						$total_prices = 0;
						if($camera)
						foreach($camera as $row)
						{
							$src_img = Common::getImage($row['picture'], 'camera', '', 'small');
							$link_detail = Url::createUrl('bList/detail', array('camera_id'=>$row['id'], 'alias'=>$row['alias']));
							$product_type = $row['title'];
							$total_prices += $row['price_buy']*1;
							$list_access_free = isset($access_free[$row['id']]) ? $access_free[$row['id']]: array();
							?>
                            <div class="itemInCart js-cartItem" data-selenium="itemInCart">
                                <div class="table">
                                    <div class="table-row">
                                        <div class="item-details">
                                            <div class="table">
                                                <div class="item-image">
                                                    <!--item image-->
                                                    <span class="itemImg" data-selenium="itemImg"> <a target="_blank" href="<?php echo $link_detail;?>" data-selenium="smallImgLink"><img data-selenium="smallImgItemLink" src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>" border="0"></a></span>
                                                    <!--end item image-->
                                                </div>
                                                <!-- END .table-cell.item-image -->
                                                <div class="table-row">
                                                    <div class="item-title">
                                                    <a onmousemove="$(this).next().show();" target="_blank" class="itemName underline-on-hover c31 bold fs16" data-selenium="itemName" href="<?php echo $link_detail;?>"><?php echo $row['title'];?></a><a onclick="removeOneBill(<?php echo $row['id'];?>, 0, <?php echo $bill_info['id']?>);" href="javascript:" style="display:none;" onmouseout="$(this).hide();">Xóa</a>
                                                    <?php
													if($row['seri']!='') echo 'Seri: '.$row['seri'].'<br>';
													if(!empty($list_access_free))
													{
														$total_value = 0;
														$list_html = '';
														foreach($list_access_free as $row2)
														{
															$link_access = Url::createUrl('access/detail', array('access_id'=>$row2['id'], 'alias'=>$row2['title']));
															$total_value += $row2['price'];
															$list_html .= '<a href="'.$link_access.'" target="_blank">'.$row2['title'].'</a>, ';
														}
														$list_html = rtrim($list_html, ', ');
														echo '<span>Quà tặng: <strong>'.Common::formatNumber2($total_value).'</strong> VND</span>';
														echo '<span>'.$list_html.'</span>';
													}
                                                    ?>
                                                    </div>
                                                    <!-- END .table-cell.item-title -->
                                                    <div class="stock-msg">
                                                        <p class="bold c41"> <span class="c29 fs16 bold" data-selenium="inStock">
														<?php echo $row['time_bh'];?>&nbsp;
                                                        </span></p>
                                                        <p class="fs11"> </p>
                                                    </div>
                                                    <div class="item-qty">
                                                        <span class="qty qty-input-wrap">
                                                            <input class="input js-qty-input" maxlength="3" size="2" data-mq="50" type="text" value="1">
														</span>
                                                    </div>
                                                    <!-- END .table-cell.item-qty -->
                                                    <div class="item-qty" style="width:16%;">
                                                        <span class="qty qty-input-wrap">
                                                        	<input class="input js-qty-input" style="width:100%; float:left; width:79%;" type="text" value="<?php echo Common::formatNumber2($row['price_buy']);?>"><strong style="float:left;width: 18%; margin-top: 13px; margin-left: 2px;">VND</strong>
                                                            <input type="hidden" class="price_buy" value="<?php echo $row['price_buy'];?>" />
                                                        </span>
													</div>
                                                    <!-- END .table-cell.item-price -->
                                                    <!--
                                                    <div class="item-right-actions">
                                                    	<a href="javascript:" class="remove-item js-remove-item" data-selenium="cartRemoveLink" onClick="removeOneBill(<?php echo $row['id']?>, 0, <?php echo $bill_id;?>);">
                                                        <svg class="delete-item">
                                                            <use xlink:href="#trash-can"></use>
                                                        </svg>
                                                        </a> 
                                                       
													</div>
                                                    -->
                                                    <!-- END .table-cell.item-right-actions -->
                                                    
                                                </div>
                                            </div>
                                            <!-- END .item-details > .table -->
                                        </div>
                                        <!-- END .table-cell.item-details -->
                                    </div>
                                    <!-- END .itemInCart > .table > .table-row -->
                                    <br class="clearfix">
                                </div>
                                
                            </div>
                            <?php
						}
						
						if($access)
						foreach($access as $row)
						{
							$src_img = Common::getImage($row['picture'], 'access', '', 'small');
							$link_detail = Url::createUrl('access/detail', array('access_id'=>$row['id'], 'alias'=>$row['alias']));
							$total_prices += $row['price_buy']*1;
							?>
                            <div class="itemInCart js-cartItem" data-selenium="itemInCart">
                                <div class="table">
                                    <div class="table-row">
                                        <div class="item-details">
                                            <div class="table">
                                                <div class="item-image">
                                                    <!--item image-->
                                                    <span class="itemImg" data-selenium="itemImg"> <a target="_blank" href="<?php echo $link_detail;?>" data-selenium="smallImgLink"><img data-selenium="smallImgItemLink" src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>" border="0"></a> </span>
                                                    <!--end item image-->
                                                </div>
                                                <!-- END .table-cell.item-image -->
                                                <div class="table-row">
                                                    <div class="item-title"> <a onmousemove="$(this).next().show();" target="_blank" class="itemName underline-on-hover c31 bold fs16" data-selenium="itemName" href="<?php echo $link_detail;?>"><?php echo $row['title'];?></a><a onclick="removeOneBill(<?php echo $row['id'];?>, 1, <?php echo $bill_info['id']?>);" href="javascript:" style="display:none;" onmouseout="$(this).hide();">Xóa</a>
                                                        
                                                    </div>
                                                    <!-- END .table-cell.item-title -->
                                                    <div class="stock-msg">
                                                        <p class="bold c41"> <span class="c29 fs16 bold" data-selenium="inStock">
                                                        <?php echo $row['time_bh'];?>&nbsp;
                                                        </span></p>
                                                        <p class="fs11"> </p>
                                                    </div>
                                                    <div class="item-qty">
                                                        <span class="qty qty-input-wrap">
                                                            <input class="input js-qty-input" maxlength="3" size="2" data-mq="50" type="text" value="1">
														</span>
                                                    </div>
                                                    <!-- END .table-cell.item-qty -->
                                                    <!--
                                                    <div class="item-price" style="width:16%;">
                                                        <span class="">
                                                        	<?php
															echo Common::formatNumber2($row['price_buy']);
                                                            ?>
                                                            VND
                                                        </span>
													</div>
                                                    -->
                                                    <div class="item-qty" style="width:16%;">
                                                        <span class="qty qty-input-wrap">
                                                        	<input class="input js-qty-input" style="width:100%; float:left; width:79%;" type="text" value="<?php echo Common::formatNumber2($row['price_buy']);?>"><strong style="float:left;width: 18%; margin-top: 13px; margin-left: 2px;">VND</strong>
                                                            <input type="hidden" class="price_buy" value="<?php echo $row['price_buy'];?>" />
                                                        </span>
													</div>
                                                    <!--
                                                    <div class="item-right-actions">
                                                    	<a href="javascript:" class="remove-item js-remove-item" data-selenium="cartRemoveLink" onClick="removeOneBill(<?php echo $row['id']?>, 1, <?php echo $bill_id;?>);">
                                                        <svg class="delete-item">
                                                            <use xlink:href="#trash-can"></use>
                                                        </svg>
                                                        </a>
													</div>
                                                    -->
                                                </div>
                                            </div>
                                            <!-- END .item-details > .table -->
                                        </div>
                                        <!-- END .table-cell.item-details -->
                                    </div>
                                    <!-- END .itemInCart > .table > .table-row -->
                                    <br class="clearfix">
                                </div>
                                <!-- END .itemInCart > .table -->
                                
                            </div>
                            <?php
						}
						
						//Color
						if($colors)
						foreach($colors as $row)
						{
							$src_img = Common::getImage($row['picture'], 'access', '', 'small');
							$link_detail = Url::createUrl('access/detail', array('access_id'=>$row['access_id'], 'color_id'=>$row['id'], 'alias'=>$row['alias']));
							$total_prices += $row['price_buy']*1;
							?>
                            <div class="itemInCart js-cartItem" data-selenium="itemInCart">
                                <div class="table">
                                    <div class="table-row">
                                        <div class="item-details">
                                            <div class="table">
                                                <div class="item-image">
                                                    <!--item image-->
                                                    <span class="itemImg" data-selenium="itemImg"> <a target="_blank" href="<?php echo $link_detail;?>" data-selenium="smallImgLink"><img data-selenium="smallImgItemLink" src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>" border="0"></a> </span>
                                                    <!--end item image-->
                                                </div>
                                                <!-- END .table-cell.item-image -->
                                                <div class="table-row">
                                                    <div class="item-title"> <a onmousemove="$(this).next().show();" target="_blank" class="itemName underline-on-hover c31 bold fs16" data-selenium="itemName" href="<?php echo $link_detail;?>"><?php echo $row['title'];?> (<?php echo $row['color'];?>)</a><a onclick="removeOneBill(<?php echo $row['id'];?>, 2, <?php echo $bill_info['id']?>);" href="javascript:" style="display:none;" onmouseout="$(this).hide();">Xóa</a>
                                                        
                                                    </div>
                                                    <!-- END .table-cell.item-title -->
                                                    <div class="stock-msg">
                                                        <p class="bold c41"> <span class="c29 fs16 bold" data-selenium="inStock">
                                                        <?php echo $row['time_bh'];?>&nbsp;
                                                        </span></p>
                                                        <p class="fs11"> </p>
                                                    </div>
                                                    <div class="item-qty">
                                                        <span class="qty qty-input-wrap">
                                                            <input class="input js-qty-input" maxlength="3" size="2" data-mq="50" type="text" value="1">
														</span>
                                                    </div>
                                                    <!-- END .table-cell.item-qty -->
                                                    <!--
                                                    <div class="item-price" style="width:16%;">
                                                        <span class="">
                                                        	<?php
															echo Common::formatNumber2($row['price_buy']);
                                                            ?>
                                                            VND
                                                        </span>
													</div>
                                                    -->
                                                    <div class="item-qty" style="width:16%;">
                                                        <span class="qty qty-input-wrap">
                                                        	<input class="input js-qty-input" style="width:100%; float:left; width:79%;" type="text" value="<?php echo Common::formatNumber2($row['price_buy']);?>"><strong style="float:left;width: 18%; margin-top: 13px; margin-left: 2px;">VND</strong>
                                                            <input type="hidden" class="price_buy" value="<?php echo $row['price_buy'];?>" />
                                                        </span>
													</div>
                                                    <!--
                                                    <div class="item-right-actions">
                                                    	<a href="javascript:" class="remove-item js-remove-item" data-selenium="cartRemoveLink" onClick="removeOneBill(<?php echo $row['id']?>, 2, <?php echo $bill_id;?>);">
                                                        <svg class="delete-item">

                                                            <use xlink:href="#trash-can"></use>
                                                        </svg>
                                                        </a> 
                                                        
													</div>
                                                    -->
                                                </div>
                                            </div>
                                            <!-- END .item-details > .table -->
                                        </div>
                                        <!-- END .table-cell.item-details -->
                                    </div>
                                    <!-- END .itemInCart > .table > .table-row -->
                                    <br class="clearfix">
                                </div>
                                <!-- END .itemInCart > .table -->                                
                                
                            </div>
                            <?php
						}
                        ?>
                        <div class="item-total-wrapper">
                            <div style="float:left; padding:20px;">
                                <p class="subL fs18 c1 bold"> <span class="priceTTL1 item-total-label">Nhân viên</span>
                                </p>
                            </div>
                            
                            <div class="item-total clearfix ">
                                <p class="subL fs18 c1 bold"> <span class="priceTTL1 item-total-label">Tổng:</span>
                                <span class="lPrice item-total-value "><span class="fs14"></span><span class="itemTTLprice">
                                <?php
                                echo Common::formatNumber2($total_prices);
                                ?>
                                VND
                                </span></span> </p>
                            </div>
                        </div>
                        <!--<div class="clearfix cart-id-number c2 OpenSans-600-normal" id="cart-id-number">Cart ID: #2083885387</div>-->
                    </div>
                    
                </div>
                
            </div>
        </div>
        
    </div>
</div>
<script>
function removeOneBill(product_id, product_type, bill_id)
{
	if(confirm('Bạn có chắc chắn muốn xóa sản phẩm hóa đơn?'))
	{
		$.ajax({
			url: '<?php echo Url::createUrl('ajax/removeOneBill');?>',
			type: "POST",
			data:({
				product_id:product_id,
				product_type:product_type,
				bill_id:bill_id
			}),
	
			success: function(resp){
				location.reload();
			}
	
		});
	}
}
function format_number(num)
{
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
	num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num*100+0.50000000001);
	cents = num%100;
	num = Math.floor(num/100).toString();
	if(cents<10)
	cents = "0" + cents;
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	num = num.substring(0,num.length-(4*i+3))+','+
	num.substring(num.length-(4*i+3));
	return (((sign)?'':'-') + num);
}

function removeCommas(str)
{
	while (str.search(",") >= 0) {
        str = (str + "").replace(',', '');
    }
    return str;
}

function updateTotalPrice()
{
	var total_price = 0;
	$('.price_buy').each(function(){
		var price_buy = parseFloat($(this).val());
		total_price = total_price + price_buy;
	});
	$('.itemTTLprice').html(format_number(total_price)+' VND');
	return total_price;
}
$(function(){

	$('.js-qty-input').keypress(function(){
		$(this).val(format_number($(this).val()));
		$(this).next().next().val(removeCommas($(this).val()));
		updateTotalPrice();
	});
	$('.js-qty-input').keyup(function(){
		$(this).val(format_number($(this).val()));
		$(this).next().next().val(removeCommas($(this).val()));
		updateTotalPrice();
	});
	$('.js-qty-input').keydown(function(){
		$(this).val(format_number($(this).val()));
		$(this).next().next().val(removeCommas($(this).val()));
		updateTotalPrice();
	});
});
</script>
<?php
$this->renderPartial('_footer') ;
?>