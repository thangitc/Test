<style>
.other-buying-options + #expertsWidget {
    border-top: 1px solid #ddd;
    margin-top: 15px;
}
#expertsWidget {
    text-align: center;
}
.experts-widget {
    display: inline-block;
    padding: 20px 0 25px;
}
.experts-widget-title {
    font-size: 18px;
    font-weight: 900;
    line-height: 22px;
}
.expert-widgets-contact-wrapper {
    display: table;
    margin: auto;
}
.contact-expert-title, .experts-widget-contact, .experts-widget-headshots, .experts-widget-img-circle {
    display: inline-block;
    vertical-align: bottom;
}
.experts-widget-contact {
    padding: 6px 0 0 6px;
    text-align: center;
}
.experts-widget-img-circle {
    border: 1px solid #dfdfdf;
    border-radius: 50%;
    height: 60px;
    overflow: hidden;
    width: 60px;
}
.experts-widget-img-circle img {
    max-width: 100%;
}
.contact-expert-title {
    font-size: 14px;
    line-height: 20px;
}
.contact-expert-email, .contact-expert-livechat, .contact-expert-telephone {
    color: #1a5888;
    float: left;
    font-size: 14px;
    text-decoration: none;
    vertical-align: middle;
}
.contact-expert-livechat::after, .contact-expert-telephone::after {
    color: #ccc;
    content: "|";
}
</style>
<div class="other-buying-options upper fs12" data-selenium="OtherBuyOpt">    
    <?php
    if(!empty($one_cheap))
	{
		$link_search = Url::createUrl('bList/search',array('cat_id'=>$one_cheap['cat_id'])).'?s=12350+3456'.$one_cheap['brand_id'].'+6789'.$one_cheap['model_id'];
		?>
        <p class="other-buying-option" data-selenium="essentailKits">
        	<a href="<?php echo $link_search;?>" target="_blank" class="c31 kits underline-on-hover">Hàng đã qua sử dụng giá từ </a>
        	<strong style="color:red;"><?php echo Common::formatNumber($one_cheap['price']);?> VNĐ</strong>
		</p>
        <?php
	}
	?>

    <?php
	if(!empty($contact))
	{
		?>
        <p class="other-buying-option" data-selenium="TradeIn"> <a target="_blank" href="<?php echo $contact['trade_in_link']?>" class="c31 underline-on-hover" data-selenium="trade-in"><?php echo $contact['trade_in_text'];?></a> </p>
        <?php
	}
    ?>
    
</div>
<?php if(!empty($contact)) { ?>
<div id="expertsWidget">
    <div class="experts-widget ">
        <div class="experts-widget-headshots">
            <div class="experts-widget-img-circle">
            <?php
			if($contact['avatar']!='')
			{
				$link_avatar = Common::getImage($contact['avatar'], 'avatar', '' ,'');
				?>
                <img class="experts-widget-headshot" src="<?php echo $link_avatar;?>"> 
                <?php
			}
            ?>
            	
            </div>
        </div>
        <div class="experts-widget-contact">
            <div class="experts-widget-title"><?php echo $contact['fullname'];?></div>
            <div class="contact-expert-title">Liên hệ để có giá tốt nhất</div>            
            <div class="expert-widgets-contact-wrapper">
            	<a class="contact-expert-livechat" href="javascript:" target="livechat"><span class="underline-on-hover">Live Chat</span></a> 
            	<span class="contact-expert-telephone">0965.505.515</span>
            	<a class="contact-expert-email js-openSlideInTray underline-on-hover" href="mailto:<?php echo $contact['email'];?>">Email</a> 
            </div>
        </div>
    </div>
</div>
<?php } ?>
