<?php
$this->renderPartial('application.views.cart.js') ;
//$time_sale_expired = mktime(0,0,0, date('m'),date('d'), date('Y'))-86400;
$time_sale_expired = time()-86400;
?>
<script>
/*
(function(){
var BH = window.BH || {};
BH.globals = BH.globals || {};
BH.globals.detailPageGlobals = BH.globals.detailPageGlobals || {};
BH.globals.detailPageGlobals.demoVideo = {};
})();
*/
function emailSubscribe(email)
{
	if(email=='')
	{
		$('#email-error-message').html('Vui lòng nhập địa chỉ email!');
		return false;
	}
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/emailSubscribe');?>',
		type: "POST",
		data:({
			email:email
		}),
		success: function(resp){
			if(resp==1)
			{
				alert('Đăng ký thành công!');
				$('#email-error-message').html('');
				$('#dealzone-email-input').val('');
				return false;
			}
			else
			{
				$('#email-error-message').html(resp);
				return false;
			}
		}
	});
}
</script>
<div class="t-main full-width clearfix">
    <div class="js-htmlbanner"></div>
    <div id="DealZonePage" class="new-page-width no-zoom">
        <div id="dealZone-app">
            <div>
                <section id="dealzone-banner-region">
                    <div id="dealzone-banner-view"></div>
                </section>
                <main id="DealZoneMain" class="page-content" data-selenium="dealzoneMain">
                    <div class="layout-content-container">
                        <div class="top-row-container new-page-width clearfix">
                            <div id="logo-timer-view" class="clearfix">
                                <div class="logo-container" data-selenium="logoCont"> <img src="<?php  echo Yii::app()->params['static_url']; ?>/images/Deal-Zone-Logo.png" alt="DealZone" data-selenium="logoImg"> </div>
                                <!-- /logo-container -->
                                <?php if(!empty($row_soc) && $row_soc['price_sale']!=0 && $row_soc['time_sale']!=0 && $row_soc['time_sale']>=time()) { ?>
                                <div class="timer-container">
                                    <section id="logo-timer-region" data-selenium="logoTimer">
                                        <div id="timer-view">
                                            <div class="timer-deal">
                                                <div class="top-content clearfix" data-selenium="topContent">
                                                    <div class="label"  style="width:28%;"> 
                                                    	<span class="top-copy">Thời gian KM<br>
                                                        </span>
                                                        <!--
                                                        <span class="end-day">Thời gian KM</span>
                                                        -->
													</div>
                                                    <div class="timer"><?php echo date('d/m/Y', $row_soc['time_sale']);?></div>
                                                    <!-- /timer -->
                                                </div>
                                                <!-- /top-content -->
                                                <!--
                                                <div class="bottom-content" style="">
                                                    <div class="remaining-percent" style="width: 17%;"></div>
                                                </div>
                                                -->
                                                <!-- /bottom-content -->
                                            </div>
                                        </div>
                                    </section>
                                    <!-- /logo-timer-region-->
                                </div>
                                <?php } ?>
                                <!-- /timer-container -->
                            </div>
                            <!-- /LogoTimer -->
                            <section id="sharing-region" data-selenium="sharingRegion">
                                <div id="social-media-sharing-view">
                                    <div class="pFaceBook social-link" data-selenium="shareFaceBook">
                                    	<div id="fb-root"></div>
										<script>(function(d, s, id) {
                                          var js, fjs = d.getElementsByTagName(s)[0];
                                          if (d.getElementById(id)) return;
                                          js = d.createElement(s); js.id = id;
                                          js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.7";
                                          fjs.parentNode.insertBefore(js, fjs);
                                        }(document, 'script', 'facebook-jssdk'));</script>
                                        <div class="fb-share-button" data-href="<?php echo $this->linkCanoncical;?>" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $this->linkCanoncical;?>%2F&amp;src=sdkpreparse">Share</a></div>
                                    </div>
                                    <div class="pTwitter social-link" data-selenium="shareTwitter">
                                        
                                    </div>
                                    <div class="pGooglePlus social-link" data-selenium="shareGooglePlus">
                                        
                                    </div>
                                    <div class="pPinterest social-link" data-selenium="sharePinterest"> </div>
                                </div>
                            </section>
                            <!-- /sharing-region -->
                        </div>
                        <!-- /top-row-container -->
                        <?php
                        if(!empty($row_soc))
						{ 
							$price_deal_show = $row_soc['price'];
							$price_deal = $row_soc['price_sale'];
							$saving = Common::formatNumber($price_deal_show-$price_deal);
							?>
							<div class="dealzone-container clearfix">
								<section id="product-info-layout-region" data-selenium="productInfo" class="new-page-width">
									<div>
										<section id="product-info-layout">
											<div class="layout-content-container">
												<div class="top-info-container clearfix">
													<section id="product-details-region" data-selenium="prodDetails">
														<div id="product-details-view">
															<h3 class="product-brand"><?php echo $row_soc['brand_title'];?></h3>
															<h2 class="product-short-description"><?php echo $row_soc['title'];?></h2>
                                                            <div class="product-rating-container">
																<a class="review-stars-link review-stars-small" href="javascript:" data-selenium="reviewStars">
                                                                <?php
																$arr_rating = LoadConfig::$arr_rating;
																$rating_name = isset($arr_rating[$row_soc['rating']]) ? $arr_rating[$row_soc['rating']].'' : 'A';
																$rating_img_name = $rating_name.'.png';
																?>
																<img style="width:81px; height:14px;" src="<?php  echo Yii::app()->params['static_url']; ?>/images/rating/<?php echo $rating_img_name;?>" />
                                                                </a>(<?php echo $rating_name;?>)

															</div>
															<div class="highlights-container" data-selenium="highlightCont"> <!--<span class="highlights-label">Top Highlights:</span>-->
                                                                <?php
																if($row_soc['status_new']==1)
																{
																	if(!empty($model_info)) echo $model_info['introtext']; else echo $row['introtext'];
																}
																if($row_soc['status_new']==0)
																{
																	if($row_soc['introtext']!='')
																		echo $row_soc['introtext'];
																	else if(!empty($model_info))
																		echo $model_info['introtext'];
																	else
																		echo '';
																}
																?>
															</div>
															<!-- /highlights-container -->
															<div class="view-product-details-link-container"> <a data-selenium="viewProductDetail" href="<?php echo Url::createUrl('bList/detail', array('camera_id'=>$row_soc['id'], 'alias'=>$row_soc['alias']));?>"><span>Chi tiết</span>
																<svg>
																	<use xlink:href="#right-arrow"></use>
																</svg>
																</a> </div>
															<!-- /view-product-details-link-container -->
														</div>
													</section>
													<!-- /product-details-region-->
													<div class="middle-regions-container">
														<section id="product-image-region" data-selenium="prodImgRegion">
															<div>
																<div id="product-image-view"><a href="<?php echo Url::createUrl('bList/detail', array('camera_id'=>$row_soc['id'], 'alias'=>$row_soc['alias']));?>"></a><a href="<?php echo Url::createUrl('bList/detail', array('camera_id'=>$row_soc['id'], 'alias'=>$row_soc['alias']));?>"><img style="width:500px; height:500px;" data-selenium="productImgView" src="<?php echo Common::getImage($row_soc['picture'], 'camera', '' ,'');?>" alt="<?php echo $row_soc['title'];?>" /></a>
																    <!--
																	<div class="enlarge-container">
																		<div class="enlargeMain" data-selenium="enlargeMain"><span class="copy">Zoom &amp; More Images</span></div>
																	</div>
                                                                    -->
																	<!-- /enlarge-container -->
																</div>
																<!-- /product-image-view -->
															</div>
														</section>
														<!-- /product-image-region -->
													</div>
													<!-- /middle-region-container -->
													<div id="product-right-info">
														<div class="regions-container">
															<section id="price-region" data-selenium="priceRegion">
																<div class="clearfix" id="product-price-view">
																	<div class="price-container clearfix">
																		<div class="deal-price" style="width:50%;">
																			<div class="price-row"> <span class="dollars"><?php if($row_soc['price_sale']!=0 && $row_soc['time_sale']!=0 && $row_soc['time_sale']>=$time_sale_expired) echo Common::formatNumber($price_deal); else echo Common::formatNumber($price_deal_show);?></span><sup class="cents">VND</sup> </div>
																			<!-- /price-row -->
																		</div>
																	</div>
                                                                    <?php if($row_soc['price_sale']!=0 && $row_soc['time_sale']!=0 && $row_soc['time_sale']>=time()) { ?>
                                                                    <div class="price-container clearfix">
																		<!-- /deal-price -->
																		<div class="right-prices">
																			<div class="save-amount"><span class="price-label">Giảm giá</span> <span class="dollars"><?php echo $saving;?></span><sup class="cents">VND</sup></div>
																			<!-- /save-amount -->
																			<div class="original-price"><span class="price-label">Giá</span> <span class="dollars"><?php echo Common::formatNumber($price_deal_show);?></span><sup class="cents">VND</sup></div>
																			<!-- /original-price -->
																		</div>
																		<!-- /right-prices -->
	
																	</div>
                                                                    <?php } ?>
																	<!-- /price-container -->
																</div>
															</section>
															<!-- /price-region -->
															<section id="cta-region" data-selenium="ctaRegion">
																<div>
																	<div id="product-cta-view" class="available">
																		<div class="quantity-container clearfix"> <span class="quantity-label">Số lượng</span> <span class="quantity-amount" data-max-quantity="2"> <span class="quantity">1</span> </span> </div>
																		<!-- /quantity-container -->
																		<div class="button-container">
																			<!-- <button id="atc-button" class="button active">Add to cart</button> -->
																			<a onclick="addCart(<?php echo $row_soc['id'];?>, 0, 1,<?php if($row_soc['price_sale']!=0 && $row_soc['time_sale']!=0 && $row_soc['time_sale']>=$time_sale_expired) echo $row_soc['price_sale']; else echo $row_soc['price'];?>);" href="javascript:" data-selenium="cartLink" id="atc-button" class="button active openInOnePopupLayer">Thêm vào giỏ hàng</a> </div>
																		<!-- /atc-coontainer -->
																	</div>
																	<!-- /product-cta-view -->
																</div>
															</section>
															
														</div>
														<!-- /regions-container -->
													</div>
													<!-- /product-right-info-container-->
												</div>
												
											</div>
											<!-- /layout-content-container -->
										</section>
										<!-- /product-info-layout -->
										<section id="product-images-overlay-region" data-selenium="prodImgOverlay">
											<div>
												<div id="product-images-overlay-view">
													<?php $this->renderPartial('_screenshot', array('detail'=>$row_soc, 'camera_pic'=>$camera_pic));?>
													<!--end #moreImages -->
												</div>
												<!-- /product-images-overlay-view -->
											</div>
										</section>
										<!-- /product-images-overlay-region -->
									</div>
								</section>
								<!-- /product-info-layout-region -->
							</div>
                        	<?php
                            } 
						?>
                        <!-- /dealzone-container -->
                        <section id="alternate-bg-container" data-selenium="altBgCont">
                            <div class="product-bundle-container new-region clearfix">
                                <section id="bundle-region" class="new-page-width" data-selenium="bundleRegion">
                                    <div class="slider clearfix" id="bundle-view"></div>
                                </section>
                                <!-- /future-deals-region -->
                            </div>
                            <!-- /product-bundle-container -->
                            <div class="future-deals-container new-region clearfix">
                                <section id="future-deals-region" class="new-page-width" data-selenium="futureDealsegion">
                                    <div></div>
                                </section>
                                <!-- /future-deals-region -->
                            </div>
                            <!-- /future-deals-container -->
                            <?php if(!empty($products_deal)) { ?>
                            <script>
							$(function(){
								showHideSlide('product-items-list','bxNext','bxPrev',<?php echo sizeof($products_deal);?>,6,'li',0);
							});
							</script>
                            <div class="past-deals-container new-region clearfix active new-bg">
                                <div class="past-deals-shadow-wrapper new-page-width">
                                    <section id="past-deals-region" class="new-page-width" data-selenium="pastDealRegion">
                                        <div>
                                            <div id="past-deals-view" class="clearfix">
                                                <h3>Sản phẩm giảm giá</h3>
                                                <div class="deals-container">
                                                    <div style="max-width: 1212px;" class="bx-wrapper">
                                                        <div style="width: 100%; overflow: hidden; position: relative; height: 206px;" class="bx-viewport">
                                                            <ul style="width: 2580%;" id="product-items-list" class="product-items-list clearfix" data-selenium="product-items-list">
                                                            <?php
															$k= 0;
															if($products_deal)
															foreach($products_deal as $row)
															{
																$src_img = Common::getImage($row['picture'], 'camera', '', 'small');
																$link_camera = Url::createUrl('bList/detail', array('camera_id'=>$row['id'], 'alias'=>$row['alias']));
																?>
																<li data-position="1" style="float: left; list-style: outside none none; position: relative; width: 202px;" class="product-item"><a data-selenium="pastDealLink" href="<?php echo $link_camera;?>" class="product-link">
                                                                    <div class="image-container"> <img data-selenium="pastDealImg" src="<?php echo $src_img;?>" alt="<?php echo $row['title'];?>"> </div>
                                                                    <!-- /image-container -->
                                                                    <div class="product-description multiline" title="<?php echo $row['title'];?>"> <?php echo $row['title'];?></div>
                                                                    <!-- /product-description -->
                                                                    <div class="previous-savings"> <?php if($row['price_sale']!=0 && $row['time_sale']!=0 && $row['time_sale']>=$time_sale_expired) echo Common::formatNumber($row['price_sale']); else echo Common::formatNumber($row['price']);?> VND</div>
                                                                    <!-- /previous-savings -->
                                                                    </a>
                                                                    <!-- /product-link -->
                                                                </li>
																<?php
																$k++;
															}
															?>
                                                                
                                                            </ul>
                                                        </div>
                                                        <div class="bx-controls bx-has-controls-direction">
                                                            <div class="bx-controls-direction"><a id="bxPrev" data-selenium="bxPrev" class="bx-prev" href="javascript:"></a><a id="bxNext" data-selenium="bxNext" class="bx-next" href="javascript:"></a></div>
                                                        </div>
                                                    </div>
                                                    <!-- /product-items-list -->
                                                </div>
                                                <!-- /deals-container -->
                                            </div>
                                            <!-- /past-deals-view -->
                                        </div>
                                    </section>
                                    <!-- /past-deals-region -->
                                    <div class="deal-zone-email-container new-region active clearfix">
                                        <section data-selenium="emailRegion" class="new-page-width" id="email-region">
                                            <div id="email-view"><a id="subscribe-dealzone" name="subscribe-dealzone"></a>
                                                <div class="email-content-container">
                                                    <div data-selenium="labelCont" class="label-container">Đăng ký email để nhận thông tin khuyến mại </div>
                                                    <!-- /label-container -->
                                                    <div data-selenium="inputCont" class="input-container">
                                                        <input type="text" id="dealzone-email-input" placeholder="Email Address" data-selenium="emailAddress" value="">
                                                    </div>
                                                    <!-- /input-container -->
                                                    <div class="subscribe-button-container">
                                                        <div onclick="emailSubscribe($('#dealzone-email-input').val());" id="subscribe-button"><span data-selenium="subscribe" class="button-label">Subscribe</span></div>
                                                    </div>
                                                    <!-- /subscribe-button-container -->
                                                </div>
                                                <!-- email-content-container -->
                                                <div class="error-message" id="email-error-message"></div>
                                            </div>
                                        </section>
                                        <!-- /email-region -->
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                            <!-- /past-deals-container -->
                            <div class="deal-zone-email-container new-region active clearfix new-bg">
                                <section id="view-more-deals-region" class="new-page-width clearfix" data-selenium="viewMoreDeals">
                                    <div id="view-more-deals-view">
                                        <div class="content-container clearfix">
                                            <div class="new-page-width"> <a data-selenium="getMoreDeals" href="<?php echo Url::createUrl('bList/dealList');?>" id="view-more-deals-button" class="button active">Xem thêm sản phẩm khuyến mại</a> </div>
                                        </div>
                                
                                    </div>
                                </section>
                            </div>
                            <!-- /deal-zone-email-container -->
                        </section>
                        <div class="clearfix"></div>
                    </div>
                    <!-- /layout-content-container -->
                </main>
                <!-- /DealZoneMain -->
                <a href="javascript:void(0)" id="zoom-link" style="display: none;" data-selenium="zoomLink"></a> </div>
        </div>
    </div>
</div>
<script>
	var BH = BH || {};
	BH.globals = BH.globals || {};			
	BH.constants = BH.constants || {};
	BH.constants.jsessionid = "";
	BH.constants.isLanguageSliderUser = false;	
	BH.constants.switchLanguageUrl = {
		english: 'https://www.bhphotovideo.com/bnh/controller/home?O=nav&A=switchLanguage&Q=&ul=E',
		spanish: 'https://www.bhphotovideo.com/spanish/changeLanguage'
	}
	BH.globals.currPageName = "dealZone.jsp";
	BH.globals.catalogId = "2";
	BH.sitespect={};
	BH.sitespect.abTest='QF-V01'.split(/\\.|:/);
	BH.sitespect.isAB=function(test){
		return BH.sitespect.abTest.indexOf(test)!==-1;
	}
</script>
<script type="text/javascript">
	//lazyLoad.setOdUrl("<?php  echo Yii::app()->params['static_url']; ?>/images/javascripts.js");
</script>