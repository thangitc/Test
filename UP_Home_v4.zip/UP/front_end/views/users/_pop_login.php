<div id="onePopupLayer" class="popupLayer ui-draggable iframeLayer openBhLayer" style="position: absolute; top: 15px; left: 485.5px; display: block; width: 380px;">
    <div class="popupLayerHeader" style="background-image: none;">
        <h2>Log Into Your Account</h2>
        <div class="close">Close</div>
    </div>
    <div class="popLayerMainContent" style="height: 397px;">
        <div style="" class="atw-layer twelve clearfix">
            <iframe id="loginframe" name="loginframe" class="login-layer" wmode="Opaque" data-src="https://www.bhphotovideo.com/find/loginIframe.jsp?referer=https%3A%2F%2Fwww.bhphotovideo.com%2F&amp;isLoginOnly=Y&amp;via=iframe" scrolling="no" allowtransparency="" src="https://www.bhphotovideo.com/find/loginIframe.jsp?referer=https%3A%2F%2Fwww.bhphotovideo.com%2F&amp;isLoginOnly=Y&amp;via=iframe" style="width: 378px; height: 407px;" width="378" height="407" frameborder="0"></iframe>
        </div>
        <style>
	   		@font-face {
				font-family: OpenSans;
				src: url('/FrameWork/fonts/OpenSans/OpenSans-Semibold.ttf') format('truetype'),
				     url('/FrameWork/fonts/OpenSans/OpenSans-Semibold.woff'),
				     url('/FrameWork/fonts/OpenSans/OpenSans-Semibold.eot');
				font-weight: 600;
				font-style: normal;
				-webkit-font-smoothing: antialiased;
			}
			@font-face {
				font-family: OpenSans;
				src: url('/FrameWork/fonts/OpenSans/OpenSans-Light.ttf') format('truetype'),
					 url('/FrameWork/fonts/OpenSans/OpenSans-Light.woff'),
					 url('/FrameWork/fonts/OpenSans/OpenSans-Light.eot');
				font-weight: 300;
				font-style: normal;
				-webkit-font-smoothing: antialiased;
			}
	   		.iframeLayer{
	   			background-color: #f7f7f7 !important;
	   		}
	   		.iframeLayer .popLayerMainContent{
	   			padding: 0px;
	   		}
	   		.iframeLayer .popupLayerHeader{
				border-bottom: none;
				text-align: center;
				background-color: #f7f7f7;
			}
			.iframeLayer.createAcct .popupLayerHeader{
				text-align: left;
				padding-left: 30px;
			}
			.iframeLayer .popupLayerHeader h2{
				font-weight: 300;
				font-size: 18px;
				margin-left:0px;
				color:#676767;
				position: relative;
				top: 24px;
			}
			.popupLayerHeader .close{
				top:6px;
				right:6px;
			}
			#loginframe{
				position: relative;
				top: -10px;
			}
			.blur{
				-webkit-filter: blur(3px);
			}
			.inlineScriptInjection{
				display: none;
			}
	   </style>
    </div>
    <div id="hiddenAjaxField" style="display:none;">
        <div id="ajaxForms"></div>
    </div>
    <div id="subLayers"></div>
</div>
