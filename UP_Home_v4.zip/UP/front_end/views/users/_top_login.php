
<div class="user login-account" data-selenium="userLogin" data-tab="js-topNavNotification">
	<?php
    	if(!isset($_SESSION['userid'])){
			$link_user = Url::createUrl('users/login');
		}else{
			$link_user = Url::createUrl('users/dashboard');
		}
	?>
	<a href="<?php echo $link_user;?>" rel="nofollow">
    	<span class="notification-count js-notification-count"></span>
        <svg class="user-icon left">
            <use xlink:href="#user"/>
        </svg>
    	<div id="js-login" class="js-login login left" data-selenium="login">
        	<span class="twelve">Hello</span> 
            <span class="twelve login-msg"><?php if(isset($this->users['fullname'])) echo $this->users['fullname'];?></span>
            <span class="twelve name js-name loggedInRel" data-selenium="loggedIn">
                <span id="js-loginname">
                	Sign In Login/Register
                    <svg>
                        <use xlink:href="#arrowDown"/>
                    </svg>
                </span>
			</span>
            <span class="myaccount-header">
                My Account
                <svg class="arrowDown">
                    <use xlink:href="#arrowDown"/>
                </svg>
            </span>
            
		</div>
    </a>
    <?php
	if(isset($_SESSION['userid'])){
		?>
        <a style="margin-left:36px; color:#06C" href="javascript:" onclick="logout();">Logout</a>
        <?php
	}
    ?> 
    
</div>
<script>
function logout()
{
	$.ajax({
		type: "POST",
		url: '<?php echo Url::createUrl('ajax/logout');?>',
		data: {
			
		},
		success: function(resp){
			window.location.href='<?php echo Url::createUrl('home/index');?>'
		}
	});
	return false;
};
</script>