<div class="t-main full-width clearfix">
    <div class="my-account-outer">
        <div class="new-page-width">            
            <?php echo $this->renderPartial('_left');?>
            <div class="col-2">
                <div class="content-block profile">
                    <div class="section expandable goToLogin accountDetails" data-selenium="accountDetail" id="accountDetailsOuter">
                        <div class="sHeader " data-lurl="accDetail" data-selenium="sHeaderAD">
                            <div class="column arrowContainer" data-selenium="ADArrow"><span class="arrow"></span></div>
                            <div class="column sTitleContainer">
                                <h2 class="sTitle">Thông tin cá nhân</h2>
                                <p class="sSubTitle">Cập nhật thông tin</p>
                            </div>
                            <p class="sInfo" data-selenium="adSinfo"></p>
                            <span class="clearB" style="display:block;"></span> </div>
                        <div class="sContent accountDetails" data-selenium="accountDetails">
                            <div class="editAccountDetails" data-selenium="editAccDetail">
                                <p class="loggedinWithSocialLogin" data-selenium="loggeninWithSocialLogin">Bạn đang đăng nhập với thông tin</p>
                                <h3>Thông tin đăng nhập:</h3>
                                <div data-selenium="adFieldName" class="ad_field " id="ad_field_name"> <span class="ad_label">Họ tên:</span><span class="ad_information"><?php echo $this->users['fullname']?></span><span class="ad_edit"><a href="<?php echo Url::createUrl('users/edit');?>">Edit</a></span>
                                    
                                </div>
                                <div data-selenium="adFieldSocialLOgin" class="ad_field socialLoginEmail " id="ad_field_email"> <span class="ad_label">Email Address:</span><span data-selenium="adInfoAD" class="ad_information"><?php echo $this->users['email']?></span><span class="fs11"></span>
                                    
                                </div>
                                <br>
                                
                                
                            </div>
                            <!--.editAccountDetails-->
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                
                <div class="content-block addresses sContent accountDetails">
                    <div class="section expandable goToLogin billShipSection" data-selenium="billShipSection">
                        <div class="sHeader" data-selenium="bsSheader">
                            <div class="column sTitleContainer" data-selenium="sTitlebs">
                                <h2 class="sTitle">Địa chỉ nhận hàng</h2>
                                <p class="sSubTitle">Thay đổi địa chỉ nhận hàng</p>
                            </div>
                        </div>
                        <div class="sContent" id="myAddresses" data-selenium="myAddress">
                        	<?php echo $this->users['address'];?>
                        </div>
                    </div>
                </div>
                
                
                <div class="content-block">
                    <div class="section expandable" data-selenium="giftCardSection" id="GiftCard">
                        <div class="sHeader" data-selenium="GCHead">
                            <div class="column arrowContainer"><span class="arrow"></span></div>
                            <div class="column sTitleContainer">
                                <h2 class="sTitle" data-selenium="GCTitle">Gift / Rewards Card Balance</h2>
                                <p class="sSubTitle" style="font-size:12px;">
                                	Thông tin điểm, thẻ, lịch sử giao dịch<br /><br />
                                    Số điểm sẽ dùng để quy đổi ra tiền khi thanh toán mua sản phẩm trên VJCamera<br /><br />
                                    1 điểm = 1.000 VNĐ
                                </p>
                            </div>
                            <p class="sInfo"></p>
                            <span class="clearB" style="display:block;"></span>
						</div>
                        <div class="sContent sContentOverride" data-selenium="GCContent">
                        <br />
                        GIF Card: <?php echo $this->users['account_number'];?><br />
                        Số điểm: <?php echo $this->users['point'];?>
                        </div>
                    </div>
                </div>
                
                
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <!-- .my-account-outer -->
    <!-- working on email  -->
</div>
