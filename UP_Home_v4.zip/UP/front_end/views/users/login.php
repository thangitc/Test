<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="ie lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="ie ie7"> <![endif]-->
<!--[if IE 8]>         <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>         <html class="ie ie9"> <![endif]-->
<html class="gecko win js">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="<?php  echo Yii::app()->params['static_url']; ?>/images/stylesheet_login.css">
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<title>Đăng nhập</title>
</head>
<body class="full-width twelve c2 loginForm " style="width:378px;">
    <div class="cont">
        <form id="form_login2" class="login clearfix cent-width">
            <label>
                <input id="email" name="emailAddress" placeholder="Địa chỉ Email" data-selenium="emailAddress" maxlength="50" class="fs14" type="text">
            </label>
            <label>
            <input id="password" name="password" data-selenium="password" placeholder="Mật khẩu" maxlength="15" class="fs14" value="" type="password">
            <!--<p class="forgotPass"><span class="passBtn " tabindex="0"><a href="<?php echo Url::createUrl('users/forgot');?>" class="c2 fs14 noUnderline" rel="nofollow" manual_cm_sp="Login-_-Login-_-ForgotPassword">quên mật khẩu?</a></span></p>-->
            </label>           
            <button onClick="login2();return false;" class="loginButton fs18">Đăng nhập</button>            
        </form>
       
        <div class="no-acc bold">
            <p> <a href="<?php echo Url::createUrl('users/register');?>" class="createAcct fs16 c5 noUnderline">Đăng ký tài khoản</a> </p>
        </div>
        <br>
        <span id="result_login2" style="font-size:14px;">
		</span>
            
    </div>

<script>
$(function(){
	$('#form_login2').keypress(function(e){
		switch(e.which)
		{
			case 13: 
				login2();
			break;
			default:
			break;
		}
	});
});
function login2()
{	
	var error='';
	var email=$('#email').val();
	var password=$('#password').val();
	if(email=='')
	{
		error+='Vui lòng nhập địa chỉ email!<br>';
		$('#email').focus();
	}
	if(password=='')
	{
		error+='Vui lòng nhập mật khẩu!<br>';
	}
	if(error!='')
	{
		$("#result_login2").css('color','red');
		$("#result_login2").html(error);
		return false;
	}

	$.ajax({
		type: "POST",
		url: '<?php echo Url::createUrl('ajax/login');?>',
		data: {
			email:email,
			password:password
		},
		success: function(resp){
			if(resp['status']==0)
			{
				$("#result_login2").html(resp['error']);
			}
			else
			{
				window.location.href='<?php echo Url::createUrl('home/index');?>';
				//history.go(-1);
			}
		}
	});
	return false;
};
</script>
</body>
</html>
