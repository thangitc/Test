<div class="t-main full-width clearfix">
    <div class="my-account-outer">
        <div class="new-page-width">
            <?php echo $this->renderPartial('_left');?>
            <div class="col-2">
                <div class="content-block">
                    <div class="section expandable" data-selenium="giftCardSection" id="GiftCard">
                        <div class="sHeader" data-selenium="GCHead">
                            <div class="column arrowContainer"><span class="arrow"></span></div>
                            <div class="column sTitleContainer">
                                <h2 class="sTitle" data-selenium="GCTitle">Gift / Rewards Card Balance</h2>
                                <p class="sSubTitle" style="font-size:12px;">
                                	Thông tin điểm, thẻ, lịch sử giao dịch<br /><br />
                                    Số điểm sẽ dùng để quy đổi ra tiền khi thanh toán mua sản phẩm trên VJCamera<br /><br />
                                    1 điểm = 1.000 VNĐ
                                </p>
                            </div>
                            <p class="sInfo"></p>
                            <span class="clearB" style="display:block;"></span>
						</div>
                        <div class="sContent sContentOverride" data-selenium="GCContent">
                        <br />
                        GIF Card: <?php echo $this->users['account_number'];?><br />
                        Số điểm: <?php echo $this->users['point'];?>
                        </div>
                    </div>
                </div>
                
                
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <!-- .my-account-outer -->
    <!-- working on email  -->
</div>
