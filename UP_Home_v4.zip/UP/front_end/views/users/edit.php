<div class="t-main full-width clearfix">
    <div class="my-account-outer">
        <div class="new-page-width">
            <?php echo $this->renderPartial('_left');?>
            <div class="col-2">
                <div class="content-block profile">
                    <div class="section expandable goToLogin accountDetails" data-selenium="accountDetail" id="accountDetailsOuter">
                        <div class="sHeader " data-lurl="accDetail" data-selenium="sHeaderAD">
                            <div class="column arrowContainer" data-selenium="ADArrow"><span class="arrow"></span></div>
                            <div class="column sTitleContainer">
                                <h2 class="sTitle">Thông tin cá nhân</h2>
                                <p class="sSubTitle">Cập nhật thông tin</p>
                            </div>
                            <p class="sInfo" data-selenium="adSinfo"></p>
                            <span class="clearB" style="display:block;"></span> </div>
                        <div class="sContent accountDetails" data-selenium="accountDetails">
                            <div class="editAccountDetails" data-selenium="editAccDetail">
                                <p class="loggedinWithSocialLogin" data-selenium="loggeninWithSocialLogin">Bạn đang đăng nhập với thông tin</p>
                                <h3>Thông tin đăng nhập:</h3>
                                <div data-selenium="adFieldName" class="ad_field " id="ad_field_name"> <span class="ad_label">Họ tên:</span><span class="ad_information"><?php echo $this->users['fullname'];?></span><span class="ad_edit"></span>
                                    
                                </div>
                                <div data-selenium="adFieldSocialLOgin" class="ad_field socialLoginEmail " id="ad_field_email"> <span class="ad_label">Email Address:</span><span data-selenium="adInfoAD" class="ad_information"><?php echo $this->users['email']?></span><span class="fs11"><a href="<?php echo Url::createUrl('users/edit');?>">&nbsp;</a></span>
                                    <form  class="ad_edit_form_inline socialEdit" style="display:block;">
                                        
                                        <div>
                                            <p class="fs12">Thay đổi thông tin cá nhân</p>
                                        </div>
                                        <p>
                                            <label>Họ tên:</label>
                                            <input name="fullname" id="fullname" type="text" value="<?php echo $this->users['fullname'];?>">
                                        </p>
                                        <p>
                                            <label>Avatar:</label>
                                            <div id="result_file1" style="margin-left:120px;">
                                            <?php
											if($this->users['avatar']!='')
											{
												$src = Common::getImage($this->users['avatar'], 'user', '');
												?>
												<img src="<?php echo $src;?>" alt="<?php echo $this->users['fullname'];?>" class="img-circle" width="100px">
												<?php
											}
											?>
                                            </div>
                                            <input type="hidden" id="filename1" name="filename1" readonly value="<?php echo $this->users['avatar'];?>"/>&nbsp;
											<div style="margin-left:120px;"><span id="spanButtonPlaceHolder" ></span></div>
                                        </p>
                                        <p>
                                            <label>Địa chỉ nhận hàng:</label>
                                            <input name="address" id="address" type="text" value="<?php echo $this->users['address'];?>">
                                        </p>
                                        <p>
                                            <label>Số điện thoại:</label>
                                            <input name="mobile_c" id="mobile_c" type="text" value="<?php echo $this->users['mobile'];?>">
                                        </p>
                                        
                                        <p>
                                            <label></label>
                                            <input class="button-style1" value="Cập nhật" type="button" onclick="changeUserInfo();">
                                        </p>
                                        <div id="result_info"></div>
                                    </form>
                                </div>
                                <br>
                                
                                <div data-selenium="adEditPassword" class="ad_edit_form ad_field_password"> <a class="close" data-selenium="close">close</a>
                                    <form>
                                        
                                        <h3>Thay đổi mật khẩu của bạn:</h3>
                                        <span>
                                        <label>Mật khẩu cũ:</label>
                                        <input name="old_pass" id="old_pass" type="password">
                                        </span> <span>
                                        <label>Mật khẩu mới:</label>
                                        <input name="new_pass" id="new_pass" placeholder="6-24 ký tự" oncopy="return false" class="filBlurred" type="password">
                                        </span> <span>
                                        <label>Nhập lại mật khẩu mới:</label>
                                        <input name="re_new_pass" id="re_new_pass" data-selenium="retypePassword" maxlength="15" oncopy="return false" type="password">
                                        </span>
                                        <input class="button-style1 passwordSubmit" value="Cập nhật" type="button" onclick="changePass();">
                                        <div id="result_change"></div>
                                    </form>
                                </div>
                                
                            </div>
                            <!--.editAccountDetails-->
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="content-block addresses sContent accountDetails">
                    <div class="section expandable goToLogin billShipSection" data-selenium="billShipSection">
                        <div class="sHeader" data-selenium="bsSheader">
                            <div class="column sTitleContainer" data-selenium="sTitlebs">
                                <h2 class="sTitle">Địa chỉ nhận hàng</h2>
                                <p class="sSubTitle">Thay đổi địa chỉ nhận hàng</p>
                            </div>
                        </div>
                        <div class="sContent" id="myAddresses" data-selenium="myAddress">
                        	<?php echo $this->users['address'];?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <!-- .my-account-outer -->
    <!-- working on email  -->
</div>
<link rel="stylesheet" href="<?php echo Yii::app()->params['upload_url'];?>/css/swfupload.css" type="text/css" />
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/swfupload.queue.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/fileprogress.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->params['upload_url'];?>/js/handlers_user.js"></script>
<script>
window.onload = function() {
	var configUploadData = {
		upload_url: upload_url_new+"upload_user.php"
		, create_date:'<?php $create_date=isset($detail["create_date"])? $detail["create_date"]:''; echo time();?>'
		, file_types: "*.jpg;*.jpeg;*.png;*.gif;*.doc;*.docx;*.xls;*.xlsx;*.pdf;*.swf"
		, file_upload_limit : 1
		, file_queue_limit : 1
		, debug : true
	};
	configUpload(configUploadData);
};

function changeUserInfo()
{
	var mobile = $('#mobile_c').val();
	var fullname = $('#fullname').val();
	var avatar = $('#filename1').val();
	var address = $('#address').val();
	var filename1 = $('#filename1').val();
	$.ajax({
		url: '<?php echo Url::createUrl('ajax/changeUserInfo');?>',
		type: "POST",
		data:({
			mobile:mobile,
			fullname:fullname,
			avatar:avatar,
			address:address,
			avatar:filename1
		}),
		success: function(resp){
			if(resp['status']==1)
			{
				alert("Cập nhật thông tin thành công!");
				location.reload();
			}
			else
			{
				$('#result_info').html(resp['error']);
			}
			
		}
	});
}

function changePass()
{	
	var error='';
	var old_pass=$('#old_pass').val();
	var new_pass=$('#new_pass').val();
	var re_new_pass=$('#re_new_pass').val();
	if(old_pass=='')
	{
		error+='Vui lòng nhập mật khẩu cũ!<br>';
	}
	if(new_pass=='')
	{
		error+='Vui lòng nhập mật khẩu mới!<br>';
	}
	if(re_new_pass=='')
	{
		error+='Vui lòng nhập lại mật khẩu mới!<br>';
	}
	if(error!='')
	{
		$("#result_change").css('color','red');
		$("#result_change").html(error);
		return false;
	}

	$.ajax({
		type: "POST",
		url: '<?php echo Url::createUrl('ajax/changePass');?>',
		data: {
			old_pass:old_pass,
			new_pass:new_pass,
			re_new_pass:re_new_pass
		},
		success: function(resp){
			if(resp['status']==0)
			{
				$("#result_change").html(resp['error']);
			}
			else
			{
				$("#result_change").html('Cập nhật thành công');
				location.reload();
				//history.go(-1);
			}
		}
	});
	return false;
};
</script>
