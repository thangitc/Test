<style>
.cartform {
    clear: both;
    display: inline;
    float: left;
    padding: 10px 0 20px 10px;
    width: 700px;	
	background:#fff none repeat scroll 0 0;
}
.cartrow {
    clear: both;
    float: left;
    padding: 3px 0 0;
    width: 650px;
}
.cartrow .text {
    color: #555;
    display: inline-block;
    float: left;
    font: bold 12px/25px Arial;
    padding: 5px 5px 0 0;
    text-align: right;
    width: 220px;
}
.cartrow .rightbl {
    float: left;
    line-height: 24px;
    margin: 0;
    padding: 0;
    vertical-align: middle;
    width: 320px;
}
.cartrow .input {
    color: #333 !important;
    float: left;
    font: 12px/35px Arial;
    margin: 0;
    padding: 0;
    text-align: left;
    width: 320px;
}
.cartrow .input input {
    background: #fff none repeat scroll 0 0;
    border: 1px solid #e5e5e5;
    margin: 0;
    padding: 0;
}
.cartrow .input textarea {
    background: #fff none repeat scroll 0 0;
    border: 1px solid #e5e5e5;
    height: 100px;
    margin: 0;
    overflow: auto;
    padding: 0;
    width: 300px;
}
</style>
<div id="customer_infor" style="padding-left:150px; height:480px;">
    <form class="cartform">
        <div class="cartrow">
            <div class="h30"><strong>Thông tin khách hàng</strong></div>
        </div>
        <div class="cartrow">
            <div class="text">Họ và tên :</div>
            <div class="input">
                <input name="billing_name" id="billing_name" type="text" style="width:300px; height:24px;" value="<?php if(isset($info_confirm['billing_name'])) echo $info_confirm['billing_name']; else if(isset($this->users['fullname'])) echo $this->users['fullname'];?>">
                <span class="redcolor">*</span> </div>
            <div class="clear"></div>
        </div>
        
        <div class="cartrow">
            <div class="text">Số điện thoại:</div>
            <div class="input">
                <input name="billing_mobile" id="billing_mobile" type="text" style="width:300px;height:24px;" value="<?php if(isset($info_confirm['billing_mobile'])) echo $info_confirm['billing_mobile']; else if(isset($this->users['mobile'])) echo $this->users['mobile'];?>">
                <span class="redcolor">*</span> </div>
            <div class="clear"></div>
        </div>
        <div class="cartrow">
            <div class="text">Email:</div>
            <div class="input">
                <input name="billing_email" id="billing_email" type="text" style="width:300px;height:24px;" value="<?php if(isset($info_confirm['billing_email'])) echo $info_confirm['billing_email']; else if(isset($this->users['email'])) echo $this->users['email'];?>">
            </div>
            <div class="clear"></div>
        </div>
        <div class="cartrow">
            <div class="text">Địa chỉ nhận hàng:</div>
            <div class="input">
                <input name="billing_address" id="billing_address" type="text" style="width:300px;height:24px;" value="<?php if(isset($info_confirm['billing_address'])) echo $info_confirm['billing_address']; else if(isset($this->users['address'])) echo $this->users['address'];?>">
                <span class="redcolor">*</span> </div>
            <div class="clear"></div>
        </div>
        
        <div class="cartrow">
            <div class="text">Ghi chú:</div>
            <div class="input" style="height:110px;">
                <textarea name="billing_note" id="billing_note"><?php if(isset($info_confirm['billing_note'])) echo $info_confirm['billing_note'];?></textarea>
            </div>
            <div class="clear"></div>
        </div>
        <div style="margin:20px 0 10px 225px; height:36px; clear:both; float:left;" align="left"> <a href="javascript:" class="updatebt" id="checkout" onclick="checkOutCart();">Đặt hàng</a> </div>
        <div class="cartrow">
            <div class="text"></div>
            <div class="input">
                <div style="color:red;" id="checkout_result"></div>
            </div>
        </div>
    </form>
</div>