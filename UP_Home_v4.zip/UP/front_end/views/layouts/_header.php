<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="ie lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="ie ie7"> <![endif]-->
<!--[if IE 8]>         <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>         <html class="ie ie9"> <![endif]-->
<html class="gecko win js">
<head>
<?php
require_once("_meta.php");
$controller_id = Yii::app()->controller->id;
$action_id = Yii::app()->controller->action->id;
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<?php if($controller_id =='access' || $controller_id =='bList'){?>
<body id="details-page" class="detailPage en" data-selenium="details-page">
<?php } else if($controller_id=='cart') { ?>
<body class="" id="cart-page">
<?php } else if($controller_id=='users') { ?>
<body id="myAccountPage" class="lggdIn" data-selenium="myAccountPage">
<?php } else { ?>
<body class="en">
<?php } ?>
<?php
	if($controller_id=='bList' && $action_id=='detail')
		$this->renderPartial('application.views.layouts._svg_detail');
	else
		$this->renderPartial('application.views.layouts._svg');
?>
<div class="t-content">
    <div class="t-head">
    	<?php $this->renderPartial('application.views.layouts._svg1') ;?>
        <?php $this->renderPartial('application.views.layouts._svg2') ;?>
        <header id="header" class="page-header js-header" data-selenium="page-header">
            <section class="header-top ">
                <div class="new-page-width"> <span class="left"> <span class="site-links" data-selenium="siteLinkS"> <span data-selenium="openSites" class="open-more-sites smbold current-reg"> Other VJCamera Corp.
                    <svg>
                        <use xlink:href="#arrowDown"></use>
                    </svg>
                    </span>
                    <ul data-selenium="siteLinks" class="js-siteLinksDropdown">
                        <li data-selenium="rootPage" class="active first"> <a class="site-link-nav" href="<?php echo Yii::app()->params['baseUrl']; ?>" data-selenium="rootPageLink">VJCamera.com site</a></li>
                        <li data-selenium="gsaPage" class=""> <a class="site-link-nav" href="http://vn-japan.com" data-selenium="gsaLink">vn-japan.com</a> </li>
                    </ul>
                    </span> </span> <a style="display:none;" data-selenium="exploraLink" class="explora-narrow left" href="<?php  echo Yii::app()->params['baseUrl']; ?>/explora">Read <span class="exploraSvgWrap">
                    <svg aria-label="Explora: News, Tips, and Reviews">
                        <use xlink:href="#explora-logo"></use>
                    </svg>
                    </span></a> <span class="right"> <span data-selenium="PhoneNum" id="js-phonenum" class="phone js-phone fs14 c4 smbold">Hotline:0965.505.515 / Mobile: 01688.888.400</span> <a name="Header-Help Center" target="_self" href="<?php echo Url::createUrl('home/contact');?>" data-selenium="helpLink" class="fs14 smbold">
                    <svg class="chat-icon">
                        <use xlink:href="#info-light"></use>
                    </svg>
                    Help</a> <a data-selenium="liveChatTop" name="Header-Live Chat" class="live-chat-link smbold fs14 right" href="https://www.facebook.com/vn.japan" >
                    <svg class="chat-icon">
                        <use xlink:href="#chat-square"></use>
                    </svg>
                    Live Chat </a> </span>
                    <div class="scene">
                        <div class="cube outer" data-selenium="cubeOut">
                            <!-- #1 -->
                            <div class="cube-face cube-face-front"><span class="tagline fs16"> <span class="bold">Everything For </span> <span class="homePageWlcm">Your Passion</span> </span> </div>
                            <!--
                            <div class="cube-face cube-face-back" data-selenium="cubeBack"><span class="smbold str-pickup upper">FREE NYC STORE PICKUP</span> Ready Within the Hour</div>
                            <div class="cube-face cube-face-bottom" data-selenium="cubeBot"><span class="smbold">&gt;&gt; Free Shipping</span> on most orders over $49</div>
                            -->
                        </div>
                    </div>
                    <br class="clearfix">
                </div>

            </section>
            <section class="header-main new-page-width">
                <svg class="mobile-menu left">
                    <use xlink:href="#menu"></use>
                </svg>
                <a class="logo left" href="<?php  echo Yii::app()->params['baseUrl']; ?>" data-selenium="rootPageLink" title="VJCamera">
                <img src="<?php  echo Yii::app()->params['static_url']; ?>/images/logo.png" />
                <!--
                <svg alt="VJCamera">
                    <use xlink:href="#bhlogo"></use>
                </svg>
                -->
                </a>
            
                <div class="search-dz" data-selenium="searchDZ" style="padding-left:250px;">
					<?php
					$row_soc = BList::getOneSoc();
                    if(!empty($row_soc))
                    {
						$link_soc = Url::createUrl('bList/deal');
						$src_soc = Common::getImage($row_soc['picture'], 'camera', '', 'small');
                        ?>
                        <div id="deal-zone-header" class="deal-zone-in-header js-deal-zone-in-header groupings-template has-deal-item"> <a href="<?php  echo $link_soc; ?>" class="deal-zone-link overlay-on-hover"> <span class="dz-deal-item">
                            <div class="logo-remaining">
                            	<span class="dz-tag"></span> <span class="dz-logo">DealZone</span> 
                                <?php if($row_soc['price_sale']!=0 && $row_soc['time_sale']!=0 && $row_soc['time_sale']>=(time()-86400)) { ?>
                                <span class="dz-remaining"> <span class="dz-countdown-container js-dz-countdown"> <span class="countdown-label">End:&nbsp;</span><span class="dz-countdown right"><span class="tcd tcd-no-days"><span class="tcd-days"><span class="tcd-days-count">&nbsp;</span><span class="tcd-days-days">days&nbsp;</span></span><span class="tcd-hours"><?php echo date('d', $row_soc['time_sale']);?></span><span class="tcd-minutes">/<?php echo date('m', $row_soc['time_sale']);?></span><span class="tcd-seconds">/<?php echo date('Y', $row_soc['time_sale']);?></span></span></span> </span>
                                <?php } ?>
                                </span> 
                            </div>
                            <div data-selenium="dzImg" class="dz-img-container js-dz-img-container"><img src="<?php echo $src_soc;?>"></div>
                            <?php if($row_soc['price_sale']!=0 && $row_soc['time_sale']!=0 && $row_soc['time_sale']>=(time()-86400)) { ?>
                            <div data-selenium="dzDiscount" class="dz-discount">
                                <!--<div class="dz-groupings-options"> 5 options from </div>-->
                                <div class="dz-discount-youpay"> <span class="dz-discount-amount"><?php echo Common::formatNumber($row_soc['price_sale']);?><sup>VND</sup></span> </div>
                                <div class="dz-savings"> <span class="label">Giảm: </span> <span class="dz-amount"><?php echo Common::formatNumber($row_soc['price']-$row_soc['price_sale']);?><sup>VND</sup></span> </div>
                                
                            </div>
                            <?php } else {?>
                            <div data-selenium="dzDiscount" class="dz-discount">
                                <!--<div class="dz-groupings-options"> 5 options from </div>-->
                                <div class="dz-discount-youpay"> <span class="dz-discount-amount"><?php echo Common::formatNumber($row_soc['price']);?><sup>VND</sup></span> </div>
                            </div>
    						<?php } ?>
                            </span> <span class="dz-placeholder" data-selenium="dzPlace"> <span class="dz-details-link c9 fs10 upper bold" data-selenium="dzDetalis"><span class="dz-logo">DealZone</span> Details &gt;</span> </span> </a>
                        </div>
                        <?php
                    }
                    ?>
                    
                    <?php
					if($controller_id=='access')
						$url_search = Url::createUrl('access/searchTop');
					else if($controller_id=='news')
						$url_search = Url::createUrl('news/search');
					else
						$url_search = Url::createUrl('bList/searchTop');
					$keyword_top = isset($_GET['keyword_top']) ? $_GET['keyword_top'] : '';	
                    ?>
                    <form class="search typeAhead" name="searchForm" method="get" target="_self" action="<?php echo $url_search; ?>">
                        <p class="searchContainer" data-selenium="searchContainer"> <span class="ui-helper-hidden-accessible" aria-live="polite" role="status"></span>
                            <input id="top-search-input" class="twelve js-placeholder js-topsearch ui-autocomplete-input" name="keyword_top" autocomplete="off" placeholder="Tìm kiếm" type="text" value="<?php echo $keyword_top;?>">
                            <input type="hidden" name="s" id="s">
                            <button type="submit" data-selenium="submitS">
                            <svg>
                                <use xlink:href="#search"></use>
                            </svg>
                            </button>
                        </p>
                    </form>
                </div>
               
                <!-- .seach-dz -->
                <div data-clicked="no" id="account-cart" data-selenium="accCart">
                	<?php $this->renderPartial('application.views.users._top_login') ;?>
                    <div class="header-cart topNavCart" data-tab="js-topNavCart" data-selenium="headerCart"  style="padding:0;"> <a class="cart js-cart fs16" href="javascript:" data-selenium="cartLink">
                        <svg class="cart-icon left">
                            <use xlink:href="#cart"></use>
                        </svg>
                        <div data-selenium="topNavCart" onMouseMove="$('.cart-alert-tab').addClass('js-show'); $('.mini-cart').show();">
                        	<?php if(isset($_SESSION['product_order']) && sizeof($_SESSION['product_order'])>0) { ?>
                        	<span class="js-items items fs12 bold"><?php echo sizeof($_SESSION['product_order']);?></span> <br>
                            <?php } ?>
                            <?php if(isset($_SESSION['product_order']) && sizeof($_SESSION['product_order'])>0) { ?>
                            <span class="myCart bold" style="line-height:21px;"><span>My Cart</span>
                            <?php } else {?>
                            <span class="myCart bold" style="line-height:39px;"><span>My Cart</span>
                            <?php } ?>
                            <svg class="arrowDown">
                                <use xlink:href="#arrowDown"></use>
                            </svg>
                            </span> </div>
                        </a>
					</div>
					<?php $this->renderPartial('application.views.layouts._cart_alert');?>
                </div>
                <!-- .account-cart -->
            </section>
            <script>
			$(function(){
				$('.nav-E li').mousemove(function(){
					$(this).addClass('active-menu');
				});
				$('.nav-E li').mouseleave(function(){
					$(this).removeClass('active-menu');
				});
			});
            </script>
            <section class="main-nav">
                <div class="nav elevn clearfix">
                    <ul class="nav-E capital">
                    <?php
					$cats = $this->array_category;
					$cat_menu = Cats::getCatMenu($cats);
					if($cat_menu)
					foreach($cat_menu as $row)
					{
						if($row['is_menu']==1)
						{
							if($row['cat_type']==1)
							{
								if($row['is_child_level3']==1)
									$link_cat = Url::createUrl('bList/index', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
								else
									$link_cat = Url::createUrl('bList/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));								
							}
							else if($row['cat_type']==2)
							{
								$link_cat = Url::createUrl('news/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
							}
							else
							{							
								if($row['is_child_level3']==1)
									$link_cat = Url::createUrl('access/index', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
								else
									$link_cat = Url::createUrl('access/cat', array('cat_id'=>$row['id'], 'alias'=>$row['alias']));
									
							}
							if($row['is_link']==1) $link_cat = $row['links'];
							?>
							<li class="first camera" data-selenium="camera">
                            	<a name="Top Nav-<?php echo $row['title'];?>" alt="<?php echo $row['title'];?>" href="<?php echo $link_cat;?>" title="<?php echo $row['title'];?>" target="_self" data-selenium="cameraLink"><span><?php echo $row['title'];?></span></a>							
								<section class="mega-menu-container default-template images-template">
									<div class="menu-background">
										<div class="new-page-width">
											<div class="top-images-container fade-content">
											<ul>
											<?php
											foreach($cats as $row2)
											{
												if($row2['parent_id']==$row['id'])
												{
													if($row2['cat_type']==1)
													{
														$link_cat2 = Url::createUrl('bList/cat', array('cat_id'=>$row2['id'], 'alias'=>$row2['alias']));
													}
													else if($row2['cat_type']==2)
													{
														$link_cat2 = Url::createUrl('news/cat', array('cat_id'=>$row2['id'], 'alias'=>$row2['alias']));
													}
													else
													{
														$link_cat2 = Url::createUrl('access/cat', array('cat_id'=>$row2['id'], 'alias'=>$row2['alias']));
													}
													if($row2['is_link']==1) $link_cat2 = $row2['links'];
													$src_img = Common::getImage($row2['picture'], 'cat', '', 'small');
													
													?>
													<li>
														<a href="<?php echo $link_cat2;?>" title="<?php echo $row2['title'];?>">
															<div class="category-image"> <img class="js-megaMenu-unveil" src="<?php echo $src_img;?>" data-src="<?php echo $src_img;?>" alt="<?php echo $row2['title'];?>" > </div>
															<div class="category-name-container"> <span class="category-name"><?php echo $row2['title'];?></span> </div>
														</a>
													</li>
													<?php
												}
											}
											?>
											</ul>
											</div>
											<!-- /top-images-container -->
										</div>
										<!-- /new-page-width -->
									</div>
									<!-- /menu-background -->
								</section>
							</li>
							<?php
						}
					}
					?>
                    	<!--
                        <li class="explora"><a data-selenium="exploraLink" href="<?php  echo Yii::app()->params['baseUrl']; ?>">
                        <svg aria-label="Explora: News, Tips, and Reviews">
                            <use xlink:href="#explora-logo"></use>
                        </svg>
                        </a>
                        </li>
                        -->
                    </ul>
                </div>
                <div style="height: 5184px; display: none;" class="mega-menu-overlay"></div>
            </section>
            
            <div id="searchautocomplete" class="sixteen old-typeahead">
                <div class="new-page-width clearfix">
                    <div id="searchautocompleteInner" class="">
                        <div class="search-suggestions-results search-result-section"></div>
                        <div class="recently-viewed-items search-result-section"></div>
                        <div class="recently-viewed-add search-result-section"></div>
                        <div class="search-suggested-items search-result-section"></div>
                        <div class="search-suggested-articles search-result-section"></div>
                    </div>
                </div>
                <ul style="display: none;" tabindex="0" id="ui-id-1" class="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all">
                </ul>
                <ul style="display: none;" tabindex="0" id="ui-id-2" class="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all">
                </ul>
                <ul style="display: none;" tabindex="0" id="ui-id-3" class="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all">
                </ul>
                <ul style="display: none;" tabindex="0" id="ui-id-4" class="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all">
                </ul>
            </div>
            <!--
            <div class="">
                <div class="site-notes clearfix js-note" style="overflow: visible;">
                    <div class="js-note-item site-note info clearfix">
                        <p> </p>
                        <div class="back-to-school-2016"> <a class="back-to-school-2016-link" href="<?php  echo Yii::app()->params['baseUrl']; ?>/c/promotion/12046/back-to-school.html" data-banner-name="back-to-school-2016">
                            <div class="inner-back-to-school-2016"></div>
                            </a> </div>
                        
                        <p></p>
                    </div>
                </div>
            </div>
            -->
        </header>
        
    </div>