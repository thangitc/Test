<script>
$(function(){
	$(window).click(function() {
		$('.mini-cart').hide();
	});		   
})

</script>
<?php
if(isset($_SESSION['product_order']) && sizeof($_SESSION['product_order'])>0)
	list($camera, $access, $colors) = Cart::getProductOrder();
else
{
	$camera = array();
	$access = array();
	$colors = array();
}
$total_p = sizeof($camera) + sizeof($access) + sizeof($colors);
?>
<?php if(isset($_SESSION['product_order']) && sizeof($_SESSION['product_order'])>0) { ?>
<div data-selenium="cartAlert" class="cart-alert-tab js-cart-alert-tab" style="top:43px;">
<div class="mini-cart" style="opacity:1; opacity: 1; margin-left: -125px; margin-right: 63px;">
    <div data-selenium="miniCart" class="miniCart js-miniCart js-cartIsEmpty">
        <div class="cartNotEmpty">
            <h3 data-selenium="mini-cart-Header" class="fs16 bold">Bạn có <?php echo $total_p;?> trong giỏ hàng </h3>
            <ul class="js-miniCartItems miniCartItems">
            <?php
			if($camera)
			foreach($camera as $row)
			{
				$src_img = Common::getImage($row['picture'], 'camera', '', 'small');
				$link_detail = Url::createUrl('bList/detail', array('camera_id'=>$row['id'], 'alias'=>$row['alias']));
				?>
                <li data-selenium="miniCartItem" class="js-miniCartItem">
                	<img src="<?php echo $src_img;?>" />
                    <div>
                        <div class="item-inner-div fs12"> <a href="<?php echo $link_detail;?>"><?php echo $row['title'];?></a> </div>
                        <span data-selenium="miniCartItemQty" class="fs12">Số lượng: <?php echo $row['qty'];?></span>
					</div>
                </li>
                <?php
			}			
			if($access)
			foreach($access as $row)
			{
				$src_img = Common::getImage($row['picture'], 'access', '', 'small');
				$link_detail = Url::createUrl('access/detail', array('access_id'=>$row['id'], 'alias'=>$row['alias']));
				?>
                <li data-selenium="miniCartItem" class="js-miniCartItem">
                	<img src="<?php echo $src_img;?>" />
                    <div>
                        <div class="item-inner-div fs12"> <a href="<?php echo $link_detail;?>"><?php echo $row['title'];?></a> </div>
                        <span data-selenium="miniCartItemQty" class="fs12">Số lượng: <?php echo $row['qty'];?></span> 
					</div>
                </li>
                <?php
			}
			if($colors)
			foreach($colors as $row)
			{
				$src_img = Common::getImage($row['picture'], 'access', '', 'small');
				$link_detail = Url::createUrl('access/detail', array('access_id'=>$row['access_id'], 'color_id'=>$row['id'], 'alias'=>$row['alias']));
				?>
                <li data-selenium="miniCartItem" class="js-miniCartItem">
                	<img src="<?php echo $src_img;?>" />
                    <div>
                        <div class="item-inner-div fs12"> <a href="<?php echo $link_detail;?>"><?php echo $row['title'];?> (<?php echo $row['color'];?>)</a> </div>
                        <span data-selenium="miniCartItemQty" class="fs12">Số lượng: <?php echo $row['qty'];?></span> </div>
                </li>
                <?php
			}
            ?>
            </ul>
            <a href="<?php echo Url::createUrl('cart/index');?>" class="miniCartLink"> Xem giỏ hàng và đặt hàng </a> 
		</div>
    </div>
    <!--Start Login-->
    <div class="account-notifications" data-selenium="accNot">
        <div class="notification-template">
            <section id="my-account-guest-notification" style="display: block">
                <div class="login-buttons" data-selenium="loginBut">
                    <p class="fs18 light">Log Into Your Account</p>
                    <a href="https://www.bhphotovideo.com/bnh/controller/home?O=product-detail.jsp&amp;A=getpage&amp;Q=Login.jsp&amp;isLoginOnly=Y" data-selenium="getPage" class="bold logInRel openInOnePopupLayer" rel="nofollow" data-bhlayercache="noLayerCache">
                    <button class="login">Log In</button>
                    </a> <a href="https://www.bhphotovideo.com/bnh/controller/home?O=product-detail.jsp&amp;A=getpage&amp;Q=Login.jsp&amp;isLoginOnly=Y&amp;action=createAcct" data-selenium="createAcc" class="bold logInRel openInOnePopupLayer" rel="noLayerCache">
                    <button class="create-account">Create a B&amp;H Account</button>
                    </a> </div>
                <div class="section gray"> <span class="notification-tab-link left"> <a secure="true" name="Header-My Account" target="_self" href="https://www.bhphotovideo.com/find/MyAccount.jsp" data-selenium="myAccountLink">
                    <svg>
                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#idcard"/>
                    </svg>
                    <span class="f10">My Account</span> </a> </span> <span class="notification-tab-link left"> <a href="https://www.bhphotovideo.com/bnh/controller/home?O=myAccount&amp;A=orderHistory&amp;Q=orderHistory" data-selenium="orderhistory">
                    <svg class="truck">
                        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#truck"/>
                    </svg>
                    <span class="f10">My Orders</span> </a> </span> 
                    <div class="clearfix"></div>
                </div>
            </section>
            
        </div>
    </div>

    <!--End Login-->
</div>
</div>
<?php } ?>
