<?php require_once("_header_news.php"); ?>
<?php echo $content; ?>
<?php require_once("_footer_news.php"); ?>