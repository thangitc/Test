<?php
$controller_id = Yii::app()->controller->id;
$action_id = Yii::app()->controller->action->id;
?>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta content="vi" http-equiv="content-language" />
<meta http-equiv="x-dns-prefetch-control" content="on">
<title><?php echo CHtml::encode($this->pageTitle); ?></title>
<meta name="keywords" content="<?php echo CHtml::encode($this->metaKeywords) ;?>,Shop Digital Cameras, 35MM Camera Equipment, Photography, Photo Printers,  Computers, Home Theater, Authorized Dealer Canon, Sony, Nikon, Apple, Olympus, Panasonic, Kodak, JBL"/>  
<meta name="description" content="<?php echo $this->metaDescription; ?>"/> 
<meta property="fb:admins" content=""/>
<meta property="fb:app_id" content=""/>
<meta property="og:type" content="article" />
<meta property="og:title" content="<?php echo CHtml::encode($this->pageTitle); ?>" />
<meta property="og:description" content="<?php echo $this->metaDescription; ?>" />
<?php if($this->srcImg!='') { ?>
<meta property="og:image" content="<?php echo $this->srcImg; ?>" />
<?php } ?>
<link href="<?php  echo Yii::app()->params['static_url']; ?>/images/news/css.css" rel="stylesheet" type="text/css">
<style type="text/css" media="all">
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/system.base.css");
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/system.menus.css");
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/system.messages.css");
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/system.theme.css");
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/bh.css");
</style>
<style type="text/css" media="all">
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/html.css");
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/style.css");
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/social.css");
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/login.css");
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/m4k.css");
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/canonLensPage.css");
</style>
<style type="text/css" media="print">
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/print.css");
</style>
<!--[if lt IE 10]>
<style type="text/css" media="all">
@import url("<?php  echo Yii::app()->params['static_url']; ?>/images/news/ie9_below.css");
</style>
<![endif]-->

<link href="<?php  echo Yii::app()->params['static_url']; ?>/images/icons.css" rel="stylesheet">
<link href="<?php  echo Yii::app()->params['static_url']; ?>/images/font-awesome.css" rel="stylesheet">
<link href="<?php  echo Yii::app()->params['static_url']; ?>/images/news/news.css" rel="stylesheet">
<?php
if($this->prevLink!='')
{
?>
<link rel="prev" href="<?php echo $this->prevLink;?>"/>
<?php
}
if($this->linkCanoncical!='')
{
?>
<link rel="canonical" href="<?php echo $this->linkCanoncical;?>" />
<?php
}
if($this->nextLink!='')
{
?>
<link rel="next" href="<?php echo $this->nextLink;?>"/>
<?php
}
?>
<?php
if($this->linkRss!='') echo $this->linkRss;
else
{
?>
<link rel="alternate" title="RSS - VJCamera"  href="<?php echo Url::createUrl('home/rss');?>" type="application/rss+xml" />    
<?php
}
?>
<meta name="robots" content="<?php echo $this->metaIndex;?>,<?php echo $this->metaFollow;?>" />
<meta name="revisit-after" content="1 days"/>
<meta name="placename" content="Việt Nam" />
<meta name="author" content="vjcamera.com" />
<meta name="owner" content="vjcamera.com" />
<meta name="generator" content="Cửa hàng bán buôn, bán lẻ hàng chính hãng Camera Canon, Fujifilm..." />
<meta name="distribution" content="Global" />
<meta name="COPYRIGHT" content="vjcamera.com - Cửa hàng bán buôn, bán lẻ hàng chính hãng Camera Canon, Fujifilm..." />
<link rel="index" title="Cửa hàng bán buôn, bán lẻ hàng chính hãng Camera Canon, Fujifilm..." href="http://vjcamera.com" />
<link href="<?php  echo Yii::app()->params['static_url']; ?>/images/appboy.css" rel="stylesheet">
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/js_v1.js"></script>
<script src="<?php  echo Yii::app()->params['static_url']; ?>/js/jquery.cookie.js"></script>