	<?php
	/*
	$controller_id = Yii::app()->controller->id;
	$action_id = Yii::app()->controller->action->id;
	if($controller_id=='cart')
	{
		?>
        <div id="tFooter">
        <footer class="footer OpenSans-600-normal  ">
        <?php
	}
	else
	{
		?>
        <div class="t-footer styled-async">
        <footer class="footer OpenSans-600-normal home-page-footer ">
        <?php
	}
	*/
	?>
    <div class="t-footer styled-async">
        <footer class="footer OpenSans-600-normal home-page-footer ">
            <div class="footer-inner footer-contact-info clearfix " data-selenium="footerContact">
                <div class="upper inlineBlock"> <span class="fs14 c37 OpenSans-300-normal">Hotline</span> <br>
                    <span class="fs30 c38 OpenSans-600-normal">0965.505.515</span> <br>
                    <span class="fs16 OpenSans-300-normal"><span class="c35 lower">or</span> Mobile: 01688.888.400 </span> </div>
                <div class="upper inlineBlock" data-selenium="footerContactUs">
                    <div class="fs26 OpenSans-600-normal clearfix"> <a class="c38 inlineBlock" href="<?php echo Url::createUrl('/home/contact');?>">
                        <svg style="width:35px;height:26px;" class="left">
                            <use xlink:href="#envelope-light"></use>
                        </svg>
                        <span class="left">Contact Us</span> </a> </div>
                </div>
                <div class="upper inlineBlock" data-selenium="footerLiveCh">
                    <div class="fs26 OpenSans-600-normal clearfix"> <a class="c38 inlineBlock" href="https://www.facebook.com/vn.japan">
                        <svg style="width:36px;height:31px;" class="left">
                            <use xlink:href="#chat-square"></use>
                        </svg>
                        <span class="c38 left">Live Chat</span> </a> </div>
                </div>
                <!--
                <div class="upper inlineBlock"> <span class="fs14 c37 OpenSans-300-normal">Hỗ trợ khách hàng, sửa chữa</span> <br>
                    <span class="fs30 c38 OpenSans-600-normal">01684.049.059</span> </div>
                    -->
            </div>
            <div class="footer-customer-informaion" data-selenium="footerCustI">
                <div class="footer-inner">
                    <div class="footer-customer-informaion-top clearfix">
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Hình ảnh</span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">Sản phẩm đã qua sử dụng luôn có hình ảnh thật, chụp chi tiết, được đánh giá chất lượng rõ ràng, mô tả khách quan</span> 
                            </a>
						</div>
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Bảo hành</span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">1 đổi 1 trong 15 ngày, cam kết BH nghiêm chỉnh 3-6-12 tháng, trong thời gian chờ BH, VJCamera cho khách hàng mượn miễn phí thiết bị tương đương.</span> 
                            </a>
						</div>
                        
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Hỗ trợ </span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">Tư vấn, giải đáp thắc mắc với khách hàng 1 cách khách quan, chính xác nhất, luôn đưa cho khách hàng các sự lựa chọn khác nhau.</span> 
                            </a>
						</div>
                        
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Order </span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">Những mặt hàng khó tìm ở VN, đặt hàng trực tiếp từ Nhật, VJCamera tư vấn khách hang địa điểm mua và luôn có mức giá tốt nhất.</span> 
                            </a>
						</div>
                        
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Free Shipping </span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">Free ship mọi miền tổ quốc với đơn hang giá trị >3tr, không giới hạn khoảng cách với khách hàng của VJCamera</span> 
                            </a>
						</div>
                        <div class="left">
                        	<a class="noUnderline c36" href="javascript:" target="_self"> <span class="fs24 OpenSans-700-normal c36 upper">Giá sốc </span><br>
                            <br>
                            <span class="fs14 OpenSans-300-normal">Hàng ngày sẽ có sản phẩm giảm giá sốc, cập nhật vào lúc 10h sáng, chỉ áp dụng trong thời gian ngắn</span> 
                            </a>
						</div>
                        
                    </div>
                    
                </div>
            </div>
            
            <div class="footer-company-info" data-selenium="footerCompInfo">
                <div class="footer-inner OpenSans-300-normal clearfix">
                    <div class="left company-copright"> <a class="c18 fs13 noUnderline copyright-link" name="Footer-NYSuperStore" data-selenium="nySuperStore" href="<?php  echo Yii::app()->params['baseUrl']; ?>" target="_self"> © 2015-2016 VJCamera -  Everything For Your Passion</a><br>
                    	
					</div>
                   
                    <div class="fs10 c35 left company-disclaimer" style="font-size:13px;">
                        Địa chỉ: <strong>11 Nguyễn Phong Sắc, Cầu Giấy, HN</strong> <br />
                        FB: <a href="http://www.facebook.com/vn.japan" target="_blank">www.facebook.com/vn.japan</a> <br />
                        Email: <a href="mailto:vnjapancamera@gmail.com">vnjapancamera@gmail.com</a> <br />
                        Tài khoản VCB: <br />
                        <strong style="color:#F90">0451000264640</strong><br />
                        <strong style="color:#F90">Nguyễn Thế Hùng, VCB Thành Công, HN</strong>
                    </div>
                </div>
            </div>
        </footer>
        
    </div>
    <!-- end t-footer -->
</div>
<!--<div class="scroll-down" style="left: 658px;"><svg><use xlink:href="#arrow-down-light"/></svg></div>-->
<!-- end t-content -->

<div style="right:30px; top:200px; position:fixed;width: 49px;">
<g:plusone size="tall" count="true"></g:plusone><br /><br />
    <iframe src="//www.facebook.com/plugins/like.php?href=https://www.facebook.com/vn.japan&amp;send=false&amp;layout=box_count&amp;width=450&amp;show_faces=true&amp;font&amp;colorscheme=light&amp;action=like&amp;height=90" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:90px;" allowTransparency="true"></iframe>
</div>

<!--Start of Zendesk Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
$.src="https://v2.zopim.com/?4tvu6xtgkv3U2N4ocTKYmpyIIwKyrcoR";z.t=+new Date;$.
type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
</script>
<!--End of Zendesk Chat Script-->

<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '1185177788213029'); // Insert your pixel ID here.
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1185177788213029&ev=PageView&noscript=1"
/></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->


<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-97836239-1', 'auto');
  ga('send', 'pageview');

</script>

</body>
</html>
<?php 
$ip = Common::getRealIpAddr();
$list_ip = array('113.23.11.168', '127.0.0.1');
if(in_array($ip,$list_ip)){
?>
<div class="showSql">                    
   <fieldset>
		<legend>Database</legend>
		<?php 
		echo Yii::app()->db->showSql;
		?>
	</fieldset>
	
	<?php echo "<b>Thời gian tải trang:</b> ".sprintf('%0.5f',Yii::getLogger()->getExecutionTime())." giây"; ?>
</div>
<?php }?>