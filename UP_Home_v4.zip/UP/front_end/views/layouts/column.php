<?php
	$pcontroller_id= Yii::app()->controller->id;
	$paction_id=Yii::app()->controller->action->id;
	if($pcontroller_id=='news')
		$this->beginContent('/layouts/main_news');
	else
		$this->beginContent('/layouts/main');
		
	echo $content;
	$this->endContent();
?>