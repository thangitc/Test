<div class="mPage">
    <?php $this->renderPartial("_menu");?>
    <!--
    <div id="breadcrumb"><h2 class="element-invisible">You are here</h2><div class="breadcrumb"><a href="<?php echo Yii::app()->params['baseUrl'];?>">VJCamera</a> » <a href="<?php echo Url::createUrl('news/cat',array('cat_id'=>$cat_info['id'], 'alias'=>$cat_info['alias']));?>"><?php echo $cat_info['title'];?></a></div></div>
    -->
    <div id="main-wrapper">
        <div id="main" class="clearfix">
            <div id="content" class="column clearfix">
                <div class="section"> <a id="main-content"></a>
                    <!---->
                    <div class="tabs edit-content"></div>
                    <div class="region region-content">
                        <div id="block-system-main" class="block block-system">
                            <div class="content">
                                <div id="node-28736" class="node node-article clearfix"> <span class="node_bc"><a href="<?php echo Yii::app()->params['baseUrl'];?>">VJCamera</a> / <a href="<?php echo Url::createUrl('news/cat',array('cat_id'=>$cat_info['id'], 'alias'=>$cat_info['alias']));?>"><?php echo $cat_info['title'];?></a></span>
                                    <h1 class="title" id="page-title"><?php echo $detail['title'];?></h1>
                                    <div class="submitted clearfix">
                                        <div class="authorName">By <a href="javascript:" rel="nofollow" class="username"><?php echo $detail['author_name'];?></a> | </div>
                                        <div class="createdOn"><?php echo date('d/m/Y',$detail['publish_date']);?></div>
                                    </div>
                                    <div class="content"> <span style="line-height: 16px;" class="a2a_kit a2a_target addtoany_list" id=""> <a class="comments-button" href="#comments"> <span class="bs-comment">&nbsp;</span> <span class="comment-count">4</span> </a> <a rel="nofollow" href="<?php echo Yii::app()->params['baseUrl'];?>/#twitter" target="_blank" class="a2a_button_twitter a2a_counter twitter-button"> <span class="bs-twitter">&nbsp;</span> </a> <a rel="nofollow" href="<?php echo Yii::app()->params['baseUrl'];?>/#facebook" target="_blank" class="a2a_button_facebook a2a_counter"> <span class="bs-facebook">&nbsp;</span> <span style="line-height: 16px; height: 16px; width: 32px; font-size: 8px; border-radius: 2px;" class="a2a_count"><span>80</span></span></a> <a rel="nofollow" target="_blank" class="a2a_button_email" href="<?php echo Yii::app()->params['baseUrl'];?>/#email"> <span class="bs-email">&nbsp;</span> </a> <a class="print-button" href="javascript:window.print()"> <span class="bs-print">&nbsp;</span> </a> <a href="https://www.addtoany.com/share#url=<?php echo $this->linkCanoncical;?>&amp;title=<?php echo $detail['title'];?>&amp;description=" class="a2a_dd"> <span class="bs-share">&nbsp;</span> </a> </span>
                                       
                                        <div class="field field-name-field-top-shot field-type-image field-label-hidden">
                                            <div class="field-items">
                                                <div class="field-item even"><center><img src="<?php echo Common::getImage($detail['picture'], 'news', '');?>" style="max-width:900px;" alt="<?php echo $detail['title'];?>"></center></div>
                                            </div>
                                        </div>
                                        <div class="field field-name-body field-type-text-with-summary field-label-hidden">
                                            <div class="field-items">
                                                <div class="field-item even">
                                                    <?php echo $detail['description'];?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="sidebar-inside" class="column sidebar">
                    <div class="section">
                        <div class="region region-sidebar-inside">
                            <div id="block-views-article-related-articles-block" class="block block-views">
                                <h2>Tin liên quan</h2>
                                <div class="content">
                                    <div class="view view-article-related-articles view-id-article_related_articles view-display-id-block three-ho view-dom-id-5505008fea850c7ecda87a63f0ef5e4d">
                                        <div class="view-content">
                                        <?php
										if($related && is_array($related))
										{
											$k=0;
											foreach($related as $row)
											{
												$k++;
												$class = '';
												if($k%2!=0) $class = 'views-row-odd';
												else $class = 'views-row-even';
												if(isset($row['related_id']) && $row['related_id']!=0)
												{
													if(isset($row['title']))
													{
														$src_img = Common::getImage($row['picture'], 'news', '', 'small');
														$link_detail = Url::createUrl('news/detail', array('news_id'=>$row['id'], 'alias'=>$row['alias']));
														$row_cat = isset($cats[$row['cat_id']]) ? $cats[$row['cat_id']] : array();
														$cat_title = isset($row_cat['title']) ? $row_cat['title'] : '';
														$link_cat = !empty($row_cat) ? Url::createUrl('news/cat',array('cat_id'=>$row_cat['id'], 'alias'=>$row_cat['alias'])) : '';
														?>                            
														<div class="views-row <?php echo $class;?> clearfix">
															<div class="views-field views-field-field-top-shot">
																<div class="field-content">
																	<div class="top-shot-280"><a href="<?php echo $link_detail;?>"><img src="<?php echo $src_img;?>"></a></div>
																</div>
															</div>
															<div class="views-field views-field-php"> <span class="field-content"><a href="<?php echo $link_cat;?>"><?php echo $cat_title;?></a></span> </div>
															<div class="views-field views-field-title"> <span class="field-content"><a href="<?php echo $link_detail;?>"><?php echo $row['title'];?></a></span> </div>
															<?php if($row['author_name']!='') {?>
															<div class="views-field views-field-field-display-author">
																<div class="field-content">by <a href="javascript:" rel="nofollow" class="username"><?php echo $row['author_name'];?></a></div>
															</div>
															<?php } ?>
															<div class="views-field views-field-field-updated-date">
																<div class="field-content"><span class="date-display-interval"><em class="placeholder"><?php echo date('d/m/Y', $row['publish_date']);?></em></span></div>
															</div>
														</div>
														<?php
													}
												}
												else if(isset($row['related_title']) && $row['related_title']!='')
												{
													$link_related=isset($row['related_link']) ? 'http://'.str_replace('http://','',$row['related_link']):'';
													?>
                                                    <div class="views-row <?php echo $class;?> clearfix">
                                                        <div class="views-field views-field-title"> <span class="field-content"><a href="<?php echo $link_related;?>"><?php echo $row['title'];?></a></span> </div>
                                                        
                                                    </div>
                                                    
													<?php
												}
											}
										}
										?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.section, /#sidebar-inside -->
                
            </div>
            <!-- /.section, /#content -->
            
            <!-- /.section, /#content-bottom -->
        </div>
    </div>
    <!-- /#main, /#main-wrapper -->
</div>